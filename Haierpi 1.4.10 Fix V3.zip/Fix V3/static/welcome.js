        if (localStorage.getItem("welcomeAnimationShown")) {
            document.getElementById("overlay").remove();
        } else {
	    const messages = [ "Goeie more ", "Miremengjes ", "እንደምን አደርክ ", "Good morning ", "صباح الخير ", "Sabahınız xeyir ", "Egun on ", "সুপ্রভাত ", "Добрай раніцы ", "မင်္ဂလာနံနက်ခင်းပါ ", "Dobro jutro ", "Добро утро ", "Maayong buntag ", "早上好 ", "早上好 ", "Dobro jutro ", "Dobré ráno ", "M'mawa wabwino ", "God morgen ", "Bonan matenon ", "Tere hommikust ", "Magandang umaga ", "Hyvää huomenta ", "Goeie moarn ", "Bos días ", "Καλημέρα ", "დილა მშვიდობისა ", "સુપ્રભાત ", "Good morning ", "Aloha kakahiaka ", "בוקר טוב ", "शुभ प्रभात ", "Buenos días ", "zoo thaum sawv ntxov ", "Goedemorgen ", "Ụtụtụ ọma ", "Selamat pagi ", "Maidin mhaith ", "Góðan daginn ", "おはようございます ", "Sugeng enjang ", "גוט מארגן ", "E kaaro ", "ಶುಭೋದಯ ", "Bon dia ", "Қайырлы таң ", "អរុណ​សួស្តី ", "Куттуу таң ", "좋은 아침 ", "Bonghjornu ", "Bonjou ", "Beyanî baş ", "ສະ​ບາຍ​ດີ​ຕອນ​ເຊົ້າ ", "Labas rytas ", "Gudde Moien ", "Bonum mane ", "Labrīt ", "Добро утро ", "സുപ്രഭാതം ", "Selamat Pagi ", "Salama ", "Bongu ", "ata pai ", "सुप्रभात ", "Сайн өглөө ", "शुभ - प्रभात ", "Guten Morgen ", "God morgen ", "Բարի առավոտ ", "سهار مو پخير ", "ਸ਼ੁਭ ਸਵੇਰ ", "صبح بخیر ", "<b class='text-secondary'>Dzień dobry<b>", "Bom Dia ", "Доброе утро ", "Buna dimineata ", "oa mai le ataeao ", "Добро јутро ", "Mangwanani akanaka ", "صبح جو سلام ", "Dobré ráno ", "Dobro jutro ", "Subax wanaagsan ", "Khotsong ", "Habari za asubuhi ", "Wilujeng énjing ", "සුභ උදෑසනක් ", "Madainn mhath ", "God morgon ", "Субҳ ба хайр ", "สวัสดี ", "காலை வணக்கம் ", "శుభోదయం ", "Günaydın ", "Доброго ранку ", "صبح بخیر ", "Xayrli tong ", "bore da ", "Jó reggelt ", "Chào buổi sáng ", "Buongiorno ", "Mholo ngalentsasa ", "Sawubona "];
        const textContainer = document.getElementById("text-container");

        messages.forEach((msg) => {
            let textElement = document.createElement("div");
            textElement.classList.add("welcome-text");
            textElement.innerHTML = msg;
            textElement.style.left = Math.random() * 90 + "vw";
            textElement.style.top = Math.random() * 90 + "vh";
            textElement.style.animationDelay = (Math.random() * 5100 + 520) + "ms";
            textContainer.appendChild(textElement);
        });

        setTimeout(() => {
            document.getElementById("final-text").style.opacity = "1";
        }, 8000);

        setTimeout(() => {
            const overlay = document.getElementById("overlay");
            overlay.style.animation = "fadeOut 2s forwards";
            setTimeout(() => {
                overlay.remove();
		    localStorage.setItem("welcomeAnimationShown", "true");
            }, 2000);
        }, 10000);
        setTimeout(() => {
            document.getElementById("final-text").style.animation = "zoomFadeOut 3s ease-in-out forwards";
        }, 8000);
	}

