def Get3way(payload):
    """
    Function for displaying if pump is on or off
    payload - register from 141 to 157
    :return:
    """
    if len(payload) == 16:
        threeway=''
        if payload[0] & 512:
            threeway='DHW'
        elif payload[0] & 1024:
            threeway = 'CH'
        return threeway
    else:
        return "Bad payload length"
