/*!
* Start Bootstrap - Simple Sidebar v6.0.6 (https://startbootstrap.com/template/simple-sidebar)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-simple-sidebar/blob/master/LICENSE)
*/
//
// Scripts
//

/*function translateElement(id) {
    const element = document.getElementById(id);
    if (!element) return;

    // Początkowe tłumaczenie po załadowaniu strony
    element.textContent = i18next.t(element.textContent.trim());

    // Obserwowanie zmian i dynamiczne tłumaczenie
    const observer = new MutationObserver(() => {
        element.textContent = i18next.t(element.textContent.trim());
    });

    observer.observe(element, { childList: true, subtree: true });
}*/

function translateElement(id) {
    const element = document.getElementById(id);
    if (!element) return;

    // Początkowe tłumaczenie po załadowaniu strony
    let lastValue = element.textContent.trim();
    element.textContent = i18next.t(lastValue);

    // Obserwowanie zmian i dynamiczne tłumaczenie
    const observer = new MutationObserver((mutationsList) => {
        for (let mutation of mutationsList) {
            if (mutation.type === "childList") {
                let newValue = element.textContent.trim();
                
                // Zapobieganie zapętleniu - zmieniamy tylko, gdy wartość się zmienia
                if (newValue !== lastValue) {
                    lastValue = newValue;

                    // Wyłączamy obserwator na czas aktualizacji tekstu
                    observer.disconnect();
                    element.textContent = i18next.t(newValue);
                    
                    // Włączamy ponownie po zmianie
                    observer.observe(element, { childList: true, subtree: true });
                }
            }
        }
    });

    observer.observe(element, { childList: true, subtree: true });
}




// i18n helper (works even before i18next is initialized)
function hpiT(key, fallback){
  try {
    if (window.i18next && typeof i18next.t === 'function') {
      const v = i18next.t(key);
      if (v && v !== key) return v;
    }
  } catch(e) {}
  return (fallback !== undefined) ? fallback : key;
}
window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }

});

/*        $(document).ready(function() {
    // Emoji flags are not available on some desktop setups; use SVG assets for consistency.
    const langFlags = {
        "en": "/static/flags/en.svg",
        "pl": "/static/flags/pl.svg",
        "nl": "/static/flags/nl.svg"
    };

            function getCookie(name) {
                let match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
                return match ? match[2] : null;
            }
            
            let browserLang = navigator.language || navigator.userLanguage;
		if (!["en", "pl", "nl"].includes(browserLang)) {
        browserLang = "en"; // Domyślny język
    }
            let savedLang = getCookie('i18next') || browserLang;
	    $("#current-lang-flag").text(langFlags[savedLang]);
            i18next
                .use(i18nextHttpBackend)
                .init({
                    lng: savedLang,
                    fallbackLng: 'en',
                    debug: false,
                    backend: {
                        loadPath: 'static/locales/{{lng}}/translation.json'
                    }
                }, function(err, t) {
                    jqueryI18next.init(i18next, $);
                    $('body').localize();
		    $('body').fadeIn(500); // Płynne pojawienie się strony
		    //$('body').show();
		    //refreshTooltips();
                });
		*/

$(document).ready(function() {
    // Emoji flags are not available on some desktop setups; use SVG assets for consistency.
    const langFlags = {
        "en": "/static/flags/en.svg",
        "pl": "/static/flags/pl.svg",
        "nl": "/static/flags/nl.svg"
    };

    function getLocalStorageItem(key) {
        return localStorage.getItem(key);
    }

    function setLocalStorageItem(key, value) {
        localStorage.setItem(key, value);
    }

    let browserLang = navigator.language || navigator.userLanguage;
    if (!["en", "pl", "nl"].includes(browserLang)) {
        browserLang = "en"; // Domyślny język
    }

    let savedLang = getLocalStorageItem('i18next') || browserLang;
    $("#current-lang-flag").attr("src", langFlags[savedLang]).attr("alt", savedLang.toUpperCase());

    i18next
        .use(i18nextHttpBackend)
        .init({
            lng: savedLang,
            fallbackLng: 'en',
            debug: false,
            backend: {
                loadPath: 'static/locales/{{lng}}/translation.json'
            }
        }, function(err, t) {
            jqueryI18next.init(i18next, $);
            $('body').localize();
            $('body').fadeIn(500);
        });

    // Obsługa zmiany języka i zapisywanie do localStorage
    $(".lang-selector").on("click", function() {
	    console.log($(this).data("lang"));
        let newLang = $(this).data("lang");
        setLocalStorageItem('i18next', newLang);
     //   location.reload(); // Przeładowanie, aby zastosować nowy język
    });
//});
function refreshTooltips() {
        // Usunięcie istniejących tooltipów
        $('[data-bs-toggle="tooltip"]').each(function() {
            let tooltipInstance = bootstrap.Tooltip.getInstance(this);
            if (tooltipInstance) {
                tooltipInstance.dispose(); // Usuń istniejący tooltip
            }
        });

        // Ponowna inicjalizacja tooltipów
        $('[data-bs-toggle="tooltip"]').tooltip();
    }
            function changeLanguage(lang) {
                i18next.changeLanguage(lang, function() {
                    $('body').localize();
                    document.cookie = "i18next=" + lang + "; path=/";
		    $("#current-lang-flag").attr("src", langFlags[lang]).attr("alt", lang.toUpperCase()); // Zmień flagę w menu
		    refreshTooltips();
                });
            }
            $('#lang-pl').click(function() { changeLanguage('pl'); });
            $('#lang-en').click(function() { changeLanguage('en'); });
	    $('#lang-nl').click(function() { changeLanguage('nl'); });
        });


/*!
 * Color mode toggler for Bootstrap's docs (https://getbootstrap.com/)
 * Copyright 2011-2024 The Bootstrap Authors
 * Licensed under the Creative Commons Attribution 3.0 Unported License.
 */

(() => {
  'use strict'
  const getStoredTheme = () => localStorage.getItem('theme')
  const setStoredTheme = theme => localStorage.setItem('theme', theme)

  const getPreferredTheme = () => {
    const storedTheme = getStoredTheme()
    if (storedTheme) {
      return storedTheme
    }

    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  }

  const setTheme = theme => {
    if (theme === 'auto') {
      document.documentElement.setAttribute('data-bs-theme', (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'))
    } else {
      document.documentElement.setAttribute('data-bs-theme', theme)
    }
  }

  setTheme(getPreferredTheme())

  const showActiveTheme = (theme, focus = false) => {
    const themeSwitcher = document.querySelector('#bd-theme')

    if (!themeSwitcher) {
      return
    }
    const themeSwitcherText = document.querySelector('#bd-theme-text')
    const activeThemeIcon = document.querySelector('.theme-icon-active use')
    const btnToActive = document.querySelector(`[data-bs-theme-value="${theme}"]`)
    const svgOfActiveBtn = btnToActive.querySelector('svg use').getAttribute('href')

    document.querySelectorAll('[data-bs-theme-value]').forEach(element => {
      element.classList.remove('active')
      element.setAttribute('aria-pressed', 'false')
    })
    btnToActive.classList.add('active')
    btnToActive.setAttribute('aria-pressed', 'true')
    activeThemeIcon.setAttribute('href', svgOfActiveBtn)
    const themeSwitcherLabel = `${themeSwitcherText.textContent} (${btnToActive.dataset.bsThemeValue})`
    themeSwitcher.setAttribute('aria-label', themeSwitcherLabel)
    if (focus) {
      themeSwitcher.focus()
    }
  }

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const storedTheme = getStoredTheme()
    if (storedTheme !== 'light' && storedTheme !== 'dark') {
      setTheme(getPreferredTheme())
    }
  })

  window.addEventListener('DOMContentLoaded', () => {
    showActiveTheme(getPreferredTheme())

    document.querySelectorAll('[data-bs-theme-value]')
      .forEach(toggle => {
        toggle.addEventListener('click', () => {
          const theme = toggle.getAttribute('data-bs-theme-value')
          setStoredTheme(theme)
          setTheme(theme)
          showActiveTheme(theme, true)
        })
      })
  })
})()
/*
const alertPlaceholder = document.getElementById('liveAlertPlaceholder');
const appendAlert = (message, type) => {
    const wrapper = document.createElement('div');
    const progressBarColors = {
        success: '#0f5132',
        danger: '#842029',
        warning: '#664d03',
        info: '#055160'
    };
    const progressBarColor = progressBarColors[type] || '#333';
        console.log(message);
    const translatedMessage = i18next.exists(String(message)) ? i18next.t(String(message)) : String(message);

    wrapper.innerHTML = [
        `<div class="alert alert-${type} alert-dismissible fade show" role="alert">`,
        `   <div>${translatedMessage}</div>`,
        '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
        `   <div id="liveAlertProgressBar" class="progress-bar-striped progress-bar-animated" style="height: 5px; background: ${progressBarColor}; width: 100%;"></div>`,
        '</div>'
    ].join('');

    alertPlaceholder.append(wrapper);

    let progressBar = wrapper.querySelector('#liveAlertProgressBar');
    let width = 100;
    let interval = setInterval(() => {
        width -= 5;
        progressBar.style.width = width + '%';
        if (width <= 0) {
            clearInterval(interval);
            wrapper.remove();
        }
    }, 100);
};
*/

const alertPlaceholder = document.getElementById('liveAlertPlaceholder');

const appendAlert = (message, type, timeout = 2000, addi = "") => {
    const wrapper = document.createElement('div');
    const progressBarColors = {
        success: '#0f5132',
        danger: '#842029',
        warning: '#664d03',
        info: '#055160'
    };
    const progressBarColor = progressBarColors[type] || '#333';

    console.log(message);
    const translatedMessage = i18next.exists(String(message)) ? i18next.t(String(message)) : String(message);
    if (type == "warning") {
	    timeout = 10000
    }
	else if (type == "danger") {
		timeout = 0
	}
    wrapper.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            <div>${translatedMessage} ${addi}</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            ${timeout > 0 ? `<div id="liveAlertProgressBar" class="progress-bar-striped progress-bar-animated" style="height: 5px; background: ${progressBarColor}; width: 100%;"></div>` : ''}
        </div>
    `;

    alertPlaceholder.append(wrapper);

    if (timeout > 0) {
    //    let progressBar = wrapper.querySelector('.progress-bar-striped');
        let progressBar = wrapper.querySelector('#liveAlertProgressBar');
        let width = 100;
        let interval = setInterval(() => {
            width -= 100 / (timeout / 100); // Skaluje animację zgodnie z czasem
            progressBar.style.width = width + '%';
            if (width <= 0) {
                clearInterval(interval);
                wrapper.remove();
            }
        }, 100);
    }
};


/* === Inline scripts extracted from templates (auto-generated) === */
(function(){
  'use strict';
  const PAGE = (document.body && document.body.dataset) ? (document.body.dataset.page || '') : '';
  function onReady(fn){
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  // From templates/base.html (block 1)
  onReady(function(){
    if(!(true)) return;
    try {
function updatecheck() {
            $.get('/updatecheck', function(data) {
                var text=data.update;
                var state="info";
                if(text.includes('Available,')) {

                    Swal.fire({
					title: text + hpiT('ui.update_prompt_suffix', '. Do you want install?'),
                        showCancelButton: true,
					    confirmButtonText: hpiT('ui.install', 'Install'),
                    }).then((result) => {
                        /* Read more about isConfirmed, isDenied below */
                        if (result.isConfirmed) {
                            $.get('/installupdate');
                            Swal.fire({
						    html: hpiT('ui.installing_update', 'Installing update, please wait...'),
                                icon: "info",
                                showCloseButton: false,
                                showConfirmButton: false,
                                timer: 60000,
                                timerProgressBar: true,
                                didOpen: () => {
                                    const b = Swal.getHtmlContainer().querySelector('b')
                                    timerInterval = setInterval(() => {
                                        b.textContent = Swal.getTimerLeft()
                                    }, 100)
                                },
                                willClose: () => {
                                    clearInterval(timerInterval)
                                    window.location.reload();
                                }
                            })

                        }
                    })
                } else {
                Swal.fire({
                    html: text,
                    icon: state,
                    showCloseButton: false,
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    didOpen: () => {
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                })
                }
            });
        }
        function restart() {
            Swal.fire({
				    title: hpiT('ui.restart_service_title', 'Restart HaierPi service'),
                showCancelButton: true,
				    confirmButtonText: hpiT('ui.yes', 'Yes'),
                }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {
                    $.get('/restart');
                    Swal.fire({
					    html: hpiT('ui.restarting_service', 'Restarting service, please wait...'),
                        icon: "info",
                        showCloseButton: false,
                        showConfirmButton: false,
                        timer: 30000,
                        timerProgressBar: true,
                        didOpen: () => {
                            const b = Swal.getHtmlContainer().querySelector('b')
                            timerInterval = setInterval(() => {
                                b.textContent = Swal.getTimerLeft()
                            }, 100)
                        },
                        willClose: () => {
                            clearInterval(timerInterval)
                            window.location.reload();
                        }
                    })
                }
            })
        }
    } catch(e) { console.error('HPI inline script error (base.html #1)', e); }
  });

  // From templates/base.html (block 2)
  onReady(function(){
    if(!(true)) return;
    try {
//                        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
//const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
    } catch(e) { console.error('HPI inline script error (base.html #2)', e); }
  });

  // From templates/charts.html (block 1)
  onReady(function(){
    if(!(PAGE === 'charts')) return;
    try {
$(document).ready(function() {
  let charts = [];

  // When user switches range (12h/48h/etc.), don't keep previous zoom/dateWindow.
  // Next render should show full newly loaded data extent.
  let resetZoomOnNextRender = false;

  function _fullDateWindowFromData(rows) {
    if (!Array.isArray(rows) || rows.length < 2) return null;
    const first = rows[0] && rows[0][0];
    const last = rows[rows.length - 1] && rows[rows.length - 1][0];
    const t0 = (first instanceof Date) ? first.getTime() : (typeof first === 'number' ? first : NaN);
    const t1 = (last instanceof Date) ? last.getTime() : (typeof last === 'number' ? last : NaN);
    if (!isFinite(t0) || !isFinite(t1) || t1 <= t0) return null;
    return [t0, t1];
  }

  // --- Persist series visibility (localStorage) ---
  const VIS_KEY = 'haierpi_charts_visibility_v1';

  function _loadVis() {
    try {
      const raw = localStorage.getItem(VIS_KEY);
      return raw ? (JSON.parse(raw) || {}) : {};
    } catch (e) {
      return {};
    }
  }

  function _saveVis(obj) {
    try { localStorage.setItem(VIS_KEY, JSON.stringify(obj || {})); }
    catch (e) { /* ignore */ }
  }

  let _vis = _loadVis();

  function _applyVisibilityToChart(seriesIdx, checked) {
    const chartObj = (Array.isArray(charts) ? charts : []).find(c => c.divId === 'chart0');
    if (chartObj && chartObj.chart && typeof chartObj.chart.setVisibility === 'function') {
      chartObj.chart.setVisibility(seriesIdx, checked);
    }
  }

  function _applyVisToUIAndConfig() {
    $('input[type="checkbox"][data-chart="0"]').each(function() {
      const id = this.id;
      if (!id || !_vis.hasOwnProperty(id)) return;

      const checked = !!_vis[id];
      this.checked = checked;

      const seriesIdx = parseInt(this.name, 10);
      if (!isNaN(seriesIdx) && chartsConfig && chartsConfig.chart0 && Array.isArray(chartsConfig.chart0.visibility)) {
        chartsConfig.chart0.visibility[seriesIdx] = checked;
      }
    });
  }

  function _onVisChange() {
    const seriesIdx = parseInt(this.name, 10);
    if (isNaN(seriesIdx)) return;

    const checked = !!this.checked;

    // keep config in sync so updateOptions() won't reset visibility
    if (chartsConfig && chartsConfig.chart0 && Array.isArray(chartsConfig.chart0.visibility)) {
      chartsConfig.chart0.visibility[seriesIdx] = checked;
    }

    // apply immediately if chart exists
    _applyVisibilityToChart(seriesIdx, checked);

    // persist
    if (this.id) {
      _vis[this.id] = checked;
      _saveVis(_vis);
    }
  }

  $('input[type="checkbox"][data-chart="0"]').on('change', _onVisChange);

  function _updateToggleAllButton() {
    const boxes = Array.from(document.querySelectorAll('input[type="checkbox"][data-chart="0"]'));
    const any = boxes.some(b => b.checked);
    const all = boxes.length ? boxes.every(b => b.checked) : false;
    const btn = document.getElementById('toggleAllSeries0');
    if (!btn) return;
    btn.textContent = all ? 'Odznacz' : 'Zaznacz';
    btn.disabled = !boxes.length;
    btn.dataset.state = all ? 'all' : (any ? 'some' : 'none');
  }

  document.getElementById('toggleAllSeries0')?.addEventListener('click', function() {
    const boxes = Array.from(document.querySelectorAll('input[type="checkbox"][data-chart="0"]'));
    if (!boxes.length) return;

    const allChecked = boxes.every(b => b.checked);
    const newState = !allChecked;

    boxes.forEach(cb => {
      if (cb.checked === newState) return;
      cb.checked = newState;

      const seriesIdx = parseInt(cb.name, 10);
      if (!isNaN(seriesIdx)) {
        if (chartsConfig && chartsConfig.chart0 && Array.isArray(chartsConfig.chart0.visibility)) {
          chartsConfig.chart0.visibility[seriesIdx] = newState;
        }
        _applyVisibilityToChart(seriesIdx, newState);
      }
      if (cb.id) _vis[cb.id] = newState;
    });

    _saveVis(_vis);
    _updateToggleAllButton();
  });

  $('input[type="checkbox"][data-chart="0"]').on('change', _updateToggleAllButton);

  // Pretty labels for series toggles + legend
  applyPrettyLabels();
  _updateToggleAllButton();


  // --- Data helpers ---
  function filterOutliers(data, threshold) {
    if (!Array.isArray(data)) return [];
    let lastValidValue = null;
    const filteredData = [];

    for (let i = 0; i < data.length; i++) {
      const currentValue = data[i];
      if (currentValue === null || currentValue === undefined || currentValue === "" || currentValue === "ERROR") {
        filteredData.push(null);
        continue;
      }
      const n = parseFloat(currentValue);
      if (isNaN(n)) {
        filteredData.push(null);
        continue;
      }

      if (lastValidValue !== null) {
        if (Math.abs(n - lastValidValue) > threshold) {
          filteredData.push(null);
        } else {
          filteredData.push(n);
          lastValidValue = n;
        }
      } else {
        filteredData.push(n);
        lastValidValue = n;
      }
    }
    return filteredData;
  }

  function normalizeFLimit(v) {
    if (v === null || v === undefined || v === '' || v === 'ERROR') return null;
    const n = parseFloat(v);
    if (isNaN(n)) return null;
    return n > 0 ? 10 : 0;
  }

  function isDefrostFromSignals(fact, fan1, fan2) {
    const f = parseFloat(fact);
    const a = parseFloat(fan1);
    const b = parseFloat(fan2);
    return isFinite(f) && f >= 30 && isFinite(a) && isFinite(b) && a === 0 && b === 0;
  }

  function mapThreewayValue(value, fact, fan1, fan2) {
    // Threeway valve chart must show ONLY two states: CH or DHW.
    // Everything else is mapped to a hidden OFF band value (216). The plotter will NOT draw OFF,
    // but keeping the value prevents Dygraphs from connecting CH/DHW segments through OFF/N.A.
    if (value === null || value === undefined) return 216;
    const v = String(value).trim().toUpperCase();
    if (v === 'CH') return 180;
    if (v === 'DHW') return 200;
    return 216; // OFF / N.A. / ERROR / anything else
  }


  // Defrost: separate series (turquoise)
  function mapDefrostValue(value, fact, fan1, fan2, threewayRaw) {
    // Defrost status is now a separate series (chartdefrost).
    // Map to a continuous ON/OFF band like in 1.4.5: 218 = ON, 205 = OFF.
    if (value === null || value === undefined) return null;
    const s = String(value).trim().toUpperCase();
    if (s === '' || s === 'N/A' || s === 'NA' || s === 'ERROR') return null;
    if (s === 'ON' || s === 'TRUE' || s === '1' || s === 'DEFROST') return 218;
    if (s === 'OFF' || s === 'FALSE' || s === '0') return 205;

    const n = parseFloat(value);
    if (!isFinite(n)) return null;
    return (n > 0) ? 218 : 205;
  }



  // Antifreeze: separate series (gold-brown)
  function mapAntifreezeValue(value, threewayRaw) {
    // Antifreeze status is now a separate series (chartantifreeze).
    // Map to a continuous ON/OFF band like in 1.4.5 (tuned): 268 = ON, 262 = OFF.
    if (value === null || value === undefined) return null;
    const s = String(value).trim().toUpperCase();
    if (s === '' || s === 'N/A' || s === 'NA' || s === 'ERROR') return null;
    if (s === 'ON' || s === 'TRUE' || s === '1' || s === 'ANTIFREEZE') return 268;
    if (s === 'OFF' || s === 'FALSE' || s === '0') return 262;

    const n = parseFloat(value);
    if (!isFinite(n)) return null;
    return (n > 0) ? 268 : 262;
  }



  function mapModeValue(quiet, eco, turbo) {
    const _toNum = (v) => {
      if (v === null || v === undefined || v === '' || v === 'ERROR') return 0;
      const n = parseFloat(v);
      return isNaN(n) ? 0 : n;
    };
    const q = _toNum(quiet);
    const e = _toNum(eco);
    const t = _toNum(turbo);

    if (q > 0) return 1;
    if (e > 0) return 2;
    if (t > 0) return 3;
    return 0;
  }

  function mapModeSeries(quietArr, ecoArr, turboArr) {
    const q = Array.isArray(quietArr) ? quietArr : [];
    const e = Array.isArray(ecoArr) ? ecoArr : [];
    const t = Array.isArray(turboArr) ? turboArr : [];
    const len = Math.max(q.length, e.length, t.length);
    const out = new Array(len);
    for (let i = 0; i < len; i++) {
      out[i] = mapModeValue(q[i], e[i], t[i]);
    }
    return out;
  }

  function modeCodeFromBand(y) {
    const v = Number(y);
    if (!isFinite(v)) return 0;
    // Now rysujemy jako: 210=Off, 220=Quiet, 230=Eco, 240=Turbo
    if (v >= 200) return Math.round((v - 210) / 10);
    return Math.round(v);
  }

  function modeColorForValue(y) {
    switch (modeCodeFromBand(y)) {
      case 1: return '#43A047'; // quiet
      case 2: return '#FB8C00'; // eco
      case 3: return '#E53935'; // turbo
      default: return '#9E9E9E'; // off/unknown
    }
  }


  function threewayGroupForValue(y) {
    const v = Number(y);
    if (!isFinite(v)) return 'OFF';
    const near = (a, b) => Math.abs(a - b) < 0.75;

    // Band levels (for Threeway valve only): CH=180, DHW=200
    if (near(v, 180)) return 'CH';
    if (near(v, 200)) return 'DHW';
    return 'OFF';
  }

  

  // Rank for "dominant" coloring on vertical edges (same idea as Mode):
  // CH < DHW < OTHER(turquoise group: Defrost/Off/N.A./ERR)
  function threewayRankFromBand(y) {
    const grp = threewayGroupForValue(y);
    // OFF < CH < DHW (so edges take CH/DHW color, not OFF)
    if (grp === 'OFF') return 0;
    if (grp === 'CH') return 1;
    return 2; // DHW
  }


function threewayColorForValue(y, baseColor) {
    const grp = threewayGroupForValue(y);
    // CH: light red; DHW: strong red; OFF: transparent/skip
    if (grp === 'CH') return '#E57373';
    if (grp === 'DHW') return '#E53935';
    return null; // OFF / unknown -> do not draw
  }

  // Custom step plotter: per-state color for Threeway valve (similar to Mode)
    // Threeway: step plot with per-state coloring, zoom-stable (same logic as Mode)
  function threewayStepPlotter(e) {
    const ctx = e.drawingContext;
    const points = e.points || [];
    if (points.length < 2) return;

    const lw = (e.dygraph && typeof e.dygraph.getOption === 'function')
      ? (e.dygraph.getOption('strokeWidth') || 2)
      : 2;

    const base = e.color || '#888';

    ctx.save();
    ctx.lineWidth = lw;
    ctx.lineJoin = 'miter';
    ctx.lineCap = 'butt';

    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      if (!p1 || !p2) continue;

      const y1 = Number(p1.yval);
      const y2 = Number(p2.yval);
      if (!isFinite(y1) || !isFinite(y2)) continue;

      // Horizontal segment: draw only for CH/DHW (OFF is skipped)
      const cH = threewayColorForValue(y1, base);
      if (cH) {
        ctx.strokeStyle = cH;
        ctx.beginPath();
        ctx.moveTo(p1.canvasx, p1.canvasy);
        ctx.lineTo(p2.canvasx, p1.canvasy);
        ctx.stroke();
      }

      // Vertical segment: use "dominant" state by rank, so edges take CH/DHW color (OFF is skipped)
      const r1 = threewayRankFromBand(y1);
      const r2 = threewayRankFromBand(y2);
      const yDom = (r1 >= r2) ? y1 : y2;

      const cV = threewayColorForValue(yDom, base);
      if (cV) {
        ctx.strokeStyle = cV;
        ctx.beginPath();
        ctx.moveTo(p2.canvasx, p1.canvasy);
        ctx.lineTo(p2.canvasx, p2.canvasy);
        ctx.stroke();
      }
    }

    ctx.restore();
  }

  // Generic status step plotter (draws ONLY when status is ON; OFF level is a hidden sentinel)
  function _nearBand(v, target) { return Math.abs(v - target) < 0.75; }

  function makeStatusStepPlotter(onLevel) {
    return function statusStepPlotter(e) {
      const ctx = e.drawingContext;
      const points = e.points || [];
      if (points.length < 2) return;

      const lw = (e.dygraph && typeof e.dygraph.getOption === 'function')
        ? (e.dygraph.getOption('strokeWidth') || 2)
        : 2;

      const base = e.color || '#888';

      ctx.save();
      ctx.lineWidth = lw;
      ctx.lineJoin = 'miter';
      ctx.lineCap = 'butt';
      ctx.strokeStyle = base;

      for (let i = 0; i < points.length - 1; i++) {
        const p1 = points[i];
        const p2 = points[i + 1];
        if (!p1 || !p2) continue;

        const y1 = Number(p1.yval);
        const y2 = Number(p2.yval);
        if (!isFinite(y1) || !isFinite(y2)) continue;

        const on1 = _nearBand(y1, onLevel);
        const on2 = _nearBand(y2, onLevel);

        // Horizontal segment: only when ON
        if (on1) {
          ctx.beginPath();
          ctx.moveTo(p1.canvasx, p1.canvasy);
          ctx.lineTo(p2.canvasx, p1.canvasy);
          ctx.stroke();
        }

        // Vertical segment at p2.x: draw only if transition involves ON
        if (on1 !== on2) {
          // Use onLevel for vertical endpoint to keep it crisp, but still draw the edge.
          const yFrom = p1.canvasy;
          const yTo = p2.canvasy;
          // If both ends are OFF, nothing to draw.
          if (on1 || on2) {
            ctx.beginPath();
            ctx.moveTo(p2.canvasx, yFrom);
            ctx.lineTo(p2.canvasx, yTo);
            ctx.stroke();
          }
        }
      }

      ctx.restore();
    };
  }


  // Niestandardowy plotter Dygraphs: "step plot" z kolorem zależnym od trybu
  function modeStepPlotter(e) {
    const ctx = e.drawingContext;
    const points = e.points || [];
    if (points.length < 2) return;

    const lw = (e.dygraph && typeof e.dygraph.getOption === 'function')
      ? (e.dygraph.getOption('strokeWidth') || 2)
      : 2;

    ctx.save();
    ctx.lineWidth = lw;
    ctx.lineJoin = 'miter';
    ctx.lineCap = 'butt';

    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      if (!p1 || !p2) continue;

      const y1 = Number(p1.yval);
      const y2 = Number(p2.yval);
      if (!isFinite(y1) || !isFinite(y2)) continue;

      // Horizontal segment: keep color of current state (y1)
      ctx.strokeStyle = modeColorForValue(y1);
      ctx.beginPath();
      ctx.moveTo(p1.canvasx, p1.canvasy);
      ctx.lineTo(p2.canvasx, p1.canvasy);
      ctx.stroke();

      // Vertical segment: use the "dominant" state by rank,
      // so both edges of a spike (A->B and B->A) keep the spike color.
      const r1 = modeCodeFromBand(y1);
      const r2 = modeCodeFromBand(y2);
      const yDom = (r1 >= r2) ? y1 : y2;

      ctx.strokeStyle = modeColorForValue(yDom);
      ctx.beginPath();
      ctx.moveTo(p2.canvasx, p1.canvasy);
      ctx.lineTo(p2.canvasx, p2.canvasy);
      ctx.stroke();
    }

    ctx.restore();
  }

  function numOrNull(v) {
    if (v === null || v === undefined || v === '' || v === 'ERROR') return null;
    const n = parseFloat(v);
    return isNaN(n) ? null : n;
  }

  function unitForLabel(label) {
    const l = String(label || '').trim();
    // Temperature-like series
    const temp = new Set([
      'tank','twi','two','thi','tho','ts','td','tao',
      'intemp','outtemp','hcurve','tdef','superheat','subcooling'
    ]);
    if (temp.has(l)) return '°C';
    if (l === 'humid') return '%';
    if (l === 'F set' || l === 'F act') return 'Hz';
    if (l === 'Ps set' || l === 'Ps act' || l === 'Pd set' || l === 'Pd act') return 'bar';
    if (l === 'Fan1' || l === 'Fan2') return 'rpm';
    if (l === 'EEV') return '°';
    return '';
  }

  function threewayLabelFromBand(y) {
    if (y == null || y === undefined) return "";
    const v = Number(y);
    if (!isFinite(v)) return "";
    const near = (a, b) => Math.abs(a - b) < 0.75;

    // Band levels (for Threeway valve only): CH=180, DHW=200
    if (near(v, 180)) return (window.i18next && i18next.exists('mode.ch')) ? i18next.t('mode.ch') : "CH";
    if (near(v, 200)) return (window.i18next && i18next.exists('mode.dhw')) ? i18next.t('mode.dhw') : "DHW";
    return "";
  }


  function formatLegendValue(label, y, yHTML) {
    if (y == null || y === undefined) return "";
    const n = Number(y);
    if (!isFinite(n)) return yHTML;

    if (label === "F limit") return (n >= 255) ? "ON" : "OFF";

    if (label === "Heater") return (n >= 170) ? "ON" : "OFF";

    if (label === "Threeway valve") {
      return threewayLabelFromBand(n);
    }

    if (label === "Defrost") {
      return (n >= 212) ? "ON" : "OFF";
    }

    if (label === "Antifreeze") {
      return (n >= 265) ? "ON" : "OFF";
    }

    if (label === "Mode") {
      const code = modeCodeFromBand(n);
      if (code === 1) return "Quiet";
      if (code === 2) return "Eco";
      if (code === 3) return "Turbo";
      return "Off";
    }

    const unit = unitForLabel(label);
    return unit ? (yHTML + ' <span class="legend-unit">' + unit + '</span>') : yHTML;
  }


  
  // Force Y-axis to show label "260" (and hide "250" label)
  function yTickerForce260(min, max, pixels, opts, dygraph, vals) {
    const ticks = Dygraph.numericTicks(min, max, pixels, opts, dygraph, vals)
      .filter(t => Math.abs(t.v - 250) > 1e-9);

    const v = 260;
    if (v >= min && v <= max) {
      const exists = ticks.some(t => Math.abs(t.v - v) < 1e-9);
      if (!exists) ticks.push({ v: v, label: String(v) });
    }

    ticks.sort((a, b) => a.v - b.v);
    return ticks;
  }

function prettyLabel(label) {
    if (!label) return label;
    // Keep common already-formatted labels as-is (e.g. "F set", "Ps act", "Fan1", "EEV")
    if (/[A-Z]/.test(label)) return label;
    // lowercase -> Capitalize first letter only
    return label.charAt(0).toUpperCase() + label.slice(1);
  }

  function applyPrettyLabels() {
    const panel = document.getElementById('seriesPanel');
    if (!panel) return;
    panel.querySelectorAll('label.btn[title]').forEach(lbl => {
      const raw = lbl.getAttribute('title') || lbl.textContent || '';
      lbl.textContent = prettyLabel(raw);
    });
  }

function customLegendFormatter(data) {
    // When not hovering: show nothing (keeps chart clean)
    if (!data || data.x == null) return "";
    let html = '<div class="dygraph-legend-inner">';
    html += '<div class="legend-x">' + data.xHTML + '</div>';
    const series = data.series || [];
    for (let i = 0; i < series.length; i++) {
      const s = series[i];
      if (!s || !s.isVisible) continue;
      let c = s.color || '#888';
      if (s.label === "Mode" && s.y != null) c = modeColorForValue(s.y);
      if (s.label === "Threeway valve" && s.y != null) {
        const cc = threewayColorForValue(s.y, s.color || c);
        if (cc) c = cc;
      }
      html += '<div class="legend-item">'
           +  '<span class="legend-swatch" style="background:' + c + '"></span>'
           +  '<span class="legend-label" style="color:' + c + '">' + prettyLabel(s.label) + '</span>'
           +  ': <span class="legend-val">' + formatLegendValue(s.label, s.y, s.yHTML) + '</span>'
           +  '</div>';
    }
    html += '</div>';
    return html;
  }

// --- Chart config (one big chart) ---
  let chartsConfig = {
    chart0: {
      labels: ["Date", "tank", "twi", "two", "thi", "tho", "ts", "td", "tao", "intemp", "humid", "outtemp", "hcurve", "tdef", "F set", "F act", "F limit", "Ps set", "Ps act", "Pd set", "Pd act", "superheat", "subcooling", "Threeway valve", "Defrost", "Antifreeze", "EEV", "Fan1", "Fan2", "Mode", "Heater"],
      // Defrost must be turquoise; Antifreeze should be gold-brown (takes the old defrost color).
      colors: ["#f44336", "#9fc5e8", "#d5a6bd", "#b6d7a8", "#6aa84f", "#FF6666", "#CC3333", "#bcbcbc", "#fc60ce", "#ccf5ff", "#999999", "#994d00", "#9cf4e1", "#a64dff", "#8c1aff", "#ffff00", "#33ffcc", "#00b386", "#ffbf80", "#ff9933", "#ff3385", "#0066ff", "#E53935", "#00CCCC", "#999966", "#a3c2c2", "#85adad", "#1a237e", "#9E9E9E", "#c40233"],
      visibility: [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
      valueRange: [-20, 270],
      axes: { y: { ticker: yTickerForce260 } },
      
      legendFormatter: customLegendFormatter,
data: [],
      series: {
        "Mode": { plotter: modeStepPlotter },
        "F limit": { stepPlot: true },
        "Threeway valve": { plotter: threewayStepPlotter },
        // Defrost/Antifreeze as continuous step lines (like in 1.4.5)
        "Defrost": { stepPlot: true },
        "Antifreeze": { stepPlot: true },
        "Heater": { stepPlot: true }
      },
      valueFormatter: function(value, opts, seriesName) {
        if (value === null || value === undefined || value === "") return "";
        const n = Number(value);
        if (!isFinite(n)) return "";

        if (seriesName === "F limit") {
          return (n >= 255) ? "ON" : "OFF"; // 260=ON, 250=OFF
        }

        if (seriesName === "Mode") {
          const code = modeCodeFromBand(n);
          if (code === 1) return "Quiet";
          if (code === 2) return "Eco";
          if (code === 3) return "Turbo";
          return "Off";
        }

        if (seriesName === "Threeway valve") {
          return threewayLabelFromBand(n);
        }

        if (seriesName === "Defrost") {
          return (n >= 212) ? "ON" : "OFF";
        }
        if (seriesName === "Antifreeze") {
          return (n >= 265) ? "ON" : "OFF";
        }

        // default numeric formatting
        return (Math.abs(n) < 10 && n % 1 !== 0) ? n.toFixed(2) : String(n);
      }
    }
  };

  // Apply persisted visibility to UI & config BEFORE first draw
  _applyVisToUIAndConfig();

  // ---- Date parsing/formatting helpers ----
  function _pad2(n) { return (n < 10 ? "0" : "") + n; }

  function parseChartDate(input) {
    const now = new Date();
    if (input === null || input === undefined || input === "") return new Date(NaN);

    const normalize = (d, kind) => {
      if (!(d instanceof Date) || isNaN(d.getTime())) return d;
      if (d.getFullYear() !== 2001) return d;

      if (kind === "timestamp") {
        return new Date(
          now.getFullYear(), now.getMonth(), now.getDate(),
          d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds()
        );
      }
      const dd = new Date(d.getTime());
      dd.setFullYear(now.getFullYear());
      return dd;
    };

    if (input instanceof Date) {
      return normalize(new Date(input.getTime()), "date");
    }

    const asString = (typeof input === "string") ? input.trim() : null;
    const isNumericString = asString && /^\d{10,13}$/.test(asString);

    if (typeof input === "number" || isNumericString) {
      let n = (typeof input === "number") ? input : parseInt(asString, 10);
      if (n > 1e9 && n < 1e11) n = n * 1000;
      return normalize(new Date(n), "timestamp");
    }

    const s = String(input).trim();
    if (!s) return new Date(NaN);

    // Try native parsing first
    const d1 = new Date(s);
    if (!isNaN(d1.getTime())) return normalize(d1, "string");

    // Fallback: YYYY/MM/DD HH:MM:SS
    const m = s.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
    if (m) {
      const yy = parseInt(m[1], 10);
      const mo = parseInt(m[2], 10) - 1;
      const dd = parseInt(m[3], 10);
      const hh = m[4] ? parseInt(m[4], 10) : 0;
      const mi = m[5] ? parseInt(m[5], 10) : 0;
      const ss = m[6] ? parseInt(m[6], 10) : 0;
      return new Date(yy, mo, dd, hh, mi, ss);
    }

    return new Date(NaN);
  }

  function defaultXValueFormatter(ms) {
    const d = parseChartDate(ms);
    if (!(d instanceof Date) || isNaN(d.getTime())) return "";
    return d.getFullYear() + "/" + _pad2(d.getMonth() + 1) + "/" + _pad2(d.getDate()) +
      " " + _pad2(d.getHours()) + ":" + _pad2(d.getMinutes()) + ":" + _pad2(d.getSeconds());
  }

  function formatChartData(rawData) {
    const { chartdate, ...series } = rawData;
    if (!chartdate || !Array.isArray(chartdate) || chartdate.length === 0) return [];

    const seriesArrays = Object.values(series);

    const mappedData = chartdate.map((date, index) => [
      parseChartDate(date),
      ...seriesArrays.map(arr => {
        if (!arr || !Array.isArray(arr)) return null;
        const value = arr[index];
        return (value === null || value === undefined || value === "" || value === "ERROR" || isNaN(value)) ? null : parseFloat(value);
      })
    ]);

    return mappedData.filter(row => {
      const d = row[0];
      return d instanceof Date && !isNaN(d.getTime());
    });
  }

  function generateOrUpdateDygraph(divId, config) {
    const _t = (key, fallback) => (window.i18next && i18next.exists(key)) ? i18next.t(key) : fallback;
    const _ylabel = _t('charts.ylabel', 'Value');
    const _xlabel = _t('charts.xlabel', 'Time');

    const axesMerged = Object.assign({}, (config.axes || {}));
    axesMerged.x = Object.assign({ valueFormatter: defaultXValueFormatter }, (axesMerged.x || {}));

    let existingChart = charts.find(c => c.divId === divId);
    if (existingChart) {
      // Preserve user zoom across *live* updates, unless the user just switched
      // the requested range (12h/48h/etc.). Then reset to full newly loaded extent.
      const _dw = (typeof existingChart.chart.getOption === 'function')
        ? existingChart.chart.getOption('dateWindow')
        : null;

      const upd = {
        file: config.data.slice(),
        labels: config.labels,
        colors: config.colors,
        visibility: config.visibility,
        axes: axesMerged,
        xValueFormatter: defaultXValueFormatter,
        series: config.series || {},
        valueFormatter: config.valueFormatter || undefined,
        legendFormatter: config.legendFormatter || undefined,
        valueRange: config.valueRange || undefined,
        interactionModel: haierpiInteractionModel
      };
      if (resetZoomOnNextRender) {
        const full = _fullDateWindowFromData(config.data);
        if (full) upd.dateWindow = full;
        resetZoomOnNextRender = false;
      } else if (Array.isArray(_dw) && _dw.length === 2 && isFinite(_dw[0]) && isFinite(_dw[1])) {
        upd.dateWindow = _dw;
      }

      existingChart.chart.updateOptions(upd);
      enableWheelZoom(existingChart.chart);
      enableLegendClamp(existingChart.chart);
    } else {
      const chart = new Dygraph(
        document.getElementById(divId),
        config.data,
        {
          legend: 'follow',
          visibility: config.visibility,
          labels: config.labels,
          ylabel: _ylabel,
          xlabel: _xlabel,
          connectSeparatedPoints: true,
          colors: config.colors,
          axes: axesMerged,
          xValueFormatter: defaultXValueFormatter,
          series: config.series || {},
          valueFormatter: config.valueFormatter || undefined,
          legendFormatter: config.legendFormatter || undefined,
          valueRange: config.valueRange || undefined,
          interactionModel: haierpiInteractionModel
        }
      );
      // Enable mouse-wheel zoom on X axis (time) when hovering the plot.
      enableWheelZoom(chart);
      enableLegendClamp(chart);
      charts.push({ divId, chart });
    }
  }

  // --- Mouse wheel zoom (X axis) ---
  // Scroll up = zoom in (shorter time span), scroll down = zoom out.
  // Note: we intentionally leave Ctrl+Wheel to the browser (page zoom).
  function enableWheelZoom(g) {
    if (!g || !g.graphDiv) return;
    if (g.__haierpiWheelZoomAttached) return;
    g.__haierpiWheelZoomAttached = true;

    const div = g.graphDiv;

    div.addEventListener('wheel', function(ev) {
      try {
        if (!g || typeof g.updateOptions !== 'function') return;
        if (ev.ctrlKey) return; // keep browser zoom

        const area = (typeof g.getArea === 'function') ? g.getArea() : null;
        if (!area || !isFinite(area.w) || area.w <= 0) return;

        const rect = div.getBoundingClientRect();
        const x = ev.clientX - rect.left;
        const y = ev.clientY - rect.top;

        // Only zoom when the pointer is over the plotting area
        if (x < area.x || x > (area.x + area.w)) return;
        if (y < area.y || y > (area.y + area.h)) return;

        ev.preventDefault();

        const range = (typeof g.xAxisRange === 'function') ? g.xAxisRange() : null;
        if (!range || !isFinite(range[0]) || !isFinite(range[1])) return;

        const extremes = (typeof g.xAxisExtremes === 'function') ? g.xAxisExtremes() : range;
        const minExt = extremes[0], maxExt = extremes[1];
        const fullSpan = maxExt - minExt;
        if (!isFinite(fullSpan) || fullSpan <= 0) return;

        const pct = Math.min(1, Math.max(0, (x - area.x) / area.w));
        const minX = range[0], maxX = range[1];
        const curSpan = maxX - minX;
        if (!isFinite(curSpan) || curSpan <= 0) return;

        // Smooth-ish zoom factor
        const direction = (ev.deltaY < 0) ? -1 : 1;
        const factor = direction < 0 ? 0.85 : 1.18;

        // Clamp span (min 2 minutes, max full data range)
        const minSpan = 2 * 60 * 1000;
        let newSpan = curSpan * factor;
        newSpan = Math.max(minSpan, Math.min(fullSpan, newSpan));

        const center = minX + pct * curSpan;
        let newMin = center - pct * newSpan;
        let newMax = newMin + newSpan;

        // Clamp to data extremes
        if (newMin < minExt) {
          newMin = minExt;
          newMax = newMin + newSpan;
        }
        if (newMax > maxExt) {
          newMax = maxExt;
          newMin = newMax - newSpan;
        }

        g.updateOptions({ dateWindow: [newMin, newMax] });
      } catch (e) {
        // ignore wheel zoom errors
      }
    }, { passive: false });
  }

  // --- Keep "follow" legend inside the chart area ---
  function enableLegendClamp(g) {
    if (!g || !g.graphDiv) return;
    if (g.__haierpiLegendClampAttached) return;
    g.__haierpiLegendClampAttached = true;

    const div = g.graphDiv;

    function clampLegend() {
      const legend = div.querySelector('.dygraph-legend');
      if (!legend) return;

      const pad = 6;

      // If legend is very tall (many series), make it scrollable.
      legend.style.maxHeight = Math.max(80, div.clientHeight - pad * 2) + 'px';
      legend.style.overflowY = 'auto';
      legend.style.overflowX = 'hidden';
      legend.style.right = '';
      legend.style.bottom = '';

      let left = parseFloat(legend.style.left);
      let top = parseFloat(legend.style.top);
      if (!isFinite(left)) left = pad;
      if (!isFinite(top)) top = pad;

      const lw = legend.offsetWidth;
      const lh = legend.offsetHeight;

      const maxLeft = div.clientWidth - lw - pad;
      const maxTop = div.clientHeight - lh - pad;

      const clampedLeft = Math.min(Math.max(left, pad), Math.max(pad, maxLeft));
      const clampedTop = Math.min(Math.max(top, pad), Math.max(pad, maxTop));

      legend.style.left = clampedLeft + 'px';
      legend.style.top = clampedTop + 'px';
    }

    div.addEventListener('mousemove', () => requestAnimationFrame(clampLegend), { passive: true });
    window.addEventListener('resize', () => requestAnimationFrame(clampLegend));
  }




  // --- Drag pan (instead of box-zoom) ---
  // Default: click-drag pans left/right. Hold Shift to use the original box-zoom selection.
  const haierpiInteractionModel = (function() {
    const d = Dygraph.defaultInteractionModel || (Dygraph.Interaction && Dygraph.Interaction.defaultModel) || {};
    const model = Object.assign({}, d);

    function _inPlotArea(ev, g) {
      const area = (typeof g.getArea === 'function') ? g.getArea() : null;
      if (!area || !g.graphDiv) return null;
      const rect = g.graphDiv.getBoundingClientRect();
      const x = ev.clientX - rect.left;
      const y = ev.clientY - rect.top;
      if (x < area.x || x > (area.x + area.w)) return null;
      if (y < area.y || y > (area.y + area.h)) return null;
      return { area, rect, x, y };
    }

    function _clampDateWindow(g, dw) {
      const ex = (typeof g.xAxisExtremes === 'function') ? g.xAxisExtremes() : dw;
      const minExt = ex[0], maxExt = ex[1];
      let a = dw[0], b = dw[1];
      const span = b - a;
      if (!isFinite(span) || span <= 0) return dw;

      if (a < minExt) { a = minExt; b = a + span; }
      if (b > maxExt) { b = maxExt; a = b - span; }
      if (a < minExt) a = minExt;
      if (b > maxExt) b = maxExt;
      return [a, b];
    }

    model.mousedown = function(ev, g, ctx) {
      // Left button only; Shift keeps legacy drag-zoom.
      if (ev.button !== 0 || ev.shiftKey) {
        if (d.mousedown) return d.mousedown(ev, g, ctx);
        return;
      }

      const hit = _inPlotArea(ev, g);
      if (!hit) {
        if (d.mousedown) return d.mousedown(ev, g, ctx);
        return;
      }

      ev.preventDefault();

      const range = (typeof g.xAxisRange === 'function') ? g.xAxisRange() : null;
      const dw = (typeof g.getOption === 'function') ? g.getOption('dateWindow') : null;
      const startDW = (Array.isArray(dw) && dw.length === 2 && isFinite(dw[0]) && isFinite(dw[1])) ? dw : range;
      if (!startDW || !isFinite(startDW[0]) || !isFinite(startDW[1])) return;

      ctx.isPanning = true;
      ctx.panStartX = ev.clientX;
      ctx.panStartDW = [startDW[0], startDW[1]];
      ctx.panAreaW = hit.area.w;

      if (g.graphDiv) g.graphDiv.style.cursor = 'grabbing';
    };

    model.mousemove = function(ev, g, ctx) {
      if (ctx && ctx.isPanning) {
        ev.preventDefault();

        const dx = ev.clientX - ctx.panStartX;
        const span = ctx.panStartDW[1] - ctx.panStartDW[0];
        if (!isFinite(span) || span <= 0 || !isFinite(ctx.panAreaW) || ctx.panAreaW <= 0) return;

        const dt = -dx * (span / ctx.panAreaW);
        let newDW = [ctx.panStartDW[0] + dt, ctx.panStartDW[1] + dt];
        newDW = _clampDateWindow(g, newDW);

        g.updateOptions({ dateWindow: newDW });
        return;
      }

      if (d.mousemove) return d.mousemove(ev, g, ctx);
    };

    model.mouseup = function(ev, g, ctx) {
      if (ctx && ctx.isPanning) {
        ctx.isPanning = false;
        if (g.graphDiv) g.graphDiv.style.cursor = '';
        return;
      }
      if (d.mouseup) return d.mouseup(ev, g, ctx);
    };

    // Keep default dblclick/click behaviour (often resets zoom)
    if (d.dblclick) model.dblclick = d.dblclick;
    if (d.click) model.click = d.click;

    return model;
  })();


  // ---- Socket handlers ----
  let socket = null;
  function disableLiveUI() {
    $("#btnradio4").prop("disabled", true);
    $('label[for="btnradio4"]').addClass("disabled");
  }
  if (typeof io === "undefined") {
    console.error("Socket.IO client not loaded (io is undefined).");
    disableLiveUI();
    $("#chart0").prepend('<div class="alert alert-danger mb-2">Brak biblioteki Socket.IO (io undefined). Sprawdź dostęp do internetu lub /socket.io/socket.io.js.</div>');
  } else {
    socket = io();

  socket.on("connect", () => {
    console.log("Połączono z serwerem Socket.io");
    const v = $("input[name='btnradio']:checked").val();
    if (v) socket.emit('client', { charts: v });
  });

socket.on('charts', function(data) {
    const chartdate = data['chartdate'] || [];

    const charttank = data['charttank'] || [];
    const charttwi = data['charttwi'] || [];
    const charttwo = data['charttwo'] || [];
    const chartthi = data['chartthi'] || [];
    const charttho = data['charttho'] || [];
    const chartts = data['chartts'] || [];
    const charttd = data['charttd'] || [];
    const charttao = data['charttao'] || [];

    const chartintemp = filterOutliers(data['chartintemp'] || [], 50);
    const charthumid = filterOutliers(data['charthumid'] || [], 50);
    const chartouttemp = filterOutliers(data['chartouttemp'] || [], 50);

    const charthcurve = data['charthcurve'] || [];
    const charttdef = data['charttdef'] || [];
    const chartheater = data['chartheater'] || [];

    const chartfset = data['chartfset'] || [];
    const chartfact = data['chartfact'] || [];
    const chartflimiton = (data['chartflimiton'] || []).map(normalizeFLimit);
    const chartflimitBand = chartflimiton.map(v => {
      if (v === null || v === undefined) return null;
      // Draw as a simple ON/OFF band near the top of the chart
      return (Number(v) > 0) ? 260 : 250; // ON/OFF band
    });

    const chartpsset = data['chartpsset'] || [];
    const chartpsact = data['chartpsact'] || [];
    const chartpdset = data['chartpdset'] || [];
    const chartpdact = data['chartpdact'] || [];
    const chartsuperheat = data['chartsuperheat'] || [];
    const chartsubcooling = data['chartsubcooling'] || [];

    const charteevlevel = data['charteevlevel'] || [];
    const chartfan1 = data['chartfan1'] || [];
    const chartfan2 = data['chartfan2'] || [];

    const rawThreeway = (data['chartthreeway'] || []);
    const rawDefrost = (data['chartdefrost'] || []);
    const rawAntifreeze = (data['chartantifreeze'] || []);

    const chartthreewayBand = rawThreeway.map((v, i) =>
      mapThreewayValue(v, chartfact[i], chartfan1[i], chartfan2[i])
    );

    // Defrost / Antifreeze — same behavior as in 1.4.5:
    // continuous "band" line with two levels (ON vs OFF)
    const chartdefrostBand = rawDefrost.map(v => {
      if (v === null || v === undefined) return null;
      const s = String(v).trim().toUpperCase();
      if (s === '' || s === 'N/A' || s === 'NA' || s === 'ERROR') return null;
      if (s === 'ON' || s === 'TRUE' || s === '1' || s === 'DEFROST') return 218;
      if (s === 'OFF' || s === 'FALSE' || s === '0') return 205;

      const n = parseFloat(v);
      if (!isFinite(n)) return null;
      return (n > 0) ? 218 : 205; // ON / OFF
    });

    const chartantifreezeBand = rawAntifreeze.map(v => {
      if (v === null || v === undefined) return null;
      const s = String(v).trim().toUpperCase();
      if (s === '' || s === 'N/A' || s === 'NA' || s === 'ERROR') return null;
      if (s === 'ON' || s === 'TRUE' || s === '1' || s === 'ANTIFREEZE') return 268;
      if (s === 'OFF' || s === 'FALSE' || s === '0') return 262;

      const n = parseFloat(v);
      if (!isFinite(n)) return null;
      return (n > 0) ? 268 : 262; // ON / OFF
    });

    const chartmode_quiet = data['chartmode_quiet'] || [];
    const chartmode_eco = data['chartmode_eco'] || [];
    const chartmode_turbo = data['chartmode_turbo'] || [];
    const chartmodeCode = mapModeSeries(chartmode_quiet, chartmode_eco, chartmode_turbo);
    const chartmodeBand = chartmodeCode.map(v => 210 + (Number(v) || 0) * 10);

    chartsConfig.chart0.data = formatChartData({
      chartdate,
      charttank,
      charttwi,
      charttwo,
      chartthi,
      charttho,
      chartts,
      charttd,
      charttao,
      chartintemp,
      charthumid,
      chartouttemp,
      charthcurve,
      charttdef,
      chartfset,
      chartfact,
      chartflimitBand,
      chartpsset,
      chartpsact,
      chartpdset,
      chartpdact,
      chartsuperheat,
      chartsubcooling,
      chartthreewayBand,
      chartdefrostBand,
      chartantifreezeBand,
      charteevlevel,
      chartfan1,
      chartfan2,
      chartmodeBand,
      chartheater
    });

    generateOrUpdateDygraph("chart0", chartsConfig.chart0);

    // apply visibility to chart (in case it was set before chart creation)
    $('input[type="checkbox"][data-chart="0"]').each(function() {
      const idx = parseInt(this.name, 10);
      if (!isNaN(idx)) _applyVisibilityToChart(idx, !!this.checked);
    });
  });

  socket.on('chart_update', function(msg) {
    if (!$('#btnradio4').prop('checked')) return;

    const dt = parseChartDate(msg.datechart);

    const flRaw = normalizeFLimit(msg.flimitonchart);
    const flBand = (flRaw === null || flRaw === undefined) ? null : (Number(flRaw) > 0 ? 260 : 250);

    const threewayBand = mapThreewayValue(msg.threewaychart, msg.factchart, msg.fan1chart, msg.fan2chart);
    const defrostBand = mapDefrostValue(msg.defrostchart, msg.factchart, msg.fan1chart, msg.fan2chart, msg.threewaychart);
    const antifreezeBand = mapAntifreezeValue(msg.antifreezechart, msg.threewaychart);

    const modeCode = mapModeValue(msg.modechart_quiet, msg.modechart_eco, msg.modechart_turbo);
    const modeBand = 210 + (Number(modeCode) || 0) * 10;

    chartsConfig.chart0.data.push([
      dt,
      numOrNull(msg.tankchart),
      numOrNull(msg.twichart),
      numOrNull(msg.twochart),
      numOrNull(msg.thichart),
      numOrNull(msg.thochart),
      numOrNull(msg.tschart),
      numOrNull(msg.tdchart),
      numOrNull(msg.taochart),
      numOrNull(msg.intempchart),
      numOrNull(msg.humidchart),
      numOrNull(msg.outtempchart),
      numOrNull(msg.hcurvechart),
      numOrNull(msg.tdefchart),
      numOrNull(msg.fsetchart),
      numOrNull(msg.factchart),
      flBand,
      numOrNull(msg.pssetchart),
      numOrNull(msg.psactchart),
      numOrNull(msg.pdsetchart),
      numOrNull(msg.pdactchart),
      numOrNull(msg.superheatchart),
      numOrNull(msg.subcoolingchart),
      threewayBand,
      defrostBand,
      antifreezeBand,
      numOrNull(msg.eevlevelchart),
      numOrNull(msg.fan1chart),
      numOrNull(msg.fan2chart),
      modeBand,
      numOrNull(msg.heaterchart)
    ]);

    generateOrUpdateDygraph("chart0", chartsConfig.chart0);
  });

  }

  $("input[name='btnradio']").click(function() {
    if (!socket) return;
    resetZoomOnNextRender = true;
    socket.emit('client', { charts: $(this).val() });
  });
});
    } catch(e) { console.error('HPI inline script error (charts.html #1)', e); }
  });

  // From templates/index.html (block 1)
  onReady(function(){
    if(!(PAGE === 'index')) return;
    try {
function modechange(newmode) {
                $.post('/modechange', {newmode}, function(data) {
                        var text=data.msg;
                        var state=data.state
                        Swal.fire({
                                html: text,
                                icon: state,
                                showCloseButton: false,
                                showConfirmButton: false,
                                timer: 2000,
                                timerProgressBar: true,
                                didOpen: () => {
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                                                })
                        });
			}
        function flrchange(newmode) {
                $.post('/flrchange', {newmode}, function(data) {
                        var text=data.msg;
                        var state=data.state
                        Swal.fire({
                                html: text,
                                icon: state,
                                showCloseButton: false,
                                showConfirmButton: false,
                                timer: 2000,
                                timerProgressBar: true,
                                didOpen: () => {
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                                                })
                        });
                        }

        function statechange(mode, value) {
		if (mode == "pdhw") {
			$("#"+mode+"-loading-overlay")[0].classList.remove("d-none")
		} else {
			$("#heat-loading-overlay")[0].classList.remove("d-none")
		}
            $.post('/statechange', {mode: mode, value: value}, function(data) {
                var text=data.msg;
                var state=data.state;
		appendAlert(text, state);
                if (mode == "pdhw") {
                        $("#"+mode+"-loading-overlay")[0].classList.add("d-none")
                } else {
                        $("#heat-loading-overlay")[0].classList.add("d-none")
                }

            });
        }
	function tchange(which,temp, direct) {
	//$.post('/tempchange', {which: which, value: temp, directly: direct}, function(data) {
        //                var text=data.msg;
         //               var state=data.state;
	//		appendAlert(text, state);
         //               });
		socket.emit("client", {tempchange:which, value:temp, directly:direct})
				}
/*        function tempchange(which, directly) {
        if (which ==  "heat") {
            minimum=minch
            maximum=maxch
            stepp=0.1
            inputval=temp
        }
        if (which == "dhw") {
            minimum=30
            maximum=55
            stepp=1
            inputval=dhwsetpoint
        }
            (async () => {
                const { value: inputValue } = await Swal.fire({
					title: "{{ _('Change temperature') }}",
                    input: 'range',
                    inputAttributes: {
                        min: minimum,
                        max: maximum,
                        step: stepp
                    },
                    inputValue: inputval
                })
                if (confirm) {
                    $("#"+which)[0].classList.add("spinn")
                    $("#"+which)[0].classList.add("iconspinner")
                    var data = inputValue
                    $.post('/tempchange', {which: which, value: data, directly: directly}, function(data) {
                        var text=data.msg;
                        var state=data.state
                        Swal.fire({
                            html: text,
                            icon: state,
                            showCloseButton: false,
                            showConfirmButton: false,
                            timer: 2000,
                            timerProgressBar: true,
                            didOpen: () => {
                                const b = Swal.getHtmlContainer().querySelector('b')
                                timerInterval = setInterval(() => {
                                    b.textContent = Swal.getTimerLeft()
                                }, 100)
                            },
                            willClose: () => {
                                clearInterval(timerInterval)
                            }
                        })
                    $("#"+which)[0].classList.remove("spinn")
                    $("#"+which)[0].classList.remove("iconspinner")
                    });
                }


            })()
        }*/


        //setInterval(getdata, 2000);
    } catch(e) { console.error('HPI inline script error (index.html #1)', e); }
  });

  // From templates/index.html (block 2)
  onReady(function(){
    if(!(PAGE === 'index')) return;
    try {
$(document).ready(function () {
				translateElement("flrelay");
translateElement("pump");
translateElement("threeway");
  $("#powerheat").change(function () {
	                //if (mode == "pdhw") {
                        $("#heat-loading-overlay")[0].classList.remove("d-none")
                        //$("#heat-loading-overlay")[0].classList.remove("d-none")
			socket.emit('client', {mode: $(this).val(), value: 'on'})
           /* $.post('/statechange', {mode: mode, value: value}, function(data) {
                var text=data.msg;
                var state=data.state;
                appendAlert(text, state);
                if (mode == "pdhw") {
                        $("#"+mode+"-loading-overlay")[0].classList.add("d-none")
                } else {
                        $("#heat-loading-overlay")[0].classList.add("d-none")
                }

            });*/

			  });
  // Obsługa kliknięcia przycisku
  $("#curvecalc-btn").click(function () {
	$("#hcurve").text("Obliczanie...");
	$("#button-spinner").removeClass("d-none");
    socket.emit('client', { curvecalc: 'curvecalc' });
    // Zmień zawartość przycisku na kręcące się kółko
/*    $("#hcurve").text("Obliczanie..."); // Zmień tekst
    $("#button-spinner").removeClass("d-none"); // Pokaż spinner
    // Wyślij żądanie GET na endpoint /curvecalc
    $.get("/curvecalc", function (data) {
      // Obsłuż odpowiedź
      console.log("Odpowiedź z serwera:", data);
	appendAlert(data.msg, 'success');
      // Przywróć oryginalną zawartość przycisku
      $("#hcurve").text(data.msg);
      $("#button-spinner").addClass("d-none"); // Ukryj spinner
    }).fail(function (error) {
      // Obsłuż błąd
      console.error("Błąd podczas wysyłania żądania:", error);
	appendAlert(error, 'danger')
      // Przywróć oryginalną zawartość przycisku
      $("#button-text").text("Oblicz krzywą");
      $("#button-spinner").addClass("d-none"); // Ukryj spinner

      // Opcjonalnie: Wyświetl komunikat o błędzie
 //     alert("Wystąpił błąd podczas obliczania krzywej.");
	appendAlert("Wystąpił nieoczekiwany błąd", 'danger')
    }); */
  });
});
    } catch(e) { console.error('HPI inline script error (index.html #2)', e); }
  });

  // From templates/index.html (block 3)
  onReady(function(){
    if(!(PAGE === 'index')) return;
    try {
(function () {
  // Try to determine flimit mode ('auto' / 'manual') as robustly as possible.
  let lastFlimitMode = null;
  let lastPresetAutoChange = null; // 'auto' or 'manual'

  // Temperature zone (normal / frost / warm)
  let lastTempZone = 'normal';

  function pickTempZoneFromData(data) {
    if (!data) return null;
    const candidates = [
      data.tempzone,
      data.temp_zone,
      data.zone,
      data.temperaturezone,
      data.temperature_zone,
      (data.settings && (data.settings.tempzone || data.settings.temp_zone || data.settings.zone))
    ];
    for (const c of candidates) {
      const v = norm(c);
      if (v) return v;
    }
    // Last resort: any key that contains 'tempzone'
    for (const [k, v] of Object.entries(data)) {
      if (typeof k === 'string' && k.toLowerCase().includes('tempzone')) {
        const nv = norm(v);
        if (nv) return nv;
      }
    }
    return null;
  }

  function t(key, fallback) {
    try {
      if (window.i18next && typeof window.i18next.t === 'function') return window.i18next.t(key);
    } catch (e) {}
    return fallback;
  }

  function applyAoodZoneUI(zone, antiOnOffOn) {
    const z = norm(zone) || 'normal';
    const isZone = (z === 'frost' || z === 'warm');

    // Keep socket.js in sync (it hides the Δt span when zone is active)
    window.__tempZone = z;

    const titleEl = document.getElementById('aood-title');
    const deltaWrap = document.getElementById('aood-delta-wrap');
    const zoneWrap = document.getElementById('aood-zone-wrap');
    const zoneIcon = document.getElementById('aood-zone-icon');
    const zoneBi = document.getElementById('aood-zone-bi');

    if (titleEl) {
      if (isZone && antiOnOffOn) {
        titleEl.textContent = (z === 'frost') ? t('set.zone_frost', 'Strefa mrozu') : t('set.zone_warm', 'Strefa ciepła');
      } else {
        titleEl.textContent = t('ind.aood', 'Tryb Anty ON-OFF "Delta"');
      }
    }

    // Right side: Δt vs icon
    if (deltaWrap && isZone && antiOnOffOn) { deltaWrap.style.display = 'none'; }
    if (zoneWrap) zoneWrap.classList.toggle('d-none', !(isZone && antiOnOffOn));

    if (zoneIcon) {
      zoneIcon.classList.toggle('frost', (z === 'frost'));
      zoneIcon.classList.toggle('warm', (z === 'warm'));
    }
    if (zoneBi) {
      zoneBi.className = 'bi ' + ((z === 'frost') ? 'bi-thermometer-snow' : 'bi-thermometer-sun');
    }
    if (zoneWrap) {
      zoneWrap.title = (z === 'frost') ? t('set.zone_frost', 'Strefa mrozu') : (z === 'warm' ? t('set.zone_warm', 'Strefa ciepła') : '');
    }

    // Hide delta conditions + delta time row in zones (keep only mode labels)
    const hide = (isZone && antiOnOffOn);
    document.querySelectorAll('.aood-hide-in-zone').forEach(el => {
      el.style.display = hide ? 'none' : '';
    });
  }

  function norm(v) {
    if (v === undefined || v === null) return null;
    return String(v).toLowerCase().trim();
  }

  

  // Heating curve (for Set Temperature label switching)
  let lastHeatingCurve = null;

  function pickHeatingCurveFromData(data) {
    if (!data) return null;
    const candidates = [
      // Prefer the live status field returned by /getdata or data_update
      data.heatingcurve,
      data.hcurve,
      data.heatingCurve,
      // Fallbacks / legacy keys
      data["SETTINGS$heatingcurve"],
      data["SETTINGS_heatingcurve"],
      data.settings_heatingcurve,
      data.settingsHeatingCurve
    ];
    for (const c of candidates) {
      const v = norm(c);
      if (v) return v;
    }
    // As a last resort, search any key that includes 'heatingcurve'
    for (const [k, v] of Object.entries(data)) {
      if (typeof k === "string" && k.toLowerCase().includes("heatingcurve")) {
        const nv = norm(v);
        if (nv) return nv;
      }
    }
    if (data.settings && typeof data.settings === "object") {
      return pickHeatingCurveFromData(data.settings);
    }
    return null;
  }

    function applySetTempLabel(heatingCurve) {
    const insideLabel = document.getElementById("settemp-label-inside");
    const chLabel = document.getElementById("settemp-label-ch");
    if (!insideLabel || !chLabel) return;

    const v = norm(heatingCurve) || "";
    // Your API returns: heatingcurve:"directly"
    const isDirect = (v === "directly" || v === "direct");

    // Export step + limits globally so +/- uses correct granularity (0.1 vs 0.5) and bounds (30 vs 55)
    window.__heatingCurve = v;

    if (isDirect) {
      window.__heatStep = 0.5;
      window.__heatMin  = 25;
      window.__heatMax  = 55;
      window.minch = 25;
      window.maxch = 55;

      insideLabel.classList.add("d-none");
      chLabel.classList.remove("d-none");
    } else {
      window.__heatStep = 0.1;
      window.__heatMin  = 12;
      window.__heatMax  = 30;
      window.minch = 12;
      window.maxch = 30;

      chLabel.classList.add("d-none");
      insideLabel.classList.remove("d-none");
    }
  }

  function pickInsideHumidityFromData(data) {
    if (!data) return null;
    const candidates = [
      data.humid,
      data.humidity,
      data.insidehumidity,
      data.insideHumidity,
      data["INSIDE$humidity"],
      data["INSIDE_humidity"]
    ];
    for (const c of candidates) {
      if (c === undefined || c === null || c === "") continue;
      const n = Number(c);
      if (!Number.isNaN(n)) return n;
    }
    return null;
  }
function pickFlimitModeFromData(data) {
    if (!data) return null;

    // Most likely keys (depending on backend/socket.js)
    const candidates = [
      data.flimitmode,
      data.freqlimitmode,
      data.flimit,                 // sometimes carries 'auto'/'manual'
      data["SETTINGS$flimit"],
      data["SETTINGS_flimit"],
      data.settings_flimit,
      data.settingsFlimit
    ];

    for (const c of candidates) {
      const v = norm(c);
      if (v === "auto" || v === "manual") return v;
    }
    return null;
  }

  function pickPresetAutoChangeFromData(data) {
    if (!data) return null;
    const direct = [
      data["SETTINGS$presetautochange"],
      data.presetautochange,
      data.SETTINGS_presetautochange,
      data["presetautochange"],
    ];
    for (const v of direct) {
      const nv = norm(v);
      if (nv === "auto" || nv === "manual") return nv;
    }
    for (const [k, v] of Object.entries(data)) {
      if (typeof k === "string" && k.toLowerCase().includes("presetautochange")) {
        const nv = norm(v);
        if (nv === "auto" || nv === "manual") return nv;
      }
    }
    if (data.settings && typeof data.settings === "object") {
      return pickPresetAutoChangeFromData(data.settings);
    }
    return null;
  }


  function detectManualFromDOMFallback() {
    // Fallback: if the "auto" block is hidden, we assume MANUAL.
    const autoBlock = document.getElementById("flimitauto");
    if (!autoBlock) return null;
    const isHidden = (autoBlock.style.display === "none") || autoBlock.classList.contains("d-none");
    return isHidden ? "manual" : "auto";
  }

  function isAntiOnOffVisible() {
    const div = document.getElementById("antionoffdiv");
    if (!div) return false;
    return !(div.style.display === "none");
  }

  function applyUI(isAntiOnOffOn, flimitMode) {
    const mode = norm(flimitMode) || detectManualFromDOMFallback();
    const isManual = (mode === "manual");

    // 1) Wiersz "Temperatura załączania >" ma znikać gdy:
    //    - Anty ON-OFF ON
    //    - LUB flimit MANUAL
    const tempRow = document.getElementById("flimittemp-row");
    if (tempRow) tempRow.style.display = (isAntiOnOffOn || isManual) ? "none" : "";

    
    // 1b) Gdy Anty ON-OFF jest WYŁĄCZONE, pokaż zastępczo kafelek "Wybór trybu" (tryb od temperatury)
    const presetAutoDiv = document.getElementById("presetauto");
    // Zakresy temperatur pokazujemy tylko w trybie AUTO zmiany trybu.
    // Jeśli nie mamy informacji z backendu, to domyślnie traktujemy jako AUTO (żeby nic nie "znikło").
    const presetSelect = document.getElementById("presetchange");
    const presetSelectVisible = !!(presetSelect && presetSelect.style.display !== "none" && !presetSelect.classList.contains("d-none"));
    const isAutoChange = (lastPresetAutoChange === "auto" || lastPresetAutoChange === null);
    const showPresetAuto = (!isAntiOnOffOn) && isAutoChange && !presetSelectVisible;
    if (presetAutoDiv) presetAutoDiv.style.display = showPresetAuto ? "" : "none";

	  // 2) W kafelku "Ograniczenie częstotliwości":
	  //    - w MANUAL ma zostać TYLKO wybór WŁ/WYŁ => chowamy <span id="flimit">...</span>
	  //    - w AUTO pokazujemy "Anty On-Off" tylko gdy Anty ON-OFF faktycznie steruje (czyli AUTO)
	  //    - podczas aktywnej strefy mrozu/ciepła ukrywamy napis "Anty On-Off" (zostaje samo "Ograniczenie częstotliwości :")
	  const z = norm(lastTempZone) || 'normal';
	  const zoneActive = ((z === 'frost' || z === 'warm') && isAntiOnOffOn);
	  const flimitStatus = document.getElementById("flimit");
	  if (flimitStatus) {
	    if (isManual) {
	      flimitStatus.textContent = "";
	      flimitStatus.style.display = "none";
	    } else {
	      if (zoneActive && isAntiOnOffOn) {
	        flimitStatus.textContent = "";
	        flimitStatus.style.display = "none";
	      } else {
	        flimitStatus.style.display = "";
	        flimitStatus.textContent = isAntiOnOffOn ? "Anty On-Off" : "Auto";
	      }
	    }
	  }

    // 3) W kafelku "Tryb Anty ON-OFF "Delta"":
    //    - w MANUAL ukrywamy cały wiersz "Ograniczenie częstot. < ... °C"
    const flimitOnLabel = document.getElementById("flimiton-label");
    if (flimitOnLabel) {
      const row = flimitOnLabel.closest(".row");
      if (row) row.style.display = isManual ? "none" : "";
    }
  }

  function refresh(dataMaybe) {
    const modeFromData = pickFlimitModeFromData(dataMaybe);
    if (modeFromData) lastFlimitMode = modeFromData;

    const presetAutoChangeFromData = pickPresetAutoChangeFromData(dataMaybe);
    if (presetAutoChangeFromData) lastPresetAutoChange = presetAutoChangeFromData;

    const antiOnOffOn = (dataMaybe && dataMaybe.antionoff !== undefined)
      ? (String(dataMaybe.antionoff) === "1")
      : isAntiOnOffVisible();

    const tz = pickTempZoneFromData(dataMaybe);
    if (tz) lastTempZone = tz;

        

    const heatingCurveFromData = pickHeatingCurveFromData(dataMaybe);
    if (heatingCurveFromData) lastHeatingCurve = heatingCurveFromData;
    applySetTempLabel(lastHeatingCurve);

    const h = pickInsideHumidityFromData(dataMaybe);
    if (h !== null) {
      // Update both: existing #humid (cooling card) and new #humid_ch (heating card)
      const humidEl = document.getElementById("humid");
      if (humidEl) humidEl.textContent = h.toFixed(1);
      const humidChEl = document.getElementById("humid_ch");
      if (humidChEl) humidChEl.textContent = h.toFixed(1);
    }
// ==== WYBÓR TRYBU – temperatury i tytuł (jak w 1.39) ====
    if (dataMaybe) {
      // temperatury progowe dla trybu Auto (Quiet/Turbo)
      if (dataMaybe.presetquiet !== undefined) {
        const pq = document.getElementById("presetquiet");
        if (pq) pq.textContent = Number(dataMaybe.presetquiet).toFixed(1);
      }
      if (dataMaybe.presetturbo !== undefined) {
        const pt = document.getElementById("presetturbo");
        if (pt) pt.textContent = Number(dataMaybe.presetturbo).toFixed(1);
      }

      // tytuł kafelka: zwykły wybór trybu vs od temperatury
      const autoChange =
        (dataMaybe["SETTINGS$presetautochange"] !== undefined ? dataMaybe["SETTINGS$presetautochange"] :
         (dataMaybe.presetautochange !== undefined ? dataMaybe.presetautochange :
          (dataMaybe["SETTINGS$presetauto"] !== undefined ? dataMaybe["SETTINGS$presetauto"] : undefined)));

      const titleEl = document.getElementById("preset-title");
      if (titleEl) {
        const v = (autoChange === undefined || autoChange === null) ? "" : String(autoChange).toLowerCase();
        titleEl.textContent = (v === "auto" || v === "1" || v === "true" || v === "on")
          ? "Wybór trybu od temperatury:"
          : "Wybór trybu:";
      }
    }

    applyUI(antiOnOffOn, lastFlimitMode);
    applyAoodZoneUI(lastTempZone, antiOnOffOn);
  }

  if (typeof socket !== "undefined" && socket && socket.on) {
    socket.on("data_update", function (data) {
      refresh(data);
    });
  }

  // Also keep the UI correct even if other scripts overwrite fields

  // Fallback: jeśli delta przychodzi w /getdata (HTTP), a nie w data_update,
  // to dociągnij ją okresowo i ustaw #delta.
  (function setupDeltaPoll() {
    const candidates = ["/getdata", "/api/getdata", "/get_data", "/data", "/status"];
    let goodUrl = null;

    async function tryFetch(url) {
      const r = await fetch(url, { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json();
      // Fallback updates from HTTP poll (in some setups socket data_update does not include all fields)
      try {
        const hc = pickHeatingCurveFromData(j);
        if (hc) {
          lastHeatingCurve = hc;
          applySetTempLabel(lastHeatingCurve);
        }
        const h = pickInsideHumidityFromData(j);
        if (h !== null) {
          const humidEl = document.getElementById("humid");
          if (humidEl) humidEl.textContent = h.toFixed(1);
          const humidChEl = document.getElementById("humid_ch");
          if (humidChEl) humidChEl.textContent = h.toFixed(1);
        }
      } catch (e) { /* ignore */ }

      // Temp zone fallback (for Frost/Warm UI)
      try {
        const tz = pickTempZoneFromData(j);
        if (tz) lastTempZone = tz;
        const antiOnOffOn = (j && j.antionoff !== undefined) ? (String(j.antionoff) === '1') : isAntiOnOffVisible();
        applyAoodZoneUI(lastTempZone, antiOnOffOn);
      } catch (e) { /* ignore */ }

      if (j && j.delta !== undefined && j.delta !== null) {
        const dv = Number(j.delta);
        if (!Number.isNaN(dv)) {
          lastDelta = dv;
          const dEl = document.getElementById("delta");
          if (dEl) dEl.textContent = dv.toFixed(1);
        }
      }
      return true;
    }

    async function tick() {
      try {
        if (goodUrl) {
          await tryFetch(goodUrl);
          return;
        }
        for (const u of candidates) {
          try {
            await tryFetch(u);
            goodUrl = u;
            return;
          } catch (e) { /* next */ }
        }
      } catch (e) { /* ignore */ }
    }

    setInterval(tick, 2000);
    tick();
  })();

  setInterval(function () { refresh(null); }, 400);
})();
    } catch(e) { console.error('HPI inline script error (index.html #3)', e); }
  });

  // From templates/parameters.html (block 1)
  onReady(function(){
    if(!(PAGE === 'parameters')) return;
    try {
function getdata() {
	$.get('/getdata', function(data) {
		$("#ttemp").text(parseFloat(data.tank).toFixed(1) + " °C");
		$("#intemp").text(parseFloat(data.intemp).toFixed(1) + " °C");
		$("#humid").text(parseFloat(data.humid).toFixed(1) + " %");
		$("#dhwsetpoint").text(parseFloat(data.dhw).toFixed(1) + " °C");
		$("#hcurve").text(parseFloat(data.hcurve).toFixed(1) + " °C");
		$("#setpoint").text(parseFloat(data.setpoint).toFixed(1) + " °C");
		$("#mode").text(data.mode)
		$("#flimiton").text(data.flimiton)
		// Defrost params
		if ($.isNumeric(data.tdef)) {
			$("#tdef").text(parseFloat(data.tdef).toFixed(1) + " °C");
		} else {
			$("#tdef").text(data.tdef);
		}
		switch(String(data.defrost).toLowerCase()) {
			case "on":
				$("#defrost").text("on");
				break;
			default:
				$("#defrost").text("off");
		}

		// Heater params
		switch(String(data.heater).toLowerCase()) {
			case "on":
				$("#heater").text("on");
				break;
			default:
				$("#heater").text("off");
		}

		// Antifreeze params
		switch(String(data.antifreeze).toLowerCase()) {
			case "on":
				$("#antifreeze").text("on");
				break;
			default:
				$("#antifreeze").text("off");
		}

switch(data.flimiton) {
		case "0":
		    if($("#flrelay").text() != "off") {
		        $("#flrelay").text("off")
			    }
			break;
		case "1":
		    if($("#flrelay").text() != "on") {
		        $("#flrelay").text("on")
			    }
			break;
			    }
switch(data.mode){
		case "quiet":
		    if($("#mode").text() != "quiet") {
			$("#mode").text("quiet")
			    }
			break;
		case "eco":
		    if($("#mode").text() != "eco") {
			$("#mode").text("eco")
			    }
			break;
		 case "turbo":
		    if($("#mode").text() != "turbo") {
			$("#mode").text("turbo")
			    }
			break;
	    default:
	    }

		})
	$.get('/getparams', function(data) {
		$("#twi").text(data.twitwo[0]+" °C")
		$("#two").text(data.twitwo[1]+" °C")
        $("#thi").text(data.thitho[0]+" °C")
        $("#tho").text(data.thitho[1]+" °C")
        $("#pdset").text(data.pdps[0]+" bar")
        $("#pdact").text(data.pdps[1]+" bar")
		$("#psset").text(data.pdps[2]+" bar")
        $("#psact").text(data.pdps[3]+" bar")
		$("#tsatpsset").text(data.tsatps[0]+" °C")
		$("#tsatpsact").text(data.tsatps[1]+" °C")
		$("#tsatpdset").text(data.tsatpd[0]+" °C")
		$("#tsatpdact").text(data.tsatpd[1]+" °C")
		$("#eevlevel").text(data.eevlevel+" °")
        $("#deltat").text((data.twitwo[1]-data.twitwo[0]).toFixed(1)+" °C")
        $("#fact").text(data.compinfo[0]+" Hz")
        $("#fset").text(data.compinfo[1]+" Hz")
        $("#ccurr").text(data.compinfo[2]+" A")
        $("#cvolt").text(data.compinfo[3]+" V")
        $("#ctemp").text(data.compinfo[4]+" °C")
        $("#fan1").text(data.fans[0]+" rpm")
		$("#fan2").text(data.fans[1]+" rpm")
		$("#tao").text(data.tao+" °C")
		$("#td").text(data.tdts[0]+" °C")
		$("#ts").text(data.tdts[1]+" °C")
		$("#pump").text(data.pump)
		$("#chkwhpd").text(parseFloat(data.chkwhpd).toFixed(1) + " kWh");
		$("#dhwkwhpd").text(parseFloat(data.dhwkwhpd).toFixed(1) + " kWh");
			let dailykwh = parseFloat(data.chkwhpd) + parseFloat(data.dhwkwhpd);
		$("#dailykwh").text(dailykwh.toFixed(1) + " kWh");
		$("#threeway").text(data.threeway)
		$("#flrelay").text(data.flrelay)
		$("#superheat").text((data.superheat !== undefined) ? (data.superheat + " °C") : "");
		$("#subcooling").text((data.subcooling !== undefined) ? (data.subcooling + " °C") : "");
switch(data.threeway) {
	    case "CH":
			if($("#threeway").text() != "ch") {
			    $("#threeway").text("ch")
				}
			break;
	    case "DHW":
			if($("#threeway").text() != "dhw") {
			    $("#threeway").text("dhw")
			}
			break;
	    default:
		}
switch(data.pump) {
	    case "ON":
			if($("#pump").text() != "on") {
			    $("#pump").text("on")
				}
			break;
	    case "OFF":
			if($("#pump").text() != "off") {
			    $("#pump").text("off")
			}
			break;
	    default:
		}
    });
	}
//setInterval(getdata, 2000);

$(document).ready(function(){ getdata(); });
    } catch(e) { console.error('HPI inline script error (parameters.html #1)', e); }
  });

  // From templates/scheduler.html (block 1)
  onReady(function(){
    if(!(PAGE === 'scheduler')) return;
    try {
/*				$('#schedule3').jqs({
      onInit: function () {
        $('#logs').val('onInit fire !\n' + $('#logs').val());
      },
      onAddPeriod: function () {
        $('#logs').val('onAddPeriod fire !\n' + $('#logs').val());
      },
      onRemovePeriod: function () {
        $('#logs').val('onRemovePeriod fire !\n' + $('#logs').val());
      },
      onClickPeriod: function () {
        $('#logs').val('onClickPeriod fire !\n' + $('#logs').val());
      }
    });
				$('#schedule4').jqs({
      onInit: function () {
        $('#logs').val('onInit fire !\n' + $('#logs').val());
      },
      onAddPeriod: function () {
        $('#logs').val('onAddPeriod fire !\n' + $('#logs').val());
      },
      onRemovePeriod: function () {
        $('#logs').val('onRemovePeriod fire !\n' + $('#logs').val());
      },
      onClickPeriod: function () {
        $('#logs').val('onClickPeriod fire !\n' + $('#logs').val());
      }
    });
$('#schedule3').jqs('import', {{ ch }});
				console.log('{{ ch }}');
$('#schedule4').jqs('import', {{ dhw }});*/
$('#savech').click(function () {
      var schedulech=$('#schedule3').jqs('export');
	$.post('/scheduler', {schedulech: schedulech}, function(data) {
		         var text=data.msg;
                        var state=data.state;
			appendAlert(text,state);
        /*                Swal.fire({
                                html: text,
                                icon: state,
                                showCloseButton: false,
                                showConfirmButton: false,
                                timer: 2000,
                                timerProgressBar: true,
                                didOpen: () => {
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                                                })*/

                        });
    });
$('#savedhw').click(function () {
      var scheduledhw=$('#schedule4').jqs('export');
        $.post('/scheduler', {scheduledhw: scheduledhw}, function(data) {
                        var text=data.msg;
                        var state=data.state
                        Swal.fire({
                                html: text,
                                icon: state,
                                showCloseButton: false,
                                showConfirmButton: false,
                                timer: 2000,
                                timerProgressBar: true,
                                didOpen: () => {
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                                                })

                        });
    });
    } catch(e) { console.error('HPI inline script error (scheduler.html #1)', e); }
  });

  // From templates/scheduler.html (block 2)
  onReady(function(){
    if(!(PAGE === 'scheduler')) return;
    try {
$('#schedule3').jqs({
      onInit: function () {
        $('#logs').val('onInit fire !\n' + $('#logs').val());
      },
      onAddPeriod: function () {
        $('#logs').val('onAddPeriod fire !\n' + $('#logs').val());
      },
      onRemovePeriod: function () {
        $('#logs').val('onRemovePeriod fire !\n' + $('#logs').val());
      },
      onClickPeriod: function () {
        $('#logs').val('onClickPeriod fire !\n' + $('#logs').val());
      }
    });
                                $('#schedule4').jqs({
      onInit: function () {
        $('#logs').val('onInit fire !\n' + $('#logs').val());
      },
      onAddPeriod: function () {
        $('#logs').val('onAddPeriod fire !\n' + $('#logs').val());
      },
      onRemovePeriod: function () {
        $('#logs').val('onRemovePeriod fire !\n' + $('#logs').val());
      },
      onClickPeriod: function () {
        $('#logs').val('onClickPeriod fire !\n' + $('#logs').val());
      }
    });
$(document).ready(function() {
    const socket = io(); // Upewniamy się, że socket jest tworzony tylko raz

    socket.on("connect", () => {
        console.log("Połączono z serwerem Socket.io");
    });
        socket.on('scheduler', function(data) {
                var scheduler1=data.chsch
		var scheduler2=data.dhwsch
		$('#schedule3').jqs('import', scheduler1);
		$('#schedule4').jqs('import', scheduler2);

    });
        socket.on('return', function(msg) {
                switch(Object.keys(msg)[0]) {
                        case "info":
                                appendAlert(msg.info, msg.status);
                                break;
                }
                console.log(msg)
        });
});

//$('#schedule4').jqs('import', {{ dhw }});
    } catch(e) { console.error('HPI inline script error (scheduler.html #2)', e); }
  });

  // From templates/settings.html (block 1)
  onReady(function(){
    if(!(PAGE === 'settings')) return;
    try {
(function () {
        function refreshTooltipsBs5(root) {
            if (!window.bootstrap || !bootstrap.Tooltip) return;
            root = root || document;
            root.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
                try {
                    var inst = bootstrap.Tooltip.getInstance(el);
                    if (inst) inst.dispose();
                    new bootstrap.Tooltip(el);
                } catch (e) {
                    // nic
                }
            });
        }

        function run() {
            var root = document.getElementById('settingsForm') || document;
            refreshTooltipsBs5(root);
        }

        // 1) Po wczytaniu strony (i18next zwykle kończy init chwilę później)
        window.addEventListener('load', function () {
            setTimeout(run, 50);
            setTimeout(run, 400);
            setTimeout(run, 1200);
        });

        // 2) Po zmianie zakładki (tooltips w ukrytych tabach też mają się odświeżyć)
        document.addEventListener('shown.bs.tab', function () {
            setTimeout(run, 0);
        });

        // 3) Jeśli i18next jest dostępny, odśwież po init i po zmianie języka
        function attachI18nHooks() {
            if (!window.i18next || typeof i18next.on !== 'function') return false;
            i18next.on('initialized', function () { setTimeout(run, 0); });
            i18next.on('languageChanged', function () { setTimeout(run, 0); });
            return true;
        }

        if (!attachI18nHooks()) {
            // jeśli i18next ładuje się później, spróbuj przez chwilę dociągnąć hooki
            var tries = 0;
            var timer = setInterval(function () {
                tries += 1;
                if (attachI18nHooks() || tries > 100) clearInterval(timer); // ~5s
            }, 50);
        }
    })();
    } catch(e) { console.error('HPI inline script error (settings.html #1)', e); }
  });

  // From templates/settings.html (block 2)
  onReady(function(){
    if(!(PAGE === 'settings')) return;
    try {
// Funkcja do usuwania klas z danym prefiksem (zostawiłem, jest przydatna)
    function removeClassesByPrefix(selector, prefix) {
        $(selector).removeClass(function (index, className) {
            return (className.match(new RegExp('\\b' + prefix + '\\S+', 'g')) || []).join(' ');
        });
    }

    // Prosty helper do tłumaczeń dynamicznych (statusy/przyciski)
    function t(key, fallback) {
        try {
            if (window.i18next && typeof i18next.t === 'function') {
                const v = i18next.t(key);
                if (v && v !== key) return v;
            }
        } catch (e) { }
        return (fallback !== undefined) ? fallback : key;
    }

    // Całą logikę umieszczamy wewnątrz $(document).ready(), aby mieć pewność, że DOM jest załadowany.
    $(document).ready(function () {

        // ########### LOGIKA UI (refaktoryzacja) ###########

        function updateAntiOnOffView() {
            const isChecked = $("#antionoff").is(":checked");
            const presetMode = $('[name="SETTINGS$presetautochange"]').val();
            const presetManual = (presetMode === 'manual');

            // blok z ustawieniami delty aktywny tylko gdy Anty ON-OFF jest włączone
            $("#antionoffsettings").toggleClass("disableddiv", !isChecked);

            // "Zmiana trybu" jest blokowana tylko gdy Anty ON-OFF jest włączone
            $("#divpresetchange").toggleClass("disableddiv", isChecked);

            // Te pola mają być wyszarzone:
            // - gdy Anty ON-OFF jest włączone, albo
            // - gdy "Zmiana trybu" jest ustawiona na Manual
            $("#divflimittemp, #divpresetquiet, #divpresetturbo").toggleClass("disableddiv", (isChecked || presetManual));
        }



        // Sterowanie ogrzewaniem: Krzywa grzewcza vs Bezpośrednio

        // --- Pamiętanie ostatniego typu krzywej (auto/static/manual) ---
        const LAST_CURVE_LS_KEY = 'hpi_last_curve_type';
        let lastCurveType = null;

        function isValidCurveType(v) {
            return v === 'auto' || v === 'static' || v === 'manual';
        }

        function getCurveTypeFromConfigHidden() {
            const v = String($("#heatingcurve_hidden").val() || '').toLowerCase().trim();
            return isValidCurveType(v) ? v : null;
        }

        function loadLastCurveType() {
            // 1) pamięć runtime (np. po przełączeniach w tej sesji)
            if (isValidCurveType(lastCurveType)) return lastCurveType;

            // 2) localStorage (jeśli było wcześniej ustawione)
            try {
                const ls = String(localStorage.getItem(LAST_CURVE_LS_KEY) || '').toLowerCase().trim();
                if (isValidCurveType(ls)) return ls;
            } catch (e) { }

            // 3) ostatecznie
            return 'auto';
        }

        function saveLastCurveType(v) {
            if (!isValidCurveType(v)) return;
            lastCurveType = v;
            try { localStorage.setItem(LAST_CURVE_LS_KEY, v); } catch (e) { }
        }
        function getEffectiveHeatingCurveMode() {
            const ctrl = $("#heatingcontrol").val();
            if (ctrl === 'direct') return 'directly';
            return $("#heatingcurve").val();
        }

        function applyHeatingCurveFromHidden() {
            const v = String($("#heatingcurve_hidden").val() || '').toLowerCase().trim();

            if (v === 'directly' || v === 'direct') {
                // Tryb Bezpośrednio: hidden trzyma "directly", ale typ krzywej ma pozostać ostatnio wybrany
                $("#heatingcontrol").val('direct');
                const remembered = loadLastCurveType();
                $("#heatingcurve").val(remembered);
            } else if (isValidCurveType(v)) {
                // Tryb Krzywa: hidden = auto/static/manual
                $("#heatingcontrol").val('curve');
                $("#heatingcurve").val(v);
                saveLastCurveType(v);
            } else {
                // Fallback
                $("#heatingcontrol").val('curve');
                const remembered = loadLastCurveType();
                $("#heatingcurve").val(remembered);
                saveLastCurveType(remembered);
            }
        }

        function syncHeatingCurveHidden() {
            const effective = getEffectiveHeatingCurveMode();
            $("#heatingcurve_hidden").val(effective);
        }

        function updateHeatingControlView() {
            const isDirect = $("#heatingcontrol").val() === 'direct';
            $("#heatingcurve_section").toggleClass('disableddiv', isDirect);
            // Direct mode options are only active when Heating control = Direct
            $("#directmode_section").toggleClass('disableddiv', !isDirect);
            syncHeatingCurveHidden();
        }

        function updateHeatingCurveView() {
            const selectedCurve = getEffectiveHeatingCurveMode();
            const divVisibility = {
                auto: { slope: true, pshift: true, hcamp: true, manual: false },
                static: { slope: true, pshift: false, hcamp: false, manual: false },
                manual: { slope: false, pshift: false, hcamp: false, manual: true },
                directly: { slope: false, pshift: false, hcamp: false, manual: false }
            };

            const config = divVisibility[selectedCurve] || divVisibility.directly; // Domyślna wartość

            $("#divslope").toggleClass("disableddiv", !config.slope);
            $("#divpshift").toggleClass("disableddiv", !config.pshift);
            $("#divhcamp").toggleClass("disableddiv", !config.hcamp);
            $("#divhcmanual").toggleClass("disableddiv", !config.manual);
        }

        function updatePresetDependency() {
            const presetMode = $('[name="SETTINGS$presetautochange"]').val();
            const antionoffCheckbox = $('#antionoff');
            const antionoffContainer = antionoffCheckbox.closest('.list-group-item');

            if (presetMode === 'manual') {
                antionoffContainer.addClass('disableddiv');
                if (antionoffCheckbox.is(':checked')) {
                    antionoffCheckbox.prop('checked', false).trigger('change');
                }
            } else {
                antionoffContainer.removeClass('disableddiv');
            }

            // odśwież zależności pól (m.in. wyszarzanie temperatur) po zmianie trybu
            updateAntiOnOffView();
        }


        function updateZoneViews() {
            const frostOn = $("#zone_frost_enable").is(":checked");
            $("#zone_frost_settings").toggleClass("disableddiv", !frostOn);

            const warmOn = $("#zone_warm_enable").is(":checked");
            $("#zone_warm_settings").toggleClass("disableddiv", !warmOn);
        }


function updateAntifreezeCustomView() {
    const on = $("#antifreeze_custom_enable").is(":checked");
    $("#antifreeze_custom_settings").toggleClass("disableddiv", !on);
}

        function updateDhwViews() {
    const DhwON = $("#dhwuse").is(":checked");
    $("#dhw_dependent").toggleClass("disableddiv", !DhwON);

    // Optional: when DHW is OFF, reset dependent switches
    if (!DhwON) {
        $("#dhwwl").prop("checked", false).trigger("change");
        $("#dhwscheduler").prop("checked", false).trigger("change");
    }
}
function updateDhwModeViews() {
            const DhwModeON = $("#dhwwl").is(":checked");
            $("#dhw_mode_settings").toggleClass("disableddiv", !DhwModeON);

        }

        // NOWA FUNKCJA DLA ZALEŻNOŚCI HOME ASSISTANT
        function updateHaDependencies() {
            // Krok 1: Sprawdzenie ogólnej konfiguracji HA (Warunek Główny)
            const haAddr = $('[name="HOMEASSISTANT$HAADDR"]').val().trim();
            const haPort = $('[name="HOMEASSISTANT$HAPORT"]').val().trim();
            const haKey = $('[name="HOMEASSISTANT$KEY"]').val().trim();
            const isHaCoreConfigured = haAddr !== '' && haPort !== '' && haKey !== '';

            // Krok 2: Sprawdzenie każdego selecta z osobna

            // 2a. Czujnik temperatury wewnętrznej
            const insideSensorEntity = $('[name="HOMEASSISTANT$insidesensor"]').val().trim();
            const canUseHaForInsideTemp = isHaCoreConfigured && insideSensorEntity !== '';
            $('[name="SETTINGS$insidetemp"] option[value="ha"]').prop('disabled', !canUseHaForInsideTemp);

            // 2b. Czujnik temperatury zewnętrznej
            const outsideSensorEntity = $('[name="HOMEASSISTANT$outsidesensor"]').val().trim();
            const canUseHaForOutsideTemp = isHaCoreConfigured && outsideSensorEntity !== '';
            $('[name="SETTINGS$outsidetemp"] option[value="ha"]').prop('disabled', !canUseHaForOutsideTemp);

            // 2c. Czujnik wilgotności
            const humiditySensorEntity = $('[name="HOMEASSISTANT$humiditysensor"]').val().trim();
            const canUseHaForHumidity = isHaCoreConfigured && humiditySensorEntity !== '';
            $('[name="SETTINGS$humidity"] option[value="ha"]').prop('disabled', !canUseHaForHumidity);

            // 2d. Czujnik temperatury CWU (DHW)
            const dhwSensorEntity = $('[name="HOMEASSISTANT$dhwsensor"]').val().trim();
            const canUseHaForDhwTemp = isHaCoreConfigured && dhwSensorEntity !== '';
            const $dhwTempSelect = $('[name="SETTINGS$dhwtemp"]');
            $dhwTempSelect.find('option[value="ha"]').prop('disabled', !canUseHaForDhwTemp);
            // Jeżeli użytkownik miał wybrane HA, a brakuje encji / konfiguracji — wracamy do wbudowanego
            if (!canUseHaForDhwTemp && ($dhwTempSelect.val() || '').toLowerCase() === 'ha') {
                $dhwTempSelect.val('builtin');
            }
        }

        function assembleManualHeatingCurve() {
            const values = $("#hcmantable input[type='number']").map(function () {
                return $(this).val();
            }).get();
            $('#hcman').val(values.join(','));
        }

        // Init state from server-rendered hidden value
        applyHeatingCurveFromHidden();
        updateHeatingControlView();
        updateHeatingCurveView();

        // ########### POWIĄZANIA ZDARZEŃ (unobtrusive JS) ###########

        // Zdarzenia dla checkboxów z ukrytym inputem
        // To jest ogólna obsługa, która zadziała dla każdego checkboxa, który ma tuż przed sobą ukryty input
        $('input[type="checkbox"]').on('change', function () {
            const hiddenInput = $(this).prev('input[type="hidden"]');
            if (hiddenInput.length) {
                hiddenInput.val($(this).is(':checked') ? '1' : '0');
            }
        });

        // Powiązania dla specyficznych kontrolek UI
        $("#antionoff").on('change', updateAntiOnOffView);
        $("#heatingcontrol").on('change', function () {
            const isDirect = $("#heatingcontrol").val() === 'direct';

            if (isDirect) {
                // przechodzimy na Bezpośrednio: zapamiętaj ostatni typ krzywej
                const cur = String($("#heatingcurve").val() || '').toLowerCase().trim();
                if (isValidCurveType(cur)) saveLastCurveType(cur);
            } else {
                // wracamy na Krzywą: przywróć ostatnio wybrany typ (z configu lub pamięci)
                const fromConfig = getCurveTypeFromConfigHidden();
                const remembered = fromConfig || loadLastCurveType();
                $("#heatingcurve").val(remembered);
                saveLastCurveType(remembered);
            }

            updateHeatingControlView();
            updateHeatingCurveView();
        });
        $("#heatingcurve").on('change', function () {
            const cur = String($("#heatingcurve").val() || '').toLowerCase().trim();
            if (isValidCurveType(cur)) saveLastCurveType(cur);
            syncHeatingCurveHidden();
            updateHeatingCurveView();
        });
        $("#zone_frost_enable, #zone_warm_enable").on('change', updateZoneViews);
        $("#antifreeze_custom_enable").on('change', updateAntifreezeCustomView);
        $("#dhwwl").on('change', updateDhwModeViews);
        $("#dhwuse").on('change', updateDhwViews);
        $("#hcmantable input[type='number']").on('change', assembleManualHeatingCurve);

        // Zdarzenia dla wykresu
        $("#tempRange, #slope, #pshift, #hcamp").on('input change', recalc);
        $('[name="SETTINGS$presetautochange"]').on('change', function () {
            const selectedMode = $(this).val();
            const antionoffCheckbox = $('#antionoff');

            // Sprawdzamy, czy użytkownik włącza tryb 'manual', a opcja 'antionoff' jest aktywna
            if (selectedMode === 'manual' && antionoffCheckbox.is(':checked')) {
                // Wyświetlamy ostrzeżenie
                appendAlert('Opcja "Anty ON-OFF" zostanie wyłączona, ponieważ jest niekompatybilna z ręczną zmianą trybu.', 'warning');
            }

            // Niezależnie od alertu, zawsze aktualizujemy stan UI
            updatePresetDependency();
        });

        $('[name^="HOMEASSISTANT$"]').on('input', updateHaDependencies);


        // ########### LOGIKA WEBSOCKET ###########

        const socket = io();

        socket.on('settings', function (data) {
            console.log("Otrzymano ustawienia:", data);

            // Wypełnianie formularza
            for (let key in data) {
                const element = $(`[name="${key}"]`);
                if (!element.length) continue;

                // Obsługa checkboxów
                if (element.attr('type') === 'hidden' && element.next().attr('type') === 'checkbox') {
                    const isChecked = parseInt(data[key]) === 1;
                    element.val(isChecked ? '1' : '0');
                    element.next().prop('checked', isChecked);
                }
                // Obsługa ręcznej krzywej
                else if (key === 'SETTINGS$hcman' && Array.isArray(data[key])) {
                    element.val(data[key].join(','));
                    const hcmanValues = data[key];
                    $("#hcmantable input[type='number']").each(function (index) {
                        if (index < hcmanValues.length) {
                            $(this).val(hcmanValues[index]);
                        }
                    });
                }
                // Pozostałe pola (text, select, number)
                else {
                    element.val(data[key]);
                }
            }

            // --- KLUCZOWA CZĘŚĆ ---
            // Po wypełnieniu wszystkich pól, ręcznie wywołujemy funkcje aktualizujące UI
            console.log("Aktualizowanie widoku UI po załadowaniu danych...");
            applyHeatingCurveFromHidden();
            updateHeatingControlView();
            updateAntiOnOffView();
            updateHeatingCurveView();
            updatePresetDependency();
            updateHaDependencies();
            updateZoneViews();
            updateAntifreezeCustomView();
            updateDhwModeViews();
            updateDhwViews();
            recalc(); // Aby wykres odświeżył się z załadowanymi danymi

            // Logika dla statusu połączenia HPI (pozostawiona bez zmian)
            if ('hpiconn' in data) {
                switch (data['hpiconn']) {
                    case 'N.A.': {
                        const unk = t('set.hpiunknown', 'Unknown');
                        $('#hpistatus').text(unk);
                        $('#hpistatus')[0].classList.add('text-warning');
                        $('#hpisid').text(unk);
                        $("#hpicontrol")[0].classList.add('btn-outline-warning');
                        $("#hpicontrol")[0].classList.add('disabled');
                        $("#hpicontrol").text(unk);
                        break;
                    }
                    case null: {
                        const disconnected = t('set.hpidisconnected', 'Disconnected');
                        const unk = t('set.hpiunknown', 'Unknown');
                        const connect = t('set.hpiconnect', 'Connect');
                        removeClassesByPrefix('#hpistatus', 'text-');
                        removeClassesByPrefix('#hpicontrol', 'btn-outline-');
                        $('#hpistatus').text(disconnected);
                        $('#hpistatus')[0].classList.add('text-danger');
                        $('#hpisid').text(unk);
                        $("#hpicontrol")[0].classList.remove('disabled');
                        $("#hpicontrol")[0].classList.add('btn-outline-success');
                        $("#hpicontrol").text(connect);
                        break;
                    }
                    case false: {
                        const disconnected = t('set.hpidisconnected', 'Disconnected');
                        const unk = t('set.hpiunknown', 'Unknown');
                        const connect = t('set.hpiconnect', 'Connect');
                        removeClassesByPrefix('#hpistatus', 'text-');
                        removeClassesByPrefix('#hpicontrol', 'btn-outline-');
                        $('#hpistatus').text(disconnected);
                        $('#hpistatus')[0].classList.add('text-danger');
                        $('#hpisid').text(unk);
                        $("#hpicontrol")[0].classList.remove('disabled');
                        $("#hpicontrol")[0].classList.add('btn-outline-success');
                        $("#hpicontrol").text(connect);
                        $("#hpicontrol")[0].classList.add('disabled');
                        break;
                    }
                    default: {
                        const connected = t('set.hpiconnected', 'Connected');
                        const disconnect = t('set.hpidisconnect', 'Disconnect');
                        removeClassesByPrefix('#hpistatus', 'text-');
                        removeClassesByPrefix('#hpicontrol', 'btn-outline-');
                        $('#hpistatus').text(connected);
                        $('#hpisid').text(data['hpiconn']);
                        $('#hpistatus')[0].classList.add('text-success');
                        $("#hpicontrol")[0].classList.remove('disabled');
                        $("#hpicontrol")[0].classList.add('btn-outline-danger');
                        $("#hpicontrol").text(disconnect);
                    }
                }
            }
        });

        socket.on('return', function (msg) {
            if (msg.info && msg.status) {
                appendAlert(msg.info, msg.status);
            }
            console.log("Odpowiedź z serwera:", msg);
        });

        // Przycisk zapisu
        $("#saveButton").on("click", function (event) {
            event.preventDefault();
            if (!socket.connected) {
                console.warn("Socket nie jest połączony!");
                appendAlert("Brak połączenia z serwerem!", "danger");
                return;
            }

            let formData = { settings: {} };
            $("#settingsForm").find("select, input").each(function () {
                if (this.name) {
                    formData.settings[this.name] = $(this).val();
                }
            });

            isFormDirty = false; // Resetujemy flagę po wysłaniu
            socket.emit("client", formData);
            console.log("Wysłano ustawienia:", formData);
        });

        // Logika HPI App (pozostawiona bez zmian)
        $('#hpicontrol').click(function () {
            const command = $(this).text().toLowerCase();
            socket.emit('client', { hpiapp: command });
        });

        // ########### SERVICE TAB (Temp compensation + errors) ###########
        function svcToNumber(v) {
            if (v === null || v === undefined) return null;
            const s = String(v).trim().replace("°C", "").replace(",", ".");
            if (!s || s.toUpperCase() === "N.A" || s.toLowerCase() === "nan") return null;
            const n = Number(s);
            return Number.isFinite(n) ? n : null;
        }

        // Show as delta vs 0.0, with sign for non-zero values
        function svcFmtDelta(v) {
            const n = svcToNumber(v);
            if (n === null) return "0.0";
            const r = Math.round(n * 2) / 2; // keep 0.5 steps in UI
            const s = r.toFixed(1);
            if (Math.abs(r) < 0.05) return "0.0";
            return (r > 0 ? "+" : "") + s;
        }
        function svcFmtPlain(v) {
            if (v === null || v === undefined) return "N.A";
            const s = String(v).trim();
            if (!s || s.toUpperCase() === "N.A" || s.toLowerCase() === "nan") return "N.A";
            return s;
        }

        function loadServiceData() {
            // Only run if Service tab exists on this page
            if (!$("#settings-service-tab").length) return;

            $.getJSON("/getdata", function (d) {
                // Temperature compensation
                // Prefer actual readback if available, otherwise fall back to last set value.
                const curN = svcToNumber(d.tempcompensation);
                const setN = svcToNumber(d.tempcompensation_set);
                const display = (curN !== null) ? curN : ((setN !== null) ? setN : 0.0);

                $("#tempcompensation_set").val(svcFmtDelta(display));

                // DHW temperature compensation (A0d)
                const dhwCurN = svcToNumber(d.dhwcompensation);
                const dhwSetN = svcToNumber(d.dhwcompensation_set);
                const dhwDisplay = (dhwCurN !== null) ? dhwCurN : ((dhwSetN !== null) ? dhwSetN : 0.0);
                $("#dhwcompensation_set").val(svcFmtDelta(dhwDisplay));

                // Service test switches + availability
                window.__svc = window.__svc || {};
                window.__svc.pump = d.pump;
                window.__svc.heater = d.heater;
                window.__svc.heatdemand = d.heatdemand;
                window.__svc.compinfo = d.compinfo;
                window.__svc.set_pump = d.set_pump;
                window.__svc.set_heater = d.set_heater;
                updateServiceTestUI();

                // Errors + info
                $("#service_error").val(svcFmtPlain(d.error));
                $("#service_lasterror").val(svcFmtPlain(d.lasterror));
                $("#service_archerror").val(svcFmtPlain(d.archerror));
                $("#service_firmware").val(svcFmtPlain(d.firmware));
            });
        }

        function serviceTestAllowed(state) {
            state = state || (window.__svc || {});
            const pump = String(state.pump || '').trim().toLowerCase();
            const heater = String(state.heater || '').trim().toLowerCase();
            const heatdemand = String(state.heatdemand || '').trim().toLowerCase();
            const compinfo = state.compinfo;

            const pumpOff = (pump === 'off' || pump === '0' || pump === 'false' || pump === '');
            const heaterOff = (heater === 'off' || heater === '0' || heater === 'false' || heater === '');
            const heatdemandZero = (heatdemand === '0' || heatdemand === 'off' || heatdemand === 'false');

            let compStopped = false;
            try {
                if (Array.isArray(compinfo) && compinfo.length >= 2) {
                    const a = Number(compinfo[0]);
                    const b = Number(compinfo[1]);
                    compStopped = Math.max(a || 0, b || 0) <= 0.1;
                } else if (Array.isArray(compinfo) && compinfo.length === 1) {
                    const a = Number(compinfo[0]);
                    compStopped = (a || 0) <= 0.1;
                } else {
                    compStopped = false;
                }
            } catch (e) {
                compStopped = false;
            }

            return pumpOff && heaterOff && heatdemandZero && compStopped;
        }

        function updateServiceTestUI() {
            if (!$("#settings-service-tab").length) return;

            const st = window.__svc || {};
            const pumpChecked = String(st.set_pump || '').toLowerCase() === 'on';
            const heaterChecked = String(st.set_heater || '').toLowerCase() === 'on';

            $("#service_set_pump").prop('checked', pumpChecked);
            $("#service_set_heater").prop('checked', heaterChecked);

            const allow = serviceTestAllowed(st);

            // Availability box on the right
            const $avail = $("#service_test_available");
            if ($avail.length) {
                $avail.val(allow ? t('set.available', 'Dostępny') : t('set.unavailable', 'Niedostępny'));
            }

            // Allow turning OFF even when conditions are not met
            $("#service_set_pump").prop('disabled', (!allow && !pumpChecked));
            $("#service_set_heater").prop('disabled', (!allow && !heaterChecked));

            // Note: we display availability only in the right-side box
        }

        function getTempCompSetNumeric() {
            const n = svcToNumber($("#tempcompensation_set").val());
            return (n === null) ? 0.0 : n;
        }

        function setTempCompensation(value) {
            // Clamp and round to 0.5
            let v = Number(value);
            if (!Number.isFinite(v)) v = 0.0;
            v = Math.max(-15.0, Math.min(15.0, v));
            v = Math.round(v * 2) / 2;

            // UI: optimistic update (delta formatting)
            $("#tempcompensation_set").val(svcFmtDelta(v));
            // If readback is not instant, keep current in sync for better UX
            // Send to backend
            $("#tempcomp_minus, #tempcomp_plus").prop("disabled", true);
            $.ajax({
                url: "/tempcompchange",
                method: "POST",
                data: { value: v.toFixed(1) }
            }).done(function (resp) {
                if (resp && resp.msg && resp.state) {
                    appendAlert(resp.msg, resp.state);
                }
                // Refresh readback shortly after write
                setTimeout(loadServiceData, 400);
            }).fail(function () {
                appendAlert("Temp compensation: request failed", "danger");
                loadServiceData();
            }).always(function () {
                $("#tempcomp_minus, #tempcomp_plus").prop("disabled", false);
            });
        }

        function getDhwTempCompSetNumeric() {
            const n = svcToNumber($("#dhwcompensation_set").val());
            return (n === null) ? 0.0 : n;
        }

        function setDhwTempCompensation(value) {
            let v = Number(value);
            if (!Number.isFinite(v)) v = 0.0;
            v = Math.max(-15.0, Math.min(15.0, v));
            v = Math.round(v * 2) / 2;
            $("#dhwcompensation_set").val(svcFmtDelta(v));
            $("#dhwtempcomp_minus, #dhwtempcomp_plus").prop("disabled", true);
            $.ajax({
                url: "/dhwcompchange",
                method: "POST",
                data: { value: v.toFixed(1) }
            }).done(function (resp) {
                if (resp && resp.msg && resp.state) {
                    appendAlert(resp.msg, resp.state);
                }
                setTimeout(loadServiceData, 400);
            }).fail(function () {
                appendAlert("DHW compensation: request failed", "danger");
                loadServiceData();
            }).always(function () {
                $("#dhwtempcomp_minus, #dhwtempcomp_plus").prop("disabled", false);
            });
        }

        // Buttons + / -
        $("#tempcomp_minus").on("click", function () {
            const v = getTempCompSetNumeric() - 0.5;
            setTempCompensation(v);
        });
        $("#tempcomp_plus").on("click", function () {
            const v = getTempCompSetNumeric() + 0.5;
            setTempCompensation(v);
        });

        // DHW comp buttons + / -
        $("#dhwtempcomp_minus").on("click", function () {
            const v = getDhwTempCompSetNumeric() - 0.5;
            setDhwTempCompensation(v);
        });
        $("#dhwtempcomp_plus").on("click", function () {
            const v = getDhwTempCompSetNumeric() + 0.5;
            setDhwTempCompensation(v);
        });

        // Service test switches (socket)
        function emitServiceTest(key, on) {
            try {
                if (socket && typeof socket.emit === 'function') {
                    const payload = {}; payload[key] = on ? 'on' : 'off';
                    socket.emit('client', payload);
                }
            } catch (e) {}
        }

        $("#service_set_pump").on("change", function () {
            const checked = $(this).is(":checked");
            if (checked && !serviceTestAllowed()) {
                // snap back
                $(this).prop('checked', false);
                updateServiceTestUI();
                appendAlert(t('set.service_test_not_ready', 'Not available (conditions not met)'), 'warning');
                return;
            }
            // Optimistic UI: keep the switch in sync immediately, backend will confirm/deny via data_update
            window.__svc = window.__svc || {};
            window.__svc.set_pump = checked ? 'on' : 'off';
            updateServiceTestUI();
            emitServiceTest('set_pump', checked);
        });

        $("#service_set_heater").on("change", function () {
            const checked = $(this).is(":checked");
            if (checked && !serviceTestAllowed()) {
                $(this).prop('checked', false);
                updateServiceTestUI();
                appendAlert(t('set.service_test_not_ready', 'Not available (conditions not met)'), 'warning');
                return;
            }
            window.__svc = window.__svc || {};
            window.__svc.set_heater = checked ? 'on' : 'off';
            updateServiceTestUI();
            emitServiceTest('set_heater', checked);
        });

        // Initial + periodic refresh (lightweight)
        loadServiceData();
        setInterval(loadServiceData, 5000);

        // Live updates (auto-off, etc.)
        try {
            if (socket && typeof socket.on === 'function') {
                socket.on('data_update', function (msg) {
                    if (!msg) return;
                    window.__svc = window.__svc || {};
                    if (msg.hasOwnProperty('set_pump')) window.__svc.set_pump = msg.set_pump;
                    if (msg.hasOwnProperty('set_heater')) window.__svc.set_heater = msg.set_heater;
                    if (msg.hasOwnProperty('pump')) window.__svc.pump = msg.pump;
                    if (msg.hasOwnProperty('heater')) window.__svc.heater = msg.heater;
                    if (msg.hasOwnProperty('heatdemand')) window.__svc.heatdemand = msg.heatdemand;
                    if (msg.hasOwnProperty('compinfo')) window.__svc.compinfo = msg.compinfo;
                    updateServiceTestUI();
                });
            }
        } catch (e) {}

        // Keep global "Save" button right under the last content of the active tab
        function placeSaveButtonIntoActiveTab() {
            const $row = $("#saveRow");
            if (!$row.length) return;
            const $activePane = $(".tab-pane.active.show");
            if ($activePane.length) {
                $activePane.append($row);
            }
        }



        // Hide global "Save" button on Service tab (not needed there)
        function toggleSaveButtonForTab(tabId) {
            const $row = $("#saveRow");
            if (!$row.length) return;
            if (tabId === "settings-service") {
                $row.addClass('d-none');
            } else {
                $row.removeClass('d-none');
            }
        }
        // Refresh when user opens a tab + move Save button under that tab content
        document.addEventListener('shown.bs.tab', function (e) {
            try {
                const targetSel = (e && e.target) ? (e.target.getAttribute("data-bs-target") || e.target.getAttribute("href")) : null;
                if (targetSel) {
                    $(targetSel).append($("#saveRow"));
                }

                if (e && e.target && e.target.id) {
                    toggleSaveButtonForTab(e.target.id);
                    if (e.target.id === "settings-service") {
                        loadServiceData();
                    }
                }
            } catch (err) { }
        });

        // Initial state (place Save button under current tab)
        placeSaveButtonIntoActiveTab();
        toggleSaveButtonForTab($(".nav-link.active").attr("id"));

    });

    // ########### LOGIKA WYKRESU (pozostawiona w większości bez zmian) ###########

    var colors = ['#007bff', '#28a745', '#333333', '#c3e6cb', '#dc3545', '#6c757d'];
    var chLine = document.getElementById('hcurvechart');
    var myChart; // Zmienna globalna dla wykresu

    var chartData = {
        labels: Array.from({ length: 41 }, (_, i) => i - 20).map(String), // Lepszy sposób generowania etykiet
        datasets: [{
            label: "Auto",
            data: [],
            backgroundColor: 'transparent',
            borderColor: colors[0],
            borderWidth: 4,
            pointBackgroundColor: colors[0]
        }, {
            label: "Static",
            data: [],
            backgroundColor: 'transparent',
            borderColor: colors[1],
            borderWidth: 4,
            pointBackgroundColor: colors[1]
        }]
    };

    if (chLine) {
        myChart = new Chart(chLine, {
            type: 'line',
            data: chartData,
            options: { /* ... Twoje opcje ... */ }
        });
    }

    function recalc() {
        if (!myChart) return; // Zabezpieczenie, jeśli wykres nie istnieje

        const settemp = 22; // Powinno być pobierane z ustawień
        const insidetemp = parseFloat($("#tempRange").val()) || settemp;
        const outsidetemp = 11; // Powinno być pobierane z danych

        $("#customtemp").text("Temperatura wewnątrz: " + insidetemp);

        const slope = parseFloat($('#slope').val()) || 0;
        const ps = parseFloat($('#pshift').val()) || 0;
        const amp = parseFloat($('#hcamp').val()) || 0;

        const autoData = myChart.data.labels.map(element => {
            const outTemp = parseFloat(element);
            const t1 = (outsidetemp / (320 - (outsidetemp * 4)));
            const t2 = Math.pow(settemp, t1);
            return ((((0.55 * slope * t2) * (((-outTemp + 20) * 2) + settemp + ps) + ((settemp - insidetemp) * amp)) + ps) * 2) / 2;
        });

        const staticData = myChart.data.labels.map(element => {
            const outTemp = parseFloat(element);
            return (settemp + (slope * 20) * Math.pow(((settemp - outTemp) / 20), 0.7));
        });

        myChart.data.datasets[0].data = autoData;
        myChart.data.datasets[1].data = staticData;
        myChart.update();
    }

    // ########### LOGIKA NIEZAPISANYCH ZMIAN (pozostawiona bez zmian) ###########
    let isFormDirty = false;
    const modal = new bootstrap.Modal(document.getElementById("unsavedChangesModal"));
    let pendingNavigation = null;

    document.addEventListener("input", (event) => {
        const el = event && event.target ? event.target : null;
        if (!el || !el.matches("input, select, textarea")) return;

        // Service tab contains only "live" controls (no saving) – don't mark page as dirty
        // so leaving the page doesn't show the unsaved-changes modal after using service tests.
        if (el.closest && el.closest("#settings-service-tab")) return;

        // Defensive: ignore readonly/disabled fields
        if (el.hasAttribute && (el.hasAttribute("readonly") || el.disabled)) return;

        isFormDirty = true;
    });
    document.querySelectorAll(".navl").forEach(link => {
        link.addEventListener("click", (event) => {
            if (isFormDirty) {
                event.preventDefault();
                pendingNavigation = event.target.href;
                modal.show();
            }
        });
    });
    document.getElementById("leavePageBtn").addEventListener("click", () => {
        if (pendingNavigation) {
            window.location.href = pendingNavigation;
        }
    });

    // --- System tab: show server (DietPi) date & time ---
    function updateSystemDateTime() {
        const el = document.getElementById('system_datetime_value');
        if (!el) return;
        $.getJSON('/api/system_time')
            .done(function (data) {
                const val = (data && (data.display || data.iso)) ? (data.display || data.iso) : '';
                if ('value' in el) { el.value = val; } else { el.textContent = val; }
            })
            .fail(function () {
                // ignore
            });
    }

    // initial + refresh when switching tabs + periodic refresh
    updateSystemDateTime();
    setInterval(updateSystemDateTime, 30000);
    document.addEventListener('shown.bs.tab', function (ev) {
        // refresh when System tab is shown
        if (ev && ev.target && (ev.target.id === 'settings-system' || ev.target.getAttribute('data-bs-target') === '#settings-system-tab')) {
            updateSystemDateTime();
        }
    });

    // Inicjalizacja tooltipów
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    } catch(e) { console.error('HPI inline script error (settings.html #2)', e); }
  });

  // From templates/weblog.html (block 1)
  onReady(function(){
    if(!(PAGE === 'weblog')) return;
    try {
var journalDiv = document.getElementById('journal');
        var eventSource = new EventSource('/stream');

        eventSource.onmessage = function(event) {
            var line = document.createElement('p');
            line.className = 'journal-entry';
            line.innerHTML = event.data;
            journalDiv.appendChild(line);

            setTimeout(function() {
                line.classList.add('fadeout');
            }, 2000);
        };
    } catch(e) { console.error('HPI inline script error (weblog.html #1)', e); }
  });

})();
