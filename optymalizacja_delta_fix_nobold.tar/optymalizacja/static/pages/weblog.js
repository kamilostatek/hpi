/* === Inline scripts extracted from templates (split) === */
(function(){
  'use strict';
  const PAGE = (document.body && document.body.dataset) ? (document.body.dataset.page || '') : '';
  function onReady(fn){
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  // From templates/weblog.html (block 1)
  onReady(function(){
    if(!(PAGE === 'weblog')) return;
    try {
var journalDiv = document.getElementById('journal');
        var eventSource = new EventSource('/stream');

        eventSource.onmessage = function(event) {
            var line = document.createElement('p');
            line.className = 'journal-entry';
            line.innerHTML = event.data;
            journalDiv.appendChild(line);

            setTimeout(function() {
                line.classList.add('fadeout');
            }, 2000);
        };
    } catch(e) { console.error('HPI inline script error (weblog.html #1)', e); }
  });

})();
