/* === Inline scripts extracted from templates (split) === */
(function(){
  'use strict';
  const PAGE = (document.body && document.body.dataset) ? (document.body.dataset.page || '') : '';
  function onReady(fn){
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  // From templates/settings.html (block 1)
  onReady(function(){
    if(!(PAGE === 'settings')) return;
    try {
(function () {
        // Tooltipy odświeżamy TYLKO w aktywnej zakładce (a nie po całym formularzu),
        // żeby przełączanie tabów nie powodowało kosztownych skanów DOM.
        function refreshTooltipsBs5(root) {
            if (!window.bootstrap || !bootstrap.Tooltip) return;
            root = root || document;
            root.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
                try {
                    var inst = bootstrap.Tooltip.getInstance(el);
                    if (inst) inst.dispose();
                    new bootstrap.Tooltip(el);
                } catch (e) {
                    // nic
                }
            });
        }

        function getActiveTabRoot(selector) {
            if (selector) {
                var el = document.querySelector(selector);
                if (el) return el;
            }
            // fallback: aktywny panel, jeśli istnieje
            var active = document.querySelector('#settingsForm .tab-pane.active.show') || document.querySelector('.tab-pane.active.show');
            return active || (document.getElementById('settingsForm') || document);
        }

        function run(selector) {
            var root = getActiveTabRoot(selector);
            refreshTooltipsBs5(root);
        }

        // 1) Po wczytaniu strony (i18next zwykle kończy init chwilę później)
        window.addEventListener('load', function () {
            setTimeout(run, 50);
            setTimeout(run, 400);
            setTimeout(run, 1200);
        });

        // 2) Po zmianie zakładki (tooltips w ukrytych tabach też mają się odświeżyć)
        document.addEventListener('shown.bs.tab', function (e) {
            var targetSel = null;
            try {
                if (e && e.target) targetSel = (e.target.getAttribute('data-bs-target') || e.target.getAttribute('href'));
            } catch (_) {}
            setTimeout(function(){ run(targetSel); }, 0);
        });

        // 3) Jeśli i18next jest dostępny, odśwież po init i po zmianie języka
        function attachI18nHooks() {
            if (!window.i18next || typeof i18next.on !== 'function') return false;
            i18next.on('initialized', function () { setTimeout(function(){ run(); }, 0); });
            i18next.on('languageChanged', function () { setTimeout(function(){ run(); }, 0); });
            return true;
        }

        if (!attachI18nHooks()) {
            // jeśli i18next ładuje się później, spróbuj przez chwilę dociągnąć hooki
            var tries = 0;
            var timer = setInterval(function () {
                tries += 1;
                if (attachI18nHooks() || tries > 100) clearInterval(timer); // ~5s
            }, 50);
        }
    })();
    } catch(e) { console.error('HPI inline script error (settings.html #1)', e); }
  });

  // From templates/settings.html (block 2)
  onReady(function(){
    if(!(PAGE === 'settings')) return;
    try {
// Funkcja do usuwania klas z danym prefiksem (zostawiłem, jest przydatna)
    function removeClassesByPrefix(selector, prefix) {
        $(selector).removeClass(function (index, className) {
            return (className.match(new RegExp('\\b' + prefix + '\\S+', 'g')) || []).join(' ');
        });
    }

    // Prosty helper do tłumaczeń dynamicznych (statusy/przyciski)
    function t(key, fallback) {
        try {
            if (window.i18next && typeof i18next.t === 'function') {
                const v = i18next.t(key);
                if (v && v !== key) return v;
            }
        } catch (e) { }
        return (fallback !== undefined) ? fallback : key;
    }

    // Całą logikę umieszczamy wewnątrz $(document).ready(), aby mieć pewność, że DOM jest załadowany.
    $(document).ready(function () {

        // ########### LOGIKA UI (refaktoryzacja) ###########

        function updateAntiOnOffView() {
            const isChecked = $("#antionoff").is(":checked");
            const presetMode = $('[name="SETTINGS$presetautochange"]').val();
            const presetManual = (presetMode === 'manual');

            // blok z ustawieniami delty aktywny tylko gdy Anty ON-OFF jest włączone
            $("#antionoffsettings").toggleClass("disableddiv", !isChecked);

            // "Zmiana trybu" jest blokowana tylko gdy Anty ON-OFF jest włączone
            $("#divpresetchange").toggleClass("disableddiv", isChecked);

            // Te pola mają być wyszarzone:
            // - gdy Anty ON-OFF jest włączone, albo
            // - gdy "Zmiana trybu" jest ustawiona na Manual
            $("#divflimittemp, #divpresetquiet, #divpresetturbo").toggleClass("disableddiv", (isChecked || presetManual));
        }



        // Sterowanie ogrzewaniem: Krzywa grzewcza vs Bezpośrednio

        // --- Pamiętanie ostatniego typu krzywej (auto/static/manual) ---
        const LAST_CURVE_LS_KEY = 'hpi_last_curve_type';
        let lastCurveType = null;

        function isValidCurveType(v) {
            return v === 'auto' || v === 'static' || v === 'manual';
        }

        function getCurveTypeFromConfigHidden() {
            const v = String($("#heatingcurve_hidden").val() || '').toLowerCase().trim();
            return isValidCurveType(v) ? v : null;
        }

        function loadLastCurveType() {
            // 1) pamięć runtime (np. po przełączeniach w tej sesji)
            if (isValidCurveType(lastCurveType)) return lastCurveType;

            // 2) localStorage (jeśli było wcześniej ustawione)
            try {
                const ls = String(localStorage.getItem(LAST_CURVE_LS_KEY) || '').toLowerCase().trim();
                if (isValidCurveType(ls)) return ls;
            } catch (e) { }

            // 3) ostatecznie
            return 'auto';
        }

        function saveLastCurveType(v) {
            if (!isValidCurveType(v)) return;
            lastCurveType = v;
            try { localStorage.setItem(LAST_CURVE_LS_KEY, v); } catch (e) { }
        }
        function getEffectiveHeatingCurveMode() {
            const ctrl = $("#heatingcontrol").val();
            if (ctrl === 'direct') return 'directly';
            return $("#heatingcurve").val();
        }

        function applyHeatingCurveFromHidden() {
            const v = String($("#heatingcurve_hidden").val() || '').toLowerCase().trim();

            if (v === 'directly' || v === 'direct') {
                // Tryb Bezpośrednio: hidden trzyma "directly", ale typ krzywej ma pozostać ostatnio wybrany
                $("#heatingcontrol").val('direct');
                const remembered = loadLastCurveType();
                $("#heatingcurve").val(remembered);
            } else if (isValidCurveType(v)) {
                // Tryb Krzywa: hidden = auto/static/manual
                $("#heatingcontrol").val('curve');
                $("#heatingcurve").val(v);
                saveLastCurveType(v);
            } else {
                // Fallback
                $("#heatingcontrol").val('curve');
                const remembered = loadLastCurveType();
                $("#heatingcurve").val(remembered);
                saveLastCurveType(remembered);
            }
        }

        function syncHeatingCurveHidden() {
            const effective = getEffectiveHeatingCurveMode();
            $("#heatingcurve_hidden").val(effective);
        }

        function updateHeatingControlView() {
            const isDirect = $("#heatingcontrol").val() === 'direct';
            $("#heatingcurve_section").toggleClass('disableddiv', isDirect);
            // Direct mode options are only active when Heating control = Direct
            $("#directmode_section").toggleClass('disableddiv', !isDirect);
            syncHeatingCurveHidden();
        }

        function updateHeatingCurveView() {
            const selectedCurve = getEffectiveHeatingCurveMode();
            const divVisibility = {
                auto: { slope: true, pshift: true, hcamp: true, manual: false },
                static: { slope: true, pshift: false, hcamp: false, manual: false },
                manual: { slope: false, pshift: false, hcamp: false, manual: true },
                directly: { slope: false, pshift: false, hcamp: false, manual: false }
            };

            const config = divVisibility[selectedCurve] || divVisibility.directly; // Domyślna wartość

            $("#divslope").toggleClass("disableddiv", !config.slope);
            $("#divpshift").toggleClass("disableddiv", !config.pshift);
            $("#divhcamp").toggleClass("disableddiv", !config.hcamp);
            $("#divhcmanual").toggleClass("disableddiv", !config.manual);
        }

        function updatePresetDependency() {
            const presetMode = $('[name="SETTINGS$presetautochange"]').val();
            const antionoffCheckbox = $('#antionoff');
            const antionoffContainer = antionoffCheckbox.closest('.list-group-item');

            if (presetMode === 'manual') {
                antionoffContainer.addClass('disableddiv');
                if (antionoffCheckbox.is(':checked')) {
                    antionoffCheckbox.prop('checked', false).trigger('change');
                }
            } else {
                antionoffContainer.removeClass('disableddiv');
            }

            // odśwież zależności pól (m.in. wyszarzanie temperatur) po zmianie trybu
            updateAntiOnOffView();
        }


        function updateZoneViews() {
            const frostOn = $("#zone_frost_enable").is(":checked");
            $("#zone_frost_settings").toggleClass("disableddiv", !frostOn);

            const warmOn = $("#zone_warm_enable").is(":checked");
            $("#zone_warm_settings").toggleClass("disableddiv", !warmOn);
        }


function updateAntifreezeCustomView() {
    const on = $("#antifreeze_custom_enable").is(":checked");
    $("#antifreeze_custom_settings").toggleClass("disableddiv", !on);
}

        function updateDhwViews() {
    const DhwON = $("#dhwuse").is(":checked");
    $("#dhw_dependent").toggleClass("disableddiv", !DhwON);

    // Optional: when DHW is OFF, reset dependent switches
    if (!DhwON) {
        $("#dhwwl").prop("checked", false).trigger("change");
        $("#dhwscheduler").prop("checked", false).trigger("change");
    }
}
function updateDhwModeViews() {
            const DhwModeON = $("#dhwwl").is(":checked");
            $("#dhw_mode_settings").toggleClass("disableddiv", !DhwModeON);

        }

        // NOWA FUNKCJA DLA ZALEŻNOŚCI HOME ASSISTANT
        function updateHaDependencies() {
            // Krok 1: Sprawdzenie ogólnej konfiguracji HA (Warunek Główny)
            const haAddr = $('[name="HOMEASSISTANT$HAADDR"]').val().trim();
            const haPort = $('[name="HOMEASSISTANT$HAPORT"]').val().trim();
            const haKey = $('[name="HOMEASSISTANT$KEY"]').val().trim();
            const isHaCoreConfigured = haAddr !== '' && haPort !== '' && haKey !== '';

            // Krok 2: Sprawdzenie każdego selecta z osobna

            // 2a. Czujnik temperatury wewnętrznej
            const insideSensorEntity = $('[name="HOMEASSISTANT$insidesensor"]').val().trim();
            const canUseHaForInsideTemp = isHaCoreConfigured && insideSensorEntity !== '';
            $('[name="SETTINGS$insidetemp"] option[value="ha"]').prop('disabled', !canUseHaForInsideTemp);

            // 2b. Czujnik temperatury zewnętrznej
            const outsideSensorEntity = $('[name="HOMEASSISTANT$outsidesensor"]').val().trim();
            const canUseHaForOutsideTemp = isHaCoreConfigured && outsideSensorEntity !== '';
            $('[name="SETTINGS$outsidetemp"] option[value="ha"]').prop('disabled', !canUseHaForOutsideTemp);

            // 2c. Czujnik wilgotności
            const humiditySensorEntity = $('[name="HOMEASSISTANT$humiditysensor"]').val().trim();
            const canUseHaForHumidity = isHaCoreConfigured && humiditySensorEntity !== '';
            $('[name="SETTINGS$humidity"] option[value="ha"]').prop('disabled', !canUseHaForHumidity);

            // 2d. Czujnik temperatury CWU (DHW)
            const dhwSensorEntity = $('[name="HOMEASSISTANT$dhwsensor"]').val().trim();
            const canUseHaForDhwTemp = isHaCoreConfigured && dhwSensorEntity !== '';
            const $dhwTempSelect = $('[name="SETTINGS$dhwtemp"]');
            $dhwTempSelect.find('option[value="ha"]').prop('disabled', !canUseHaForDhwTemp);
            // Jeżeli użytkownik miał wybrane HA, a brakuje encji / konfiguracji — wracamy do wbudowanego
            if (!canUseHaForDhwTemp && ($dhwTempSelect.val() || '').toLowerCase() === 'ha') {
                $dhwTempSelect.val('builtin');
            }
        }

        function assembleManualHeatingCurve() {
            const values = $("#hcmantable input[type='number']").map(function () {
                return $(this).val();
            }).get();
            $('#hcman').val(values.join(','));
        }

        // Init state from server-rendered hidden value
        applyHeatingCurveFromHidden();
        updateHeatingControlView();
        updateHeatingCurveView();

        // ########### POWIĄZANIA ZDARZEŃ (unobtrusive JS) ###########

        // Zdarzenia dla checkboxów z ukrytym inputem
        // To jest ogólna obsługa, która zadziała dla każdego checkboxa, który ma tuż przed sobą ukryty input
        $('input[type="checkbox"]').on('change', function () {
            const hiddenInput = $(this).prev('input[type="hidden"]');
            if (hiddenInput.length) {
                hiddenInput.val($(this).is(':checked') ? '1' : '0');
            }
        });

        // Powiązania dla specyficznych kontrolek UI
        $("#antionoff").on('change', updateAntiOnOffView);
        $("#heatingcontrol").on('change', function () {
            const isDirect = $("#heatingcontrol").val() === 'direct';

            if (isDirect) {
                // przechodzimy na Bezpośrednio: zapamiętaj ostatni typ krzywej
                const cur = String($("#heatingcurve").val() || '').toLowerCase().trim();
                if (isValidCurveType(cur)) saveLastCurveType(cur);
            } else {
                // wracamy na Krzywą: przywróć ostatnio wybrany typ (z configu lub pamięci)
                const fromConfig = getCurveTypeFromConfigHidden();
                const remembered = fromConfig || loadLastCurveType();
                $("#heatingcurve").val(remembered);
                saveLastCurveType(remembered);
            }

            updateHeatingControlView();
            updateHeatingCurveView();
        });
        $("#heatingcurve").on('change', function () {
            const cur = String($("#heatingcurve").val() || '').toLowerCase().trim();
            if (isValidCurveType(cur)) saveLastCurveType(cur);
            syncHeatingCurveHidden();
            updateHeatingCurveView();
        });
        $("#zone_frost_enable, #zone_warm_enable").on('change', updateZoneViews);
        $("#antifreeze_custom_enable").on('change', updateAntifreezeCustomView);
        $("#dhwwl").on('change', updateDhwModeViews);
        $("#dhwuse").on('change', updateDhwViews);
        $("#hcmantable input[type='number']").on('change', assembleManualHeatingCurve);

        // Zdarzenia dla wykresu
        $("#tempRange, #slope, #pshift, #hcamp").on('input change', recalc);
        $('[name="SETTINGS$presetautochange"]').on('change', function () {
            const selectedMode = $(this).val();
            const antionoffCheckbox = $('#antionoff');

            // Sprawdzamy, czy użytkownik włącza tryb 'manual', a opcja 'antionoff' jest aktywna
            if (selectedMode === 'manual' && antionoffCheckbox.is(':checked')) {
                // Wyświetlamy ostrzeżenie
                appendAlert('Opcja "Anty ON-OFF" zostanie wyłączona, ponieważ jest niekompatybilna z ręczną zmianą trybu.', 'warning');
            }

            // Niezależnie od alertu, zawsze aktualizujemy stan UI
            updatePresetDependency();
        });

        $('[name^="HOMEASSISTANT$"]').on('input', updateHaDependencies);


        // ########### LOGIKA WEBSOCKET ###########

        const socket = io();

        socket.on('settings', function (data) {
            console.log("Otrzymano ustawienia:", data);

            // Wypełnianie formularza
            for (let key in data) {
                const element = $(`[name="${key}"]`);
                if (!element.length) continue;

                // Obsługa checkboxów
                if (element.attr('type') === 'hidden' && element.next().attr('type') === 'checkbox') {
                    const isChecked = parseInt(data[key]) === 1;
                    element.val(isChecked ? '1' : '0');
                    element.next().prop('checked', isChecked);
                }
                // Obsługa ręcznej krzywej
                else if (key === 'SETTINGS$hcman' && Array.isArray(data[key])) {
                    element.val(data[key].join(','));
                    const hcmanValues = data[key];
                    $("#hcmantable input[type='number']").each(function (index) {
                        if (index < hcmanValues.length) {
                            $(this).val(hcmanValues[index]);
                        }
                    });
                }
                // Pozostałe pola (text, select, number)
                else {
                    element.val(data[key]);
                }
            }

            // --- KLUCZOWA CZĘŚĆ ---
            // Po wypełnieniu wszystkich pól, ręcznie wywołujemy funkcje aktualizujące UI
            console.log("Aktualizowanie widoku UI po załadowaniu danych...");
            applyHeatingCurveFromHidden();
            updateHeatingControlView();
            updateAntiOnOffView();
            updateHeatingCurveView();
            updatePresetDependency();
            updateHaDependencies();
            updateZoneViews();
            updateAntifreezeCustomView();
            updateDhwModeViews();
            updateDhwViews();
            recalc(); // Aby wykres odświeżył się z załadowanymi danymi

            // Logika dla statusu połączenia HPI (pozostawiona bez zmian)
            if ('hpiconn' in data) {
                switch (data['hpiconn']) {
                    case 'N.A.': {
                        const unk = t('set.hpiunknown', 'Unknown');
                        $('#hpistatus').text(unk);
                        $('#hpistatus')[0].classList.add('text-warning');
                        $('#hpisid').text(unk);
                        $("#hpicontrol")[0].classList.add('btn-outline-warning');
                        $("#hpicontrol")[0].classList.add('disabled');
                        $("#hpicontrol").text(unk);
                        break;
                    }
                    case null: {
                        const disconnected = t('set.hpidisconnected', 'Disconnected');
                        const unk = t('set.hpiunknown', 'Unknown');
                        const connect = t('set.hpiconnect', 'Connect');
                        removeClassesByPrefix('#hpistatus', 'text-');
                        removeClassesByPrefix('#hpicontrol', 'btn-outline-');
                        $('#hpistatus').text(disconnected);
                        $('#hpistatus')[0].classList.add('text-danger');
                        $('#hpisid').text(unk);
                        $("#hpicontrol")[0].classList.remove('disabled');
                        $("#hpicontrol")[0].classList.add('btn-outline-success');
                        $("#hpicontrol").text(connect);
                        break;
                    }
                    case false: {
                        const disconnected = t('set.hpidisconnected', 'Disconnected');
                        const unk = t('set.hpiunknown', 'Unknown');
                        const connect = t('set.hpiconnect', 'Connect');
                        removeClassesByPrefix('#hpistatus', 'text-');
                        removeClassesByPrefix('#hpicontrol', 'btn-outline-');
                        $('#hpistatus').text(disconnected);
                        $('#hpistatus')[0].classList.add('text-danger');
                        $('#hpisid').text(unk);
                        $("#hpicontrol")[0].classList.remove('disabled');
                        $("#hpicontrol")[0].classList.add('btn-outline-success');
                        $("#hpicontrol").text(connect);
                        $("#hpicontrol")[0].classList.add('disabled');
                        break;
                    }
                    default: {
                        const connected = t('set.hpiconnected', 'Connected');
                        const disconnect = t('set.hpidisconnect', 'Disconnect');
                        removeClassesByPrefix('#hpistatus', 'text-');
                        removeClassesByPrefix('#hpicontrol', 'btn-outline-');
                        $('#hpistatus').text(connected);
                        $('#hpisid').text(data['hpiconn']);
                        $('#hpistatus')[0].classList.add('text-success');
                        $("#hpicontrol")[0].classList.remove('disabled');
                        $("#hpicontrol")[0].classList.add('btn-outline-danger');
                        $("#hpicontrol").text(disconnect);
                    }
                }
            }
        });

        socket.on('return', function (msg) {
            if (msg.info && msg.status) {
                appendAlert(msg.info, msg.status);
            }
            console.log("Odpowiedź z serwera:", msg);
        });

        // Przycisk zapisu
        $("#saveButton").on("click", function (event) {
            event.preventDefault();
            if (!socket.connected) {
                console.warn("Socket nie jest połączony!");
                appendAlert("Brak połączenia z serwerem!", "danger");
                return;
            }

            let formData = { settings: {} };
            $("#settingsForm").find("select, input").each(function () {
                if (this.name) {
                    formData.settings[this.name] = $(this).val();
                }
            });

            isFormDirty = false; // Resetujemy flagę po wysłaniu
            socket.emit("client", formData);
            console.log("Wysłano ustawienia:", formData);
        });

        // Logika HPI App (pozostawiona bez zmian)
        $('#hpicontrol').click(function () {
            const command = $(this).text().toLowerCase();
            socket.emit('client', { hpiapp: command });
        });

        // ########### SERVICE TAB (Temp compensation + errors) ###########
        function svcToNumber(v) {
            if (v === null || v === undefined) return null;
            const s = String(v).trim().replace("°C", "").replace(",", ".");
            if (!s || s.toUpperCase() === "N.A" || s.toLowerCase() === "nan") return null;
            const n = Number(s);
            return Number.isFinite(n) ? n : null;
        }

        // Show as delta vs 0.0, with sign for non-zero values
        function svcFmtDelta(v) {
            const n = svcToNumber(v);
            if (n === null) return "0.0";
            const r = Math.round(n * 2) / 2; // keep 0.5 steps in UI
            const s = r.toFixed(1);
            if (Math.abs(r) < 0.05) return "0.0";
            return (r > 0 ? "+" : "") + s;
        }
        function svcFmtPlain(v) {
            if (v === null || v === undefined) return "N.A";
            const s = String(v).trim();
            if (!s || s.toUpperCase() === "N.A" || s.toLowerCase() === "nan") return "N.A";
            return s;
        }

        // Service data cache: nie odpalamy /getdata przy KAŻDYM przełączeniu tabów.
        // Ładujemy pierwszy raz na wejściu w Serwis, a później tylko warunkowo (TTL)
        // i tylko wtedy, gdy zakładka Serwis jest aktywna.
        let __svcLoadedOnce = false;
        let __svcLastFetchMs = 0;
        const __svcTtlMs = 15000; // 15s: UI jest responsywne, a backend nie dostaje lawiny requestów

        function isServiceTabActive() {
            return $("#settings-service").hasClass("active") || $("#settings-service-tab").hasClass("active") || $("#settings-service-tab").hasClass("show");
        }

        function loadServiceData(opts) {
            opts = opts || {};
            const force = !!opts.force;

            // Only run if Service tab exists on this page
            if (!$("#settings-service-tab").length) return;

            // Jeśli nie jesteśmy w zakładce Serwis – nie rób odświeżeń w tle (bez sensu)
            if (!force && !isServiceTabActive()) return;

            const now = Date.now();
            if (!force && __svcLastFetchMs && (now - __svcLastFetchMs) < __svcTtlMs) return;
            __svcLastFetchMs = now;

            $.getJSON("/getdata", function (d) {
                __svcLoadedOnce = true;
                // Temperature compensation
                // Prefer actual readback if available, otherwise fall back to last set value.
                const curN = svcToNumber(d.tempcompensation);
                const setN = svcToNumber(d.tempcompensation_set);
                const display = (curN !== null) ? curN : ((setN !== null) ? setN : 0.0);

                $("#tempcompensation_set").val(svcFmtDelta(display));

                // DHW temperature compensation (A0d)
                const dhwCurN = svcToNumber(d.dhwcompensation);
                const dhwSetN = svcToNumber(d.dhwcompensation_set);
                const dhwDisplay = (dhwCurN !== null) ? dhwCurN : ((dhwSetN !== null) ? dhwSetN : 0.0);
                $("#dhwcompensation_set").val(svcFmtDelta(dhwDisplay));

                // Service test switches + availability
                window.__svc = window.__svc || {};
                window.__svc.pump = d.pump;
                window.__svc.heater = d.heater;
                window.__svc.heatdemand = d.heatdemand;
                window.__svc.compinfo = d.compinfo;
                window.__svc.set_pump = d.set_pump;
                window.__svc.set_heater = d.set_heater;
                updateServiceTestUI();

                // Service test duration (UI in minutes, config in seconds)
                if ($('#service_test_duration_min').length) {
                    const secRaw = (d && d.service_test_duration_s !== undefined && d.service_test_duration_s !== null)
                        ? String(d.service_test_duration_s).trim()
                        : '';
                    const sec = parseFloat(String(secRaw).replace(',', '.'));
                    if (isFinite(sec)) {
                        const min = sec / 60.0;
                        // show integer when possible, otherwise 1 decimal (trim trailing .0)
                        let out = (Math.round(min) === min) ? String(min) : String(Math.round(min * 10) / 10);
                        $('#service_test_duration_min').val(out);
                    } else {
                        $('#service_test_duration_min').val('');
                    }
                }

                // Errors + info
                $("#service_error").val(svcFmtPlain(d.error));
                $("#service_lasterror").val(svcFmtPlain(d.lasterror));
                $("#service_archerror").val(svcFmtPlain(d.archerror));
                $("#service_firmware").val(svcFmtPlain(d.firmware));
            });
        }

        function serviceTestAllowed(state) {
            state = state || (window.__svc || {});
            const pump = String(state.pump || '').trim().toLowerCase();
            const heater = String(state.heater || '').trim().toLowerCase();
            const heatdemand = String(state.heatdemand || '').trim().toLowerCase();
            const compinfo = state.compinfo;

            const pumpOff = (pump === 'off' || pump === '0' || pump === 'false' || pump === '');
            const heaterOff = (heater === 'off' || heater === '0' || heater === 'false' || heater === '');
            const heatdemandZero = (heatdemand === '0' || heatdemand === 'off' || heatdemand === 'false');

            let compStopped = false;
            try {
                if (Array.isArray(compinfo) && compinfo.length >= 2) {
                    const a = Number(compinfo[0]);
                    const b = Number(compinfo[1]);
                    compStopped = Math.max(a || 0, b || 0) <= 0.1;
                } else if (Array.isArray(compinfo) && compinfo.length === 1) {
                    const a = Number(compinfo[0]);
                    compStopped = (a || 0) <= 0.1;
                } else {
                    compStopped = false;
                }
            } catch (e) {
                compStopped = false;
            }

            return pumpOff && heaterOff && heatdemandZero && compStopped;
        }

        function updateServiceTestUI() {
            if (!$("#settings-service-tab").length) return;

            const st = window.__svc || {};
            const pumpChecked = String(st.set_pump || '').toLowerCase() === 'on';
            const heaterChecked = String(st.set_heater || '').toLowerCase() === 'on';

            $("#service_set_pump").prop('checked', pumpChecked);
            $("#service_set_heater").prop('checked', heaterChecked);

            const allow = serviceTestAllowed(st);

            // Availability box on the right
            const $avail = $("#service_test_available");
            if ($avail.length) {
                $avail.val(allow ? t('set.available', 'Dostępny') : t('set.unavailable', 'Niedostępny'));
            }

            // Allow turning OFF even when conditions are not met
            $("#service_set_pump").prop('disabled', (!allow && !pumpChecked));
            $("#service_set_heater").prop('disabled', (!allow && !heaterChecked));

            // Note: we display availability only in the right-side box
        }

        function getTempCompSetNumeric() {
            const n = svcToNumber($("#tempcompensation_set").val());
            return (n === null) ? 0.0 : n;
        }

        function setTempCompensation(value) {
            // Clamp and round to 0.5
            let v = Number(value);
            if (!Number.isFinite(v)) v = 0.0;
            v = Math.max(-15.0, Math.min(15.0, v));
            v = Math.round(v * 2) / 2;

            // UI: optimistic update (delta formatting)
            $("#tempcompensation_set").val(svcFmtDelta(v));
            // If readback is not instant, keep current in sync for better UX
            // Send to backend
            $("#tempcomp_minus, #tempcomp_plus").prop("disabled", true);
            $.ajax({
                url: "/tempcompchange",
                method: "POST",
                data: { value: v.toFixed(1) }
            }).done(function (resp) {
                if (resp && resp.msg && resp.state) {
                    appendAlert(resp.msg, resp.state);
                }
                // Refresh readback shortly after write
                setTimeout(loadServiceData, 400);
            }).fail(function () {
                appendAlert("Temp compensation: request failed", "danger");
                loadServiceData();
            }).always(function () {
                $("#tempcomp_minus, #tempcomp_plus").prop("disabled", false);
            });
        }

        function getDhwTempCompSetNumeric() {
            const n = svcToNumber($("#dhwcompensation_set").val());
            return (n === null) ? 0.0 : n;
        }

        function setDhwTempCompensation(value) {
            let v = Number(value);
            if (!Number.isFinite(v)) v = 0.0;
            v = Math.max(-15.0, Math.min(15.0, v));
            v = Math.round(v * 2) / 2;
            $("#dhwcompensation_set").val(svcFmtDelta(v));
            $("#dhwtempcomp_minus, #dhwtempcomp_plus").prop("disabled", true);
            $.ajax({
                url: "/dhwcompchange",
                method: "POST",
                data: { value: v.toFixed(1) }
            }).done(function (resp) {
                if (resp && resp.msg && resp.state) {
                    appendAlert(resp.msg, resp.state);
                }
                setTimeout(loadServiceData, 400);
            }).fail(function () {
                appendAlert("DHW compensation: request failed", "danger");
                loadServiceData();
            }).always(function () {
                $("#dhwtempcomp_minus, #dhwtempcomp_plus").prop("disabled", false);
            });
        }

        // Buttons + / -
        $("#tempcomp_minus").on("click", function () {
            const v = getTempCompSetNumeric() - 0.5;
            setTempCompensation(v);
        });
        $("#tempcomp_plus").on("click", function () {
            const v = getTempCompSetNumeric() + 0.5;
            setTempCompensation(v);
        });

        // DHW comp buttons + / -
        $("#dhwtempcomp_minus").on("click", function () {
            const v = getDhwTempCompSetNumeric() - 0.5;
            setDhwTempCompensation(v);
        });
        $("#dhwtempcomp_plus").on("click", function () {
            const v = getDhwTempCompSetNumeric() + 0.5;
            setDhwTempCompensation(v);
        });

        // Service test switches (socket)
        function emitServiceTest(key, on) {
            try {
                if (socket && typeof socket.emit === 'function') {
                    const payload = {}; payload[key] = on ? 'on' : 'off';
                    socket.emit('client', payload);
                }
            } catch (e) {}
        }

        $("#service_set_pump").on("change", function () {
            const checked = $(this).is(":checked");
            if (checked && !serviceTestAllowed()) {
                // snap back
                $(this).prop('checked', false);
                updateServiceTestUI();
                appendAlert(t('set.service_test_not_ready', 'Not available (conditions not met)'), 'warning');
                return;
            }
            // Optimistic UI: keep the switch in sync immediately, backend will confirm/deny via data_update
            window.__svc = window.__svc || {};
            window.__svc.set_pump = checked ? 'on' : 'off';
            updateServiceTestUI();
            emitServiceTest('set_pump', checked);
        });

        $("#service_set_heater").on("change", function () {
            const checked = $(this).is(":checked");
            if (checked && !serviceTestAllowed()) {
                $(this).prop('checked', false);
                updateServiceTestUI();
                appendAlert(t('set.service_test_not_ready', 'Not available (conditions not met)'), 'warning');
                return;
            }
            window.__svc = window.__svc || {};
            window.__svc.set_heater = checked ? 'on' : 'off';
            updateServiceTestUI();
            emitServiceTest('set_heater', checked);
        });


        // Service test duration (UI in minutes, config in seconds)
        function clampFloat(v, minV, maxV) {
            var n = parseFloat(String(v).trim().replace(',', '.'));
            if (!isFinite(n)) n = minV;
            n = Math.max(minV, Math.min(maxV, n));
            return n;
        }

        $('#service_test_duration_min').on('change', function () {
            var $el = $(this);
            if (!$el.length) return;
            var min = clampFloat($el.val(), 1, 240);
            // keep one decimal max for UX, but store seconds as int
            min = Math.round(min * 10) / 10;
            $el.val((Math.round(min) === min) ? String(min) : String(min));
            var v = Math.round(min * 60);
            $el.prop('disabled', true);
            $.ajax({
                url: '/service_test_duration',
                method: 'POST',
                data: { value: v }
            }).done(function (resp) {
                if (resp && resp.msg && resp.state) {
                    appendAlert(resp.msg, resp.state);
                }
                setTimeout(function(){ loadServiceData({ force: true }); }, 300);
            }).fail(function () {
                appendAlert('Service test duration: request failed', 'danger');
                loadServiceData({ force: true });
            }).always(function () {
                $el.prop('disabled', false);
            });
        });

        // Initial + periodic refresh
        // - nie uderzamy w /getdata na starcie, jeśli Serwis nie jest aktywny
        // - co 5s próbujemy odświeżyć, ale loadServiceData samo robi guard (aktywny tab + TTL)
        if (isServiceTabActive()) {
            loadServiceData({ force: true });
        }
        setInterval(function(){ loadServiceData(); }, 5000);

        // Live updates (auto-off, etc.)
        try {
            if (socket && typeof socket.on === 'function') {
                socket.on('data_update', function (msg) {
                    if (!msg) return;
                    window.__svc = window.__svc || {};
                    if (msg.hasOwnProperty('set_pump')) window.__svc.set_pump = msg.set_pump;
                    if (msg.hasOwnProperty('set_heater')) window.__svc.set_heater = msg.set_heater;
                    if (msg.hasOwnProperty('pump')) window.__svc.pump = msg.pump;
                    if (msg.hasOwnProperty('heater')) window.__svc.heater = msg.heater;
                    if (msg.hasOwnProperty('heatdemand')) window.__svc.heatdemand = msg.heatdemand;
                    if (msg.hasOwnProperty('compinfo')) window.__svc.compinfo = msg.compinfo;
                    if (msg.hasOwnProperty('service_test_duration_s')) {
                        try {
                            var sec = parseFloat(String(msg.service_test_duration_s).replace(',', '.'));
                            if (isFinite(sec)) {
                                var min = sec / 60.0;
                                var out = (Math.round(min) === min) ? String(min) : String(Math.round(min * 10) / 10);
                                $('#service_test_duration_min').val(out);
                            }
                        } catch (e) {}
                    }
                    updateServiceTestUI();
                });
            }
        } catch (e) {}

        // Keep global "Save" button right under the last content of the active tab
        function placeSaveButtonIntoActiveTab() {
            const $row = $("#saveRow");
            if (!$row.length) return;
            const $activePane = $(".tab-pane.active.show");
            if ($activePane.length) {
                // Przeniesienie w rAF, żeby uniknąć kosztownych przeliczeń layoutu w trakcie eventu tabów
                requestAnimationFrame(function(){ $activePane.append($row); });
            }
        }



        // Hide global "Save" button on Service tab (not needed there)
        function toggleSaveButtonForTab(tabId) {
            const $row = $("#saveRow");
            if (!$row.length) return;
            if (tabId === "settings-service") {
                $row.addClass('d-none');
            } else {
                $row.removeClass('d-none');
            }
        }
        // Refresh when user opens a tab + move Save button under that tab content
        document.addEventListener('shown.bs.tab', function (e) {
            try {
                const targetSel = (e && e.target) ? (e.target.getAttribute("data-bs-target") || e.target.getAttribute("href")) : null;
                if (targetSel) {
                    // Przeniesienie w następnym paint – mniej reflow/jank przy przełączaniu tabów
                    requestAnimationFrame(function(){
                        try { $(targetSel).append($("#saveRow")); } catch(_) {}
                    });
                }

                if (e && e.target && e.target.id) {
                    toggleSaveButtonForTab(e.target.id);
                    if (e.target.id === "settings-service") {
                        // pierwszy raz -> force, potem TTL + aktywny tab zrobi resztę
                        loadServiceData({ force: !__svcLoadedOnce });
                    }
                }
            } catch (err) { }
        });

        // Initial state (place Save button under current tab)
        placeSaveButtonIntoActiveTab();
        toggleSaveButtonForTab($(".nav-link.active").attr("id"));

    });

    // ########### LOGIKA WYKRESU (pozostawiona w większości bez zmian) ###########

    var colors = ['#007bff', '#28a745', '#333333', '#c3e6cb', '#dc3545', '#6c757d'];
    var chLine = document.getElementById('hcurvechart');
    var myChart; // Zmienna globalna dla wykresu

    var chartData = {
        labels: Array.from({ length: 41 }, (_, i) => i - 20).map(String), // Lepszy sposób generowania etykiet
        datasets: [{
            label: "Auto",
            data: [],
            backgroundColor: 'transparent',
            borderColor: colors[0],
            borderWidth: 4,
            pointBackgroundColor: colors[0]
        }, {
            label: "Static",
            data: [],
            backgroundColor: 'transparent',
            borderColor: colors[1],
            borderWidth: 4,
            pointBackgroundColor: colors[1]
        }]
    };

    if (chLine) {
        myChart = new Chart(chLine, {
            type: 'line',
            data: chartData,
            options: { /* ... Twoje opcje ... */ }
        });
    }

    function recalc() {
        if (!myChart) return; // Zabezpieczenie, jeśli wykres nie istnieje

        const settemp = 22; // Powinno być pobierane z ustawień
        const insidetemp = parseFloat($("#tempRange").val()) || settemp;
        const outsidetemp = 11; // Powinno być pobierane z danych

        $("#customtemp").text("Temperatura wewnątrz: " + insidetemp);

        const slope = parseFloat($('#slope').val()) || 0;
        const ps = parseFloat($('#pshift').val()) || 0;
        const amp = parseFloat($('#hcamp').val()) || 0;

        const autoData = myChart.data.labels.map(element => {
            const outTemp = parseFloat(element);
            const t1 = (outsidetemp / (320 - (outsidetemp * 4)));
            const t2 = Math.pow(settemp, t1);
            return ((((0.55 * slope * t2) * (((-outTemp + 20) * 2) + settemp + ps) + ((settemp - insidetemp) * amp)) + ps) * 2) / 2;
        });

        const staticData = myChart.data.labels.map(element => {
            const outTemp = parseFloat(element);
            return (settemp + (slope * 20) * Math.pow(((settemp - outTemp) / 20), 0.7));
        });

        myChart.data.datasets[0].data = autoData;
        myChart.data.datasets[1].data = staticData;
        myChart.update();
    }

    // ########### LOGIKA NIEZAPISANYCH ZMIAN (pozostawiona bez zmian) ###########
    let isFormDirty = false;
    const modal = new bootstrap.Modal(document.getElementById("unsavedChangesModal"));
    let pendingNavigation = null;

    document.addEventListener("input", (event) => {
        const el = event && event.target ? event.target : null;
        if (!el || !el.matches("input, select, textarea")) return;

        // Service tab contains only "live" controls (no saving) – don't mark page as dirty
        // so leaving the page doesn't show the unsaved-changes modal after using service tests.
        if (el.closest && el.closest("#settings-service-tab")) return;

        // Defensive: ignore readonly/disabled fields
        if (el.hasAttribute && (el.hasAttribute("readonly") || el.disabled)) return;

        isFormDirty = true;
    });
    document.querySelectorAll(".navl").forEach(link => {
        link.addEventListener("click", (event) => {
            if (isFormDirty) {
                event.preventDefault();
                pendingNavigation = event.target.href;
                modal.show();
            }
        });
    });
    document.getElementById("leavePageBtn").addEventListener("click", () => {
        if (pendingNavigation) {
            window.location.href = pendingNavigation;
        }
    });

    // --- System tab: show server (DietPi) date & time ---
    function updateSystemDateTime() {
        const el = document.getElementById('system_datetime_value');
        if (!el) return;
        $.getJSON('/api/system_time')
            .done(function (data) {
                const val = (data && (data.display || data.iso)) ? (data.display || data.iso) : '';
                if ('value' in el) { el.value = val; } else { el.textContent = val; }
            })
            .fail(function () {
                // ignore
            });
    }

    // initial + refresh when switching tabs + periodic refresh
    updateSystemDateTime();
    setInterval(updateSystemDateTime, 30000);
    document.addEventListener('shown.bs.tab', function (ev) {
        // refresh when System tab is shown
        if (ev && ev.target && (ev.target.id === 'settings-system' || ev.target.getAttribute('data-bs-target') === '#settings-system-tab')) {
            updateSystemDateTime();
        }
    });

    // Inicjalizacja tooltipów
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    } catch(e) { console.error('HPI inline script error (settings.html #2)', e); }
  });


})();
