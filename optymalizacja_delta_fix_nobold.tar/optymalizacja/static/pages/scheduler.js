/* === Inline scripts extracted from templates (split) === */
(function(){
  'use strict';
  const PAGE = (document.body && document.body.dataset) ? (document.body.dataset.page || '') : '';
  function onReady(fn){
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  // From templates/scheduler.html (block 1)
  onReady(function(){
    if(!(PAGE === 'scheduler')) return;
    try {
/*				$('#schedule3').jqs({
      onInit: function () {
        $('#logs').val('onInit fire !\n' + $('#logs').val());
      },
      onAddPeriod: function () {
        $('#logs').val('onAddPeriod fire !\n' + $('#logs').val());
      },
      onRemovePeriod: function () {
        $('#logs').val('onRemovePeriod fire !\n' + $('#logs').val());
      },
      onClickPeriod: function () {
        $('#logs').val('onClickPeriod fire !\n' + $('#logs').val());
      }
    });
				$('#schedule4').jqs({
      onInit: function () {
        $('#logs').val('onInit fire !\n' + $('#logs').val());
      },
      onAddPeriod: function () {
        $('#logs').val('onAddPeriod fire !\n' + $('#logs').val());
      },
      onRemovePeriod: function () {
        $('#logs').val('onRemovePeriod fire !\n' + $('#logs').val());
      },
      onClickPeriod: function () {
        $('#logs').val('onClickPeriod fire !\n' + $('#logs').val());
      }
    });
$('#schedule3').jqs('import', {{ ch }});
				console.log('{{ ch }}');
$('#schedule4').jqs('import', {{ dhw }});*/
$('#savech').click(function () {
      var schedulech=$('#schedule3').jqs('export');
	$.post('/scheduler', {schedulech: schedulech}, function(data) {
		         var text=data.msg;
                        var state=data.state;
			appendAlert(text,state);
        /*                Swal.fire({
                                html: text,
                                icon: state,
                                showCloseButton: false,
                                showConfirmButton: false,
                                timer: 2000,
                                timerProgressBar: true,
                                didOpen: () => {
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                                                })*/

                        });
    });
$('#savedhw').click(function () {
      var scheduledhw=$('#schedule4').jqs('export');
        $.post('/scheduler', {scheduledhw: scheduledhw}, function(data) {
                        var text=data.msg;
                        var state=data.state
                        Swal.fire({
                                html: text,
                                icon: state,
                                showCloseButton: false,
                                showConfirmButton: false,
                                timer: 2000,
                                timerProgressBar: true,
                                didOpen: () => {
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                                                })

                        });
    });
    } catch(e) { console.error('HPI inline script error (scheduler.html #1)', e); }
  });

  // From templates/scheduler.html (block 2)
  onReady(function(){
    if(!(PAGE === 'scheduler')) return;
    try {
$('#schedule3').jqs({
      onInit: function () {
        $('#logs').val('onInit fire !\n' + $('#logs').val());
      },
      onAddPeriod: function () {
        $('#logs').val('onAddPeriod fire !\n' + $('#logs').val());
      },
      onRemovePeriod: function () {
        $('#logs').val('onRemovePeriod fire !\n' + $('#logs').val());
      },
      onClickPeriod: function () {
        $('#logs').val('onClickPeriod fire !\n' + $('#logs').val());
      }
    });
                                $('#schedule4').jqs({
      onInit: function () {
        $('#logs').val('onInit fire !\n' + $('#logs').val());
      },
      onAddPeriod: function () {
        $('#logs').val('onAddPeriod fire !\n' + $('#logs').val());
      },
      onRemovePeriod: function () {
        $('#logs').val('onRemovePeriod fire !\n' + $('#logs').val());
      },
      onClickPeriod: function () {
        $('#logs').val('onClickPeriod fire !\n' + $('#logs').val());
      }
    });
$(document).ready(function() {
    const socket = io(); // Upewniamy się, że socket jest tworzony tylko raz

    socket.on("connect", () => {
        console.log("Połączono z serwerem Socket.io");
    });
        socket.on('scheduler', function(data) {
                var scheduler1=data.chsch
		var scheduler2=data.dhwsch
		$('#schedule3').jqs('import', scheduler1);
		$('#schedule4').jqs('import', scheduler2);

    });
        socket.on('return', function(msg) {
                switch(Object.keys(msg)[0]) {
                        case "info":
                                appendAlert(msg.info, msg.status);
                                break;
                }
                console.log(msg)
        });
});

//$('#schedule4').jqs('import', {{ dhw }});
    } catch(e) { console.error('HPI inline script error (scheduler.html #2)', e); }
  });


})();
