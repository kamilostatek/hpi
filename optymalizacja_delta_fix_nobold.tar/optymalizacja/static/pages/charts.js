/* === Inline scripts extracted from templates (split) === */
(function(){
  'use strict';
  const PAGE = (document.body && document.body.dataset) ? (document.body.dataset.page || '') : '';
  function onReady(fn){
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  // From templates/charts.html (block 1)
  onReady(function(){
    if(!(PAGE === 'charts')) return;
    try {
$(document).ready(function() {
  let charts = [];

  // --- Startup loading guard: avoid showing partial/wrong range before the requested range arrives ---
  let requestedChartsVal = null;
  let suppressUntilMatch = true;
  // When the user switches the time range (e.g. 12h -> 48h), we want the chart to
  // immediately display the *full* newly loaded extent, not keep the previous zoom.
  let resetZoomOnNextRender = false;

  function _fullDateWindowFromData(rows) {
    if (!Array.isArray(rows) || rows.length < 2) return null;
    const first = rows[0] && rows[0][0];
    const last = rows[rows.length - 1] && rows[rows.length - 1][0];
    const t0 = (first instanceof Date) ? first.getTime() : (typeof first === 'number' ? first : NaN);
    const t1 = (last instanceof Date) ? last.getTime() : (typeof last === 'number' ? last : NaN);
    if (!isFinite(t0) || !isFinite(t1) || t1 <= t0) return null;
    return [t0, t1];
  }

  function _expectedSpanMs(val) {
    const n = parseInt(val, 10);
    if (!isFinite(n)) return null;
    if (n === 24) return 12 * 60 * 60 * 1000;  // 12h
    if (n === 96) return 48 * 60 * 60 * 1000;  // 48h
    // For "All" / "Live" we don't enforce span.
    return null;
  }

  function _setChartLoading(isLoading) {
    const el = document.getElementById('chart0');
    if (!el) return;

    // Place overlay on the card body (parent of chart0)
    const host = el.parentElement || el;
    let overlay = document.getElementById('chart0-loading');

    if (isLoading) {
      // Hide chart until we have the right payload, to avoid partial first paint.
      el.style.opacity = '0';

      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'chart0-loading';
        overlay.style.position = 'absolute';
        overlay.style.inset = '0';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.pointerEvents = 'none';
        overlay.innerHTML = '<div class="spinner-border" role="status" aria-label="Loading"></div>';

        // Ensure host can host an absolute overlay
        const cs = getComputedStyle(host);
        if (!cs.position || cs.position === 'static') host.style.position = 'relative';

        host.appendChild(overlay);
      }
    } else {
      el.style.opacity = '';
      if (overlay && overlay.parentElement) overlay.parentElement.removeChild(overlay);
    }
  }

  // --- Persist series visibility (localStorage) ---
  const VIS_KEY = 'haierpi_charts_visibility_v1';

  function _loadVis() {
    try {
      const raw = localStorage.getItem(VIS_KEY);
      return raw ? (JSON.parse(raw) || {}) : {};
    } catch (e) {
      return {};
    }
  }

  function _saveVis(obj) {
    try { localStorage.setItem(VIS_KEY, JSON.stringify(obj || {})); }
    catch (e) { /* ignore */ }
  }

  let _vis = _loadVis();

  function _applyVisibilityToChart(seriesIdx, checked) {
    const chartObj = (Array.isArray(charts) ? charts : []).find(c => c.divId === 'chart0');
    if (chartObj && chartObj.chart && typeof chartObj.chart.setVisibility === 'function') {
      chartObj.chart.setVisibility(seriesIdx, checked);
    }
  }

  function _applyVisToUIAndConfig() {
    $('input[type="checkbox"][data-chart="0"]').each(function() {
      const id = this.id;
      if (!id || !_vis.hasOwnProperty(id)) return;

      const checked = !!_vis[id];
      this.checked = checked;

      const seriesIdx = parseInt(this.name, 10);
      if (!isNaN(seriesIdx) && chartsConfig && chartsConfig.chart0 && Array.isArray(chartsConfig.chart0.visibility)) {
        chartsConfig.chart0.visibility[seriesIdx] = checked;
      }
    });
  }

  function _onVisChange() {
    const seriesIdx = parseInt(this.name, 10);
    if (isNaN(seriesIdx)) return;

    const checked = !!this.checked;

    // keep config in sync so updateOptions() won't reset visibility
    if (chartsConfig && chartsConfig.chart0 && Array.isArray(chartsConfig.chart0.visibility)) {
      chartsConfig.chart0.visibility[seriesIdx] = checked;
    }

    // apply immediately if chart exists
    _applyVisibilityToChart(seriesIdx, checked);

    // persist
    if (this.id) {
      _vis[this.id] = checked;
      _saveVis(_vis);
    }
  }

  $('input[type="checkbox"][data-chart="0"]').on('change', _onVisChange);

  function _updateToggleAllButton() {
    const boxes = Array.from(document.querySelectorAll('input[type="checkbox"][data-chart="0"]'));
    const any = boxes.some(b => b.checked);
    const all = boxes.length ? boxes.every(b => b.checked) : false;
    const btn = document.getElementById('toggleAllSeries0');
    if (!btn) return;
    btn.textContent = all ? 'Odznacz' : 'Zaznacz';
    btn.disabled = !boxes.length;
    btn.dataset.state = all ? 'all' : (any ? 'some' : 'none');
  }

  document.getElementById('toggleAllSeries0')?.addEventListener('click', function() {
    const boxes = Array.from(document.querySelectorAll('input[type="checkbox"][data-chart="0"]'));
    if (!boxes.length) return;

    const allChecked = boxes.every(b => b.checked);
    const newState = !allChecked;

    boxes.forEach(cb => {
      if (cb.checked === newState) return;
      cb.checked = newState;

      const seriesIdx = parseInt(cb.name, 10);
      if (!isNaN(seriesIdx)) {
        if (chartsConfig && chartsConfig.chart0 && Array.isArray(chartsConfig.chart0.visibility)) {
          chartsConfig.chart0.visibility[seriesIdx] = newState;
        }
        _applyVisibilityToChart(seriesIdx, newState);
      }
      if (cb.id) _vis[cb.id] = newState;
    });

    _saveVis(_vis);
    _updateToggleAllButton();
  });

  $('input[type="checkbox"][data-chart="0"]').on('change', _updateToggleAllButton);

  // Pretty labels for series toggles + legend
  applyPrettyLabels();
  _updateToggleAllButton();


  // --- Data helpers ---
  function filterOutliers(data, threshold) {
    if (!Array.isArray(data)) return [];
    let lastValidValue = null;
    const filteredData = [];

    for (let i = 0; i < data.length; i++) {
      const currentValue = data[i];
      if (currentValue === null || currentValue === undefined || currentValue === "" || currentValue === "ERROR") {
        filteredData.push(null);
        continue;
      }
      const n = parseFloat(currentValue);
      if (isNaN(n)) {
        filteredData.push(null);
        continue;
      }

      if (lastValidValue !== null) {
        if (Math.abs(n - lastValidValue) > threshold) {
          filteredData.push(null);
        } else {
          filteredData.push(n);
          lastValidValue = n;
        }
      } else {
        filteredData.push(n);
        lastValidValue = n;
      }
    }
    return filteredData;
  }

  function normalizeFLimit(v) {
    if (v === null || v === undefined || v === '' || v === 'ERROR') return null;
    const n = parseFloat(v);
    if (isNaN(n)) return null;
    return n > 0 ? 10 : 0;
  }

  function isDefrostFromSignals(fact, fan1, fan2) {
    const f = parseFloat(fact);
    const a = parseFloat(fan1);
    const b = parseFloat(fan2);
    return isFinite(f) && f >= 30 && isFinite(a) && isFinite(b) && a === 0 && b === 0;
  }

  function mapThreewayValue(value, fact, fan1, fan2) {
    // Threeway valve chart must show ONLY two states: CH or DHW.
    // Everything else is mapped to a hidden OFF band value (216). The plotter will NOT draw OFF,
    // but keeping the value prevents Dygraphs from connecting CH/DHW segments through OFF/N.A.
    if (value === null || value === undefined) return 216;
    const v = String(value).trim().toUpperCase();
    if (v === 'CH') return 180;
    if (v === 'DHW') return 200;
    return 216; // OFF / N.A. / ERROR / anything else
  }


  // Defrost: separate series (turquoise)
  function mapDefrostValue(value, fact, fan1, fan2, threewayRaw) {
    // Defrost status is now a separate series (chartdefrost).
    // Map to a continuous ON/OFF band like in 1.4.5: 218 = ON, 205 = OFF.
    if (value === null || value === undefined) return null;
    const s = String(value).trim().toUpperCase();
    if (s === '' || s === 'N/A' || s === 'NA' || s === 'ERROR') return null;
    if (s === 'ON' || s === 'TRUE' || s === '1' || s === 'DEFROST') return 218;
    if (s === 'OFF' || s === 'FALSE' || s === '0') return 205;

    const n = parseFloat(value);
    if (!isFinite(n)) return null;
    return (n > 0) ? 218 : 205;
  }



  // Antifreeze: separate series (gold-brown)
  function mapAntifreezeValue(value, threewayRaw) {
    // Antifreeze status is now a separate series (chartantifreeze).
    // Map to a continuous ON/OFF band like in 1.4.5 (tuned): 268 = ON, 262 = OFF.
    if (value === null || value === undefined) return null;
    const s = String(value).trim().toUpperCase();
    if (s === '' || s === 'N/A' || s === 'NA' || s === 'ERROR') return null;
    if (s === 'ON' || s === 'TRUE' || s === '1' || s === 'ANTIFREEZE') return 268;
    if (s === 'OFF' || s === 'FALSE' || s === '0') return 262;

    const n = parseFloat(value);
    if (!isFinite(n)) return null;
    return (n > 0) ? 268 : 262;
  }



  function mapModeValue(quiet, eco, turbo) {
    const _toNum = (v) => {
      if (v === null || v === undefined || v === '' || v === 'ERROR') return 0;
      const n = parseFloat(v);
      return isNaN(n) ? 0 : n;
    };
    const q = _toNum(quiet);
    const e = _toNum(eco);
    const t = _toNum(turbo);

    if (q > 0) return 1;
    if (e > 0) return 2;
    if (t > 0) return 3;
    return 0;
  }

  function mapModeSeries(quietArr, ecoArr, turboArr) {
    const q = Array.isArray(quietArr) ? quietArr : [];
    const e = Array.isArray(ecoArr) ? ecoArr : [];
    const t = Array.isArray(turboArr) ? turboArr : [];
    const len = Math.max(q.length, e.length, t.length);
    const out = new Array(len);
    for (let i = 0; i < len; i++) {
      out[i] = mapModeValue(q[i], e[i], t[i]);
    }
    return out;
  }

  function modeCodeFromBand(y) {
    const v = Number(y);
    if (!isFinite(v)) return 0;
    // Now rysujemy jako: 210=Off, 220=Quiet, 230=Eco, 240=Turbo
    if (v >= 200) return Math.round((v - 210) / 10);
    return Math.round(v);
  }

  function modeColorForValue(y) {
    switch (modeCodeFromBand(y)) {
      case 1: return '#43A047'; // quiet
      case 2: return '#FB8C00'; // eco
      case 3: return '#E53935'; // turbo
      default: return '#9E9E9E'; // off/unknown
    }
  }


  function threewayGroupForValue(y) {
    const v = Number(y);
    if (!isFinite(v)) return 'OFF';
    const near = (a, b) => Math.abs(a - b) < 0.75;

    // Band levels (for Threeway valve only): CH=180, DHW=200
    if (near(v, 180)) return 'CH';
    if (near(v, 200)) return 'DHW';
    return 'OFF';
  }

  

  // Rank for "dominant" coloring on vertical edges (same idea as Mode):
  // CH < DHW < OTHER(turquoise group: Defrost/Off/N.A./ERR)
  function threewayRankFromBand(y) {
    const grp = threewayGroupForValue(y);
    // OFF < CH < DHW (so edges take CH/DHW color, not OFF)
    if (grp === 'OFF') return 0;
    if (grp === 'CH') return 1;
    return 2; // DHW
  }


function threewayColorForValue(y, baseColor) {
    const grp = threewayGroupForValue(y);
    // CH: light red; DHW: strong red; OFF: transparent/skip
    if (grp === 'CH') return '#E57373';
    if (grp === 'DHW') return '#E53935';
    return null; // OFF / unknown -> do not draw
  }

  // Custom step plotter: per-state color for Threeway valve (similar to Mode)
    // Threeway: step plot with per-state coloring, zoom-stable (same logic as Mode)
  function threewayStepPlotter(e) {
    const ctx = e.drawingContext;
    const points = e.points || [];
    if (points.length < 2) return;

    const lw = (e.dygraph && typeof e.dygraph.getOption === 'function')
      ? (e.dygraph.getOption('strokeWidth') || 2)
      : 2;

    const base = e.color || '#888';

    ctx.save();
    ctx.lineWidth = lw;
    ctx.lineJoin = 'miter';
    ctx.lineCap = 'butt';

    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      if (!p1 || !p2) continue;

      const y1 = Number(p1.yval);
      const y2 = Number(p2.yval);
      if (!isFinite(y1) || !isFinite(y2)) continue;

      // Horizontal segment: draw only for CH/DHW (OFF is skipped)
      const cH = threewayColorForValue(y1, base);
      if (cH) {
        ctx.strokeStyle = cH;
        ctx.beginPath();
        ctx.moveTo(p1.canvasx, p1.canvasy);
        ctx.lineTo(p2.canvasx, p1.canvasy);
        ctx.stroke();
      }

      // Vertical segment: use "dominant" state by rank, so edges take CH/DHW color (OFF is skipped)
      const r1 = threewayRankFromBand(y1);
      const r2 = threewayRankFromBand(y2);
      const yDom = (r1 >= r2) ? y1 : y2;

      const cV = threewayColorForValue(yDom, base);
      if (cV) {
        ctx.strokeStyle = cV;
        ctx.beginPath();
        ctx.moveTo(p2.canvasx, p1.canvasy);
        ctx.lineTo(p2.canvasx, p2.canvasy);
        ctx.stroke();
      }
    }

    ctx.restore();
  }

  // Generic status step plotter (draws ONLY when status is ON; OFF level is a hidden sentinel)
  function _nearBand(v, target) { return Math.abs(v - target) < 0.75; }

  function makeStatusStepPlotter(onLevel) {
    return function statusStepPlotter(e) {
      const ctx = e.drawingContext;
      const points = e.points || [];
      if (points.length < 2) return;

      const lw = (e.dygraph && typeof e.dygraph.getOption === 'function')
        ? (e.dygraph.getOption('strokeWidth') || 2)
        : 2;

      const base = e.color || '#888';

      ctx.save();
      ctx.lineWidth = lw;
      ctx.lineJoin = 'miter';
      ctx.lineCap = 'butt';
      ctx.strokeStyle = base;

      for (let i = 0; i < points.length - 1; i++) {
        const p1 = points[i];
        const p2 = points[i + 1];
        if (!p1 || !p2) continue;

        const y1 = Number(p1.yval);
        const y2 = Number(p2.yval);
        if (!isFinite(y1) || !isFinite(y2)) continue;

        const on1 = _nearBand(y1, onLevel);
        const on2 = _nearBand(y2, onLevel);

        // Horizontal segment: only when ON
        if (on1) {
          ctx.beginPath();
          ctx.moveTo(p1.canvasx, p1.canvasy);
          ctx.lineTo(p2.canvasx, p1.canvasy);
          ctx.stroke();
        }

        // Vertical segment at p2.x: draw only if transition involves ON
        if (on1 !== on2) {
          // Use onLevel for vertical endpoint to keep it crisp, but still draw the edge.
          const yFrom = p1.canvasy;
          const yTo = p2.canvasy;
          // If both ends are OFF, nothing to draw.
          if (on1 || on2) {
            ctx.beginPath();
            ctx.moveTo(p2.canvasx, yFrom);
            ctx.lineTo(p2.canvasx, yTo);
            ctx.stroke();
          }
        }
      }

      ctx.restore();
    };
  }


  // Niestandardowy plotter Dygraphs: "step plot" z kolorem zależnym od trybu
  function modeStepPlotter(e) {
    const ctx = e.drawingContext;
    const points = e.points || [];
    if (points.length < 2) return;

    const lw = (e.dygraph && typeof e.dygraph.getOption === 'function')
      ? (e.dygraph.getOption('strokeWidth') || 2)
      : 2;

    ctx.save();
    ctx.lineWidth = lw;
    ctx.lineJoin = 'miter';
    ctx.lineCap = 'butt';

    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      if (!p1 || !p2) continue;

      const y1 = Number(p1.yval);
      const y2 = Number(p2.yval);
      if (!isFinite(y1) || !isFinite(y2)) continue;

      // Horizontal segment: keep color of current state (y1)
      ctx.strokeStyle = modeColorForValue(y1);
      ctx.beginPath();
      ctx.moveTo(p1.canvasx, p1.canvasy);
      ctx.lineTo(p2.canvasx, p1.canvasy);
      ctx.stroke();

      // Vertical segment: use the "dominant" state by rank,
      // so both edges of a spike (A->B and B->A) keep the spike color.
      const r1 = modeCodeFromBand(y1);
      const r2 = modeCodeFromBand(y2);
      const yDom = (r1 >= r2) ? y1 : y2;

      ctx.strokeStyle = modeColorForValue(yDom);
      ctx.beginPath();
      ctx.moveTo(p2.canvasx, p1.canvasy);
      ctx.lineTo(p2.canvasx, p2.canvasy);
      ctx.stroke();
    }

    ctx.restore();
  }

  function numOrNull(v) {
    if (v === null || v === undefined || v === '' || v === 'ERROR') return null;
    const n = parseFloat(v);
    return isNaN(n) ? null : n;
  }

  function unitForLabel(label) {
    const l = String(label || '').trim();
    // Temperature-like series
    const temp = new Set([
      'tank','twi','two','thi','tho','ts','td','tao',
      'intemp','outtemp','hcurve','tdef','superheat','subcooling'
    ]);
    if (temp.has(l)) return '°C';
    if (l === 'humid') return '%';
    if (l === 'F set' || l === 'F act') return 'Hz';
    if (l === 'Ps set' || l === 'Ps act' || l === 'Pd set' || l === 'Pd act') return 'bar';
    if (l === 'Fan1' || l === 'Fan2') return 'rpm';
    if (l === 'EEV') return '°';
    return '';
  }

  function threewayLabelFromBand(y) {
    if (y == null || y === undefined) return "";
    const v = Number(y);
    if (!isFinite(v)) return "";
    const near = (a, b) => Math.abs(a - b) < 0.75;

    // Band levels (for Threeway valve only): CH=180, DHW=200
    if (near(v, 180)) return (window.i18next && i18next.exists('mode.ch')) ? i18next.t('mode.ch') : "CH";
    if (near(v, 200)) return (window.i18next && i18next.exists('mode.dhw')) ? i18next.t('mode.dhw') : "DHW";
    return "";
  }


  function formatLegendValue(label, y, yHTML) {
    if (y == null || y === undefined) return "";
    const n = Number(y);
    if (!isFinite(n)) return yHTML;

    if (label === "F limit") return (n >= 255) ? "ON" : "OFF";

    if (label === "Heater") return (n >= 170) ? "ON" : "OFF";

    if (label === "Threeway valve") {
      return threewayLabelFromBand(n);
    }

    if (label === "Defrost") {
      return (n >= 212) ? "ON" : "OFF";
    }

    if (label === "Antifreeze") {
      return (n >= 265) ? "ON" : "OFF";
    }

    if (label === "Mode") {
      const code = modeCodeFromBand(n);
      if (code === 1) return "Quiet";
      if (code === 2) return "Eco";
      if (code === 3) return "Turbo";
      return "Off";
    }

    const unit = unitForLabel(label);
    return unit ? (yHTML + ' <span class="legend-unit">' + unit + '</span>') : yHTML;
  }


  
  // Force Y-axis to show label "260" (and hide "250" label)
  function yTickerForce260(min, max, pixels, opts, dygraph, vals) {
    const ticks = Dygraph.numericTicks(min, max, pixels, opts, dygraph, vals)
      .filter(t => Math.abs(t.v - 250) > 1e-9);

    const v = 260;
    if (v >= min && v <= max) {
      const exists = ticks.some(t => Math.abs(t.v - v) < 1e-9);
      if (!exists) ticks.push({ v: v, label: String(v) });
    }

    ticks.sort((a, b) => a.v - b.v);
    return ticks;
  }

function prettyLabel(label) {
    if (!label) return label;
    // Keep common already-formatted labels as-is (e.g. "F set", "Ps act", "Fan1", "EEV")
    if (/[A-Z]/.test(label)) return label;
    // lowercase -> Capitalize first letter only
    return label.charAt(0).toUpperCase() + label.slice(1);
  }

  function applyPrettyLabels() {
    const panel = document.getElementById('seriesPanel');
    if (!panel) return;
    panel.querySelectorAll('label.btn[title]').forEach(lbl => {
      const raw = lbl.getAttribute('title') || lbl.textContent || '';
      lbl.textContent = prettyLabel(raw);
    });
  }

function customLegendFormatter(data) {
    // When not hovering: show nothing (keeps chart clean)
    if (!data || data.x == null) return "";
    let html = '<div class="dygraph-legend-inner">';
    html += '<div class="legend-x">' + data.xHTML + '</div>';
    const series = data.series || [];
    for (let i = 0; i < series.length; i++) {
      const s = series[i];
      if (!s || !s.isVisible) continue;
      let c = s.color || '#888';
      if (s.label === "Mode" && s.y != null) c = modeColorForValue(s.y);
      if (s.label === "Threeway valve" && s.y != null) {
        const cc = threewayColorForValue(s.y, s.color || c);
        if (cc) c = cc;
      }
      html += '<div class="legend-item">'
           +  '<span class="legend-swatch" style="background:' + c + '"></span>'
           +  '<span class="legend-label" style="color:' + c + '">' + prettyLabel(s.label) + '</span>'
           +  ': <span class="legend-val">' + formatLegendValue(s.label, s.y, s.yHTML) + '</span>'
           +  '</div>';
    }
    html += '</div>';
    return html;
  }

// --- Chart config (one big chart) ---
  let chartsConfig = {
    chart0: {
      labels: ["Date", "tank", "twi", "two", "thi", "tho", "ts", "td", "tao", "intemp", "humid", "outtemp", "hcurve", "tdef", "F set", "F act", "F limit", "Ps set", "Ps act", "Pd set", "Pd act", "superheat", "subcooling", "Threeway valve", "Defrost", "Antifreeze", "EEV", "Fan1", "Fan2", "Mode", "Heater"],
      // Defrost must be turquoise; Antifreeze should be gold-brown (takes the old defrost color).
      colors: ["#f44336", "#9fc5e8", "#d5a6bd", "#b6d7a8", "#6aa84f", "#FF6666", "#CC3333", "#bcbcbc", "#fc60ce", "#ccf5ff", "#999999", "#994d00", "#9cf4e1", "#a64dff", "#8c1aff", "#ffff00", "#33ffcc", "#00b386", "#ffbf80", "#ff9933", "#ff3385", "#0066ff", "#E53935", "#00CCCC", "#999966", "#a3c2c2", "#85adad", "#1a237e", "#9E9E9E", "#c40233"],
      visibility: [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
      valueRange: [-20, 270],
      axes: { y: { ticker: yTickerForce260 } },
      
      legendFormatter: customLegendFormatter,
data: [],
      series: {
        "Mode": { plotter: modeStepPlotter },
        "F limit": { stepPlot: true },
        "Threeway valve": { plotter: threewayStepPlotter },
        // Defrost/Antifreeze as continuous step lines (like in 1.4.5)
        "Defrost": { stepPlot: true },
        "Antifreeze": { stepPlot: true },
        "Heater": { stepPlot: true }
      },
      valueFormatter: function(value, opts, seriesName) {
        if (value === null || value === undefined || value === "") return "";
        const n = Number(value);
        if (!isFinite(n)) return "";

        if (seriesName === "F limit") {
          return (n >= 255) ? "ON" : "OFF"; // 260=ON, 250=OFF
        }

        if (seriesName === "Mode") {
          const code = modeCodeFromBand(n);
          if (code === 1) return "Quiet";
          if (code === 2) return "Eco";
          if (code === 3) return "Turbo";
          return "Off";
        }

        if (seriesName === "Threeway valve") {
          return threewayLabelFromBand(n);
        }

        if (seriesName === "Defrost") {
          return (n >= 212) ? "ON" : "OFF";
        }
        if (seriesName === "Antifreeze") {
          return (n >= 265) ? "ON" : "OFF";
        }

        // default numeric formatting
        return (Math.abs(n) < 10 && n % 1 !== 0) ? n.toFixed(2) : String(n);
      }
    }
  };

  // Apply persisted visibility to UI & config BEFORE first draw
  _applyVisToUIAndConfig();

  // ---- Date parsing/formatting helpers ----
  function _pad2(n) { return (n < 10 ? "0" : "") + n; }

  function parseChartDate(input) {
    const now = new Date();
    if (input === null || input === undefined || input === "") return new Date(NaN);

    const normalize = (d, kind) => {
      if (!(d instanceof Date) || isNaN(d.getTime())) return d;
      if (d.getFullYear() !== 2001) return d;

      if (kind === "timestamp") {
        return new Date(
          now.getFullYear(), now.getMonth(), now.getDate(),
          d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds()
        );
      }
      const dd = new Date(d.getTime());
      dd.setFullYear(now.getFullYear());
      return dd;
    };

    if (input instanceof Date) {
      return normalize(new Date(input.getTime()), "date");
    }

    const asString = (typeof input === "string") ? input.trim() : null;
    const isNumericString = asString && /^\d{10,13}$/.test(asString);

    if (typeof input === "number" || isNumericString) {
      let n = (typeof input === "number") ? input : parseInt(asString, 10);
      if (n > 1e9 && n < 1e11) n = n * 1000;
      return normalize(new Date(n), "timestamp");
    }

    const s = String(input).trim();
    if (!s) return new Date(NaN);

    // Try native parsing first
    const d1 = new Date(s);
    if (!isNaN(d1.getTime())) return normalize(d1, "string");

    // Fallback: YYYY/MM/DD HH:MM:SS
    const m = s.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
    if (m) {
      const yy = parseInt(m[1], 10);
      const mo = parseInt(m[2], 10) - 1;
      const dd = parseInt(m[3], 10);
      const hh = m[4] ? parseInt(m[4], 10) : 0;
      const mi = m[5] ? parseInt(m[5], 10) : 0;
      const ss = m[6] ? parseInt(m[6], 10) : 0;
      return new Date(yy, mo, dd, hh, mi, ss);
    }

    return new Date(NaN);
  }

  function defaultXValueFormatter(ms) {
    const d = parseChartDate(ms);
    if (!(d instanceof Date) || isNaN(d.getTime())) return "";
    return d.getFullYear() + "/" + _pad2(d.getMonth() + 1) + "/" + _pad2(d.getDate()) +
      " " + _pad2(d.getHours()) + ":" + _pad2(d.getMinutes()) + ":" + _pad2(d.getSeconds());
  }

  function formatChartData(rawData) {
    const { chartdate, ...series } = rawData;
    if (!chartdate || !Array.isArray(chartdate) || chartdate.length === 0) return [];

    const seriesArrays = Object.values(series);

    const mappedData = chartdate.map((date, index) => [
      parseChartDate(date),
      ...seriesArrays.map(arr => {
        if (!arr || !Array.isArray(arr)) return null;
        const value = arr[index];
        return (value === null || value === undefined || value === "" || value === "ERROR" || isNaN(value)) ? null : parseFloat(value);
      })
    ]);

    return mappedData.filter(row => {
      const d = row[0];
      return d instanceof Date && !isNaN(d.getTime());
    });
  }

  function generateOrUpdateDygraph(divId, config) {
    const _t = (key, fallback) => (window.i18next && i18next.exists(key)) ? i18next.t(key) : fallback;
    const _ylabel = _t('charts.ylabel', 'Value');
    const _xlabel = _t('charts.xlabel', 'Time');

    const axesMerged = Object.assign({}, (config.axes || {}));
    axesMerged.x = Object.assign({ valueFormatter: defaultXValueFormatter }, (axesMerged.x || {}));

    let existingChart = charts.find(c => c.divId === divId);
    if (existingChart) {
      // Preserve user zoom (dateWindow) across *live* updates, unless the user
      // explicitly switched the requested time range (12h/48h/etc.). In that case,
      // reset to the full extent of the newly loaded data.
      const _dw = (typeof existingChart.chart.getOption === 'function')
        ? existingChart.chart.getOption('dateWindow')
        : null;

      const upd = {
        file: config.data.slice(),
        labels: config.labels,
        colors: config.colors,
        visibility: config.visibility,
        axes: axesMerged,
        xValueFormatter: defaultXValueFormatter,
        series: config.series || {},
        valueFormatter: config.valueFormatter || undefined,
        legendFormatter: config.legendFormatter || undefined,
        valueRange: config.valueRange || undefined,
        interactionModel: haierpiInteractionModel
      };
      if (resetZoomOnNextRender) {
        const full = _fullDateWindowFromData(config.data);
        if (full) upd.dateWindow = full;
        resetZoomOnNextRender = false;
      } else if (Array.isArray(_dw) && _dw.length === 2 && isFinite(_dw[0]) && isFinite(_dw[1])) {
        upd.dateWindow = _dw;
      }

      existingChart.chart.updateOptions(upd);
      enableWheelZoom(existingChart.chart);
      enableLegendClamp(existingChart.chart);
    } else {
      const chart = new Dygraph(
        document.getElementById(divId),
        config.data,
        {
          legend: 'follow',
          visibility: config.visibility,
          labels: config.labels,
          ylabel: _ylabel,
          xlabel: _xlabel,
          connectSeparatedPoints: true,
          colors: config.colors,
          axes: axesMerged,
          xValueFormatter: defaultXValueFormatter,
          series: config.series || {},
          valueFormatter: config.valueFormatter || undefined,
          legendFormatter: config.legendFormatter || undefined,
          valueRange: config.valueRange || undefined,
          interactionModel: haierpiInteractionModel
        }
      );
      // Enable mouse-wheel zoom on X axis (time) when hovering the plot.
      enableWheelZoom(chart);
      enableLegendClamp(chart);
      charts.push({ divId, chart });
    }
  }

  // --- Mouse wheel zoom (X axis) ---
  // Scroll up = zoom in (shorter time span), scroll down = zoom out.
  // Note: we intentionally leave Ctrl+Wheel to the browser (page zoom).
  function enableWheelZoom(g) {
    if (!g || !g.graphDiv) return;
    if (g.__haierpiWheelZoomAttached) return;
    g.__haierpiWheelZoomAttached = true;

    const div = g.graphDiv;

    div.addEventListener('wheel', function(ev) {
      try {
        if (!g || typeof g.updateOptions !== 'function') return;
        if (ev.ctrlKey) return; // keep browser zoom

        const area = (typeof g.getArea === 'function') ? g.getArea() : null;
        if (!area || !isFinite(area.w) || area.w <= 0) return;

        const rect = div.getBoundingClientRect();
        const x = ev.clientX - rect.left;
        const y = ev.clientY - rect.top;

        // Only zoom when the pointer is over the plotting area
        if (x < area.x || x > (area.x + area.w)) return;
        if (y < area.y || y > (area.y + area.h)) return;

        ev.preventDefault();

        const range = (typeof g.xAxisRange === 'function') ? g.xAxisRange() : null;
        if (!range || !isFinite(range[0]) || !isFinite(range[1])) return;

        const extremes = (typeof g.xAxisExtremes === 'function') ? g.xAxisExtremes() : range;
        const minExt = extremes[0], maxExt = extremes[1];
        const fullSpan = maxExt - minExt;
        if (!isFinite(fullSpan) || fullSpan <= 0) return;

        const pct = Math.min(1, Math.max(0, (x - area.x) / area.w));
        const minX = range[0], maxX = range[1];
        const curSpan = maxX - minX;
        if (!isFinite(curSpan) || curSpan <= 0) return;

        // Smooth-ish zoom factor
        const direction = (ev.deltaY < 0) ? -1 : 1;
        const factor = direction < 0 ? 0.85 : 1.18;

        // Clamp span (min 2 minutes, max full data range)
        const minSpan = 2 * 60 * 1000;
        let newSpan = curSpan * factor;
        newSpan = Math.max(minSpan, Math.min(fullSpan, newSpan));

        const center = minX + pct * curSpan;
        let newMin = center - pct * newSpan;
        let newMax = newMin + newSpan;

        // Clamp to data extremes
        if (newMin < minExt) {
          newMin = minExt;
          newMax = newMin + newSpan;
        }
        if (newMax > maxExt) {
          newMax = maxExt;
          newMin = newMax - newSpan;
        }

        g.updateOptions({ dateWindow: [newMin, newMax] });
      } catch (e) {
        // ignore wheel zoom errors
      }
    }, { passive: false });
  }

  // --- Keep "follow" legend inside the chart area ---
  function enableLegendClamp(g) {
    if (!g || !g.graphDiv) return;
    if (g.__haierpiLegendClampAttached) return;
    g.__haierpiLegendClampAttached = true;

    const div = g.graphDiv;

    function clampLegend() {
      const legend = div.querySelector('.dygraph-legend');
      if (!legend) return;

      const pad = 6;

      // If legend is very tall (many series), make it scrollable.
      legend.style.maxHeight = Math.max(80, div.clientHeight - pad * 2) + 'px';
      legend.style.overflowY = 'auto';
      legend.style.overflowX = 'hidden';
      legend.style.right = '';
      legend.style.bottom = '';

      let left = parseFloat(legend.style.left);
      let top = parseFloat(legend.style.top);
      if (!isFinite(left)) left = pad;
      if (!isFinite(top)) top = pad;

      const lw = legend.offsetWidth;
      const lh = legend.offsetHeight;

      const maxLeft = div.clientWidth - lw - pad;
      const maxTop = div.clientHeight - lh - pad;

      const clampedLeft = Math.min(Math.max(left, pad), Math.max(pad, maxLeft));
      const clampedTop = Math.min(Math.max(top, pad), Math.max(pad, maxTop));

      legend.style.left = clampedLeft + 'px';
      legend.style.top = clampedTop + 'px';
    }

    div.addEventListener('mousemove', () => requestAnimationFrame(clampLegend), { passive: true });
    window.addEventListener('resize', () => requestAnimationFrame(clampLegend));
  }




  // --- Drag pan (instead of box-zoom) ---
  // Default: click-drag pans left/right. Hold Shift to use the original box-zoom selection.
  const haierpiInteractionModel = (function() {
    const d = Dygraph.defaultInteractionModel || (Dygraph.Interaction && Dygraph.Interaction.defaultModel) || {};
    const model = Object.assign({}, d);

    function _inPlotArea(ev, g) {
      const area = (typeof g.getArea === 'function') ? g.getArea() : null;
      if (!area || !g.graphDiv) return null;
      const rect = g.graphDiv.getBoundingClientRect();
      const x = ev.clientX - rect.left;
      const y = ev.clientY - rect.top;
      if (x < area.x || x > (area.x + area.w)) return null;
      if (y < area.y || y > (area.y + area.h)) return null;
      return { area, rect, x, y };
    }

    function _clampDateWindow(g, dw) {
      const ex = (typeof g.xAxisExtremes === 'function') ? g.xAxisExtremes() : dw;
      const minExt = ex[0], maxExt = ex[1];
      let a = dw[0], b = dw[1];
      const span = b - a;
      if (!isFinite(span) || span <= 0) return dw;

      if (a < minExt) { a = minExt; b = a + span; }
      if (b > maxExt) { b = maxExt; a = b - span; }
      if (a < minExt) a = minExt;
      if (b > maxExt) b = maxExt;
      return [a, b];
    }

    model.mousedown = function(ev, g, ctx) {
      // Left button only; Shift keeps legacy drag-zoom.
      if (ev.button !== 0 || ev.shiftKey) {
        if (d.mousedown) return d.mousedown(ev, g, ctx);
        return;
      }

      const hit = _inPlotArea(ev, g);
      if (!hit) {
        if (d.mousedown) return d.mousedown(ev, g, ctx);
        return;
      }

      ev.preventDefault();

      const range = (typeof g.xAxisRange === 'function') ? g.xAxisRange() : null;
      const dw = (typeof g.getOption === 'function') ? g.getOption('dateWindow') : null;
      const startDW = (Array.isArray(dw) && dw.length === 2 && isFinite(dw[0]) && isFinite(dw[1])) ? dw : range;
      if (!startDW || !isFinite(startDW[0]) || !isFinite(startDW[1])) return;

      ctx.isPanning = true;
      ctx.panStartX = ev.clientX;
      ctx.panStartDW = [startDW[0], startDW[1]];
      ctx.panAreaW = hit.area.w;

      if (g.graphDiv) g.graphDiv.style.cursor = 'grabbing';
    };

    model.mousemove = function(ev, g, ctx) {
      if (ctx && ctx.isPanning) {
        ev.preventDefault();

        const dx = ev.clientX - ctx.panStartX;
        const span = ctx.panStartDW[1] - ctx.panStartDW[0];
        if (!isFinite(span) || span <= 0 || !isFinite(ctx.panAreaW) || ctx.panAreaW <= 0) return;

        const dt = -dx * (span / ctx.panAreaW);
        let newDW = [ctx.panStartDW[0] + dt, ctx.panStartDW[1] + dt];
        newDW = _clampDateWindow(g, newDW);

        g.updateOptions({ dateWindow: newDW });
        return;
      }

      if (d.mousemove) return d.mousemove(ev, g, ctx);
    };

    model.mouseup = function(ev, g, ctx) {
      if (ctx && ctx.isPanning) {
        ctx.isPanning = false;
        if (g.graphDiv) g.graphDiv.style.cursor = '';
        return;
      }
      if (d.mouseup) return d.mouseup(ev, g, ctx);
    };

    // Keep default dblclick/click behaviour (often resets zoom)
    if (d.dblclick) model.dblclick = d.dblclick;
    if (d.click) model.click = d.click;

    return model;
  })();


  // ---- Socket handlers ----
  let socket = null;
  function disableLiveUI() {
    $("#btnradio4").prop("disabled", true);
    $('label[for="btnradio4"]').addClass("disabled");
  }
  if (typeof io === "undefined") {
    console.error("Socket.IO client not loaded (io is undefined).");
    disableLiveUI();
    $("#chart0").prepend('<div class="alert alert-danger mb-2">Brak biblioteki Socket.IO (io undefined). Sprawdź dostęp do internetu lub /socket.io/socket.io.js.</div>');
  } else {
    socket = io();

    // Start hidden until the first correct-range payload arrives
    requestedChartsVal = $("input[name='btnradio']:checked").val();
    suppressUntilMatch = true;
    _setChartLoading(true);

    socket.on("connect", () => {
    console.log("Połączono z serwerem Socket.io");

    const v = $("input[name='btnradio']:checked").val();
    requestedChartsVal = v || requestedChartsVal;
    suppressUntilMatch = true;
    _setChartLoading(true);

    if (v) socket.emit('client', { charts: v });
  });

socket.on('charts', function(data) {
    const chartdate = data['chartdate'] || [];

    // If the server pushes a default payload first (e.g. shorter range), wait until we get
    // the requested range before rendering, so the user only sees a complete 12h/48h view.
    try {
      const expect = _expectedSpanMs(requestedChartsVal);
      if (suppressUntilMatch && expect && Array.isArray(chartdate) && chartdate.length > 1) {
        const t0 = parseChartDate(chartdate[0]);
        const t1 = parseChartDate(chartdate[chartdate.length - 1]);
        const span = (t0 instanceof Date && t1 instanceof Date) ? (t1.getTime() - t0.getTime()) : NaN;
        // Accept if within ~80% of expected span (tolerant to missing edge points).
        if (isFinite(span) && span < expect * 0.8) {
          return; // still waiting for the real payload
        }
        suppressUntilMatch = false;
      }
    } catch (e) { /* ignore */ }

    _setChartLoading(false);

    const charttank = data['charttank'] || [];
    const charttwi = data['charttwi'] || [];
    const charttwo = data['charttwo'] || [];
    const chartthi = data['chartthi'] || [];
    const charttho = data['charttho'] || [];
    const chartts = data['chartts'] || [];
    const charttd = data['charttd'] || [];
    const charttao = data['charttao'] || [];

    const chartintemp = filterOutliers(data['chartintemp'] || [], 50);
    const charthumid = filterOutliers(data['charthumid'] || [], 50);
    const chartouttemp = filterOutliers(data['chartouttemp'] || [], 50);

    const charthcurve = data['charthcurve'] || [];
    const charttdef = data['charttdef'] || [];
    const chartheater = data['chartheater'] || [];

    const chartfset = data['chartfset'] || [];
    const chartfact = data['chartfact'] || [];
    const chartflimiton = (data['chartflimiton'] || []).map(normalizeFLimit);
    const chartflimitBand = chartflimiton.map(v => {
      if (v === null || v === undefined) return null;
      // Draw as a simple ON/OFF band near the top of the chart
      return (Number(v) > 0) ? 260 : 250; // ON/OFF band
    });

    const chartpsset = data['chartpsset'] || [];
    const chartpsact = data['chartpsact'] || [];
    const chartpdset = data['chartpdset'] || [];
    const chartpdact = data['chartpdact'] || [];
    const chartsuperheat = data['chartsuperheat'] || [];
    const chartsubcooling = data['chartsubcooling'] || [];

    const charteevlevel = data['charteevlevel'] || [];
    const chartfan1 = data['chartfan1'] || [];
    const chartfan2 = data['chartfan2'] || [];

    const rawThreeway = (data['chartthreeway'] || []);
    const rawDefrost = (data['chartdefrost'] || []);
    const rawAntifreeze = (data['chartantifreeze'] || []);

    const chartthreewayBand = rawThreeway.map((v, i) =>
      mapThreewayValue(v, chartfact[i], chartfan1[i], chartfan2[i])
    );

    // Defrost / Antifreeze — same behavior as in 1.4.5:
    // continuous "band" line with two levels (ON vs OFF)
    const chartdefrostBand = rawDefrost.map(v => {
      if (v === null || v === undefined) return null;
      const s = String(v).trim().toUpperCase();
      if (s === '' || s === 'N/A' || s === 'NA' || s === 'ERROR') return null;
      if (s === 'ON' || s === 'TRUE' || s === '1' || s === 'DEFROST') return 218;
      if (s === 'OFF' || s === 'FALSE' || s === '0') return 205;

      const n = parseFloat(v);
      if (!isFinite(n)) return null;
      return (n > 0) ? 218 : 205; // ON / OFF
    });

    const chartantifreezeBand = rawAntifreeze.map(v => {
      if (v === null || v === undefined) return null;
      const s = String(v).trim().toUpperCase();
      if (s === '' || s === 'N/A' || s === 'NA' || s === 'ERROR') return null;
      if (s === 'ON' || s === 'TRUE' || s === '1' || s === 'ANTIFREEZE') return 268;
      if (s === 'OFF' || s === 'FALSE' || s === '0') return 262;

      const n = parseFloat(v);
      if (!isFinite(n)) return null;
      return (n > 0) ? 268 : 262; // ON / OFF
    });

    const chartmode_quiet = data['chartmode_quiet'] || [];
    const chartmode_eco = data['chartmode_eco'] || [];
    const chartmode_turbo = data['chartmode_turbo'] || [];
    const chartmodeCode = mapModeSeries(chartmode_quiet, chartmode_eco, chartmode_turbo);
    const chartmodeBand = chartmodeCode.map(v => 210 + (Number(v) || 0) * 10);

    chartsConfig.chart0.data = formatChartData({
      chartdate,
      charttank,
      charttwi,
      charttwo,
      chartthi,
      charttho,
      chartts,
      charttd,
      charttao,
      chartintemp,
      charthumid,
      chartouttemp,
      charthcurve,
      charttdef,
      chartfset,
      chartfact,
      chartflimitBand,
      chartpsset,
      chartpsact,
      chartpdset,
      chartpdact,
      chartsuperheat,
      chartsubcooling,
      chartthreewayBand,
      chartdefrostBand,
      chartantifreezeBand,
      charteevlevel,
      chartfan1,
      chartfan2,
      chartmodeBand,
      chartheater
    });

    generateOrUpdateDygraph("chart0", chartsConfig.chart0);

    // apply visibility to chart (in case it was set before chart creation)
    $('input[type="checkbox"][data-chart="0"]').each(function() {
      const idx = parseInt(this.name, 10);
      if (!isNaN(idx)) _applyVisibilityToChart(idx, !!this.checked);
    });
  });

  socket.on('chart_update', function(msg) {
    if (!$('#btnradio4').prop('checked')) return;

    const dt = parseChartDate(msg.datechart);

    const flRaw = normalizeFLimit(msg.flimitonchart);
    const flBand = (flRaw === null || flRaw === undefined) ? null : (Number(flRaw) > 0 ? 260 : 250);

    const threewayBand = mapThreewayValue(msg.threewaychart, msg.factchart, msg.fan1chart, msg.fan2chart);
    const defrostBand = mapDefrostValue(msg.defrostchart, msg.factchart, msg.fan1chart, msg.fan2chart, msg.threewaychart);
    const antifreezeBand = mapAntifreezeValue(msg.antifreezechart, msg.threewaychart);

    const modeCode = mapModeValue(msg.modechart_quiet, msg.modechart_eco, msg.modechart_turbo);
    const modeBand = 210 + (Number(modeCode) || 0) * 10;

    chartsConfig.chart0.data.push([
      dt,
      numOrNull(msg.tankchart),
      numOrNull(msg.twichart),
      numOrNull(msg.twochart),
      numOrNull(msg.thichart),
      numOrNull(msg.thochart),
      numOrNull(msg.tschart),
      numOrNull(msg.tdchart),
      numOrNull(msg.taochart),
      numOrNull(msg.intempchart),
      numOrNull(msg.humidchart),
      numOrNull(msg.outtempchart),
      numOrNull(msg.hcurvechart),
      numOrNull(msg.tdefchart),
      numOrNull(msg.fsetchart),
      numOrNull(msg.factchart),
      flBand,
      numOrNull(msg.pssetchart),
      numOrNull(msg.psactchart),
      numOrNull(msg.pdsetchart),
      numOrNull(msg.pdactchart),
      numOrNull(msg.superheatchart),
      numOrNull(msg.subcoolingchart),
      threewayBand,
      defrostBand,
      antifreezeBand,
      numOrNull(msg.eevlevelchart),
      numOrNull(msg.fan1chart),
      numOrNull(msg.fan2chart),
      modeBand,
      numOrNull(msg.heaterchart)
    ]);

    generateOrUpdateDygraph("chart0", chartsConfig.chart0);
  });

  }

  $("input[name='btnradio']").click(function() {
    if (!socket) return;
    requestedChartsVal = $(this).val();
    // User switched range: next render should show the full available range.
    resetZoomOnNextRender = true;
    suppressUntilMatch = true;
    _setChartLoading(true);
    socket.emit('client', { charts: requestedChartsVal });
  });
});
    } catch(e) { console.error('HPI inline script error (charts.html #1)', e); }
  });


})();
