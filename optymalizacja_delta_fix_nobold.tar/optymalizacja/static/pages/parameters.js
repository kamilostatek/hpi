/* === Inline scripts extracted from templates (split) === */
(function(){
  'use strict';
  const PAGE = (document.body && document.body.dataset) ? (document.body.dataset.page || '') : '';
  function onReady(fn){
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  // From templates/parameters.html (block 1)
  onReady(function(){
    if(!(PAGE === 'parameters')) return;
    try {
function getdata() {
	$.get('/getdata', function(data) {
		$("#ttemp").text(parseFloat(data.tank).toFixed(1) + " °C");
		$("#intemp").text(parseFloat(data.intemp).toFixed(1) + " °C");
		$("#humid").text(parseFloat(data.humid).toFixed(1) + " %");
		$("#dhwsetpoint").text(parseFloat(data.dhw).toFixed(1) + " °C");
		$("#hcurve").text(parseFloat(data.hcurve).toFixed(1) + " °C");
		$("#setpoint").text(parseFloat(data.setpoint).toFixed(1) + " °C");
		$("#mode").text(data.mode)
		$("#flimiton").text(data.flimiton)
		// Defrost params
		if ($.isNumeric(data.tdef)) {
			$("#tdef").text(parseFloat(data.tdef).toFixed(1) + " °C");
		} else {
			$("#tdef").text(data.tdef);
		}
		switch(String(data.defrost).toLowerCase()) {
			case "on":
				$("#defrost").text("on");
				break;
			default:
				$("#defrost").text("off");
		}

		// Heater params
		switch(String(data.heater).toLowerCase()) {
			case "on":
				$("#heater").text("on");
				break;
			default:
				$("#heater").text("off");
		}

		// Antifreeze params
		switch(String(data.antifreeze).toLowerCase()) {
			case "on":
				$("#antifreeze").text("on");
				break;
			default:
				$("#antifreeze").text("off");
		}

switch(data.flimiton) {
		case "0":
		    if($("#flrelay").text() != "off") {
		        $("#flrelay").text("off")
			    }
			break;
		case "1":
		    if($("#flrelay").text() != "on") {
		        $("#flrelay").text("on")
			    }
			break;
			    }
switch(data.mode){
		case "quiet":
		    if($("#mode").text() != "quiet") {
			$("#mode").text("quiet")
			    }
			break;
		case "eco":
		    if($("#mode").text() != "eco") {
			$("#mode").text("eco")
			    }
			break;
		 case "turbo":
		    if($("#mode").text() != "turbo") {
			$("#mode").text("turbo")
			    }
			break;
	    default:
	    }

		})
	$.get('/getparams', function(data) {
		$("#twi").text(data.twitwo[0]+" °C")
		$("#two").text(data.twitwo[1]+" °C")
        $("#thi").text(data.thitho[0]+" °C")
        $("#tho").text(data.thitho[1]+" °C")
        $("#pdset").text(data.pdps[0]+" bar")
        $("#pdact").text(data.pdps[1]+" bar")
		$("#psset").text(data.pdps[2]+" bar")
        $("#psact").text(data.pdps[3]+" bar")
		$("#tsatpsset").text(data.tsatps[0]+" °C")
		$("#tsatpsact").text(data.tsatps[1]+" °C")
		$("#tsatpdset").text(data.tsatpd[0]+" °C")
		$("#tsatpdact").text(data.tsatpd[1]+" °C")
		$("#eevlevel").text(data.eevlevel+" °")
        $("#deltat").text((data.twitwo[1]-data.twitwo[0]).toFixed(1)+" °C")
        $("#fact").text(data.compinfo[0]+" Hz")
        $("#fset").text(data.compinfo[1]+" Hz")
        $("#ccurr").text(data.compinfo[2]+" A")
        $("#cvolt").text(data.compinfo[3]+" V")
        $("#ctemp").text(data.compinfo[4]+" °C")
        $("#fan1").text(data.fans[0]+" rpm")
		$("#fan2").text(data.fans[1]+" rpm")
		$("#tao").text(data.tao+" °C")
		$("#td").text(data.tdts[0]+" °C")
		$("#ts").text(data.tdts[1]+" °C")
		$("#pump").text(data.pump)
		$("#chkwhpd").text(parseFloat(data.chkwhpd).toFixed(1) + " kWh");
		$("#dhwkwhpd").text(parseFloat(data.dhwkwhpd).toFixed(1) + " kWh");
			let dailykwh = parseFloat(data.chkwhpd) + parseFloat(data.dhwkwhpd);
		$("#dailykwh").text(dailykwh.toFixed(1) + " kWh");
		$("#threeway").text(data.threeway)
		$("#flrelay").text(data.flrelay)
		$("#superheat").text((data.superheat !== undefined) ? (data.superheat + " °C") : "");
		$("#subcooling").text((data.subcooling !== undefined) ? (data.subcooling + " °C") : "");
switch(data.threeway) {
	    case "CH":
			if($("#threeway").text() != "ch") {
			    $("#threeway").text("ch")
				}
			break;
	    case "DHW":
			if($("#threeway").text() != "dhw") {
			    $("#threeway").text("dhw")
			}
			break;
	    default:
		}
switch(data.pump) {
	    case "ON":
			if($("#pump").text() != "on") {
			    $("#pump").text("on")
				}
			break;
	    case "OFF":
			if($("#pump").text() != "off") {
			    $("#pump").text("off")
			}
			break;
	    default:
		}
    });
	}
//setInterval(getdata, 2000);

$(document).ready(function(){ getdata(); });
    } catch(e) { console.error('HPI inline script error (parameters.html #1)', e); }
  });


})();
