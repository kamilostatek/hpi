#!/usr/bin/env bash
# Instalator HaierPi Alpha13: menu, konfiguracja i bezpieczne potwierdzenia T/N.
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
[[ $EUID -eq 0 ]] || { echo 'Uruchom jako administrator: sudo bash install.sh'; exit 1; }
[[ -f "$ROOT_DIR/scripts/install-fresh.sh" && -f "$ROOT_DIR/app/main.py" ]] || {
  echo 'Niekompletne archiwum instalatora. Rozpakuj całą paczkę TAR.GZ.' >&2; exit 1;
}
[[ -r /dev/tty ]] || { echo 'Instalator wymaga terminala (SSH lub konsoli).'; exit 1; }

komunikat() { printf '%s\n' "$*" > /dev/tty; }
pytaj() { local odpowiedz; read -r -p "$1" odpowiedz < /dev/tty || return 1; printf '%s' "$odpowiedz"; }
potwierdz() {
  local odp
  odp="$(pytaj 'Czy chcesz kontynuować? [T/N]: ')" || return 1
  case "${odp^^}" in
    T) return 0 ;;
    N|'') komunikat 'Anulowano. Nie wprowadzono zmian.'; return 1 ;;
    *) komunikat 'Nieprawidłowa odpowiedź. Wpisz T (tak) albo N (nie).'; return 1 ;;
  esac
}
rozpoznaj_plytke() {
  local model=''
  if [[ -r /proc/device-tree/model ]]; then
    model=$(tr -d '\000' < /proc/device-tree/model)
  fi
  if [[ "${model,,}" == *'nanopi neo2'* || "${model,,}" == *'nanopi neo3'* ]]; then echo unsupported
  elif [[ "${model,,}" == *'nanopi neo'* ]]; then echo nanopi
  elif [[ "${model,,}" == *'raspberry pi zero'* ]]; then echo rpi
  else echo unknown; fi
}
wybierz_plytke() {
  local wykryta plytka
  wykryta=$(rozpoznaj_plytke)
  case "$wykryta" in
    nanopi) komunikat 'Wykryto NanoPi NEO (Allwinner H3).' ;;
    rpi) komunikat 'Wykryto Raspberry Pi Zero / Zero 2.' ;;
    unsupported) komunikat 'NanoPi NEO2/NEO3 nie jest obsługiwany przez ten profil.'; return 1 ;;
    unknown) komunikat 'Nie udało się automatycznie rozpoznać płytki.' ;;
  esac
  komunikat '1) NanoPi NEO'
  komunikat '2) Raspberry Pi Zero / Zero 2'
  case "$(pytaj 'Wybierz płytkę [1/2]: ')" in
    1) plytka=nanopi ;;
    2) plytka=rpi ;;
    *) komunikat 'Anulowano: nieprawidłowy wybór płytki.'; return 1 ;;
  esac
  if [[ "$wykryta" != unknown && "$plytka" != "$wykryta" ]]; then
    komunikat 'Wybrany profil nie zgadza się z wykrytą płytką. Nic nie zmieniono.'
    return 1
  fi
  if [[ "$wykryta" == unknown ]]; then
    komunikat 'UWAGA: błędne przypisanie GPIO może uszkodzić podłączony sprzęt.'
    potwierdz || return 1
  fi
  printf '%s\n' "$plytka"
}
bezpiecznie_zatrzymaj() {
  local opis="$1"
  komunikat "Operacja: $opis."
  komunikat 'Może spowodować zatrzymanie sterowania ogrzewaniem i pompą.'
  komunikat 'Najpierw zapewnij bezpieczny stan pompy oraz przekaźników.'
  potwierdz || return 1
  if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files haier.service --no-legend 2>/dev/null | grep -q 'haier.service'; then
    systemctl disable --now haier.service || { komunikat 'BŁĄD: nie udało się zatrzymać usługi haier.service.'; return 1; }
    komunikat 'Usługa haier.service zatrzymana i wyłączona (wymaga ręcznego uruchomienia).'
  fi
}
sprawdz_instalacje() {
  [[ -s /opt/haier/main.py && -f /opt/config.ini ]] || {
    komunikat 'Nie znaleziono instalacji HaierPi w /opt/haier i /opt/config.ini.'
    komunikat 'Wybierz opcję 1, aby wykonać nową instalację.'; return 1;
  }
}
wybierz_temperature() {
  komunikat 'Skąd NanoPi NEO ma pobierać temperaturę zewnętrzną?'
  komunikat '1) Fizyczny czujnik DS18B20 (1-Wire, PA6)'
  komunikat '2) Home Assistant (encja temperatury)'
  case "$(pytaj 'Wybierz [1/2]: ')" in
    1) echo ds18b20 ;;
    2) echo ha ;;
    *) komunikat 'Anulowano: nieprawidłowy wybór.'; return 1 ;;
  esac
}
pelna_instalacja() {
  local plytka; plytka=$(wybierz_plytke) || return
  if [[ -e /opt/haier/main.py ]]; then
    komunikat 'HaierPi jest już zainstalowany. Opcja 1 go nie nadpisze.'
    komunikat 'Użyj opcji 5, aby usunąć starą instalację z zachowaniem config.ini.'; return
  fi
  komunikat 'Pełna instalacja: Python, biblioteki pip, HaierPi i usługa systemowa.'
  potwierdz || return
  bash "$ROOT_DIR/scripts/install-fresh.sh" "$plytka"
}
konfiguruj_sprzet() {
  local plytka; plytka=$(wybierz_plytke) || return
  sprawdz_instalacje || return
  bezpiecznie_zatrzymaj 'konfiguracja UART i GPIO' || return
  if [[ "$plytka" == nanopi ]]; then
    python3 "$ROOT_DIR/scripts/apply-board-profile.py" nanopi || return
  else
    python3 "$ROOT_DIR/scripts/apply-board-profile.py" rpi || return
  fi
  bash "$ROOT_DIR/scripts/configure-uart.sh" "$plytka" || {
    komunikat 'UWAGA: nie udało się automatycznie skonfigurować UART. Sprawdź ustawienia rozruchowe.'
    return 1
  }
  komunikat 'Zapisano konfigurację. Przed włączeniem HaierPi uruchom ponownie urządzenie.'
}
konfiguruj_temperature() {
  local plytka wybrana; plytka=$(wybierz_plytke) || return
  [[ "$plytka" == nanopi ]] || { komunikat 'Wybór źródła temperatury dotyczy tylko NanoPi NEO.'; return; }
  sprawdz_instalacje || return
  wybrana=$(wybierz_temperature) || return
  bezpiecznie_zatrzymaj 'źródło temperatury zewnętrznej' || return
  if [[ "$wybrana" == ds18b20 ]]; then
    bash "$ROOT_DIR/scripts/configure-onewire-nanopi.sh" || return
    python3 "$ROOT_DIR/scripts/set-outside-source.py" ds18b20 || return
    komunikat 'Po restarcie sprawdź czujnik: ls /sys/bus/w1/devices/28-*'
  else
    bash "$ROOT_DIR/scripts/disable-onewire-nanopi.sh" || return
    python3 "$ROOT_DIR/scripts/set-outside-source.py" ha || return
    komunikat 'Uzupełnij dane Home Assistant w sekcji [HOMEASSISTANT] pliku /opt/config.ini.'
  fi
  komunikat 'Zapisano źródło temperatury. Po zmianie nakładki 1-Wire wymagany jest restart.'
}
napraw_zaleznosci() {
  [[ -d /opt/haier ]] || { komunikat 'Nie ma /opt/haier. Najpierw wybierz opcję 1.'; return; }
  bezpiecznie_zatrzymaj 'naprawa bibliotek Python / pip' || return
  bash "$ROOT_DIR/scripts/repair-deps.sh" || return
  komunikat 'Zakończono sprawdzanie bibliotek. Usługa pozostaje wyłączona.'
}
usun_stary() {
  local plytka; plytka=$(wybierz_plytke) || return
  komunikat 'Operacja usuwa wyłącznie /opt/haier — nigdy cały katalog /opt.'
  komunikat 'Zachowuje /opt/config.ini i dopisuje brakujące ustawienia Alpha13.'
  bash "$ROOT_DIR/scripts/remove-old.sh" "$plytka" || return
}
# Tryb zgodny z poprzednim instalatorem: instaluje, ale wymaga potwierdzenia T/N.
if [[ $# -eq 1 && ( $1 == nanopi || $1 == rpi ) ]]; then
  komunikat 'Pełna instalacja HaierPi Alpha13 na wskazanej płytce.'
  potwierdz || exit 0
  exec bash "$ROOT_DIR/scripts/install-fresh.sh" "$1"
fi
[[ $# -eq 0 ]] || { echo 'Użycie: sudo bash install.sh [nanopi|rpi]'; exit 1; }
while true; do
  komunikat ''
  komunikat '=============================================='
  komunikat '              Instalator HaierPi'
  komunikat '=============================================='
  komunikat '1. Pełna instalacja HaierPi na czystym systemie'
  komunikat '2. Konfiguracja UART i GPIO'
  komunikat '3. Konfiguracja temperatury zewnętrznej dla NanoPi'
  komunikat '4. Naprawa zależności Python / pip'
  komunikat '5. Usuń starą instalację HaierPi (zachowaj config.ini)'
  komunikat '6. Zakończ'
  komunikat '=============================================='
  wybor=$(pytaj 'Wybierz opcję [1-6]: ') || exit 0
  case "$wybor" in
    1) pelna_instalacja || komunikat 'Operacja nie została zakończona.' ;;
    2) konfiguruj_sprzet || komunikat 'Operacja nie została zakończona.' ;;
    3) konfiguruj_temperature || komunikat 'Operacja nie została zakończona.' ;;
    4) napraw_zaleznosci || komunikat 'Operacja nie została zakończona.' ;;
    5) usun_stary || komunikat 'Usuwanie nie zostało zakończone.' ;;
    6) komunikat 'Zakończono pracę instalatora.'; exit 0 ;;
    *) komunikat 'Nieprawidłowy wybór.' ;;
  esac
done
