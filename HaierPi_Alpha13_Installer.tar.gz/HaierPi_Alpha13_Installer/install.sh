#!/usr/bin/env bash
# HaierPi Alpha13 installer and configuration menu (no updater).
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
[[ $EUID -eq 0 ]] || { echo 'Run as root: sudo bash install.sh'; exit 1; }
[[ -f "$ROOT_DIR/scripts/install-fresh.sh" && -f "$ROOT_DIR/app/main.py" ]] || {
  echo 'Incomplete installer archive; unpack the complete tar.gz first.' >&2; exit 1;
}
# Preserve compatibility with the original v5 one-shot command.
if [[ $# -eq 1 && ( $1 == nanopi || $1 == rpi ) ]]; then
  exec bash "$ROOT_DIR/scripts/install-fresh.sh" "$1"
fi
[[ $# -eq 0 ]] || { echo 'Usage: sudo bash install.sh [nanopi|rpi]'; exit 1; }
[[ -r /dev/tty ]] || { echo 'This menu requires an interactive terminal.' >&2; exit 1; }

say() { printf '%s\n' "$*" > /dev/tty; }
ask() { local REPLY; read -r -p "$1" REPLY < /dev/tty || return 1; printf '%s' "$REPLY"; }
model_board() {
  local model=''
  if [[ -r /proc/device-tree/model ]]; then
    model=$(tr -d '\000' < /proc/device-tree/model)
  fi
  if [[ "${model,,}" == *'nanopi neo2'* || "${model,,}" == *'nanopi neo3'* ]]; then echo unsupported
  elif [[ "${model,,}" == *'nanopi neo'* ]]; then echo nanopi
  elif [[ "${model,,}" == *'raspberry pi zero'* ]]; then echo rpi
  else echo unknown; fi
}
choose_board() {
  local detected board
  detected=$(model_board)
  if [[ "$detected" == nanopi ]]; then
    say 'Detected NanoPi NEO (Allwinner H3).'
  elif [[ "$detected" == rpi ]]; then
    say 'Detected Raspberry Pi Zero / Zero 2.'
  elif [[ "$detected" == unsupported ]]; then
    say 'NanoPi NEO2/NEO3 is not supported by this profile.'
    return 1
  else
    say 'Board model could not be verified automatically.'
  fi
  say '1) NanoPi NEO'
  say '2) Raspberry Pi Zero / Zero 2'
  case "$(ask 'Board [1/2]: ')" in
    1) board=nanopi ;;
    2) board=rpi ;;
    *) say 'Cancelled: invalid board.'; return 1 ;;
  esac
  if [[ "$detected" != unknown && "$board" != "$detected" ]]; then
    say 'Selected profile does not match the detected board. No changes made.'
    return 1
  fi
  if [[ "$detected" == unknown ]]; then
    say 'WARNING: wrong board configuration may damage connected hardware.'
    [[ "$(ask 'Type ZGADZA_SIE to confirm board manually: ')" == ZGADZA_SIE ]] || return 1
  fi
  printf '%s\n' "$board"
}
safe_stop() {
  local purpose="$1"
  say "This action ($purpose) may stop active heating/pump control."
  say 'First put the heat pump and relay outputs into a safe state.'
  [[ "$(ask 'Type BEZPIECZNIE to continue: ')" == BEZPIECZNIE ]] || {
    say 'Cancelled: no changes.'; return 1;
  }
  if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files haier.service --no-legend 2>/dev/null | grep -q 'haier.service'; then
    systemctl disable --now haier.service || { say 'Could not stop/disable haier.service. Aborting.'; return 1; }
    say 'haier.service stopped and disabled (manual re-enable required).'
  fi
}
check_existing() {
  [[ -s /opt/haier/main.py && -f /opt/config.ini ]] || {
    say 'HaierPi was not found at /opt/haier/main.py with /opt/config.ini.'
    say 'Use menu option 1 for a fresh installation.'; return 1;
  }
}
choose_outside() {
  say 'Temperature source for NanoPi NEO:'
  say '1) DS18B20 sensor (1-Wire, PA6)'
  say '2) Home Assistant (HA temperature sensor)'
  case "$(ask 'Choice [1/2]: ')" in
    1) echo ds18b20 ;;
    2) echo ha ;;
    *) say 'Cancelled: invalid choice.'; return 1 ;;
  esac
}
option_fresh() {
  local board; board=$(choose_board) || return
  if [[ -e /opt/haier/main.py ]]; then
    say 'HaierPi is already installed. Option 1 will not overwrite it.'
    say 'Use option 5 to remove old HaierPi with config preservation.'; return
  fi
  say 'FULL installation: Python, pip, HaierPi code and systemd service.'
  [[ "$(ask 'Type INSTALUJ to continue: ')" == INSTALUJ ]] || return
  bash "$ROOT_DIR/scripts/install-fresh.sh" "$board"
}
option_hardware() {
  local board; board=$(choose_board) || return
  check_existing || return
  safe_stop 'UART and GPIO configuration' || return
  if [[ "$board" == nanopi ]]; then
    python3 "$ROOT_DIR/scripts/apply-board-profile.py" nanopi --port 80 || return
  else
    python3 "$ROOT_DIR/scripts/apply-board-profile.py" rpi || return
  fi
  bash "$ROOT_DIR/scripts/configure-uart.sh" "$board" || {
    say 'WARNING: UART configuration was not completed; check boot settings manually.'
    return 1
  }
  say 'Configuration saved. Reboot required before enabling HaierPi.'
}
option_temperature() {
  local board selected; board=$(choose_board) || return
  [[ "$board" == nanopi ]] || { say 'Temperature-source menu is only for NanoPi NEO.'; return; }
  check_existing || return
  selected=$(choose_outside) || return
  safe_stop 'outside temperature source' || return
  if [[ "$selected" == ds18b20 ]]; then
    # First verify and configure 1-Wire, only then select the new source in app config.
    bash "$ROOT_DIR/scripts/configure-onewire-nanopi.sh" || return
    python3 "$ROOT_DIR/scripts/set-outside-source.py" ds18b20 || return
    say 'Verify DS18B20 after reboot: ls /sys/bus/w1/devices/28-*'
  else
    bash "$ROOT_DIR/scripts/disable-onewire-nanopi.sh" || return
    python3 "$ROOT_DIR/scripts/set-outside-source.py" ha || return
    say 'Set [HOMEASSISTANT] server/token/temperature entity in /opt/config.ini.'
  fi
  say 'Source saved. Reboot if 1-Wire boot configuration changed.'
}
option_repair() {
  [[ -d /opt/haier ]] || { say 'No /opt/haier directory. Use option 1.'; return; }
  safe_stop 'repair Python / pip dependencies' || return
  bash "$ROOT_DIR/scripts/repair-deps.sh" || return
  say 'Dependency checks completed. Service remains disabled until manually enabled.'
}
option_remove_old() {
  local board; board=$(choose_board) || return
  say 'This action removes only /opt/haier, NEVER the whole /opt directory.'
  say 'It retains /opt/config.ini and fills only missing Alpha13 options.'
  bash "$ROOT_DIR/scripts/remove-old.sh" "$board" || return
}
while true; do
  say ''
  say '=============================================='
  say '        HaierPi Alpha13 Installer v8'
  say '=============================================='
  say '1. Pełna instalacja HaierPi na czystym systemie'
  say '2. Konfiguracja UART i GPIO'
  say '3. Konfiguracja temperatury zewnętrznej dla NanoPi'
  say '4. Naprawa zależności Python / pip'
  say '5. Usuń starą instalację HaierPi (zachowaj config.ini)'
  say '6. Zakończ'
  say '=============================================='
  choice=$(ask 'Wybierz opcje [1-6]: ') || exit 0
  case "$choice" in
    1) option_fresh || say 'Operation not completed.' ;;
    2) option_hardware || say 'Operation not completed.' ;;
    3) option_temperature || say 'Operation not completed.' ;;
    4) option_repair || say 'Operation not completed.' ;;
    5) option_remove_old || say 'Usuwanie nie zostalo zakonczone.' ;;
    6) say 'Zakończono.'; exit 0 ;;
    *) say 'Nieprawidlowy wybor.' ;;
  esac
done
