# Instalator HaierPi

Pakiet instalacyjny i serwisowy dla DietPi z Debianem 11 Bullseye (archiwalne repozytoria)
oraz wybranych zgodnych wersji Debiana. Sprzet: NanoPi NEO (Allwinner H3) i
Raspberry Pi Zero W / Zero 2 W. To wydanie jest testowe; NIE zostalo
uruchomione z podlaczona pompa ciepla na fizycznej plytce.

## Uruchomienie

Skopiuj archiwum na urzadzenie, rozpakuj je i uruchom:

    tar -xzf HaierPi_Alpha13_Installer.tar.gz
    cd HaierPi_Alpha13_Installer
    sudo bash install.sh

Dziala tez dotychczasowy tryb bez menu (wylacznie NOWA instalacja po ewentualnym usunieciu starej):

    sudo bash install.sh nanopi
    sudo bash install.sh rpi

## Menu

    Instalator HaierPi

    1. Pelna instalacja HaierPi na czystym systemie
    2. Konfiguracja UART i GPIO
    3. Konfiguracja temperatury zewnetrznej dla NanoPi
    4. Naprawa zaleznosci Python / pip
    5. Usun stara instalacje HaierPi, zachowaj config.ini
    6. Zakoncz

### 1. Pelna instalacja na czystym systemie

- Wybierasz NanoPi NEO lub Raspberry Pi Zero/Zero 2.
- Instalator sprawdza, czy root jest zapisywalny i czy /opt ma wystarczajaco miejsca.
- Na Bullseye probuje wykonac `apt update`; w razie typowych bledow 404 dla
  oficjalnych serwerow Debiana przenosi ich wpisy na archive.debian.org,
  z kopia /etc/apt. Nie wycofuje kontroli podpisow APT.
- Instaluje `python3`, `venv`, `pip` i zaleznosci systemowe, nastepnie
  zaleznosci Pythona z `requirements-pinned.txt` do `/opt/haier/env`.
- Kopiuje aplikacje do `/opt/haier` i tworzy bezpieczna konfiguracje, haslo
  administratora, sekret sesji oraz usluge `haier.service` (wylaczona).
- Konfiguruje UART. Na RPi Zero W/Zero 2 W zwalnia PL011 poprzez wylaczenie
  Bluetooth; na NanoPi NEO wlacza UART1, jezeli obecny obraz ma overlay.
- TYLKO NanoPi pyta o DS18B20 na PA6 lub odczyt z Home Assistant.
- Nie uruchamia sterowania pompa. Po konfiguracji wymagany jest restart.

### 2. Konfiguracja UART i GPIO

- Zatrzymuje i wylacza `haier.service` po jawnym potwierdzeniu bezpieczenstwa.
- NanoPi NEO: `modbusdev=/dev/ttyS1`, GPIO modbus=0, freqlimit=64,
  heatdemand=2, cooldemand=3, bindport=80.
- Raspberry Pi: `modbusdev=/dev/ttyAMA0`, GPIO modbus=17, freqlimit=27,
  heatdemand=22, cooldemand=10 (nie zmienia ustawionego portu WWW).
- Tworzy kopie `/opt/config.ini`, przygotowuje UART w plikach rozruchowych.
- Nie zmienia konfiguracji temperatury, MQTT, danych HA ani harmonogramow.
- Wymagany jest restart przed uruchomieniem HaierPi.

### 3. Temperatura zewnetrzna (tylko NanoPi NEO)

- DS18B20: wlacza overlay 1-Wire PA6 z zalaczonego pliku DTBO i ustawia
  `[SETTINGS] outsidetemp = builtin`.
- Home Assistant: usuwa *jedynie* wpis `haierpi-w1-pa6` z `user_overlays`
  (jezeli byl aktywowany przez zestaw) i ustawia `outsidetemp = ha`.
- Nie modyfikuje overlayow innych urzadzen ani profilu Raspberry Pi.
- Przed zmiana zatrzymuje usluge, tworzy kopie config.ini i boot config.
- Dla HA nalezy recznie podac adres, token i encje temperatury w `/opt/config.ini`.
- Weryfikuj dostepnosc DS18B20 po restarcie:

    ls /sys/bus/w1/devices/28-*

### Aktualizacja istniejącego HaierPi — osobno

Ta paczka **nie zawiera aktualizatora**. Aby zaktualizowac istniejaca
instalacje, wykorzystywany moze byc osobny skrypt autora:

    https://github.com/kamilostatek/hpi/blob/main/alpha13.sh

UWAGA: obecna wersja skryptu z GitHub usuwa katalogi `static` i `templates`
oraz `main.py` jeszcze przed pobraniem nowego archiwum, a kopie `config.ini`
wykonuje dopiero po podmianie kodu. Przed zastosowaniem na dzialajacym
sterowniku nalezy go poprawic (pobranie i kontrola archiwum PRZED usunieciem,
pelna kopia konfiguracji i plikow aplikacji oraz bezpieczna obsluga bledow).
Skrypt dodaje brakujace klucze konfiguracyjne, ale wymaga przegladu:
`restore_state_on_boot=1` oznacza przywrocenie poprzedniego stanu sterowania
po ponownym wlaczeniu, czego nie nalezy wymuszac bez zgody uzytkownika.

### 4. Naprawa zaleznosci Python / pip

- Zatrzymuje usluge po potwierdzeniu.
- Naprawia dostep do archiwalnych repozytoriow Bullseye, jesli to konieczne,
  doinstalowuje brakujace elementy Python/venv i ponownie instaluje wersje
  pakietow z `requirements-pinned.txt` w `/opt/haier/env`.
- Uruchamia `pip check` i kontrole importow; nie zmienia `config.ini`,
  kodu aplikacji ani uslugi uruchamianej automatycznie.

### 5. Usun stara instalacje, zachowaj konfiguracje

Przeznaczone do migracji ze starej wersji HaierPi na **czysta instalacje**
Alpha13. Nie trzeba uruchamiac osobnego skryptu aktualizacji.

1. Instalator sprawdza **obie** lokalizacje pliku `config.ini`:
   `/opt/config.ini` oraz `/opt/haier/config.ini`.
2. Jezeli istnieje tylko jeden plik, wykorzysta go jako konfiguracje docelowa.
   Jesli istnieja oba, **pyta, ktory zachowac**, ale archiwizuje obydwa.
   Jesli nie istnieje zaden, usuwniecie zostaje anulowane.
3. Po potwierdzeniu stanu bezpiecznego pompy zatrzymuje znane uslugi HaierPi.
4. Tworzy prywatny katalog kopii `/var/backups/haierpi-clean-.../` i
   zachowuje oba znalezione `config.ini`, a takze `users.json` oraz
   `schedule_ch.json` i `schedule_dhw.json` (jezeli istnialy).
   Kopie danych pozostaja do odzyskania, ale nowa instalacja utworzy
   nowego administratora i czyste harmonogramy.
5. Wybrany plik konfiguracyjny zapisuje do **`/opt/config.ini`**.
   DOPISUJE jedynie brakujace sekcje i klucze Alpha13, zachowuje
   dotychczasowe wartosci i komentarze.
6. Dopiero po udanej migracji usuwa **wylacznie `/opt/haier`**.
   NIE usuwa calego `/opt`, repozytoriow APT ani systemowego Pythona.
7. Aby zainstalowac nowa aplikacje, wybierz opcje **1** w tym samym menu.
   Po instalacji usluga pozostaje wylaczona. Zweryfikuj UART i GPIO.

**Wazne:** jezeli masz stary, niestandardowy `config.ini`, instalator
automatycznie koryguje tylko ModbusDev i cztery wpisy GPIO do wybranej plytki; nie zmienia haseł ani innych ustawien sterowania.
Nieaktualne wpisy zostaja zachowane, a brakujace sa dopisane. Przed
wlaczeniem pompy sprawdz konfiguracje i parametr
`[SETTINGS] restore_state_on_boot`.

**Ograniczenia:** skrypt nie przenosi dowolnych prywatnych plikow
ze starego katalogu `/opt/haier` (poza wskazanymi wyzej).
Jezeli masz tam wlasne dane, zabezpiecz je oddzielnie przed usunieciem.
Nie usuwaj `/opt/haier` recznie przed wykonaniem opcji 5.

### 6. Zakoncz

Zamyka menu bez modyfikacji plikow.

### Domyslne ustawienia 1.4.5 Alpha13

`configure.py` podczas **nowej instalacji** tworzy konfiguracje zawierajaca
wpisy Alpha13, m.in. CWU, strefy temperatur, ochrone przed legionella,
antifreeze, czasy testow oraz `ui_font`. Tryby sterowania i automatyczne
przywracanie stanu sa domyslnie wylaczone. Istniejacego `/opt/config.ini`
instalator nie nadpisuje.

## Uruchomienie sterowania po zmianach

Najpierw sprawdz `config.ini`, port UART oraz faktyczne polaczenia z przekaznikami.
Nie testuj dzialania z podlaczona pompa, dopoki polaryzacja wyjsc GPIO i tryb
pracy nie sa potwierdzone. Po zmianach w boot wymagany jest restart:

    sudo reboot

Po restarcie sprawdz port, stan systemu i logi:

    findmnt -no SOURCE,FSTYPE,OPTIONS /
    df -hT / /opt
    ls -l /dev/ttyS1       # NanoPi
    ls -l /dev/ttyAMA0     # RPi
    systemctl status haier.service --no-pager

Po weryfikacji mozna wlaczyc serwis za pomoca:

    cd HaierPi_Alpha13_Installer
    sudo bash enable-haierpi.sh

`enable-haierpi.sh` wymaga potwierdzenia T (tak) lub N (nie). Aplikacja nie
zostanie uruchomiona automatycznie po wyborze opcji menu.

## Ograniczenia

- Debian 11 Bullseye ma zakonczone standardowe wsparcie LTS. Repozytoria
  archiwalne sluzy jedynie kompatybilnosci, nie sa aktualnym wsparciem
  bezpieczenstwa. Nie wystawiaj tego panelu bezposrednio do Internetu.
- Uzywane zaleznosci sa przypiete do starszego API. Nowe systemy z Pythonem
  poza wersjami 3.9-3.11 wymagaja oddzielnych testow kompatybilnosci.
- `HPi.GPIO` korzysta z historycznego interfejsu `/sys/class/gpio`; na
  nowym jadre moze byc niedostepny.
- Zmiany UART/DTBO wymagaja zgodnego jadra i bootloadera i nie zostaly
  przetestowane na kazdej wersji DietPi.
- Profil NanoPi NEO nie jest profilem NanoPi NEO2 / NEO3.
- Pliki z haslami i tokenami sa prywatne; nie publikuj obrazu systemu po
  konfiguracji kont i HA. Zawsze rob kopie karty przed zmianami.

## Status testow

Sprawdzono skladnie skryptow, menu, generowanie konfiguracji Alpha13 i
zachowanie istniejacego pliku konfiguracyjnego. Instalacja `apt`/`pip`, konfiguracja boot
oraz fizyczna praca na NanoPi NEO / Raspberry Pi wymagaja testu przed
publicznym wydaniem.

## Jezyk i potwierdzenia (v9)

Komunikaty instalatora sa po polsku. Potwierdzenia operacji maja format `[T/N]` (T = tak, N = nie); Enter oznacza NIE. Szczegolowe komunikaty dostarczane przez systemowe APT i pip moga pozostac w ich oryginalnym jezyku.

Po instalacji uruchamianie kontrolera dostepne jest przez polecenie `haierpi-wlacz` po sprawdzeniu UART, GPIO i bezpiecznego stanu pompy.

## Uruchomienie z GitHuba

Po zamieszczeniu instalatora i pliku SHA256 w GitHub Releases lub w glownym katalogu galezi main skopiuj `install-haierpi.sh` do galezi main. Uruchamianie:

```bash
curl -fsSL https://raw.githubusercontent.com/kamilostatek/hpi/main/install-haierpi.sh -o install-haierpi.sh && bash install-haierpi.sh
```

Potwierdzenia operacji: `[T/N]`. Enter albo N = anulowanie. Skrypt nie uruchamia automatycznie pompy.

## Poprawka v9.1

Usunięto próbę kopiowania pliku `README_HARMONOGRAM_TEMPERATURY.md`.
Jego brak nie wstrzymuje już instalacji. Wcześniej przerwaną instalację można usunąć opcją 5,
a następnie ponowić instalację opcją 1. Pozostała zawartość Alpha13 pozostaje bez zmian.

## Zmiany v9.2
- Wyszukiwanie UART1 w katalogach /boot/dtb-*/overlay (zgodnie z jadrem NanoPi NEO).
- Poprawione ustawienie temperatury zewnetrznej w zachowanym config.ini.
- Haslo administratora: minimum 8 znakow (zalecane 12 lub wiecej).
- Usuniete komunikaty o Raspberry Pi i rezystorze z konfiguracji DS18B20 NanoPi.


### Automatyczne dopasowanie config.ini do plytki

Podczas pelnej instalacji (takze po usunieciu starej aplikacji) instalator sprawdza zachowany /opt/config.ini. W profilu NanoPi NEO poprawia [MAIN] modbusdev na /dev/ttyS1 oraz [GPIO] modbus=0, freqlimit=64, heatdemand=2, cooldemand=3. W profilu Raspberry Pi stosuje /dev/ttyAMA0 oraz numery GPIO 17, 27, 22, 10. Zmienia tylko piec ustawien sprzetowych, nie zmienia MQTT, hasel, harmonogramow ani innych wpisow. Przy zmianach tworzy kopie /opt/config.ini.bak-profil-*. Jezeli ustawienia sa poprawne, nie nadpisuje config.ini. Opcja menu 2 stosuje te same reguly i nie nadpisuje indywidualnego portu WWW. Nie jest to sprawdzenie fizycznego okablowania ani poprawnosci polaryzacji przekaznikow.

### Ponowne uruchomienie DietPi po pełnej instalacji

Po ukończeniu pełnej instalacji pojawia się pytanie `Czy chcesz teraz ponownie uruchomić DietPi? [T/N]:`. Odpowiedź `T` wykonuje restart, a `N` lub Enter pozostawia system uruchomiony. Restart jest potrzebny do aktywacji zmienionych nakładek UART i 1-Wire. Usługa HaierPi pozostaje wyłączona do ręcznej weryfikacji i uruchomienia poleceniem `haierpi-wlacz`.
