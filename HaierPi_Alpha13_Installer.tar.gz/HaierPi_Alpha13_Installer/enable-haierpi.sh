#!/usr/bin/env bash
set -Eeuo pipefail
[[ "$EUID" -eq 0 ]] || { echo 'Uruchom jako administrator: sudo bash enable-haierpi.sh'; exit 1; }
[[ -f /opt/config.ini && -f /opt/haier/main.py ]] || { echo 'Nie znaleziono zainstalowanego HaierPi.'; exit 1; }
[[ -e /sys/class/gpio/export ]] || { echo 'Brak starego interfejsu GPIO sysfs. Sterownik HaierPi nie może tu działać.'; exit 1; }
PORT="$(/opt/haier/env/bin/python - <<'PY'
import configparser
c=configparser.ConfigParser();c.read('/opt/config.ini')
print(c.get('MAIN','modbusdev'))
PY
)"
[[ -c "$PORT" ]] || { echo "Nie znaleziono portu szeregowego: $PORT. Najpierw skonfiguruj UART."; exit 1; }
printf 'Port szeregowy: %s\nUWAGA: sprawdź przypisanie GPIO do TWOJEJ płytki przekaźnikowej.\n' "$PORT"
read -r -p 'Czy chcesz włączyć sterowanie pompą? [T/N]: ' ANSWER
[[ "${ANSWER^^}" == T ]] || { echo 'Anulowano. Sterowanie nie zostało uruchomione.'; exit 1; }
systemctl enable --now haier.service
systemctl --no-pager --full status haier.service || true
