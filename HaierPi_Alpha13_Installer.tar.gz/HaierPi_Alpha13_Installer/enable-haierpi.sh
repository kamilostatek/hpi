#!/usr/bin/env bash
set -Eeuo pipefail
[[ "$EUID" -eq 0 ]] || { echo 'Use sudo bash enable-haierpi.sh'; exit 1; }
[[ -f /opt/config.ini && -f /opt/haier/main.py ]] || { echo 'HaierPi not installed.'; exit 1; }
[[ -e /sys/class/gpio/export ]] || { echo 'Legacy GPIO sysfs unavailable; HaierPi cannot use this driver.'; exit 1; }
PORT="$(/opt/haier/env/bin/python - <<'PY'
import configparser
c=configparser.ConfigParser();c.read('/opt/config.ini')
print(c.get('MAIN','modbusdev'))
PY
)"
[[ -c "$PORT" ]] || { echo "Serial port missing: $PORT. Configure UART first."; exit 1; }
printf 'Serial: %s\nIMPORTANT: verify GPIO mapping for YOUR relay board.\n' "$PORT"
read -r -p 'Type URUCHOM to enable active pump control: ' ANSWER
[[ "$ANSWER" == URUCHOM ]] || { echo 'Cancelled.'; exit 1; }
systemctl enable --now haier.service
systemctl --no-pager --full status haier.service || true
