def SetPump(current, new):
    """
    Circulation Pump (A05) set function 0=OFF 1=ON.

    The pump enable is bit 5 (0x20) in the low byte of R101[0]. When turning OFF we must
    explicitly clear this bit; simple addition keeps it latched if it was already ON.
    """
    try:
        frame = []

        new_bit = 1 if int(new) else 0

        low = int(current[0]) & 0xFF
        low = (low & ~0x20) | (new_bit << 5)

        frame.append(8192 + low)
        frame.append(current[1])
        frame.append(current[2])
        frame.append(current[3] & 15)
        frame.append(current[4] & 255)
        frame.append(current[5])

        return frame
    except Exception:
        return "ERROR"
