def SetDHWCompensation(current, newcompe):
    """
    DHW Compensation (A0d) set function
    :return:
    """
    try:
        frame = []
        pumpstate = int(current[0]) & 0xFF

        if isinstance(newcompe, int) and not isinstance(newcompe, bool):
            steps = int(newcompe)
        else:
            steps = int(round(float(newcompe) * 2))

        if steps < -30:
            steps = -30
        elif steps > 30:
            steps = 30

        comp_byte = 30 + steps
        if comp_byte < 0:
            comp_byte = 0
        elif comp_byte > 255:
            comp_byte = 255

        word5_new = (int(current[5]) & 0xFF00) | (comp_byte & 0xFF)

        frame.append(0x2000 | pumpstate)
        frame.append(int(current[1]))
        frame.append(int(current[2]))
        frame.append(int(current[3]))
        frame.append(int(current[4]))
        frame.append(int(word5_new))
        return frame
    except:
        return "ERROR"
