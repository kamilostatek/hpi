# HaierPi 1.4.5_alpha13 — harmonogram temperatur CO i CWU

Wersja poprawki: `1.4.5_alpha13`.

Cała logika harmonogramu, łącznie z walidacją i wyborem temperatur, znajduje się
w `main.py`. Zachowano dotychczasowy układ aplikacji HPI.

Paczka powstała na podstawie dostarczonego archiwum `1.4.5_alpha12.tar.gz`.
Jest aktualizacją istniejącej instalacji HaierPi, a nie kompletnym instalatorem
systemu Raspberry Pi. Nie zawiera konfiguracji konkretnej pompy ani nowych
plików `schedule_ch.json` i `schedule_dhw.json`.

## Co można ustawić

Każdy przedział tygodniowego harmonogramu CO i CWU ma teraz opcjonalną
temperaturę. Przedziały wybiera się na dotychczasowej siatce co 30 minut.
Można ustawić kilka kolejnych przedziałów jednego dnia, każdy z inną nastawą.

| Obieg / tryb CO | Znaczenie temperatury | Zakres | Krok |
| --- | --- | --- | --- |
| CO, krzywa `auto`, `static`, `manual` | Zadana temperatura w pomieszczeniu, czyli dotychczasowe `settemp` | 12–30 °C | 0,1 °C |
| CO, tryb bezpośredni `directly` | Temperatura wody zasilającej CO | 25–55 °C | 0,5 °C |
| CO, tryb bezpośredni z `expert_mode=1` | Temperatura wody zasilającej CO | 20–55 °C | 0,5 °C |
| CWU | Temperatura zadana zasobnika | 30–55 °C | 0,5 °C |

Zakresy wynikają z ograniczeń istniejącego kodu tej wersji HaierPi. Nie są
automatycznym rozpoznaniem możliwości konkretnego modelu pompy.

W krzywej ręcznej (`manual`) temperatura wody nadal pochodzi z tabeli `hcman`.
Nastawa pokojowa wpływa na termostat, gdy jest on włączony. W trybie
bezpośrednim harmonogram nie zmienia oddzielnego parametru termostatu
`direct_inside_settemp`.

## Korzystanie

1. W ustawieniach włącz harmonogram wybranego obiegu: CO i/lub CWU.
2. Otwórz **Harmonogram** i odpowiednią zakładkę.
3. Zaznacz zakres godzin w wybranym dniu albo kliknij istniejący przedział.
4. Zaznacz **Ustaw temperaturę dla tego przedziału** i wpisz nastawę.
5. Wybierz **Zastosuj**, a następnie **Zapisz** pod siatką danego obiegu.
6. Opcja **Kopiuj na wszystkie dni** przenosi także temperaturę. Przedziały
   kolidujące z już istniejącymi nie zostaną dodane; sprawdź wynik na siatce.

Wyłączenie opcji temperatury daje dotychczasowy przedział włącz/wyłącz.
W takim przedziale temperatura nie jest zmieniana — pozostaje ostatnia
nastawa sterownika, także ta pochodząca z wcześniejszego przedziału.

**Poza wszystkimi przedziałami danego dnia harmonogram wyłącza dany obieg.**
Niższa temperatura nocna wymaga osobnego przedziału nocnego; pusta część
siatki nie oznacza automatycznej temperatury obniżonej.

Przykładowy całodobowy harmonogram CO przy sterowaniu krzywą:

| Godziny | Nastawa pokojowa |
| --- | --- |
| 00:00–06:00 | 19 °C |
| 06:00–08:00 | 21 °C |
| 08:00–16:00 | 19 °C |
| 16:00–22:00 | 21,5 °C |
| 22:00–24:00 | 19 °C |

To przykład obsługi, nie dobór temperatur dla konkretnej instalacji.
Analogicznie dla CWU można np. ustawić 05:30–07:00 → 45 °C oraz
17:00–20:00 → 50 °C. Poza tymi przedziałami CWU będzie wyłączone przez
harmonogram, z uwzględnieniem opisanych niżej wyjątków.

Przedział przez północ podziel na dwie części, np. poniedziałek
22:00–24:00 oraz wtorek 00:00–06:00. Zapis `00:00` jako końca przedziału
ze starszych wersji jest odczytywany jako koniec bieżącego dnia (`24:00`).

## Zasady działania

- Początek jest włączony, koniec wyłączony: `[od, do)`. O godzinie 08:00
  obowiązuje przedział zaczynający się o 08:00, a nie kończący się o 08:00.
- Harmonogram jest sprawdzany w istniejącym cyklu odczytu parametrów, nominalnie
  co 30 sekund. Polecenia komunikacyjne i odroczone operacje mogą wydłużyć
  ten czas. Godzina oznacza zmianę nastawy, nie osiągnięcie tej temperatury.
- Czas i dzień pochodzą z lokalnego zegara urządzenia uruchamiającego HaierPi.
  Poprawka nie zmienia strefy czasowej ani zasad zegara systemowego.
- W aktywnym przedziale z nastawą harmonogram ponownie narzuci ją po zmianie
  ręcznej przy następnym sprawdzeniu. Przedział bez nastawy tego nie robi.
- Po zakończeniu przedziału lub wyłączeniu harmonogramu ostatnia temperatura
  pozostaje w sterowniku. Nie ma automatycznego przywracania osobnej nastawy bazowej.
- Jednorazowe grzanie CWU na żądanie oraz aktywny lub zlecony cykl
  antylegionella mają pierwszeństwo: harmonogram CWU nie zmienia wtedy
  ani jego stanu, ani temperatury. Po zakończeniu wyjątku wraca bieżący plan.
- Nowe nastawy CO zapisują także rodzaj temperatury: pokojowa lub wody.
  Po zmianie trybu sterowania niezgodna nastawa jest pomijana, a sterowanie
  czasem nadal działa. Otwórz i ponownie zatwierdź przedziały w nowym trybie.
- Liczbowe tytuły dawnych harmonogramów CO są obsługiwane zgodnie z bieżącym
  trybem CO i dopuszczalnym zakresem. Stare pliki nie określały rodzaju
  temperatury, dlatego warto je przejrzeć i zapisać po aktualizacji.
- Numeryczne tytuły dawnych przedziałów CWU pozostają opisami. Nie zostają
  samoczynnie przekształcone w nastawy CWU.

## Instalacja na istniejącym urządzeniu

Kod źródłowy wskazuje usługę `haier.service`, katalog aplikacji `/opt/haier`
i konfigurację `/opt/config.ini`. Przed użyciem poniższego przykładu sprawdź,
czy Twoja instalacja korzysta z tych ścieżek:

```bash
sudo systemctl cat haier.service
```

Pobierz archiwum na urządzenie. Poniższe polecenia zakładają, że bieżący katalog
zawiera pobrany plik `1.4.5_alpha13.tar.gz`. Jeśli nazwa jest inna, popraw
pierwszą linię.

```bash
haier_pakiet="$PWD/1.4.5_alpha13.tar.gz"
haier_kopia="/tmp/haier-przed-harmonogramem-$(date +%Y%m%d-%H%M%S).tar.gz"

# Wykonaj kroki po kolei; jeśli którykolwiek zgłosi błąd, wyjaśnij go przed następnym.
sudo systemctl stop haier.service
sudo tar -czf "$haier_kopia" -C /opt haier config.ini

# Podmień wyłącznie kod poprawki; pozostaw własną konfigurację i pliki harmonogramów.
sudo tar -xzf "$haier_pakiet" -C /opt/haier \
  ./main.py \
  ./templates/scheduler.html \
  ./static/jquery.schedule2.js \
  ./static/jquery.light.schedule.css \
  ./static/jquery.dark.schedule.css \
  ./static/locales/pl/translation.json \
  ./static/locales/en/translation.json \
  ./static/locales/nl/translation.json

sudo systemctl start haier.service
sudo systemctl status haier.service --no-pager
sudo journalctl -u haier.service -n 60 --no-pager
```

Zachowaj kopię w trwałym miejscu poza `/tmp`. Po uruchomieniu odśwież stronę
w przeglądarce z pominięciem pamięci podręcznej, np. **Ctrl+F5**. Wersja
wyświetlana przez aplikację powinna być `1.4.5_alpha13`.

Najpierw sprawdź jeden krótki przedział CO i jeden CWU oraz odczyt nastawy
przez urządzenie. Testy komputerowe tej paczki nie zastępują sprawdzenia
komunikacji z konkretną pompą.

### Powrót do poprzedniej wersji

Zatrzymaj usługę, odtwórz kopię wykonaną przed aktualizacją i uruchom usługę:

```bash
# Ustaw rzeczywistą ścieżkę do zapisanej wcześniej kopii.
haier_kopia="/sciezka/do/haier-przed-harmonogramem-DATA.tar.gz"
sudo systemctl stop haier.service
sudo tar -xzf "$haier_kopia" -C /opt
sudo systemctl start haier.service
```

Nowe pole `temperature` nie jest rozumiane przez oryginalny kod, dlatego
powrót powinien obejmować także pierwotne pliki harmonogramów z kopii.

## Zmienione i dodane pliki

| Plik | Zmiana |
| --- | --- |
| `main.py` | Cała logika harmonogramu: walidacja, wybór przedziału i temperatury CO/CWU, atomowy zapis, obsługa błędów, ponowienia odroczonego CO, bezpieczne dane strony |
| `templates/scheduler.html` | Obsługa obu zakładek, opis typu temperatury, zapis i sygnalizacja niezapisanych zmian |
| `static/jquery.schedule2.js` | Okno nastawy, temperatura na siatce, import/eksport i kopiowanie nastawy |
| `static/jquery.light.schedule.css`, `static/jquery.dark.schedule.css` | Czytelne oznaczenie temperatury również w krótkich przedziałach |
| `static/locales/pl/translation.json`, `en/translation.json`, `nl/translation.json` | Teksty interfejsu w trzech językach |
| `tests/test_scheduler.py` | Testy regresji działające bez podłączonej pompy i bez uruchamiania aplikacji |

Pozostałe pliki z archiwum wejściowego zachowano. Nie dodano nowych zależności
do uruchamiania HaierPi; funkcje harmonogramu w `main.py` korzystają z biblioteki standardowej Pythona.

## Sprawdzenie programowe

Z katalogu z rozpakowanym kodem można wykonać:

```bash
python3 -m unittest discover -s tests -v
python3 -m py_compile main.py
```

Weryfikacja zakończyła się powodzeniem: **50 testów Pythona** i **9 scenariuszy
interfejsu w przeglądarce Chromium**.

Testy pobierają funkcje bezpośrednio z `main.py` przez AST i używają atrap
poleceń sprzętowych.
Nie importują całego `main.py`, nie łączą się z pompą, MQTT ani Home Assistant.
Sprawdzają m.in. granice godzin, północ, dni tygodnia, stare i nowe dane,
zakresy i kroki temperatur, priorytety CWU, zmianę trybu CO, bezpieczny zapis,
defrost, opóźnione potwierdzenie włączenia, błędy zapisu i brak potwierdzenia
wysłania nastawy. Oddzielnie sprawdzono składnię JavaScript i renderowanie
szablonu Jinja z plikiem bazowym.

Scenariusze przeglądarkowe obejmowały edycję i odczyt nastaw, krok CWU 0,5 °C,
zgodność ze starymi tytułami, jawne wyłączenie nastawy, zachowanie opisów,
kopiowanie, ukrytą zakładkę CWU, sąsiedztwo i kolizje przedziałów oraz
cykl życia okna edycji. Rejestracja przeciągania i skalowania jQuery UI była
w izolowanym teście zastąpiona atrapą; rzeczywiste gesty przeciągania/skalowania
i połączenia Socket.IO z urządzeniem nie były sprawdzane. Szablon z plikiem
bazowym został wyrenderowany osobno.
