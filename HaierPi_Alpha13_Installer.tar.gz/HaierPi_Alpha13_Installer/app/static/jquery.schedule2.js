/**
 * jQuery Schedule v2.1.0
 * https://github.com/nileshgamit/jquery-schedule.git
 * Original Developer: Thomas BORUSZEWSKI <yehzuna@outlook.com>
 * Touch Support and Few options added - Developer: Nilesh Gamit <nilesh.gamit@gmail.com>
 */
;(function ($, window, document, undefined) {
  'use strict';
  // Defaults options
  var defaults = {
      mode: 'edit', // read
      hour: 24, // 12
      days: 7, // 7/5
      periodDuration: 30, // 15/30/60
      data: [],
      periodOptions: true,
      periodColors: [],
      periodTitle: '',
      periodBackgroundColor: 'rgba(82, 155, 255, 0.5)',
      periodBorderColor: '#2a3cff',
      periodTextColor: '#000',
      periodRemoveButton: 'Remove',
      periodDuplicateButton: 'Duplicate',
      periodTitlePlaceholder: 'Temperature',
      temperature: {target: 'room', min: 12, max: 30, step: 0.1},
      legacyTitleTemperature: false,
      translate: function (key, fallback) { return fallback; },
      onChange: function () {},
      daysList: [
        'Mon',
        'Tue',
        'Wed',
        'Thu',
        'Fri',
        'Sat',
        'Sun'
      ],
      hideScroll: false, // true will display full scheduler without scroll
      hideDayHeading: false, // true will hide day heading
      hidePeriodOnGrid: false, // true will hide period on grid 
      hideDuplicatePeriodIcon: false, // true will hide duplicate period icon 
      onInit: function () {},
      onAddPeriod: function () {},
      onRemovePeriod: function () {},
      onDuplicatePeriod: function () {},
      onClickPeriod: function () {}
      },
    pluginName = 'jqs';
  // Plugin constructor
  function Plugin(element, options) {
    this.element = element;
    this.settings = $.extend({}, defaults, options);
    this.periodOptions = {
      title: this.settings.periodTitle,
      backgroundColor: this.settings.periodBackgroundColor,
      borderColor: this.settings.periodBorderColor,
      textColor: this.settings.periodTextColor
    };
    this.seed = Math.random().toString(36).substr(2);
    this.counter = 0;
    this.init();
  }

  $.extend(Plugin.prototype, {
    /**
     * Plugin instance seed
     */
    seed: Math.random().toString(36).substr(2),

    /**
     * Period addition counter
     */
    counter: 0,

    /**
     * Period interval multiplier
     */
    periodInterval: 0,

    /**
     * Period max height
     */
    periodHeight: 0,

    /**
     * Period position max step
     */
    periodPosition: 0,

    /**
     * Generate id for a period
     * @returns {string}
     */
    uniqId: function () {
      this.counter++;

      return pluginName + '_' + this.seed + '_' + this.counter;
    },

    /**
     * Plugin init
     */
    init: function () {
      var $this = this;
      // colors validation
      if (this.settings.periodColors.length > 0) {
        $.each(this.settings.periodColors, function (index, color) {
          if (!$.inArray(color) || color.length !== 3) {
            throw new Error('Invalid periodColors');
          }
        });
      }

      // duration validation
      if ($.inArray(this.settings.periodDuration, [15, 30, 60]) === -1) {
        throw new Error('Invalid periodDuration');
      }

      this.periodInterval = 60 / this.settings.periodDuration;
      this.periodHeight = 24 * this.periodInterval;
      this.periodPosition = 40 / this.periodInterval;

      $(this.element).addClass('jqs').addClass('jqs-mode-' + this.settings.mode);
      
      if(!this.settings.autoScroll) {
	  $(this.element).addClass('jqs-no-scroll');
      }

      // Init events
      if (this.settings.mode === 'edit') {
        var position = 0;
        var helper = false;

        $(this.element).on('mousedown touchstart', '.jqs-day', function (event) {
            
          var offset = $this.getY(event, false) - $(this).offset().top;
          position = Math.floor(offset / $this.periodPosition);

          if (!$(event.target).hasClass('jqs-period') && $(event.target).parents('.jqs-period').length === 0) {
            var time = '';
            if ($this.settings.periodDuration !== 15) {
              time = $this.periodInit(position, position + 1);
            }

            helper = $('<div>').addClass('jqs-period-helper').css({
              'height': $this.periodPosition,
              'top': position * $this.periodPosition
            }).append('<div class="jqs-period-helper-time">' + time + '</div>');

            $(this).append(helper);
          }
        });

        $(this.element).on('mousemove touchmove', '.jqs-day', function (event) {
          if (helper) {

            var offset = $this.getY(event, true) - $(this).offset().top;
            var height = Math.round(offset / $this.periodPosition) - position;
            if (height <= 0) {
              height = 1;
            }

            helper.css({
              'height': height * $this.periodPosition
            });

            if (height >= 1) {
              $('.jqs-period-helper-time', helper).text($this.periodInit(position, position + height));
            } else {
              $('.jqs-period-helper-time', helper).text('');
            }
          }
        });

        $(this.element).on('mouseup touchend', '.jqs-day', function (event) {
          if (!$(event.target).hasClass('jqs-period') && $(event.target).parents('.jqs-period').length === 0) {

            var offset = $this.getY(event, false) - $(this).offset().top;
            var height = Math.round(offset / $this.periodPosition) - position;
            if (height <= 0) {
              height = 1;
            }

            if ($this.add($(this), position, height)) {
              $this.openOptions(event, $(this).children('.jqs-period').last());
            }
          }

          position = 0;
          if (helper) {
            helper.remove();
            helper = false;
          }
        });

        $(this.element).on('mouseenter touchenter', '.jqs-day', function () {
          var index = $(this).parents('td').index();
          $('.jqs-grid-day', $this.element).eq(index).addClass('jqs-grid-day-buttons');
        });

        $(this.element).on('mouseleave touchleave', '.jqs-day', function () {
          var index = $(this).parents('td').index();
          $('.jqs-grid-day', $this.element).eq(index).removeClass('jqs-grid-day-buttons');
        });

        $(this.element).on('click', '.jqs-period-remove', function () {
          var period = $(this).parents('.jqs-period');
          $this.remove(period);
        });

        $(this.element).on('click', '.jqs-period-duplicate', function () {
          var period = $(this).parents('.jqs-period');
          $this.duplicate(period);
        });

        $(this.element).on('click', '.jqs-day-remove', function () {
          var index = $(this).parents('.jqs-grid-day').index();
          var parent = $('.jqs-day', $this.element).eq(index);
          $this.removeAll(parent);
        });

        $(this.element).on('click', '.jqs-day-duplicate', function () {
          var index = $(this).parents('.jqs-grid-day').index();
          var parent = $('.jqs-day', $this.element).eq(index);
          $this.duplicateAll(parent);
        });
      }

      this.create();
      this.generate();

      this.settings.onInit.call(this, this.element);
    },

    /**
     * Generate schedule structure
     */
    create: function () {

      $('<table class="jqs-table"><tr></tr></table>').appendTo($(this.element));

      for (var i = 0; i < this.settings.days; i++) {
        $('<td><div class="jqs-day"></div></td>').
          appendTo($('.jqs-table tr', this.element));
      }

      $('<div class="jqs-grid"><div class="jqs-grid-head"></div></div>').appendTo($(this.element));

      for (var j = 0; j < 25; j++) {
        $('<div class="jqs-grid-line"><div class="jqs-grid-hour">' + this.formatHour(j) + '</div></div>').
          appendTo($('.jqs-grid', this.element));
      }

      var dayRemove = '';
      var dayDuplicate = '';
      if (this.settings.mode === 'edit') {
	var dayRemoveClass = (this.settings.days == 1) ? 'jqs-single-day-remove' : '';
        dayRemove = '<div class="jqs-day-remove ' + dayRemoveClass + '" title="' + this.settings.periodRemoveButton + '"></div>';
        if(!this.settings.hideDuplicatePeriodIcon) {
            dayDuplicate = (this.settings.day == 1) ? '' : '<div class="jqs-day-duplicate" title="' + this.settings.periodDuplicateButton + '"></div>';
        }
      }

      for (var k = 0; k < this.settings.days; k++) {
	  var day = (this.settings.hideDayHeading) ? '' : this.settings.daysList[k];
          var heading = $('<div class="jqs-grid-day">').append(
            $('<span class="jqs-grid-day-label">').text(day)
          ).append(dayRemove + dayDuplicate);
          heading.appendTo($('.jqs-grid-head', this.element));
      }
    },

    /**
     * Generate periods from data option
     */
    generate: function () {
      if (this.settings.data.length > 0) {
        var $this = this;

        $.each(this.settings.data, function (index, data) {
          $.each(data.periods, function (index, period) {

            var parent = $('.jqs-day', $this.element).eq(data.day);
            var options = {};
            var height, position;
            if ($.isArray(period)) {
              position = $this.positionFormat(period[0]);
              height = $this.positionFormat(period[1]);
            } else {
              position = $this.positionFormat(period.start);
              height = $this.positionFormat(period.end);
              options = period;
            }

            if (height === 0) {
              height = $this.periodHeight;
            }

            $this.add(parent, position, height - position, options);
          });
        });
      }
    },

    /**
     * Add a period to a day
     * @param parent
     * @param {int} position
     * @param {int} height
     * @param options
     */
    add: function (parent, position, height, options) {
	//console.log(parent)
	//console.log(position)
	//console.log(height)
	//console.log(options)
	//console.log("----------------")
      if (!Number.isFinite(position) || !Number.isFinite(height) || position < 0 || height <= 0 || position + height > this.periodHeight) {
        console.error('Invalid period');

        return false;
      }

      options = $.extend({}, this.periodOptions, options);
	//console.log(options)
      // new period
      var periodRemove = '';
      var periodDuplicate = '';
      if (this.settings.mode === 'edit') {
	      //console.log("edit")
        periodRemove = '<div class="jqs-period-remove" title="' + this.settings.periodRemoveButton + '"></div>';
        if(!this.settings.hideDuplicatePeriodIcon) {
            periodDuplicate = (this.settings.days == 1) ? '' : '<div class="jqs-period-duplicate" title="' + this.settings.periodDuplicateButton + '"></div>';
  	}
      }

      var periodTitle = '<div class="jqs-period-title"></div>';
      var periodTime = '';
      if(!this.settings.hidePeriodOnGrid) {
	  periodTime = '<div class="jqs-period-time">' + this.periodInit(position, position + height) + '</div>';
      }
	    //console.log(position)
	    //console.log(height)
	    //console.log(position * this.periodPosition);
	    //console.log(height * this.periodPosition);
      var period = $('<div class="jqs-period">' +
        '<div class="jqs-period-container">' + periodTime + periodTitle + periodRemove + periodDuplicate + '</div>' +
        '</div>').css({
        'top': position * this.periodPosition,
        'height': height * this.periodPosition,
      }).attr('id', this.uniqId()).attr('tabindex', '0').attr('role', 'button').appendTo(parent);
      var temperature = null;
      var target = options.temperature_target;
      if (Object.prototype.hasOwnProperty.call(options, 'temperature')) {
        temperature = options.temperature;
      } else if (this.settings.legacyTitleTemperature && String(options.title || '').trim() !== '') {
        var legacy = Number(String(options.title).replace(',', '.'));
        if (this.validTemperature(legacy)) {
          temperature = legacy;
          target = this.settings.temperature.target;
        }
      }
      period.data('period-title', String(options.title || ''));
      period.data('temperature', temperature);
      period.data('temperature-target', target || this.settings.temperature.target);
      this.updatePeriodDisplay(period);
      $('.jqs-period-container', period).css({
        'background-color': options.backgroundColor,
        'border-color': options.borderColor,
        'color': options.textColor
      });
	//console.log(period)
	//console.log(period[0].style.top)
      // period validation
	//console.log(period)
      if (!this.isValid(period)) {
        console.error('Invalid period', this.periodInit(position, position + height));
	//console.log(period)
        $(period).remove();

        return false;
      }

      // text format
      this.periodText(period);

      // period events
      if (this.settings.mode === 'edit') {
        var $this = this;

        period.draggable({
          grid: [0, this.periodPosition],
          containment: 'parent',
          drag: function (event, ui) {
            $('.jqs-period-time', ui.helper).text($this.periodDrag(ui));
            $this.closeOptions();
          },
          stop: function (event, ui) {
            if (!$this.isValid($(ui.helper))) {
              console.error('Invalid position');

              $(ui.helper).css('top', Math.round(ui.originalPosition.top));
            }
            $this.updatePeriodDisplay($(ui.helper));
            $this.settings.onChange.call($this, $this.element);
          }
        }).resizable({
          grid: [0, this.periodPosition],
          containment: 'parent',
          handles: 'n, s',
          resize: function (event, ui) {
            $('.jqs-period-time', ui.helper).text($this.periodResize(ui));

            $this.periodText(period);
            $this.closeOptions();
          },
          stop: function (event, ui) {
            if (!$this.isValid($(ui.helper))) {
              console.error('Invalid position');

              $(ui.helper).css({
                'height': Math.round(ui.originalSize.height),
                'top': Math.round(ui.originalPosition.top)
              });
            }
            $this.periodText($(ui.helper));
            $this.updatePeriodDisplay($(ui.helper));
            $this.settings.onChange.call($this, $this.element);
          }
        });
        if (this.settings.periodOptions) {
          period.click(function (event) {
		  const target1 = $(event.target).hasClass('jqs-period-remove')
		  const target2 = $(event.target).hasClass('jqs-period-duplicate')
            if (target1 || target2){
            } else{
		                  $this.settings.onClickPeriod.call(this, event, period, $this.element);
                $this.openOptions(event, period);
		         //         $this.openOptions(event, period);

              //const myModal = new bootstrap.Modal('#scheduleModal', {keyboard: true });
              //myModal.show();

	    }
          });
          period.on('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
              event.preventDefault();
              $this.openOptions(event, period);
            }
          });
        }
      }

      this.settings.onAddPeriod.call(this, period, this.element);
      this.settings.onChange.call(this, this.element);

      return true;
    },

    /**
     * Remove a period
     * @param period
     */
    remove: function (period) {
      if (!this.settings.onRemovePeriod.call(this, period, this.element)) {
        $(period).remove();
        this.closeOptions();
        this.settings.onChange.call(this, this.element);
      }
    },

    /**
     * Remove all periods in the parent container
     * @param parent
     */
    removeAll: function (parent) {
      var $this = this;
      $('.jqs-period', parent).each(function (index, period) {
        $this.remove(period);
      });
    },

    /**
     * Duplicate a period
     * @param period
     */
    duplicate: function (period) {
      if (!this.settings.onDuplicatePeriod.call(this, period, this.element)) {
        var options = this.periodData(period);
        var bounds = this.periodBounds(period);
        var position = bounds.start;
        var height = bounds.end - bounds.start;

        var $this = this;
        $('.jqs-day', this.element).each(function (index, parent) {
          $this.add(parent, position, height, options);
        });

        this.closeOptions();
      }
    },

    /**
     * Duplicate all periods in the parent container
     * @param parent
     */
    duplicateAll: function (parent) {
      var $this = this;
      $('.jqs-period', parent).each(function (index, period) {
        $this.duplicate($(period));
      });
    },

    /**
     * Open the options popup
     * @param event
     * @param period
     */
    openOptions: function (event, period) {
      var $this = this;
      this.closeOptions();
      var settings = this.settings.temperature;
      var t = this.settings.translate;
      var bounds = this.periodBounds(period);
      var modalId = 'schedule-modal-' + this.seed;
      var inputId = modalId + '-temperature';
      var enableId = modalId + '-enabled';
      var helpId = modalId + '-help';
      var errorId = modalId + '-error';
      var temperature = period.data('temperature');
      var target = period.data('temperature-target');
      var hasTemperature = temperature !== null && temperature !== undefined && temperature !== '';

      var modal = $('<div class="modal" tabindex="-1" role="dialog" aria-modal="true">').attr({
        id: modalId, 'aria-labelledby': modalId + '-title'
      });
      var content = $('<div class="modal-content">');
      modal.append($('<div class="modal-dialog modal-dialog-centered">').append(content));
      var header = $('<div class="modal-header">').appendTo(content);
      var dayIndex = period.closest('td').index();
      $('<h5 class="modal-title">').attr('id', modalId + '-title')
        .text(t('scheduler.day.' + dayIndex, this.settings.daysList[dayIndex]) + ' · ' +
          this.periodInit(bounds.start, bounds.end)).appendTo(header);
      $('<button type="button" class="btn-close" data-bs-dismiss="modal">')
        .attr('aria-label', t('common.cancel', 'Cancel')).appendTo(header);
      var body = $('<div class="modal-body">').appendTo(content);
      $('<div class="form-check mb-3">').append(
        $('<input type="checkbox" class="form-check-input">').attr('id', enableId).prop('checked', hasTemperature),
        $('<label class="form-check-label">').attr('for', enableId)
          .text(t('scheduler.change_temperature', 'Set a temperature for this period'))
      ).appendTo(body);
      var labelKey = 'scheduler.temperature.' + settings.target;
      $('<label class="form-label">').attr('for', inputId)
        .text(t(labelKey, 'Target temperature (°C)')).appendTo(body);
      var group = $('<div class="input-group">').appendTo(body);
      var decrement = $('<button type="button" class="btn btn-outline-secondary">').text('−')
        .attr('aria-label', t('scheduler.decrease', 'Decrease temperature')).appendTo(group);
      var input = $('<input type="number" class="form-control text-center" inputmode="decimal">')
        .attr({id: inputId, min: settings.min, max: settings.max, step: settings.step,
          'aria-describedby': helpId + ' ' + errorId})
        .val(hasTemperature ? temperature : '').appendTo(group);
      var increment = $('<button type="button" class="btn btn-outline-secondary">').text('+')
        .attr('aria-label', t('scheduler.increase', 'Increase temperature')).appendTo(group);
      $('<div class="form-text">').attr('id', helpId)
        .text(t('scheduler.range', 'Allowed range') + ': ' + settings.min + '–' + settings.max +
          ' °C; ' + t('scheduler.step', 'step') + ': ' + settings.step + ' °C. ' +
          t('scheduler.no_temperature_help', 'Without a temperature, this period only enables heating.'))
        .appendTo(body);
      var error = $('<div class="text-danger small mt-2" role="alert">').attr('id', errorId).appendTo(body);
      if (hasTemperature && target && target !== settings.target) {
        $('<div class="alert alert-warning mt-3 mb-0">')
          .text(t('scheduler.mode_changed', 'The heating mode has changed. Check and save this period’s temperature again.'))
          .appendTo(body);
      }
      var footer = $('<div class="modal-footer">').appendTo(content);
      var remove = $('<button type="button" class="btn btn-outline-danger">')
        .text(t('scheduler.remove', 'Remove')).appendTo(footer);
      var duplicate = $('<button type="button" class="btn btn-outline-secondary">')
        .text(t('scheduler.duplicate', 'Copy to all days')).appendTo(footer);
      var apply = $('<button type="button" class="btn btn-primary">')
        .text(t('scheduler.apply', 'Apply')).appendTo(footer);
      var enabled = $('#' + enableId, modal);
      function updateEnabled() {
        input.prop('disabled', !enabled.prop('checked')).prop('required', enabled.prop('checked'));
        decrement.add(increment).prop('disabled', !enabled.prop('checked'));
        input.removeClass('is-invalid');
        error.text('');
      }
      function stepTemperature(direction) {
        var value = Number(input.val());
        if (input.val() === '' || !Number.isFinite(value)) value = settings.min;
        else value += direction * settings.step;
        value = Math.max(settings.min, Math.min(settings.max, value));
        input.val(Number(value.toFixed(1))).trigger('input');
      }
      function applyChanges() {
        var value = null;
        if (enabled.prop('checked')) {
          value = Number(String(input.val()).replace(',', '.'));
          if (input.val() === '' || !input[0].checkValidity() || !$this.validTemperature(value)) {
            input.addClass('is-invalid').attr('aria-invalid', 'true');
            error.text(t('scheduler.invalid_temperature', 'Enter a temperature within the allowed range and step.'));
            input.trigger('focus');
            return false;
          }
        }
        period.data('temperature', value);
        period.data('temperature-target', settings.target);
        $this.updatePeriodDisplay(period);
        $this.settings.onChange.call($this, $this.element);
        return true;
      }
      enabled.on('change', updateEnabled);
      input.on('input', function () { input.removeClass('is-invalid').removeAttr('aria-invalid'); error.text(''); });
      decrement.on('click', function () { stepTemperature(-1); });
      increment.on('click', function () { stepTemperature(1); });
      remove.on('click', function () { $this.remove(period); });
      duplicate.on('click', function () { if (applyChanges()) $this.duplicate(period); });
      apply.on('click', function () { if (applyChanges()) $this.closeOptions(); });
      input.on('keydown', function (keyEvent) {
        if (keyEvent.key === 'Enter') { keyEvent.preventDefault(); apply.trigger('click'); }
      });
      updateEnabled();
      modal.appendTo(document.body);
      var instance = new bootstrap.Modal(modal[0], {keyboard: true, backdrop: 'static'});
      this._modal = instance;
      this._modalElement = modal;
      modal.on('hidden.bs.modal', function () {
        instance.dispose();
        modal.remove();
        if ($this._modal === instance) { $this._modal = null; $this._modalElement = null; }
      });
      instance.show();
    },

    /** Close the current period editor, including its Bootstrap backdrop. */
    closeOptions: function () {
      if (this._modal) this._modal.hide();
      $('.jqs-options', this.element).remove();
    },

    /** Pixel styles work for both the visible tab and a hidden scheduler tab. */
    periodBounds: function (period) {
      var top = parseFloat(period[0].style.top) || 0;
      var height = parseFloat(period[0].style.height) || 0;
      return {
        start: Math.round(top / this.periodPosition),
        end: Math.round((top + height) / this.periodPosition)
      };
    },

    validTemperature: function (value) {
      var limits = this.settings.temperature;
      if (typeof value !== 'number' || !Number.isFinite(value) || value < limits.min || value > limits.max) return false;
      var steps = (value - limits.min) / limits.step;
      return Math.abs(steps - Math.round(steps)) < 0.000001;
    },

    updatePeriodDisplay: function (period) {
      var temperature = period.data('temperature');
      var target = period.data('temperature-target');
      var label;
      if (temperature !== null && temperature !== undefined && temperature !== '') {
        label = String(temperature) + ' °C';
        var incompatible = target && target !== this.settings.temperature.target;
        if (incompatible || !this.validTemperature(temperature)) label += ' ⚠';
      } else {
        label = this.settings.translate('scheduler.no_temperature', 'No temperature change');
      }
      var bounds = this.periodBounds(period);
      var time = this.periodInit(bounds.start, bounds.end);
      $('.jqs-period-time', period).text(time);
      $('.jqs-period-title', period).text(label);
      period.attr({title: time + ' · ' + label, 'aria-label': time + ' · ' + label});
    },

    refreshLabels: function () {
      var $this = this;
      $('.jqs-grid-day-label', this.element).each(function (index) {
        $(this).text($this.settings.translate('scheduler.day.' + index, $this.settings.daysList[index]));
      });
      $('.jqs-period', this.element).each(function () { $this.updatePeriodDisplay($(this)); });
      $('.jqs-period-remove, .jqs-day-remove', this.element)
        .attr('title', this.settings.translate('scheduler.remove', 'Remove'));
      $('.jqs-period-duplicate, .jqs-day-duplicate', this.element)
        .attr('title', this.settings.translate('scheduler.duplicate', 'Copy to all days'));
    },

    /**
     * Return a readable period string from a period position
     * @param start
     * @param end
     * @returns {string}
     */
    periodInit: function (start, end) {
      return this.periodFormat(start) + ' - ' + this.periodFormat(end);
    },

    /**
     * Return a readable period string from a drag event
     * @param ui
     * @returns {string}
     */
    periodDrag: function (ui) {
      var start = Math.round(ui.position.top / this.periodPosition);
      var end = Math.round(($(ui.helper).height() + ui.position.top) / this.periodPosition);

      return this.periodFormat(start) + ' - ' + this.periodFormat(end);
    },

    /**
     * Return a readable period string from a resize event
     * @param ui
     * @returns {string}
     */
    periodResize: function (ui) {
      var start = Math.round(ui.position.top / this.periodPosition);
      var end = Math.round((ui.size.height + ui.position.top) / this.periodPosition);

      return this.periodFormat(start) + ' - ' + this.periodFormat(end);
    },

    /**
     *
     * @param period
     */
    periodText: function (period) {
      var height = period.height();
      period.removeClass('jqs-period-15').removeClass('jqs-period-30');

      if (height === 10) {
        period.addClass('jqs-period-15');
        return false;
      }

      if (height === 20) {
        period.addClass('jqs-period-30');
        return false;
      }

      var newHeight = Math.floor((height - 16 - 4) / 12) * 12;
      $('.jqs-period-title', period).height(newHeight);
    },

    /**
     * Return an object with all period data
     * @param period
     * @returns {[*,*]}
     */
    periodData: function (period) {
      var bounds = this.periodBounds(period);
      var data = {
        start: this.periodFormat(bounds.start),
        end: this.periodFormat(bounds.end),
        title: period.data('period-title') || '',
        temperature: period.data('temperature'),
        backgroundColor: $('.jqs-period-container', period).css('background-color'),
        borderColor: $('.jqs-period-container', period).css('border-top-color'),
        textColor: $('.jqs-period-container', period).css('color')
      };
      if (data.temperature !== null && data.temperature !== undefined) {
        data.temperature_target = period.data('temperature-target') || this.settings.temperature.target;
      }
      return data;
    },

    /**
     * Return a readable hour from a position
     * @param position
     * @returns {number}
     */
    periodFormat: function (position) {
      if (position >= this.periodHeight) {
        position = 0;
      }

      if (position < 0) {
        position = 0;
      }

      var hour = Math.floor(position / this.periodInterval);
      var mn = (position / this.periodInterval - hour) * 60;

      if (this.settings.hour === 12) {
        var time = hour;
        var ind = ' am';

        if (hour >= 12) {
          ind = ' pm';
        }
        if (hour > 12) {
          time = hour - 12;
        }
        if (hour === 0 || hour === 24) {
          ind = ' am';
          time = 12;
        }
        if (mn !== 0) {
          time += ':' + mn;
        }

        return time + ind;
      }

      if (hour < 10) {
        hour = '0' + hour;
      }
      if (mn < 10) {
        mn = '0' + mn;
      }

      return hour + ':' + mn;
    },

    /**
     * Return a position from a readable hour
     * @param time
     * @returns {number}
     */
    positionFormat: function (time) {
      var split = time.split(':');
      var hour = parseInt(split[0]);
      var mn = parseInt(split[1]);

      if (this.settings.hour === 12) {
        var matches = time.match(/([0-1]?[0-9]):?([0-5][0-9])?\s?(am|pm|p)?/);
        var ind = matches[3];
        if (!ind) {
          ind = 'am';
        }

        hour = parseInt(matches[1]);
        mn = parseInt(matches[2]);

        if (!mn) {
          mn = 0;
        }

        if (hour === 12 && ind === 'am') {
          hour = 0;
        }
        if (hour === 12 && (ind === 'pm' || ind === 'p')) {
          ind = 'am';
        }
        if (ind === 'pm' || ind === 'p') {
          hour += 12;
        }
      }

      var position = 0;
      position += hour * this.periodInterval;
      position += mn / 60 * this.periodInterval;

      if (Math.floor(position) !== position) {
        return -1;
      }

      return position;
    },

    /**
     * Return a hour to readable format (Grid structure)
     * @param hour
     * @returns {string}
     */
    formatHour: function (hour) {
      if (this.settings.hour === 12) {
        switch (hour) {
          case 0:
          case 24:
            hour = '12 am';
            break;
          case 12:
            hour = '12 pm';
            break;
          default:
            if (hour > 12) {
              hour = (hour - 12) + ' pm';
            } else {
              hour += ' am';
            }
        }
      } else {
        if (hour >= 24) {
          hour = 0;
        }

        if (hour < 10) {
          hour = '0' + hour;
        }
        hour += ':00';
      }

      return hour;
    },

    /**
     * Check if a period is valid
     * @param current
     * @returns {boolean}
     */
    isValid: function (current) {
      var $this = this;
      var bounds = this.periodBounds(current);
      var valid = bounds.start >= 0 && bounds.end <= this.periodHeight && bounds.end > bounds.start;
      $('.jqs-period', current.parent()).each(function () {
        if (this !== current[0]) {
          var other = $this.periodBounds($(this));
          if (bounds.start < other.end && other.start < bounds.end) valid = false;
        }
      });
      return valid;
    },

    /**
     * Export data to JSON string
     * @returns {string}
     */
    export: function () {
      var $this = this;
      var data = [];

      $('.jqs-day', $this.element).each(function (index, day) {
        var periods = [];
        $('.jqs-period', day).each(function (index, period) {
          periods.push($this.periodData($(period)));
        });

        data.push({
          day: index,
          periods: periods
        });
      });

      return JSON.stringify(data);
    },

    /**
     * Import data on plugin init
     * @param args
     * @returns {Array}
     */
    import: function (args) {
      var $this = this;
      var dataImport = args[1];
      var ret = [];
      $.each(dataImport, function (index, data) {
        $.each(data.periods, function (index, period) {
          var parent = $('.jqs-day', $this.element).eq(data.day);
          var options = {};
          var height, position;
          if ($.isArray(period)) {
            position = $this.positionFormat(period[0]);
            height = $this.positionFormat(period[1]);
          } else {
            position = $this.positionFormat(period.start);
            height = $this.positionFormat(period.end);
            options = period;
          }

          if (height === 0) {
            height = $this.periodHeight;
          }

          var status = true;
          if (!$this.add(parent, position, height - position, options)) {
            status = false;
          }

          ret.push({
            day: data.day,
            period: [
              $this.periodFormat(position),
              $this.periodFormat(height)
            ],
            status: status
          });
        });
      });

      return JSON.stringify(ret);
    },

    /**
     * Remove all periods
     */
    reset: function () {
      this.removeAll(this.element);
    },
    
    /**
     * Touch - getY
     */
    getY: function (event, preventDefault) {
        var touch = undefined;
        if(event.originalEvent.touches) { 
            if(preventDefault) {
        	event.preventDefault(); 
            }
            touch = event.originalEvent.changedTouches[0]; 
        }
          
        var pageY = event.pageY;
        if(typeof touch !== 'undefined') { pageY = touch.pageY; }
        
        return pageY;
    }
  });

  $.fn[pluginName] = function (options) {
    var ret = false;
    var args = Array.prototype.slice.call(arguments);
    var loop = this.each(function () {
      if (!$.data(this, 'plugin_' + pluginName)) {
        $.data(this, 'plugin_' + pluginName, new Plugin(this, options));
      } else if ($.isFunction(Plugin.prototype[options])) {
        ret = $.data(this, 'plugin_' + pluginName)[options](args);
      }
    });

    if (ret) {
      return ret;
    }

    return loop;
  };
})(jQuery, window, document);
