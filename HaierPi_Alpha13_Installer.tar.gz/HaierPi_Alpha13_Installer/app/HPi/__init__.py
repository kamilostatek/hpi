# GPIO compatibility namespace for legacy HaierPi.
