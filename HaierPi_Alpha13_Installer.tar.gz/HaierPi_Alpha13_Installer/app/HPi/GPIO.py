"""Compatibility with legacy HaierPi GPIO sysfs API.

Requires a Linux kernel with /sys/class/gpio/export enabled.
No GPIO operations are performed at import time.
"""
from pathlib import Path
import time

HIGH, LOW = 1, 0
OUT, IN = 'out', 'in'
BASE = Path('/sys/class/gpio')


def _gpio_dir(pin):
    return BASE / ('gpio' + str(int(pin)))


def setup(pin, action):
    if action not in (OUT, IN):
        raise ValueError('GPIO direction must be in or out')
    path = _gpio_dir(pin)
    if not path.exists():
        (BASE / 'export').write_text(str(int(pin)), encoding='ascii')
        for _ in range(30):
            if path.exists():
                break
            time.sleep(0.01)
    (path / 'direction').write_text(action, encoding='ascii')


def output(pin, value):
    ( _gpio_dir(pin) / 'value').write_text(str(int(value)), encoding='ascii')


def input(pin):
    return (_gpio_dir(pin) / 'value').read_text(encoding='ascii').strip()


def cleanup(pin):
    if _gpio_dir(pin).exists():
        (BASE / 'unexport').write_text(str(int(pin)), encoding='ascii')
