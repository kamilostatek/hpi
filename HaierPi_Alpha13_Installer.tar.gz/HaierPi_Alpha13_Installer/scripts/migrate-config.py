#!/usr/bin/env python3
"""Migrate a selected legacy HaierPi INI to /opt/config.ini.

Adds only missing Alpha13 options and sections; keeps existing values and
comments. Never imports the controller or starts heating hardware.
"""
import argparse
import configparser
import os
from pathlib import Path
import re
import tempfile
from configure import create_defaults

SECTION_RE = re.compile(r'^\s*\[([^\]]+)\]\s*(?:[;#].*)?$')


def merge_ini(original, defaults):
    cfg = configparser.ConfigParser(interpolation=None)
    cfg.read_string(original)
    missing = {}
    for section, options in defaults.items():
        absent = [(key, str(value)) for key, value in options.items()
                  if not cfg.has_option(section, key)]
        if absent:
            missing[section] = absent
    if not missing:
        return original, 0
    lines = original.splitlines(keepends=True)
    boundaries = []
    for ix, line in enumerate(lines):
        match = SECTION_RE.match(line.rstrip('\r\n'))
        if match:
            boundaries.append((ix, match.group(1)))
    inserts = {}
    for i, (line_ix, section) in enumerate(boundaries):
        if section not in missing:
            continue
        at = boundaries[i + 1][0] if i + 1 < len(boundaries) else len(lines)
        block = ['\n; Dodano brakujace ustawienia HaierPi Alpha13\n']
        block += [f'{key} = {value}\n' for key, value in missing.pop(section)]
        inserts[at] = inserts.get(at, []) + block
    out = []
    for pos in range(len(lines) + 1):
        if pos in inserts:
            out.extend(inserts[pos])
        if pos < len(lines):
            out.append(lines[pos])
    result = ''.join(out)
    if result and not result.endswith('\n'):
        result += '\n'
    for section, values in missing.items():
        result += f'\n[{section}]\n'
        result += ''.join(f'{key} = {val}\n' for key, val in values)
    # Validate compatibility with the same parser used by HaierPi.
    check = configparser.ConfigParser(interpolation=None)
    check.read_string(result)
    for section, opts in defaults.items():
        for key in opts:
            if not check.has_option(section, key):
                raise ValueError(f'Po migracji nadal brakuje [{section}] {key}')
    count = sum(len(v) for v in defaults.values()) - sum(
        1 for section, opts in defaults.items() for key in opts
        if cfg.has_option(section, key))
    return result, count


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('--source', required=True, type=Path)
    args.add_argument('--destination', required=True, type=Path)
    args.add_argument('--board', choices=('nanopi', 'rpi'), required=True)
    args.add_argument('--outside-source', choices=('ha', 'ds18b20'), default='ha')
    a = args.parse_args()
    if a.source.is_symlink() or a.destination.is_symlink():
        args.error('Pliki konfiguracji nie mogą być dowiązaniami symbolicznymi')
    if not a.source.is_file() or not a.source.stat().st_size:
        args.error(f'Brakuje konfiguracji lub plik jest pusty: {a.source}')
    if not a.destination.parent.is_dir():
        args.error(f'Nie istnieje katalog docelowy: {a.destination.parent}')
    raw = a.source.read_bytes()
    try:
        source = raw.decode('utf-8-sig')
    except UnicodeDecodeError as e:
        args.error(f'Plik konfiguracji nie jest kodowany w UTF-8: {e}')
    try:
        merged, count = merge_ini(source, create_defaults(a.board, a.outside_source))
    except (configparser.Error, ValueError) as e:
        args.error(f'Nieprawidłowy config.ini; odmowa nadpisania: {e}')
    fd, tmp = tempfile.mkstemp(prefix='.haierpi-config-', dir=str(a.destination.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            fh.write(merged)
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp, 0o600)
        os.replace(tmp, a.destination)
        # Directory sync ensures rename durability if power goes out.
        dfd = os.open(a.destination.parent, os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    print(f'Zachowano konfigurację w {a.destination}; dodano {count} brakujących wpisów Alpha13.')
    print('Dotychczasowe wartości nie zostały zmienione. Usługa nadal jest wyłączona.')


if __name__ == '__main__':
    main()
