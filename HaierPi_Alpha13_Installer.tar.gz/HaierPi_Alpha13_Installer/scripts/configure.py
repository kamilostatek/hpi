#!/usr/bin/env python3
"""Create safe, per-device default configuration without importing main.py."""
import configparser
import getpass
import json
import os
from pathlib import Path
import secrets
import sys

BASE = Path('/opt/haier')
CONFIG = Path('/opt/config.ini')
SECRET = Path('/etc/haierpi/flask_secret')


def create_defaults(board, outside_source):
    if outside_source not in ("ha", "ds18b20"):
        raise ValueError("outside_source must be ha or ds18b20")
    # Verified NanoPi NEO values supplied from a working installation.
    pins = {'nanopi': ('0', '64', '2', '3'), 'rpi': ('17', '27', '22', '10')}
    port = '/dev/ttyS1' if board == 'nanopi' else '/dev/ttyAMA0'
    a, b, c, d = pins[board]
    return {
        'MAIN': {'bindport': '80' if board == 'nanopi' else '4000',
                 'bindaddress': '0.0.0.0',
                 'modbusdev': port, 'heizfreq': '10', 'firstrun': '1',
                 'release': 'master', 'expert_mode': '0', 'log_level': 'INFO',
                 'ui_font': 'inter'},
        'SETTINGS': {
            'settemp': '20', 'dhwtemp': '45', 'heatingcurve': 'auto',
            'hcslope': '0.7', 'hcpshift': '1', 'hcamp': '1',
            'hcman': '40,35,30,25,20,20,20',
            'insidetemp': 'ha', 'outsidetemp': ('builtin' if outside_source == 'ds18b20' else 'ha'), 'humidity': 'ha',
            'omlat': '0', 'omlon': '0', 'flimit': 'manual',
            'flimittemp': '10', 'presetautochange': 'manual',
            'presetquiet': '10', 'presetturbo': '-10',
            'antionoff': '0', 'antionoffdeltatime': '5.5',
            'deltatempflimit': '1.5', 'deltatempquiet': '3',
            'deltatempturbo': '6', 'chscheduler': '0',
            'dhwscheduler': '0', 'dhwwl': '0', 'dhwuse': '0',
            'kwhnowcorr': '1.0', 'thermostat_on': '0',
            'heatingcurve_last': 'manual', 'direct_inside_settemp': '22.0',
            'emergency_intemp': '20.0', 'dhwnolimit_mode': 'turbo',
            'zone_frost_enable': '0', 'zone_frost_temp': '-5',
            'zone_frost_mode': 'quiet',
            'zone_warm_enable': '0', 'zone_warm_temp': '10',
            'zone_warm_mode': 'quiet_flimit',
            'antifreeze_custom_enable': '0', 'antifreeze_custom_outtemp': '1',
            'antifreeze_custom_twi': '4', 'antifreeze_custom_two': '4',
            'antifreeze_custom_runtime_min': '0.5',
            'service_test_duration_s': '30',
            'restore_state_on_boot': '0', 'last_operating_state': 'off',
            'anti_legionella_enable': '0', 'anti_legionella_temp': '60.0',
            'dhw_heater_assist_enable': '0',
            'dhw_heater_assist_below_temp': '10'
        },
        'HOMEASSISTANT': {
            'HAADDR': '127.0.0.1', 'HAPORT': '8123', 'KEY': '',
            'insidesensor': '', 'outsidesensor': '',
            'humiditysensor': '', 'dhwsensor': '',
            'ha_mqtt_discovery': '0',
            'ha_mqtt_discovery_prefix': 'homeassistant'
        },
        'MQTT': {'mqtt': '0', 'address': '127.0.0.1', 'port': '1883',
                 'mqtt_ssl': '0', 'main_topic': 'climate/haier',
                 'username': '', 'password': '', 'snapshot_interval_s': '0'},
        'HPIAPP': {'hpiatstart': '0', 'hpikey': ''},
        'GPIO': {'modbus': a, 'freqlimit': b, 'heatdemand': c, 'cooldemand': d},
    }


def write_ini(path, settings):
    parser = configparser.ConfigParser(interpolation=None)
    parser.read_dict(settings)
    with open(path, 'w', encoding='utf-8') as fh:
        parser.write(fh)
    os.chmod(path, 0o600)


def main(board, outside_source):
    defaults = create_defaults(board, outside_source)
    if not (BASE / 'config.ini.repo').exists():
        write_ini(BASE / 'config.ini.repo', defaults)
    if not CONFIG.exists():
        write_ini(CONFIG, defaults)
        print(f'Utworzono /opt/config.ini (źródło temperatury: {outside_source}); sterowanie pompą pozostaje wyłączone.')
    else:
        print('Zachowano istniejący /opt/config.ini. Źródło temperatury zmienisz przez scripts/set-outside-source.py.')
    SECRET.parent.mkdir(parents=True, exist_ok=True)
    if not SECRET.exists():
        SECRET.write_text(secrets.token_hex(48) + '\n', encoding='ascii')
        SECRET.chmod(0o600)

    users = BASE / 'users.json'
    if not users.exists():
        from werkzeug.security import generate_password_hash
        if not sys.stdin.isatty():
            raise RuntimeError('Do ustawienia hasła administratora wymagany jest terminal.')
        print('\nUtwórz nowe hasło do HaierPi (minimum 8 znaków).')
        while True:
            password = getpass.getpass('Nowe hasło do HaierPi: ')
            confirm = getpass.getpass('Powtórz nowe hasło: ')
            if len(password) >= 8 and password == confirm:
                break
            print('Hasła muszą być identyczne i mieć co najmniej 8 znaków. Spróbuj ponownie.')
        item = {'admin': {'username': 'admin', 'password': generate_password_hash(
            password, method='pbkdf2:sha256')}}
        with open(users, 'w', encoding='utf-8') as fh:
            json.dump(item, fh)
        users.chmod(0o600)

        # Pokaz dane tylko raz, bez zapisu jawnego hasla do dziennika instalatora.
        # /dev/tty zamiast stdout: nawet jesli stdout zostanie przekierowane,
        # haslo nie trafi przypadkiem do pliku z logami.
        tty_fd = os.open('/dev/tty', os.O_RDWR)
        try:
            komunikat = ( '\n' + '=' * 46 + '\n'
                + '       DANE LOGOWANIA DO HAIERPI\n'
                + '=' * 46 + '\n'
                + 'Login: admin\n'
                + f'Hasło: {password}\n'
                + '=' * 46 + '\n'
                + 'Zapisz te dane w bezpiecznym miejscu.\n'
                + 'Hasło nie będzie ponownie wyświetlane przez instalator.\n'
                + 'Naciśnij Enter po zapisaniu danych... ')
            os.write(tty_fd, komunikat.encode('utf-8'))
            while True:
                dane = os.read(tty_fd, 256)
                if not dane or b'\n' in dane:
                    break
        finally:
            os.close(tty_fd)
        del password, confirm
    for name in ('schedule_ch.json', 'schedule_dhw.json'):
        p = BASE / name
        if not p.exists():
            # Empty/disabled schedule; HaierPi accepts and migrates on first use.
            p.write_text(json.dumps([{'day': day, 'periods': []}
                                     for day in range(7)], indent=2) + '\n',
                         encoding='utf-8')
    print('Konfiguracja początkowa gotowa. Wpisy GPIO i Modbus będą zweryfikowane automatycznie; sprawdź okablowanie i UART przed startem.')


if __name__ == '__main__':
    if len(sys.argv) != 3 or sys.argv[1] not in ('nanopi', 'rpi') or sys.argv[2] not in ('ha', 'ds18b20'):
        sys.exit('Usage: configure.py nanopi|rpi ha|ds18b20')
    main(sys.argv[1], sys.argv[2])
