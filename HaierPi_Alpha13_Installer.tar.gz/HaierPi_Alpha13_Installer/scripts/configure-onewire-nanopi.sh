#!/usr/bin/env bash
# Optional HaierPi DS18B20 1-Wire support for NanoPi NEO (Allwinner H3).
# Installs the supplied PA6 overlay in overlay-user; never overwrites kernel DTBs.
set -Eeuo pipefail

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ "$(id -u)" == 0 ]] || fail 'Run as root: sudo bash scripts/configure-onewire-nanopi.sh'

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$ROOT_DIR/overlays/haierpi-w1-pa6.dtbo"
[[ -s "$SRC" ]] || fail "Missing overlay: $SRC"
[[ -f /proc/device-tree/compatible ]] || fail 'Device-tree compatible list not available.'
tr '\000' '\n' < /proc/device-tree/compatible | grep -Fxq 'allwinner,sun8i-h3' || \
  fail 'This script is exclusively for Allwinner H3 / NanoPi NEO. Not Raspberry Pi.'

BOOT_ENV=''
for file in /boot/dietpiEnv.txt /boot/armbianEnv.txt; do
  if [[ -f "$file" ]]; then BOOT_ENV="$file"; break; fi
done
[[ -n "$BOOT_ENV" ]] || fail 'No /boot/dietpiEnv.txt or /boot/armbianEnv.txt found.'

# For this mode, the active U-Boot script must consume user_overlays.
[[ -f /boot/boot.scr ]] || fail 'No /boot/boot.scr; cannot verify user_overlays support.'
LC_ALL=C grep -aq 'user_overlays' /boot/boot.scr || \
  fail 'Current boot.scr does not mention user_overlays. No changes made. Consult board-specific boot setup.'

# Prevent two w1 masters from being activated via both overlay variables.
python3 - "$BOOT_ENV" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
lines = p.read_text(encoding='utf-8').splitlines()
for var in ('overlays', 'user_overlays'):
    hits = [x for x in lines if x.strip().startswith(var+'=')]
    if len(hits) > 1:
        sys.exit(f'ERROR: duplicate {var}= lines; please repair {p} manually.')
    if var == 'overlays' and hits:
        names = hits[0].split('=',1)[1].split()
        if 'w1-gpio' in names:
            sys.exit(f'ERROR: stock w1-gpio already enabled in {p}. Do not enable a second 1-Wire overlay.')
PY

# Check the file is a valid DTB overlay for H3 with the expected PA6 pin.
python3 - "$SRC" <<'PY'
from pathlib import Path
import struct, sys
b = Path(sys.argv[1]).read_bytes()
if len(b) < 40:
    sys.exit('ERROR: invalid DTBO: too short')
h = struct.unpack_from('>10I', b)
magic,total,os,ots,_,_,_,_,ss,sst = h
if magic != 0xd00dfeed or total != len(b):
    sys.exit('ERROR: invalid DTBO header')
strings = b[ots:ots+ss]
off = os
vals = {}
while off < os+sst:
    tag, = struct.unpack_from('>I', b, off); off += 4
    if tag == 1:
        off = (b.index(b'\0', off)+4)//4*4
    elif tag == 2 or tag == 4:
        continue
    elif tag == 3:
        n, no = struct.unpack_from('>II', b, off); off += 8
        name = strings[no:strings.index(b'\0', no)].decode('ascii')
        val = b[off:off+n]
        vals.setdefault(name, []).append(val)
        off = (off+n+3)//4*4
    elif tag == 9:
        break
    else:
        sys.exit('ERROR: unexpected DTBO tag')
if b'allwinner,sun8i-h3\0' not in vals.get('compatible', []):
    sys.exit('ERROR: overlay is not marked for Allwinner H3')
if b'PA6\0' not in vals.get('pins', []):
    sys.exit('ERROR: overlay does not target PA6')
if b'w1-gpio\0' not in vals.get('compatible', []):
    sys.exit('ERROR: overlay has no w1-gpio node')
PY

TARGET_DIR=/boot/overlay-user
TARGET="$TARGET_DIR/haierpi-w1-pa6.dtbo"
mkdir -p "$TARGET_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
if [[ -f "$TARGET" ]] && ! cmp -s "$SRC" "$TARGET"; then
  cp -p "$TARGET" "$TARGET.bak-haierpi-$STAMP"
fi
install -m 644 "$SRC" "$TARGET"
cp -p "$BOOT_ENV" "$BOOT_ENV.bak-haierpi-$STAMP"
python3 - "$BOOT_ENV" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
lines = p.read_text(encoding='utf-8').splitlines()
found = False
out=[]
for line in lines:
    if line.strip().startswith('user_overlays='):
        names = line.partition('=')[2].split()
        if 'haierpi-w1-pa6' not in names:
            names.append('haierpi-w1-pa6')
        out.append('user_overlays='+' '.join(names))
        found=True
    else:
        out.append(line)
if not found:
    out.append('user_overlays=haierpi-w1-pa6')
p.write_text('\n'.join(out)+'\n', encoding='utf-8')
PY
sync
printf 'Installed %s\n' "$TARGET"
printf 'Enabled user_overlays=haierpi-w1-pa6 in %s\n' "$BOOT_ENV"
printf '1-Wire pin: PA6 (Linux GPIO6), physical header pin 12 on NanoPi NEO.\n'
printf 'External DS18B20 data pull-up to 3.3V usually required (e.g. 4.7 kohm).\n'
printf 'REBOOT REQUIRED. Then check: ls /sys/bus/w1/devices/\n'
printf 'No HaierPi service was started. Raspberry Pi settings unchanged.\n'
