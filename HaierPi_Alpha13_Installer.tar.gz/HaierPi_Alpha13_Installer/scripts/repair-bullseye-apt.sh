#!/usr/bin/env bash
# HaierPi: recover APT on archived Debian 11 Bullseye, without replacing other distro sources.
# Safeguards: only Debian Bullseye; only after APT failed due to unavailable/expired repos;
# preserves third-party apt sources, APT signatures, and a complete backup.
set -Eeuo pipefail
IFS=$'\n\t'

[[ $EUID -eq 0 ]] || { echo 'Run as root.' >&2; exit 1; }
# Override is intended only for offline regression testing in an isolated sandbox.
APT_ROOT="${HAIERPI_APT_ROOT:-/etc/apt}"
APT_GET="${HAIERPI_APT_GET:-apt-get}"
OS_RELEASE="${HAIERPI_OS_RELEASE:-/etc/os-release}"
BACKUP_PARENT="${HAIERPI_APT_BACKUP_DIR:-/root/haierpi-apt-backups}"
[[ -f "$OS_RELEASE" ]] || { echo 'Missing /etc/os-release' >&2; exit 1; }
# shellcheck disable=SC1090
source "$OS_RELEASE"
if [[ "${VERSION_CODENAME:-${DEBIAN_CODENAME:-}}" != bullseye ]]; then
    echo '[APT] Not Debian Bullseye; repository files left unchanged.'
    exit 0
fi
[[ -d "$APT_ROOT/sources.list.d" ]] || mkdir -p "$APT_ROOT/sources.list.d"

report=$(mktemp)
trap 'rm -f "$report"' EXIT
if "$APT_GET" update -o APT::Update::Error-Mode=any >"$report" 2>&1; then
    echo '[APT] apt update succeeded; no repository changes needed.'
    exit 0
fi
if ! grep -Eiq '(^|[^0-9])404([^0-9]|$)|does not have a Release file|Release file.*(expired|not valid)|Release file is expired' "$report"; then
    echo '[APT] apt update failed, but not due to archived Debian sources. No files modified.' >&2
    tail -n 25 "$report" >&2
    exit 1
fi
# Refuse to edit Debian deb822 sources automatically; preserve custom/third-party configs.
if grep -lsE '(^Suites:[[:space:]].*bullseye|^Suites:[[:space:]]*$)' "$APT_ROOT"/sources.list.d/*.sources > /dev/null 2>&1; then
    echo '[APT] Bullseye .sources (deb822) detected. Repair manually; no files modified.' >&2
    exit 1
fi

# At least one recognizable official Debian repository must be present.
any_old=0
for file in "$APT_ROOT/sources.list" "$APT_ROOT"/sources.list.d/*.list; do
  [[ -f "$file" ]] || continue
  if grep -Eq '^[[:space:]]*deb(-src)?[[:space:]].*(deb\.debian\.org|security\.debian\.org|ftp\.debian\.org|archive\.debian\.org).*[[:space:]]bullseye(-security|-updates|-backports)?[[:space:]]' "$file"; then
    any_old=1
  fi
done
if [[ "$any_old" != 1 ]]; then
    echo '[APT] No recognized Bullseye Debian .list entries. No files modified.' >&2
    tail -n 20 "$report" >&2
    exit 1
fi

umask 077
mkdir -p "$BACKUP_PARENT"
backup="$BACKUP_PARENT/$(date -u +%Y%m%dT%H%M%SZ)-$$"
mkdir -p "$backup"
cp -a "$APT_ROOT" "$backup/apt-original"
echo "[APT] Saved original APT settings: $backup/apt-original"

# Disable only official Debian 11 sources; keep all third-party repos untouched.
for file in "$APT_ROOT/sources.list" "$APT_ROOT"/sources.list.d/*.list; do
  [[ -f "$file" ]] || continue
  temp=$(mktemp "${file}.tmp.XXXXXXXX")
  awk '
    /^[[:space:]]*deb(-src)?[[:space:]]/ &&
    /[[:space:]]bullseye(-security|-updates|-backports)?[[:space:]]/ &&
    /(deb\.debian\.org|security\.debian\.org|ftp\.debian\.org|archive\.debian\.org)/ {
       print "# HaierPi: moved to archive (backup available): " $0
       next
    }
    {print}
  ' "$file" > "$temp"
  chmod --reference="$file" "$temp"
  chown --reference="$file" "$temp"
  mv -f "$temp" "$file"
done
cat > "$APT_ROOT/sources.list.d/haierpi-bullseye-archive.list" <<'REPOS'
# Archived Debian 11 (EOL). Signed Release files are still verified.
deb [check-valid-until=no] http://archive.debian.org/debian bullseye main contrib non-free
deb [check-valid-until=no] http://archive.debian.org/debian bullseye-updates main contrib non-free
deb [check-valid-until=no] http://archive.debian.org/debian-security bullseye-security main contrib non-free
deb [check-valid-until=no] http://archive.debian.org/debian bullseye-backports main contrib non-free
REPOS
chmod 644 "$APT_ROOT/sources.list.d/haierpi-bullseye-archive.list"

if "$APT_GET" update -o APT::Update::Error-Mode=any >"$report" 2>&1; then
    echo '[APT] Bullseye archive repositories configured and update succeeded.'
    echo "[APT] Backup: $backup/apt-original"
else
    echo '[APT] Update still failed; restoring previous configuration. Details:' >&2
    tail -n 30 "$report" >&2
    rm -f "$APT_ROOT/sources.list.d/haierpi-bullseye-archive.list"
    [[ ! -f "$backup/apt-original/sources.list" ]] || cp -a "$backup/apt-original/sources.list" "$APT_ROOT/sources.list"
    rm -rf "$APT_ROOT/sources.list.d"
    cp -a "$backup/apt-original/sources.list.d" "$APT_ROOT/sources.list.d"
    exit 1
fi
