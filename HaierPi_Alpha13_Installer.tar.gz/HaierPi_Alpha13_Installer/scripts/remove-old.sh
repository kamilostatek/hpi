#!/usr/bin/env bash
# Remove ONLY the legacy HaierPi application, preserving the selected config
# under /opt/config.ini with added (only missing) Alpha13 settings.
set -Eeuo pipefail
IFS=$'\n\t'
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BOARD="${1:-}"
[[ $EUID -eq 0 ]] || { echo 'Run as root.' >&2; exit 1; }
[[ "$BOARD" == nanopi || "$BOARD" == rpi ]] || { echo 'Usage: remove-old.sh nanopi|rpi' >&2; exit 1; }
[[ -r /dev/tty ]] || { echo 'Interactive terminal is required.' >&2; exit 1; }
APP=/opt/haier
NEW=/opt/config.ini
OLD=/opt/haier/config.ini
say() { printf '%s\n' "$*" > /dev/tty; }
ask() { local REPLY; read -r -p "$1" REPLY < /dev/tty || return 1; printf '%s' "$REPLY"; }
abort() { say "PRZERWANO: $*"; exit 1; }

[[ -d "$APP" && ! -L "$APP" ]] || abort 'Brak zwyklego katalogu /opt/haier (albo jest dowiazaniem).'
[[ -f "$APP/main.py" || -f "$OLD" ]] || abort 'Nie rozpoznano katalogu /opt/haier jako instalacji HaierPi.'
[[ ! -L "$NEW" && ! -L "$OLD" ]] || abort 'config.ini jest dowiazaniem symbolicznym. Nic nie usunieto.'
[[ -w /opt && -w /var/backups ]] || abort 'Brak prawa zapisu do /opt lub /var/backups.'
# Protect against deleting nested mounts, including F2FS mounts inside the app directory.
if findmnt -rn -o TARGET | grep -Eq '^/opt/haier(/|$)'; then
  abort 'W katalogu /opt/haier istnieje punkt montowania. Najpierw go odmontuj.'
fi

if [[ -s "$NEW" && -s "$OLD" ]]; then
  say 'Znaleziono dwa pliki konfiguracji:'
  say '1. /opt/config.ini (obecny format)'
  say '2. /opt/haier/config.ini (stara lokalizacja)'
  say 'Ktora konfiguracje zachowac? Obydwie zostana skopiowane do backupu.'
  case "$(ask 'Wybierz [1/2] lub Enter aby anulowac: ')" in
    1) SELECTED="$NEW" ;;
    2) SELECTED="$OLD" ;;
    *) abort 'Nie wybrano zrodla konfiguracji.' ;;
  esac
elif [[ -s "$NEW" ]]; then
  SELECTED="$NEW"
elif [[ -s "$OLD" ]]; then
  SELECTED="$OLD"
else
  abort 'Nie znaleziono niepustego /opt/config.ini ani /opt/haier/config.ini. Usuwanie wstrzymane.'
fi

say "Wybrana konfiguracja: $SELECTED"
say 'Pliki w /opt/haier (kod, env, stare dane) beda usuniete.'
say 'Zostana zachowane: /opt/config.ini i kopia znalezionych danych w /var/backups/haierpi.'
say 'Przed zmiana zadbaj o bezpieczny stan pompy oraz przekaznikow.'
[[ "$(ask 'Wpisz USUN_STARY_HAIERPI aby kontynuowac: ')" == USUN_STARY_HAIERPI ]] || abort 'Brak potwierdzenia.'

# Stop only known HaierPi services. Do not stop unrelated system units.
for unit in haier.service haierpi.service hpi.service; do
  content="$(systemctl cat "$unit" 2>/dev/null || true)"
  if [[ -n "$content" && ( "$content" == *'/opt/haier'* || "$content" == *'HaierPi'* || "$content" == *'haierpi'* ) ]]; then
    systemctl disable --now "$unit" || abort "Nie udalo sie zatrzymac $unit."
    say "Zatrzymano i wylaczono $unit"
  fi
done
# Refuse deletion if a remaining process still runs from /opt/haier.
if ps -eo args= | grep -E '(^|[[:space:]])/opt/haier/(main.py|env/bin/python)([[:space:]]|$)' | grep -v grep -q; then
  abort 'Wykryto nadal dzialajacy proces HaierPi. Zatrzymaj go przed usunieciem.'
fi

stamp="$(date -u '+%Y%m%dT%H%M%SZ')"
backup="$(mktemp -d "/var/backups/haierpi-clean-${stamp}-XXXXXX")"
chmod 700 "$backup"
say "Kopia: $backup"
for item in "$NEW" "$OLD" "$APP/users.json" "$APP/schedule_ch.json" "$APP/schedule_dhw.json"; do
  if [[ -f "$item" && ! -L "$item" ]]; then
    case "$item" in
      "$NEW") name=opt-config.ini ;;
      "$OLD") name=haier-config.ini ;;
      *) name="$(basename "$item")" ;;
    esac
    install -m 600 "$item" "$backup/$name" || abort "Nie mozna zabezpieczyc $item"
    cmp -s "$item" "$backup/$name" || abort "Nieudana weryfikacja kopii $item"
  fi
done
selected_copy="$backup/$( [[ "$SELECTED" == "$NEW" ]] && echo opt-config.ini || echo haier-config.ini )"
[[ -s "$selected_copy" ]] || abort 'Wybranej konfiguracji nie ma w kopii bezpieczenstwa.'

# Merge into the canonical location BEFORE deleting the original app directory.
python3 "$ROOT_DIR/scripts/migrate-config.py" \
  --source "$selected_copy" --destination "$NEW" --board "$BOARD" \
  --outside-source ha || abort 'Migracja config.ini nie powiodla sie. Nie usunieto aplikacji.'
[[ -s "$NEW" ]] || abort 'Wynikowy /opt/config.ini jest pusty. Nie usunieto aplikacji.'

# Remove only /opt/haier. Never remove /opt or any other directory in it.
rm -rf --one-file-system -- "$APP" || abort 'Nie udalo sie usunac /opt/haier.'
[[ ! -e "$APP" ]] || abort 'Katalog /opt/haier nadal istnieje.'
say 'Stara instalacja /opt/haier zostala usunieta.'
if grep -Eiq '^[[:space:]]*restore_state_on_boot[[:space:]]*=[[:space:]]*(1|yes|true|on)([[:space:]]|$)' "$NEW"; then
  say 'UWAGA: restore_state_on_boot jest aktywne w zachowanym config.ini.'
  say 'Przed pierwszym wlaczeniem sterowania rozważ ustawienie tego parametru na 0.'
fi
say "Zachowano /opt/config.ini (w tym nowe, brakujace wpisy Alpha13)."
say "Kopie prywatnych plikow: $backup"
say 'Teraz wybierz opcje 1, aby wykonac czysta instalacje Alpha13.'
say 'Po instalacji sprawdz UART, GPIO i konfiguracje przed uruchomieniem sterowania.'
