#!/usr/bin/env bash
# Repair or (re)install pinned Python dependencies in a dedicated venv.
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
[[ $EUID -eq 0 ]] || { echo 'Run as root.' >&2; exit 1; }
[[ -d /opt/haier ]] || { echo 'No /opt/haier directory.' >&2; exit 1; }
[[ -f "$ROOT_DIR/requirements-pinned.txt" ]] || { echo 'No requirements file.' >&2; exit 1; }
findmnt -n -o FSTYPE / | grep -Fxq overlay && { echo 'Root is overlay, changes may be lost.' >&2; exit 1; }
findmnt -n -o OPTIONS / | grep -qE '(^|,)rw(,|$)' || { echo 'Root filesystem is read-only.' >&2; exit 1; }
export DEBIAN_FRONTEND=noninteractive
bash "$ROOT_DIR/scripts/repair-bullseye-apt.sh"
apt-get update
apt-get install -y --no-install-recommends python3 python3-venv python3-pip python3-dev build-essential ca-certificates
PY_VERSION="$(python3 -c 'import sys; print(sys.version_info.major * 100 + sys.version_info.minor)')"
(( PY_VERSION >= 309 && PY_VERSION <= 311 )) || { echo 'Python 3.9-3.11 required by tested dependency pins.' >&2; exit 1; }
if [[ ! -x /opt/haier/env/bin/python ]]; then
  python3 -m venv /opt/haier/env
fi
export TMPDIR=/var/tmp PIP_NO_CACHE_DIR=1
/opt/haier/env/bin/python -m pip install --disable-pip-version-check --upgrade --force-reinstall -r "$ROOT_DIR/requirements-pinned.txt"
/opt/haier/env/bin/python -m pip check
(cd /opt/haier && /opt/haier/env/bin/python - <<'PY'
import flask, werkzeug, flask_babel, flask_socketio
import jinja2, requests, serial, socketio, PyHaier
import paho.mqtt.client, schedule, termcolor, waitress
import w1thermsensor, HPi.GPIO
from pymodbus.client.sync import ModbusSerialClient
from flask_simplelogin import SimpleLogin
from flask import Markup
print('Required Python imports: OK')
PY
)
echo 'Dependencies repaired; service not started.'
