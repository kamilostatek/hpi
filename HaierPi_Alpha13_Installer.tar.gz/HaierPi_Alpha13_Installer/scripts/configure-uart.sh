#!/usr/bin/env bash
# Prepare boot configuration for the selected board, do not reboot or start HaierPi.
set -Eeuo pipefail
BOARD="${1:-}"
[[ "$(id -u)" == 0 ]] || { echo 'Run as root' >&2; exit 1; }
[[ "$BOARD" == nanopi || "$BOARD" == rpi ]] || { echo 'Usage: bash scripts/configure-uart.sh nanopi|rpi' >&2; exit 1; }
backup() { cp -p "$1" "$1.bak-haierpi-$(date -u +%Y%m%dT%H%M%SZ)"; }
if [[ "$BOARD" == nanopi ]]; then
    BOOT_ENV=''
    for p in /boot/dietpiEnv.txt /boot/armbianEnv.txt; do
        if [[ -f "$p" ]]; then BOOT_ENV="$p"; break; fi
    done
    [[ -n "$BOOT_ENV" ]] || { echo 'No dietpiEnv.txt or armbianEnv.txt found. Configure UART1 manually.' >&2; exit 1; }
    # Only add when the overlay exists for this kernel. Do not touch DS18B20 overlays.
    if ! find /boot/dtb /boot/dtbs /boot/overlay-user -type f \( -name '*uart1*.dtbo' -o -name '*uart1*.dtb' \) -print -quit 2>/dev/null | grep -q .; then
        echo 'No UART1 device-tree overlay found in /boot/dtb or /boot/dtbs. No changes made.' >&2
        exit 1
    fi
    backup "$BOOT_ENV"
    python3 - "$BOOT_ENV" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); src=p.read_text(); lines=src.splitlines(keepends=True)
found=False
for i, line in enumerate(lines):
    if line.lstrip().startswith('overlays='):
        key, _, val=line.partition('=')
        before=val.rstrip('\r\n').split()
        if 'uart1' not in before:
            before.append('uart1')
        lines[i]=key+'='+' '.join(before)+'\n'
        found=True
        break
if not found: lines.append('\noverlays=uart1\n')
p.write_text(''.join(lines))
PY
    echo "Enabled uart1 in $BOOT_ENV. Reboot required before /dev/ttyS1 works."
else
    CFG=''
    for p in /boot/firmware/config.txt /boot/config.txt; do
        if [[ -f "$p" ]]; then CFG="$p"; break; fi
    done
    [[ -n "$CFG" ]] || { echo 'Raspberry Pi boot config not found.' >&2; exit 1; }
    backup "$CFG"
    python3 - "$CFG" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); text=p.read_text()
# Append an explicit [all] section; safe even if other model-dependent sections exist.
if '# HaierPi: UART0 for Modbus, Bluetooth disabled' not in text:
    with p.open('a') as f:
        if not text.endswith('\n'): f.write('\n')
        f.write('\n# HaierPi: UART0 for Modbus, Bluetooth disabled\n[all]\nenable_uart=1\ndtoverlay=disable-bt\n')
PY
    for unit in hciuart.service serial-getty@ttyAMA0.service serial-getty@serial0.service; do
        systemctl disable --now "$unit" 2>/dev/null || true
    done
    for p in /boot/firmware/cmdline.txt /boot/cmdline.txt; do
        if [[ -f "$p" ]]; then
            backup "$p"
            python3 - "$p" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); text=p.read_text().strip()
text=re.sub(r'(?<!\S)console=(?:serial0|ttyAMA0|ttyS0),\S+\s*', '', text)
p.write_text(' '.join(text.split())+'\n')
PY
            break
        fi
    done
    echo "Configured Raspberry Pi UART0 in $CFG, disabled Bluetooth service. Reboot required."
fi
