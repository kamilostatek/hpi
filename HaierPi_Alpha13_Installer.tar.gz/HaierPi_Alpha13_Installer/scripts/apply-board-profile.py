#!/usr/bin/env python3
"""Apply verified serial/GPIO settings without reinstalling HaierPi.

Changes only MAIN.modbusdev and four GPIO mappings (plus optional web port).
Preserves other configuration options, including the real MQTT.mqtt flag.
Creates a dated backup and never starts the control service.
"""
import argparse
import configparser
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import tempfile

PROFILES = {
    'nanopi': {
        'modbusdev': '/dev/ttyS1',
        'modbus': '0', 'freqlimit': '64', 'heatdemand': '2', 'cooldemand': '3'
    },
    'rpi': {
        'modbusdev': '/dev/ttyAMA0',
        'modbus': '17', 'freqlimit': '27', 'heatdemand': '22', 'cooldemand': '10'
    },
}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('board', choices=PROFILES)
    cli.add_argument('--config', type=Path, default=Path('/opt/config.ini'))
    cli.add_argument('--port', type=int, help='Optional web port (e.g. --port 80).')
    args = cli.parse_args()
    if args.port is not None and not (1 <= args.port <= 65535):
        cli.error('--port must be in the range 1..65535')
    if not args.config.is_file():
        cli.error(f'Configuration does not exist: {args.config}')

    parser = configparser.ConfigParser(interpolation=None)
    parser.read(args.config, encoding='utf-8')
    for section in ('MAIN', 'GPIO'):
        if not parser.has_section(section):
            cli.error(f'Missing required section [{section}] in {args.config}')
    before = {
        'modbusdev': parser.get('MAIN', 'modbusdev', fallback='<unset>'),
        **{k: parser.get('GPIO', k, fallback='<unset>') for k in ('modbus','freqlimit','heatdemand','cooldemand')}
    }
    for k, v in PROFILES[args.board].items():
        parser.set('MAIN' if k == 'modbusdev' else 'GPIO', k, v)
    if args.port is not None:
        parser.set('MAIN', 'bindport', str(args.port))

    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = args.config.with_name(args.config.name + '.bak-' + stamp)
    if backup.exists():
        cli.error(f'Backup already exists: {backup}')
    shutil.copy2(args.config, backup)
    fd, tmp = tempfile.mkstemp(prefix='.config.ini.', dir=args.config.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            parser.write(fh)
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp, os.stat(args.config).st_mode & 0o777)
        os.chown(tmp, os.stat(args.config).st_uid, os.stat(args.config).st_gid)
        os.replace(tmp, args.config)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    print(f'Zastosowano profil {args.board} w {args.config}. Kopia: {backup}')
    print('Poprzednie wartości:', before)
    print('Nowe wartości:', PROFILES[args.board])
    if args.port is not None:
        print(f'Port WWW ustawiony na: {args.port}')
    print('Ustawienia MQTT bez zmian. Usługa nie została uruchomiona ani zrestartowana.')

if __name__ == '__main__':
    main()
