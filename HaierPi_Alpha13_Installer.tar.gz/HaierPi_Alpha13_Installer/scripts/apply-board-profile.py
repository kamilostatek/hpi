#!/usr/bin/env python3
"""Correct HaierPi ModbusDev and GPIO numbers for NanoPi NEO or Raspberry Pi.

Only the five hardware values are adjusted. Every unrelated INI line is
preserved verbatim. Existing config is backed up before any change.
This tool never starts the pump or any related service.
"""
import argparse
import configparser
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import tempfile

PROFILES = {
    'nanopi': {
        'MAIN': {'modbusdev': '/dev/ttyS1'},
        'GPIO': {'modbus': '0', 'freqlimit': '64', 'heatdemand': '2', 'cooldemand': '3'},
    },
    'rpi': {
        'MAIN': {'modbusdev': '/dev/ttyAMA0'},
        'GPIO': {'modbus': '17', 'freqlimit': '27', 'heatdemand': '22', 'cooldemand': '10'},
    },
}
SECTION = re.compile(r'^\s*\[([^\]]+)\]\s*(?:[;#].*)?$')
ENTRY = re.compile(r'^(\s*)([A-Za-z][A-Za-z_0-9]*)(\s*[:=]\s*)(.*?)(\r?\n)?$')


def read_config(contents):
    cfg = configparser.ConfigParser(interpolation=None)
    cfg.read_string(contents)
    return cfg


def patch(contents, profile):
    original = read_config(contents)
    required = PROFILES[profile]
    for section in required:
        if not original.has_section(section):
            raise ValueError('Brakuje sekcji [' + section + '] w config.ini')

    lines = contents.splitlines(keepends=True)
    result = []
    section = None
    seen = {s: set() for s in required}
    changes = []

    def missing_for(section_name):
        if section_name not in required:
            return
        for key, desired in required[section_name].items():
            if key not in seen[section_name]:
                result.append(f'{key} = {desired}\n')
                changes.append((section_name, key, '<brak>', desired))

    for line in lines:
        header = SECTION.match(line.rstrip('\r\n'))
        if header:
            missing_for(section)
            section = header.group(1)
            result.append(line)
            continue
        match = ENTRY.match(line)
        if section in required and match:
            key = match.group(2).lower()
            if key in required[section]:
                seen[section].add(key)
                desired = required[section][key]
                old = match.group(4).strip()
                if old != desired:
                    newline = match.group(5) or ''
                    line = match.group(1) + match.group(2) + match.group(3) + desired + newline
                    changes.append((section, key, old, desired))
        result.append(line)
    missing_for(section)
    updated = ''.join(result)
    check = read_config(updated)
    for sec, pairs in required.items():
        for key, desired in pairs.items():
            got = check.get(sec, key, fallback=None)
            if got != desired:
                raise ValueError(f'Nieskuteczna zmiana [{sec}] {key}: {got!r}')
    return updated, changes


def main():
    cli = argparse.ArgumentParser(description='Sprawdza i ustawia Modbus oraz GPIO HaierPi.')
    cli.add_argument('board', choices=PROFILES)
    cli.add_argument('--config', type=Path, default=Path('/opt/config.ini'))
    args = cli.parse_args()
    src = args.config
    if src.is_symlink() or not src.is_file():
        cli.error('Brakuje poprawnego pliku lub wykryto dowi\u0105zanie symboliczne: ' + str(src))
    try:
        original = src.read_text(encoding='utf-8-sig')
        updated, changes = patch(original, args.board)
    except (OSError, UnicodeError, ValueError, configparser.Error) as exc:
        cli.error('Nie mo\u017cna bezpiecznie poprawi\u0107 config.ini: ' + str(exc))

    name = 'NanoPi NEO' if args.board == 'nanopi' else 'Raspberry Pi Zero / Zero 2'
    if not changes:
        print('Profil ' + name + ': wszystkie wpisy Modbus i GPIO s\u0105 poprawne. Bez zmian.')
        return

    stats = src.stat()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')
    back_fd, backup_path = tempfile.mkstemp(prefix=src.name + '.bak-profil-' + stamp + '-', dir=src.parent)
    tmp_path = None
    try:
        with os.fdopen(back_fd, 'wb') as fh:
            fh.write(src.read_bytes())
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(backup_path, 0o600)
        fd, tmp_path = tempfile.mkstemp(prefix='.haierpi-profil-', dir=src.parent)
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            fh.write(updated)
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp_path, stats.st_mode & 0o777)
        os.chown(tmp_path, stats.st_uid, stats.st_gid)
        os.replace(tmp_path, src)
        tmp_path = None
        dfd = os.open(src.parent, os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    finally:
        if tmp_path is not None and os.path.exists(tmp_path):
            os.unlink(tmp_path)
    print('Wykryto niezgodne wpisy. Zastosowano profil ' + name + ':')
    for section, key, old, new in changes:
        print('  [' + section + '] ' + key + ': ' + old + ' -> ' + new)
    print('Kopia poprzedniej konfiguracji: ' + backup_path)
    print('Pozosta\u0142e ustawienia config.ini nie zosta\u0142y zmienione.')
    print('Nie uruchomiono HaierPi ani sterowania pomp\u0105.')


if __name__ == '__main__':
    main()
