#!/usr/bin/env bash
# Remove only the HaierPi-owned PA6 1-Wire overlay selection.
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'Run as root.' >&2; exit 1; }
if [[ -r /proc/device-tree/compatible ]]; then
  tr '\000' '\n' </proc/device-tree/compatible | grep -Fxq 'allwinner,sun8i-h3' || {
    echo 'Not an Allwinner H3 / NanoPi NEO. No changes made.' >&2; exit 1;
  }
fi
BOOT_ENV=''
for p in /boot/dietpiEnv.txt /boot/armbianEnv.txt; do
  if [[ -f "$p" ]]; then BOOT_ENV="$p"; break; fi
done
[[ -n "$BOOT_ENV" ]] || { echo 'No boot environment file found.' >&2; exit 1; }
if ! grep -Eq '^user_overlays=.*haierpi-w1-pa6' "$BOOT_ENV"; then
  echo 'Custom HaierPi PA6 overlay is not enabled; leaving boot configuration unchanged.'
  exit 0
fi
cp -p "$BOOT_ENV" "$BOOT_ENV.bak-haierpi-$(date -u +%Y%m%dT%H%M%SZ)-$$"
python3 - "$BOOT_ENV" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
lines = p.read_text(encoding='utf-8').splitlines()
new=[]
for line in lines:
    if line.startswith('user_overlays='):
        names = line.partition('=')[2].split()
        names = [n for n in names if n != 'haierpi-w1-pa6']
        if names:
            new.append('user_overlays=' + ' '.join(names))
        # If empty, omit the variable, do not touch other overlays.
    else:
        new.append(line)
p.write_text('\n'.join(new)+'\n', encoding='utf-8')
PY
sync
echo 'Disabled HaierPi custom PA6 1-Wire overlay; other overlays preserved.'
echo 'Reboot required before hardware changes take effect.'
