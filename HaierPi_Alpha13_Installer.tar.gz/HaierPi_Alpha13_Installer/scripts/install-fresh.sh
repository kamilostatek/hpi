#!/usr/bin/env bash
# Fresh DietPi installer; intentionally does not start the heat-pump controller.
set -Eeuo pipefail
IFS=$'\n\t'
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BOARD="${1:-}"
APP_DIR=/opt/haier

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
log() { printf '\n[HaierPi installer] %s\n' "$*"; }

[[ $EUID -eq 0 ]] || fail 'Run with: sudo bash install.sh nanopi   OR   sudo bash install.sh rpi'
[[ "$BOARD" == nanopi || "$BOARD" == rpi ]] || fail 'Select board: nanopi or rpi'
[[ -f "$ROOT_DIR/app/main.py" && -f "$ROOT_DIR/requirements-pinned.txt" ]] || fail 'Incomplete installer package'
[[ -f /etc/os-release ]] || fail 'Not a Linux Debian/DietPi system'
# shellcheck disable=SC1091
source /etc/os-release
[[ "${ID:-}" == debian || " ${ID_LIKE:-} " == *' debian '* ]] || fail 'Only Debian/DietPi supported'
[[ "$BOARD" == nanopi ]] && model='NanoPi NEO' || model='Raspberry Pi Zero / Zero 2'
log "Target hardware profile: $model"

# Outdoor sensor choice is a NanoPi NEO-only feature in this installer.
# Raspberry Pi keeps its v2 defaults and does not touch 1-Wire overlays.
if [[ "$BOARD" == nanopi ]]; then
  OUTSIDE_SOURCE="${HAIERPI_OUTSIDE_SOURCE:-}"
  if [[ -z "$OUTSIDE_SOURCE" ]]; then
    [[ -r /dev/tty ]] || fail 'Interactive terminal required. For automation use HAIERPI_OUTSIDE_SOURCE=ha|ds18b20.'
    printf '\nSkad NanoPi NEO ma odczytywac temperature zewnetrzna?\n' > /dev/tty
    printf '  1) Fizyczny czujnik DS18B20 (1-Wire, PA6)\n' > /dev/tty
    printf '  2) Home Assistant (encja temperatury)\n' > /dev/tty
    while true; do
      read -r -p 'Wybor [1/2]: ' answer < /dev/tty || fail 'No answer given.'
      case "$answer" in
        1) OUTSIDE_SOURCE=ds18b20; break ;;
        2) OUTSIDE_SOURCE=ha; break ;;
        *) printf 'Wpisz 1 albo 2.\n' > /dev/tty ;;
      esac
    done
  fi
  [[ "$OUTSIDE_SOURCE" == ha || "$OUTSIDE_SOURCE" == ds18b20 ]] || fail 'HAIERPI_OUTSIDE_SOURCE must be ha or ds18b20.'
  log "NanoPi outdoor temperature mode: $OUTSIDE_SOURCE"
else
  [[ -z "${HAIERPI_OUTSIDE_SOURCE:-}" ]] || fail 'HAIERPI_OUTSIDE_SOURCE is NanoPi-only; do not set it for rpi.'
  OUTSIDE_SOURCE=ha
  log 'Raspberry Pi: keeping v2 outside-temperature default (ha); no 1-Wire changes.'
fi
ROOT_FS="$(findmnt -n -o FSTYPE / || true)"
ROOT_OPTS="$(findmnt -n -o OPTIONS / || true)"
[[ "$ROOT_FS" != overlay ]] || fail 'Root is overlay; changes may vanish after reboot'
[[ ",$ROOT_OPTS," == *,rw,* ]] || fail 'Root filesystem is not writable'
if [[ -f /opt/haier/main.py ]]; then
  fail '/opt/haier/main.py exists; this kit is for fresh DietPi, not an upgrade. Back up and use updater.'
fi
FREE_KB="$(df -Pk /opt | awk 'NR==2 {print $4}')"
[[ "$FREE_KB" =~ ^[0-9]+$ ]] || fail 'Cannot check free space in /opt'
(( FREE_KB >= 800000 )) || fail 'At least 800 MB free on /opt is required. Expand the SD partition first.'

log 'Checking apt repositories; archived Bullseye will be repaired only if needed'
export DEBIAN_FRONTEND=noninteractive
bash "$ROOT_DIR/scripts/repair-bullseye-apt.sh"
log 'Installing Python and build dependencies using apt'
apt-get update
apt-get install -y --no-install-recommends python3 python3-venv python3-pip python3-dev build-essential curl git ca-certificates p7zip-full
PY_VERSION="$(python3 -c 'import sys; print(sys.version_info.major * 100 + sys.version_info.minor)')"
if (( PY_VERSION < 309 || PY_VERSION > 311 )); then
  fail 'Alpha13 dependency set targets Python 3.9-3.11; this Python release has not been verified.'
fi
log 'Copying HaierPi code and creating an isolated virtual environment'
install -d -m 755 "$APP_DIR"
cp -a "$ROOT_DIR/app/main.py" "$ROOT_DIR/app/static" "$ROOT_DIR/app/templates" "$ROOT_DIR/app/HPi" "$ROOT_DIR/app/PyHaier" "$ROOT_DIR/app/tests" "$ROOT_DIR/app/README_HARMONOGRAM_TEMPERATURY.md" "$APP_DIR/"
python3 -m venv "$APP_DIR/env"
# Some DietPi images mount /tmp in RAM; use disk-backed /var/tmp for pip builds.
export TMPDIR=/var/tmp PIP_NO_CACHE_DIR=1
"$APP_DIR/env/bin/python" -m pip install --disable-pip-version-check -r "$ROOT_DIR/requirements-pinned.txt"

log 'Checking Python imports before installing the service'
(cd "$APP_DIR" && "$APP_DIR/env/bin/python" - <<'PY'
import flask, werkzeug, flask_babel, flask_socketio
import jinja2, requests, serial, socketio, PyHaier
import paho.mqtt.client, schedule, termcolor, waitress
import w1thermsensor, HPi.GPIO
from pymodbus.client.sync import ModbusSerialClient
from flask_simplelogin import SimpleLogin
from flask import Markup
print('Python import test: OK')
PY
)
log 'Generating safe default configuration and admin account'
"$APP_DIR/env/bin/python" "$ROOT_DIR/scripts/configure.py" "$BOARD" "$OUTSIDE_SOURCE"
install -m 644 "$ROOT_DIR/systemd/haier.service" /etc/systemd/system/haier.service
systemctl daemon-reload
systemctl disable --now haier.service 2>/dev/null || true
if [[ "${HAIERPI_AUTO_UART:-1}" == 1 ]]; then
  log 'Preparing UART boot configuration for the selected board (no reboot)'
  if bash "$ROOT_DIR/scripts/configure-uart.sh" "$BOARD"; then
    log 'UART boot settings updated. Reboot required before starting HaierPi.'
  else
    log 'WARNING: UART auto-configuration not completed. Read README_PL.md and configure manually.'
  fi
else
  log 'HAIERPI_AUTO_UART=0: left UART boot settings unchanged.'
fi
if [[ "$BOARD" == nanopi ]]; then
  if [[ "$OUTSIDE_SOURCE" == ds18b20 ]]; then
    log 'NanoPi NEO: enabling PA6 1-Wire overlay for DS18B20 (reboot required)'
    bash "$ROOT_DIR/scripts/configure-onewire-nanopi.sh" || \
      fail 'Cannot enable NanoPi DS18B20 overlay. Service remains disabled.'
  else
    log 'NanoPi NEO: Home Assistant selected; no 1-Wire overlay changes.'
    log 'Set [HOMEASSISTANT] HAADDR/HAPORT/KEY/outsidesensor in /opt/config.ini before starting HaierPi.'
  fi
else
  log 'Raspberry Pi: skipped optional outside-temperature and 1-Wire setup.'
fi
log 'Installation complete. Service deliberately NOT started.'

printf 'Next: review /opt/config.ini and physical GPIO wiring; reboot; then sudo bash enable-haierpi.sh\n'
