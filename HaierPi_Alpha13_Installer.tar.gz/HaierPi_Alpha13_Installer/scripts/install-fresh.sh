#!/usr/bin/env bash
# Fresh DietPi installer; intentionally does not start the heat-pump controller.
set -Eeuo pipefail
IFS=$'\n\t'
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BOARD="${1:-}"
APP_DIR=/opt/haier

# Standardowe narzedzia APT i pip wypisuja komunikaty we wlasnym jezyku.
# Instalator pokazuje polskie podsumowanie; szczegoly sa w pliku dziennika.
DZIENNIK="${HAIERPI_DZIENNIK:-/var/log/haierpi-installer.log}"
umask 077
mkdir -p "$(dirname -- "$DZIENNIK")"
touch "$DZIENNIK"
wykonaj_z_logiem() {
  local opis="$1"
  shift
  log "$opis - trwa..."
  if "$@" >> "$DZIENNIK" 2>&1; then
    log "$opis - zakończono pomyślnie."
  else
    fail "$opis nie powiodło się. Szczegóły: $DZIENNIK"
  fi
}

fail() { printf 'BŁĄD: %s\n' "$*" >&2; exit 1; }
log() { printf '\n[Instalator HaierPi] %s\n' "$*"; }

[[ $EUID -eq 0 ]] || fail 'Uruchom jako root: sudo bash install.sh nanopi LUB sudo bash install.sh rpi'
[[ "$BOARD" == nanopi || "$BOARD" == rpi ]] || fail 'Wybierz płytkę: nanopi lub rpi'
[[ -f "$ROOT_DIR/app/main.py" && -f "$ROOT_DIR/requirements-pinned.txt" ]] || fail 'Niekompletna paczka instalacyjna'
[[ -f /etc/os-release ]] || fail 'Nie znaleziono systemu Debian/DietPi'
# shellcheck disable=SC1091
source /etc/os-release
[[ "${ID:-}" == debian || " ${ID_LIKE:-} " == *' debian '* ]] || fail 'Obsługiwane są tylko Debian i DietPi'
[[ "$BOARD" == nanopi ]] && model='NanoPi NEO' || model='Raspberry Pi Zero / Zero 2'
log "Wybrany profil sprzętowy: $model"

# Outdoor sensor choice is a NanoPi NEO-only feature in this installer.
# Raspberry Pi keeps its v2 defaults and does not touch 1-Wire overlays.
if [[ "$BOARD" == nanopi ]]; then
  OUTSIDE_SOURCE="${HAIERPI_OUTSIDE_SOURCE:-}"
  if [[ -z "$OUTSIDE_SOURCE" ]]; then
    [[ -r /dev/tty ]] || fail 'Wymagany terminal interaktywny. W trybie automatycznym ustaw HAIERPI_OUTSIDE_SOURCE=ha albo ds18b20.'
    printf '\nSkąd NanoPi NEO ma odczytywać temperaturę zewnętrzną?\n' > /dev/tty
    printf '  1) Fizyczny czujnik DS18B20 (1-Wire, PA6)\n' > /dev/tty
    printf '  2) Home Assistant (encja temperatury)\n' > /dev/tty
    while true; do
      read -r -p 'Wybór [1/2]: ' answer < /dev/tty || fail 'Nie podano odpowiedzi.'
      case "$answer" in
        1) OUTSIDE_SOURCE=ds18b20; break ;;
        2) OUTSIDE_SOURCE=ha; break ;;
        *) printf 'Wpisz 1 albo 2.\n' > /dev/tty ;;
      esac
    done
  fi
  [[ "$OUTSIDE_SOURCE" == ha || "$OUTSIDE_SOURCE" == ds18b20 ]] || fail 'Zmienna HAIERPI_OUTSIDE_SOURCE musi mieć wartość ha lub ds18b20.'
  log "NanoPi: źródło temperatury zewnętrznej: $OUTSIDE_SOURCE"
else
  [[ -z "${HAIERPI_OUTSIDE_SOURCE:-}" ]] || fail 'HAIERPI_OUTSIDE_SOURCE dotyczy wyłącznie NanoPi, nie Raspberry Pi.'
  OUTSIDE_SOURCE=ha
  log 'Raspberry Pi: pozostawiono odczyt temperatury z HA; bez zmian 1-Wire.'
fi
ROOT_FS="$(findmnt -n -o FSTYPE / || true)"
ROOT_OPTS="$(findmnt -n -o OPTIONS / || true)"
[[ "$ROOT_FS" != overlay ]] || fail 'System główny korzysta z nakładki RAM; zapisane zmiany mogą zniknąć po restarcie'
[[ ",$ROOT_OPTS," == *,rw,* ]] || fail 'System plików jest tylko do odczytu'
if [[ -f /opt/haier/main.py ]]; then
  fail 'HaierPi jest już zainstalowany. W menu wybierz opcję 5 przed czystą instalacją.'
fi
FREE_KB="$(df -Pk /opt | awk 'NR==2 {print $4}')"
[[ "$FREE_KB" =~ ^[0-9]+$ ]] || fail 'Nie można sprawdzić wolnego miejsca w /opt'
(( FREE_KB >= 800000 )) || fail 'Wymagane jest przynajmniej 800 MB wolnego miejsca w /opt. Powiększ partycję karty microSD.'

log 'Sprawdzam repozytoria APT; archiwum Bullseye zostanie użyte tylko w razie potrzeby'
export DEBIAN_FRONTEND=noninteractive
bash "$ROOT_DIR/scripts/repair-bullseye-apt.sh"
log 'Instaluję Pythona i pakiety systemowe przez APT'
wykonaj_z_logiem 'Odświeżenie listy pakietów' apt-get update
wykonaj_z_logiem 'Instalacja pakietów systemowych' apt-get install -y --no-install-recommends python3 python3-venv python3-pip python3-dev build-essential curl git ca-certificates p7zip-full
PY_VERSION="$(python3 -c 'import sys; print(sys.version_info.major * 100 + sys.version_info.minor)')"
if (( PY_VERSION < 309 || PY_VERSION > 311 )); then
  fail 'Zestaw zależności Alpha13 wymaga Pythona 3.9-3.11; wykryta wersja nie była testowana.'
fi
log 'Kopiuję pliki HaierPi i tworzę odrębne środowisko Python'
install -d -m 755 "$APP_DIR"
cp -a "$ROOT_DIR/app/main.py" "$ROOT_DIR/app/static" "$ROOT_DIR/app/templates" "$ROOT_DIR/app/HPi" "$ROOT_DIR/app/PyHaier" "$ROOT_DIR/app/tests" "$ROOT_DIR/app/README_HARMONOGRAM_TEMPERATURY.md" "$APP_DIR/"
python3 -m venv "$APP_DIR/env"
# Some DietPi images mount /tmp in RAM; use disk-backed /var/tmp for pip builds.
export TMPDIR=/var/tmp PIP_NO_CACHE_DIR=1
wykonaj_z_logiem 'Instalacja bibliotek Python (pip)' "$APP_DIR/env/bin/python" -m pip install --disable-pip-version-check -r "$ROOT_DIR/requirements-pinned.txt"

log 'Sprawdzam dostępność bibliotek Python'
(cd "$APP_DIR" && "$APP_DIR/env/bin/python" - <<'PY'
import flask, werkzeug, flask_babel, flask_socketio
import jinja2, requests, serial, socketio, PyHaier
import paho.mqtt.client, schedule, termcolor, waitress
import w1thermsensor, HPi.GPIO
from pymodbus.client.sync import ModbusSerialClient
from flask_simplelogin import SimpleLogin
from flask import Markup
print('Test bibliotek Pythona: poprawny')
PY
)
log 'Przygotowuję konfigurację i konto administratora HaierPi'
"$APP_DIR/env/bin/python" "$ROOT_DIR/scripts/configure.py" "$BOARD" "$OUTSIDE_SOURCE"
install -m 644 "$ROOT_DIR/systemd/haier.service" /etc/systemd/system/haier.service
systemctl daemon-reload
install -m 755 "$ROOT_DIR/enable-haierpi.sh" /usr/local/sbin/haierpi-wlacz
systemctl disable --now haier.service 2>/dev/null || true
if [[ "${HAIERPI_AUTO_UART:-1}" == 1 ]]; then
  log 'Przygotowuję ustawienia UART (bez restartu)'
  if bash "$ROOT_DIR/scripts/configure-uart.sh" "$BOARD"; then
    log 'Zmieniono ustawienia UART. Przed uruchomieniem HaierPi wykonaj restart urządzenia.'
  else
    log 'UWAGA: nie udało się skonfigurować UART. Wykonaj kroki z README_PL.md.'
  fi
else
  log 'HAIERPI_AUTO_UART=0: pozostawiono ustawienia UART bez zmian.'
fi
if [[ "$BOARD" == nanopi ]]; then
  if [[ "$OUTSIDE_SOURCE" == ds18b20 ]]; then
    log 'NanoPi NEO: włączam 1-Wire PA6 dla DS18B20 (wymagany restart)'
    bash "$ROOT_DIR/scripts/configure-onewire-nanopi.sh" || \
      fail 'Nie udało się włączyć nakładki DS18B20. Usługa pozostaje wyłączona.'
  else
    log 'NanoPi NEO: wybrano Home Assistant; bez zmian 1-Wire.'
    log 'Przed startem HaierPi uzupełnij [HOMEASSISTANT] HAADDR/HAPORT/KEY/outsidesensor w /opt/config.ini.'
  fi
else
  log 'Raspberry Pi: pominięto opcjonalną konfigurację temperatury i 1-Wire.'
fi
log 'Instalacja zakończona. Usługa HaierPi celowo nie została uruchomiona.'

printf 'Dalej: sprawdź /opt/config.ini i połączenia GPIO, wykonaj restart, a następnie uruchom: haierpi-wlacz\n'
