#!/usr/bin/env bash
# Wlacza uruchamianie HaierPi podczas startu systemu, ale nie uruchamia uslugi od razu.
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'BŁĄD: wymagane uprawnienia administratora.' >&2; exit 1; }
[[ -f /opt/haier/main.py && -f /opt/config.ini && -f /etc/systemd/system/haier.service ]] || {
    echo 'BŁĄD: instalacja HaierPi nie jest kompletna. Autostart pozostał wyłączony.' >&2
    exit 1
}
if [[ ! -r /dev/tty ]]; then
    echo 'Brak terminala: autostart nie został włączony. Po sprawdzeniu sprzętu użyj: systemctl enable haier.service'
    exit 0
fi
printf '\nAutostart HaierPi przy każdym uruchomieniu DietPi\n' > /dev/tty
printf 'UWAGA: po restarcie HaierPi może sterować pompą i przekaźnikami.\n' > /dev/tty
printf 'Włącz autostart tylko po sprawdzeniu połączeń GPIO i konfiguracji urządzenia.\n' > /dev/tty
while true; do
    read -r -p 'Czy włączyć automatyczne uruchamianie HaierPi po restarcie? [T/N]: ' ODPOWIEDZ < /dev/tty || ODPOWIEDZ=N
    case "${ODPOWIEDZ^^}" in
        T)
            if ! systemctl enable haier.service; then
                echo 'BŁĄD: nie udało się włączyć autostartu HaierPi.' >&2
                exit 1
            fi
            if [[ "$(systemctl is-enabled haier.service)" != enabled ]]; then
                echo 'BŁĄD: autostart nie został potwierdzony przez systemd.' >&2
                exit 1
            fi
            printf 'Autostart HaierPi: WŁĄCZONY. Usługa uruchomi się dopiero po restarcie.\n' > /dev/tty
            exit 0
            ;;
        N|'')
            printf 'Autostart HaierPi: WYŁĄCZONY. Możesz go później włączyć: systemctl enable haier.service\n' > /dev/tty
            exit 0
            ;;
        *) printf 'Wpisz T (tak) albo N (nie).\n' > /dev/tty ;;
    esac
done
