"""
HaierPi 1.4.5_alpha
creator: J.B, 'jacekb' on Haier hetpump Discord chanel
co-creator's: K.O 'kamil.ost' and D.M 'kocur' and T.U 'ur6an' on Haier hetpump Discord channel
"""

# --- Importy: standard library ---
import base64
import collections
import configparser
from datetime import datetime
import io
import json
import logging
import math
import os
import pickle
import signal
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
from itertools import islice

# --- Importy: biblioteki zewnętrzne ---
import jinja2
import requests
import serial
import socketio
import PyHaier
import paho.mqtt.client as mqtt
from flask import Flask, flash, jsonify, redirect, render_template, request, session, send_file, url_for, Markup, Response
from flask_babel import Babel, gettext
from flask_simplelogin import SimpleLogin, get_username, is_logged_in, login_required
from flask_socketio import SocketIO, emit
from pymodbus.client.sync import ModbusSerialClient
from schedule import cancel_job, clear, every, get_jobs, run_pending
from termcolor import colored
from waitress import serve
from w1thermsensor import W1ThermSensor
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

# --- Importy: sprzęt / GPIO (RaspberryPi / HPi) ---
import HPi.GPIO as GPIO

# --- Sekcja: Globalne zmienne i konfiguracja ---
services = []
event = threading.Event()

# --- MQTT runtime control (start/stop without restart) ---
mqtt_lock = threading.Lock()
mqtt_stop_event = threading.Event()

# --- MQTT snapshot publish (optional periodic full-state push) ---
# 0 => disabled. If enabled, HaierPi republishes *all* MQTT state topics from statusdict
# every mqtt_snapshot_interval_s seconds (retained), regardless of ischanged().
mqtt_snapshot_interval_s = 0
_mqtt_snapshot_last_ts = 0.0




def mqtt_current_config():
    """Return effective MQTT config snapshot (used to detect changes)."""
    def _s(v, default=''):
        try:
            return str(v if v is not None else default).strip()
        except Exception:
            return str(default)

    return {
        'enabled': _s(globals().get('use_mqtt', '0'), '0'),
        'address': _s(globals().get('mqtt_broker_addr', ''), ''),
        'port': _s(globals().get('mqtt_broker_port', ''), ''),
        'ssl': _s(globals().get('mqtt_ssl', '0'), '0'),
        'topic': _s(globals().get('mqtt_topic', ''), ''),
        'username': _s(globals().get('mqtt_username', ''), ''),
        'password': _s(globals().get('mqtt_password', ''), ''),
        'ha_discovery': _s(globals().get('ha_mqtt_discovery', '0'), '0'),
        'ha_discovery_prefix': _s(globals().get('ha_mqtt_discovery_prefix', ''), ''),
    }


def mqtt_is_running() -> bool:
    try:
        t = globals().get('mqtt_bg')
        return bool(t and t.is_alive())
    except Exception:
        return False


def mqtt_stop(reason: str = '') -> None:
    """Stop MQTT thread + disconnect client (best-effort)."""
    global services
    with mqtt_lock:
        try:
            mqtt_stop_event.set()
        except Exception:
            pass

        cl = globals().get('client', None)
        if cl is not None:
            # Try graceful offline signal
            try:
                _t = str(getattr(cl, '_client_id', b'').decode())
                if _t:
                    cl.publish(_t + "/haierpi/connected", "offline", qos=1, retain=True)
            except Exception:
                pass
            try:
                cl.disconnect()
            except Exception:
                pass

        # Remove from publish list immediately (so queue_pub stops sending)
        try:
            if cl in services:
                services = [x for x in services if x is not cl]
        except Exception:
            pass

        # Wait a moment for the worker to exit
        t = None
        try:
            t = globals().get('mqtt_bg', None)
            if t and t.is_alive():
                t.join(timeout=2.0)
        except Exception:
            pass

        # Only clear mqtt_bg reference once the thread is actually dead.
        # (Prevents accidental restart while the old thread is still running.)
        try:
            if not (t and t.is_alive()):
                globals()['mqtt_bg'] = None
        except Exception:
            pass

        # Clear global client immediately so publishing paths stop using it.
        # (The worker thread keeps its own local reference.)
        try:
            globals()['client'] = None
        except Exception:
            pass

    if reason:
        logging.info("MQTT stopped (%s)", reason)
    else:
        logging.info("MQTT stopped")


def mqtt_start(reason: str = '') -> None:
    """Start MQTT thread if enabled in config."""
    global services

    with mqtt_lock:
        if str(globals().get('use_mqtt', '0')) != '1':
            return
        if mqtt_is_running():
            return

        mqtt_stop_event.clear()

        try:
            cl = mqtt.Client(str(mqtt_topic))
        except Exception:
            # paho-mqtt older versions
            cl = mqtt.Client(mqtt_topic)

        # Configure callbacks
        cl.on_connect = on_connect
        cl.on_message = on_message
        cl.on_disconnect = on_disconnect

        # LWT + credentials + TLS
        try:
            cl.will_set(str(mqtt_topic) + "/haierpi/connected", "offline", qos=1, retain=True)
        except Exception:
            pass
        try:
            if str(mqtt_ssl) == '1':
                cl.tls_set(tls_version=mqtt.ssl.PROTOCOL_TLS)
        except Exception:
            pass
        try:
            cl.username_pw_set(str(mqtt_username), str(mqtt_password))
        except Exception:
            pass
        try:
            cl.reconnect_delay_set(min_delay=1, max_delay=30)
        except Exception:
            pass

        # Expose globally (publishing uses globals().get('client') and services list)
        globals()['client'] = cl
        try:
            if cl not in services:
                services.append(cl)
        except Exception:
            services = [cl]

        mqtt_bg = threading.Thread(target=connect_mqtt, daemon=True)
        globals()['mqtt_bg'] = mqtt_bg
        mqtt_bg.start()

    if reason:
        logging.info("MQTT started (%s)", reason)
    else:
        logging.info("MQTT started")


def mqtt_sync(prev_cfg: dict = None, reason: str = '') -> None:
    """Ensure MQTT runtime matches current config.

    - If MQTT disabled -> stop
    - If enabled and config changed (address/port/ssl/topic/user/pass/discovery) -> restart
    - If enabled and not running -> start
    """
    try:
        cur = mqtt_current_config()
    except Exception:
        cur = {}

    enabled = str(cur.get('enabled', '0')) == '1'

    if not enabled:
        if mqtt_is_running() or globals().get('client', None) is not None:
            mqtt_stop(reason=reason or 'config')
        return

    # Enabled:
    if not mqtt_is_running() or globals().get('client', None) is None:
        mqtt_start(reason=reason or 'config')
        return

    # Check whether we need a restart
    if prev_cfg is None:
        return

    keys = ['address', 'port', 'ssl', 'topic', 'username', 'password', 'ha_discovery', 'ha_discovery_prefix']
    changed = any(str(prev_cfg.get(k, '')) != str(cur.get(k, '')) for k in keys)
    if changed:
        mqtt_stop(reason=reason or 'reconfigure')
        mqtt_start(reason=reason or 'reconfigure')

# --- Service tests (Pump/Heater) ---
service_set_pump_until_ts = 0.0
service_set_heater_until_ts = 0.0
service_pump_forced_by_heater = False
# --- DHW on-demand (skip DHW schedule for one heating cycle) ---
DHW_ONDEMAND_MAX_SEC = int(os.getenv("DHW_ONDEMAND_MAX_SEC", "14400"))  # 4h safety timeout
DHW_ONDEMAND_MIN_DELTA = float(os.getenv("DHW_ONDEMAND_MIN_DELTA", "3.5"))  # °C required delta (setpoint - tank)
dhw_ondemand_active = False
dhw_ondemand_seen_dhw = False
dhw_ondemand_started_ts = 0.0
dhw_ondemand_lock = threading.Lock()


#NOWE Opóźnienie wyłączenia heatdemand w sekundach
HEATDEMAND_OFF_DELAY_S = int(os.getenv("HEATDEMAND_OFF_DELAY_S", "30"))
heatdemand_hi_since = None

version="1.4.5_alpha"
ip_address=subprocess.run(['hostname', '-I'], check=True, capture_output=True, text=True).stdout.strip()
welcome="\n┌────────────────────────────────────────┐\n│              "+colored("!!!Warning!!!", "red", attrs=['bold','blink'])+colored("             │\n│      This script is experimental       │\n│                                        │\n│ Products are provided strictly 'as-is' │\n│ without any other warranty or guaranty │\n│              of any kind.              │\n└────────────────────────────────────────┘\n","yellow", attrs=['bold'])

# --- Ograniczanie częstotliwości aktualizacji ramek (throttling) ---
# Minimalny odstęp czasu między przetworzeniami ramek (dla każdego typu bloku rejestrów).
UPDATE_INTERVAL_SEC = 1.0
# Minimalny odstęp czasu między dopisywaniem punktów do wykresów (żeby nie zasypywać UI/HA).
CHART_INTERVAL_SEC = 1.0
# Znaczniki czasu ostatniego przetworzenia (klucz = liczba rejestrów w ramce).
_last_block_ts = {6: 0.0, 16: 0.0, 1: 0.0, 22: 0.0}
# Znacznik czasu ostatniego dopisania punktów do wykresów.
_last_chart_ts = 0.0

config = configparser.ConfigParser()
config.read('config.ini.repo')
config.read('/opt/config.ini')
log_level_info = {'DEBUG': logging.DEBUG, 
                    'INFO': logging.INFO,
                    'WARNING': logging.WARNING,
                    'ERROR': logging.ERROR,
                    }


class _DowngradeWerkzeugInfoToDebugFilter(logging.Filter):
    """Downgrade noisy Werkzeug request INFO logs to DEBUG.

    Goal: keep INFO logs clean (ischanged + errors), while still allowing
    request traces when loglevel is DEBUG.
    """
    def filter(self, record: logging.LogRecord) -> bool:
        if record.name.startswith('werkzeug') and record.levelno == logging.INFO:
            record.levelno = logging.DEBUG
            record.levelname = 'DEBUG'
        return True


def apply_log_level(level: int) -> None:
    """Apply runtime log level & keep noisy request logs out of INFO."""
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Werkzeug emits HTTP request logs at INFO by default.
    # - When global level is DEBUG, allow them (they'll be downgraded to DEBUG by the filter).
    # - Otherwise suppress them entirely.
    wz_logger = logging.getLogger('werkzeug')
    wz_logger.setLevel(logging.DEBUG if level <= logging.DEBUG else logging.WARNING)

    # Install filter (idempotent)
    for lg in (root_logger, wz_logger):
        if not any(isinstance(f, _DowngradeWerkzeugInfoToDebugFilter) for f in lg.filters):
            lg.addFilter(_DowngradeWerkzeugInfoToDebugFilter())

# --- Sekcja: Integracja z portalem HaierPi (opcjonalnie) ---
SERVER_URL = "https://app.haierpi.pl"
TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoyfQ.uNzcoMkLSOONHZAOeEWI1l2KEAnzeh0DuADajOrWfUw'
sio_remote = socketio.Client(reconnection=True, reconnection_delay=1, reconnection_delay_max=10)
#, logger=True, engineio_logger=True)

custom_headers = {
    "User-Agent": "HaierPi/1.4"
}
remote=False
# Send initial 'snapshot' to remote server on connect.
# Disabled by default to avoid overwriting transient values (e.g. delta) right after start.
remote_snapshot_on_connect = False
@sio_remote.event
def connect():
    global remote
    remote = True
    logging.info("Connected to remote server")
    sio_remote.emit("connect_device", {"token": hpikey})

    if remote_snapshot_on_connect:
        _emit_remote_snapshot()
    else:
        logging.info("Remote snapshot on connect: disabled")

@sio_remote.event
def disconnect():
    global remote
    remote = False
    logging.warning("Disconnected from server!")
@sio_remote.event
def connect_error(data):
    global remote
    remote = False
    logging.error(f"Connection failed: {data}")
def _emit_remote_snapshot(delay_s: float = 0.8):
    """Send an initial state snapshot to the remote server after connection.

    Some UI fields (e.g. flrelay/flimiton) may never change during a session, so
    they won't be delivered by ischanged() unless we push an initial snapshot.
    This snapshot is remote-only and does not affect the local UI logic.
    """
    def _do():
        try:
            if not getattr(sio_remote, "connected", False):
                return
            snap = {}

            # GPIO-derived states. Send as strings so JS frontends won't treat 0 as "falsy/missing".
            try:
                snap["flimiton"] = str(GPIO.input(freqlimitpin))
                snap["flrelay"] = snap["flimiton"]
            except Exception:
                pass

            try:
                snap["heatdemand"] = str(GPIO.input(heatdemandpin))
                snap["cooldemand"] = str(GPIO.input(cooldemandpin))
            except Exception:
                pass

            # Config-derived states
            try:
                snap["flimit"] = str(config["SETTINGS"].get("flimit", "auto")).strip().lower()
                snap["flimittemp"] = str(config["SETTINGS"].get("flimittemp", flimittemp)).strip()
            except Exception:
                pass

            if snap:
                for _k, _v in snap.items():
                    sio_remote.emit("data_from_device", {"data_update": {_k: _v}})
                logging.info("Remote snapshot sent: %s", ", ".join(sorted(snap.keys())))
        except Exception:
            logging.exception("Remote snapshot failed")

    try:
        threading.Timer(float(delay_s), _do).start()
    except Exception:
        _do()


def normalize_zone_mode(val, default):
    """Normalize zone mode setting to one of: turbo, eco, quiet, quiet_flimit."""
    v = str(val).strip().lower()
    if v in ('quiet_only', 'quietonly'):
        return 'quiet'
    if v in ('quiet+flimit', 'quiet flimit', 'quietflimit', 'quiet-flimit', 'quiet_flimit', 'quiet_flimit (aoo)', 'quietflimit (aoo)'):
        return 'quiet_flimit'
    if v in ('turbo', 'eco', 'quiet'):
        return v
    return default

def loadconfig():
    global grestarted
    grestarted = 1
    logging.info("Loading new config.ini")
    global loglevel
    # log level (config.ini: [MAIN] log_level=...), default INFO
    try:
        loglevel = config.get('MAIN', 'log_level', fallback='INFO').strip().upper()
    except Exception:
        loglevel = 'INFO'
    if loglevel not in log_level_info:
        loglevel = 'INFO'
    # Apply immediately (so changes via settings take effect without restart)
    apply_log_level(log_level_info.get(loglevel, logging.INFO))
    global ui_font
    try:
        _f = str(config.get('MAIN', 'ui_font', fallback='inter')).strip().lower()
    except Exception:
        _f = 'inter'
    if _f not in ('inter', 'roboto', 'system'):
        _f = 'inter'
    ui_font = _f
    global timeout
    timeout = config['MAIN']['heizfreq']
    global firstrun
    firstrun = config['MAIN']['firstrun']
    global bindaddr
    bindaddr = config['MAIN']['bindaddress']
    global bindport
    bindport = config['MAIN']['bindport']
    global modbusdev
    modbusdev = config['MAIN']['modbusdev']
    global release
    release = config['MAIN']['release']
    global expert_mode
    expert_mode = config['MAIN']['expert_mode']
    global settemp
    settemp = config['SETTINGS']['settemp']
    global slope
    slope = config['SETTINGS']['hcslope']
    global pshift
    pshift = config['SETTINGS']['hcpshift']
    global hcamp
    hcamp = config['SETTINGS']['hcamp']
    global heatingcurve
    heatingcurve = config['SETTINGS']['heatingcurve']

    global heatingcurve_last
    heatingcurve_last = str(config['SETTINGS'].get('heatingcurve_last', 'auto')).strip().lower()
    if heatingcurve_last not in ('auto', 'static', 'manual'):
        heatingcurve_last = 'auto'

    _hc_norm = str(heatingcurve).strip().lower()
    # Keep heatingcurve_last in sync when we are in curve mode
    if _hc_norm in ('auto', 'static', 'manual'):
        heatingcurve_last = _hc_norm

    global heatcontrol
    heatcontrol = 'direct' if _hc_norm == 'directly' else 'curve'

    global heatingcurve_mode
    heatingcurve_mode = heatingcurve_last if _hc_norm == 'directly' else _hc_norm
    if heatingcurve_mode not in ('auto', 'static', 'manual'):
        heatingcurve_mode = 'auto'
    # Global thermostat gating (curve + direct): [SETTINGS] thermostat_on=0/1
    global thermostat_on

    _ton_raw = config['SETTINGS'].get('thermostat_on', None)

    # Migration: ensure thermostat_on exists and remove legacy direct_thermostat
    config_changed = False
    if _ton_raw is None:
        # Backward compat: old direct_thermostat existed only for Direct mode
        if _hc_norm == 'directly':
            _ton_raw = config['SETTINGS'].get('direct_thermostat', '0')
        else:
            _ton_raw = '1'
        config['SETTINGS']['thermostat_on'] = str(_ton_raw).strip()
        config_changed = True

    if config.has_option('SETTINGS', 'direct_thermostat'):
        try:
            config.remove_option('SETTINGS', 'direct_thermostat')
        except Exception:
            try:
                del config['SETTINGS']['direct_thermostat']
            except Exception:
                pass
        config_changed = True

    thermostat_on = '1' if str(_ton_raw).strip() == '1' else '0'

    if config_changed:
        try:
            with open('/opt/config.ini', 'w') as configfile:
                config.write(configfile)
            logging.info('Config migrated: removed direct_thermostat (use thermostat_on)')
        except Exception:
            logging.exception('Config migration write failed')

    # Target inside temperature used only when thermostat_on=1 in Direct mode
    global direct_inside_settemp
    _dis = str(config['SETTINGS'].get('direct_inside_settemp', '21.0')).strip().replace(',', '.')
    try:
        direct_inside_settemp = float(_dis)
    except Exception:
        direct_inside_settemp = 21.0
    
    global insidetemp
    insidetemp = config['SETTINGS']['insidetemp']
    global outsidetemp
    outsidetemp = config['SETTINGS']['outsidetemp']
    global dhwtemp
    dhwtemp = config['SETTINGS']['dhwtemp']
    global emergency_intemp
    emergency_intemp = config['SETTINGS'].get('emergency_intemp', '20.0')
    global omlat
    omlat = config['SETTINGS']['omlat']
    global omlon
    omlon = config['SETTINGS']['omlon']
    global humidity
    humidity = config['SETTINGS']['humidity']
    global flimit
    flimit = config['SETTINGS']['flimit']
    global flimittemp
    flimittemp = config['SETTINGS']['flimittemp']
    global presetautochange
    presetautochange = config['SETTINGS']['presetautochange']
    global presetquiet
    presetquiet = config['SETTINGS']['presetquiet']
    global presetturbo
    presetturbo = config['SETTINGS']['presetturbo']
    # publish config-related states to MQTT (for HA discovery sensors/switches)
    try:
        _pairs = [
            ('flimit', flimit),
            ('flimittemp', flimittemp),
            ('presetautochange', presetautochange),
            ('presetquiet', presetquiet),
            ('presetturbo', presetturbo),
            ('thermostat_on', thermostat_on),
            ('direct_inside_settemp', direct_inside_settemp),
        ]
        # Keep statusdict in sync (safe if statusdict/queue_pub not ready yet)
        for _k, _v in _pairs:
            try:
                if 'statusdict' in globals() and isinstance(statusdict.get(_k, None), dict):
                    statusdict[_k]['value'] = _v
            except Exception:
                pass
            try:
                if 'queue_pub' in globals():
                    queue_pub(_k, _v)
            except Exception:
                pass
    except Exception:
        pass

    global antionoff
    antionoff = config['SETTINGS']['antionoff']
    global antionoffdelta
    antionoffdelta = config['SETTINGS']['antionoffdeltatime']
    global chscheduler
    chscheduler = config['SETTINGS']['chscheduler']
    global dhwscheduler
    dhwscheduler = config['SETTINGS']['dhwscheduler']
    # Keep DHW on-demand state across config reloads (saving settings must not cancel an ongoing one-shot DHW cycle).
    global dhw_ondemand_active, dhw_ondemand_seen_dhw, dhw_ondemand_started_ts
    global dhwwl
    dhwwl = config['SETTINGS']['dhwwl']
    global dhwnolimit_mode
    dhwnolimit_mode = config['SETTINGS'].get('dhwnolimit_mode', 'turbo')
    global dhwuse
    dhwuse = config['SETTINGS'].get('dhwuse', '1')

    # --- DHW heater assist + Anti-legionella (electric heater) ---
    # Stored in config.ini: [SETTINGS]
    #   dhw_heater_assist_enable=0/1
    #   dhw_heater_assist_below_temp=<float>   # OUTTEMP threshold (REQUIRED when enabled)
    #   anti_legionella_enable=0/1  (master enable/disable feature)
    #   anti_legionella_temp=<float>
    def _cfg_float_setting_dhw(key: str, default: str) -> str:
        try:
            raw = str(config['SETTINGS'].get(key, default))
        except Exception:
            raw = str(default)
        raw = raw.strip().replace(',', '.')
        if raw == '':
            return str(default).strip().replace(',', '.')
        try:
            float(raw)
        except Exception:
            raw = str(default).strip().replace(',', '.')
        return raw

    def _cfg_float_setting_dhw_required(key: str) -> str:
        # Return '' if blank/invalid, otherwise validated float string.
        try:
            raw = str(config['SETTINGS'].get(key, '')).strip().replace(',', '.')
        except Exception:
            raw = ''
        if raw == '':
            return ''
        try:
            float(raw)
            return raw
        except Exception:
            return ''

    global dhw_heater_assist_enable
    dhw_heater_assist_enable = '1' if str(config['SETTINGS'].get('dhw_heater_assist_enable', '0')).strip() == '1' else '0'

    global dhw_heater_assist_below_temp
    # OUTTEMP threshold is REQUIRED when heater assist is enabled
    dhw_heater_assist_below_temp = _cfg_float_setting_dhw_required('dhw_heater_assist_below_temp')

    # Warn once on config reload if heater assist enabled but outtemp threshold missing
    try:
        if dhw_heater_assist_enable == '1' and str(dhw_heater_assist_below_temp).strip() == '':
            logging.warning('DHW heater assist enabled but dhw_heater_assist_below_temp is empty/invalid; heater assist will NOT start until configured')
    except Exception:
        pass

    global anti_legionella_enable
    anti_legionella_enable = '1' if str(config['SETTINGS'].get('anti_legionella_enable', '0')).strip() == '1' else '0'

    # Run/abort request is a runtime switch (NOT stored in config.ini, does not require Save)
    # Keep it across loadconfig() so saving other settings does not abort an ongoing cycle.
    global anti_legionella_run
    if 'anti_legionella_run' not in globals():
        anti_legionella_run = '0'

    global anti_legionella_temp
    anti_legionella_temp = _cfg_float_setting_dhw('anti_legionella_temp', '60.0')

    # publish heater assist + anti-legionella settings to MQTT (for HA discovery)
    try:
        _pairs = [
            ('dhw_heater_assist_enable', dhw_heater_assist_enable),
            ('dhw_heater_assist_below_temp', dhw_heater_assist_below_temp),
            ('anti_legionella_enable', anti_legionella_enable),
            ('anti_legionella_run', globals().get('anti_legionella_run', '0')),
            ('anti_legionella_temp', anti_legionella_temp),
        ]
        for _k, _v in _pairs:
            try:
                if 'statusdict' in globals() and isinstance(statusdict.get(_k, None), dict):
                    statusdict[_k]['value'] = _v
            except Exception:
                pass
            try:
                if 'queue_pub' in globals():
                    queue_pub(_k, _v)
            except Exception:
                pass
    except Exception:
        pass

   
    global kwhnowcorr 
    kwhnowcorr = config['SETTINGS']['kwhnowcorr']
    global lohysteresis
    lohysteresis = str(config['SETTINGS'].get('lohysteresis', '0.0')).strip().replace(',', '.')
    if lohysteresis == '':
        lohysteresis = '0.0'
    global hihysteresis
    hihysteresis = str(config['SETTINGS'].get('hihysteresis', '0.1')).strip().replace(',', '.')
    if hihysteresis == '':
        hihysteresis = '0.1'
    global hcman
    hcman = config['SETTINGS']['hcman'].split(',')
    global hpiatstart
    hpiatstart = config['HPIAPP']['hpiatstart']
    global hpikey
    hpikey = config['HPIAPP']['hpikey']
    global remote_snapshot_on_connect
    try:
        _rs = config.get('HPIAPP', 'remote_snapshot_on_connect', fallback='0')
    except Exception:
        _rs = '0'
    remote_snapshot_on_connect = str(_rs).strip().lower() in ('1','true','yes','on')
    global use_mqtt
    use_mqtt = config['MQTT']['mqtt']
    global mqtt_broker_addr
    mqtt_broker_addr=config['MQTT']['address']
    global mqtt_broker_port
    mqtt_broker_port=config['MQTT']['port']
    global mqtt_ssl
    mqtt_ssl=config['MQTT']['mqtt_ssl']
    global mqtt_topic
    mqtt_topic=config['MQTT']['main_topic']
    global mqtt_username
    mqtt_username=config['MQTT']['username']
    global mqtt_password
    mqtt_password=config['MQTT']['password']

    # Optional periodic MQTT snapshot publish (republish all state topics every N seconds)
    global mqtt_snapshot_interval_s
    try:
        mqtt_snapshot_interval_s = int(float(config['MQTT'].get('snapshot_interval_s', '0')))
    except Exception:
        mqtt_snapshot_interval_s = 0
    mqtt_snapshot_interval_s = max(0, min(3600, mqtt_snapshot_interval_s))

    global modbuspin
    modbuspin=config['GPIO']['modbus']
    global freqlimitpin
    freqlimitpin=config['GPIO']['freqlimit']
    global heatdemandpin
    heatdemandpin=config['GPIO']['heatdemand']
    global cooldemandpin
    cooldemandpin=config['GPIO']['cooldemand']
    global haaddr
    haaddr = config['HOMEASSISTANT']['HAADDR']
    global haport
    haport = config['HOMEASSISTANT']['HAPORT']
    global hakey
    hakey = config['HOMEASSISTANT']['KEY']
    global insidesensor
    insidesensor = config['HOMEASSISTANT']['insidesensor']
    global outsidesensor
    outsidesensor = config['HOMEASSISTANT']['outsidesensor']
    global humiditysensor
    humiditysensor = config['HOMEASSISTANT']['humiditysensor']
    global dhwsensor
    dhwsensor = config['HOMEASSISTANT']['dhwsensor']
    global ha_mqtt_discovery
    ha_mqtt_discovery=config['HOMEASSISTANT']['ha_mqtt_discovery']
    global ha_mqtt_discovery_prefix
    ha_mqtt_discovery_prefix = config['HOMEASSISTANT']['ha_mqtt_discovery_prefix']
    # Normalize discovery prefix (HA default is 'homeassistant')
    try:
        ha_mqtt_discovery_prefix = (str(ha_mqtt_discovery_prefix or 'homeassistant').strip() or 'homeassistant')
    except Exception:
        ha_mqtt_discovery_prefix = 'homeassistant'
    ha_mqtt_discovery_prefix = ha_mqtt_discovery_prefix.strip('/')

    global antionoffdeltatime
    antionoffdeltatime = config['SETTINGS']['antionoffdeltatime']
    global deltatempturbo
    deltatempturbo = config['SETTINGS']['deltatempturbo']
    global deltatempquiet
    deltatempquiet = config['SETTINGS']['deltatempquiet']
    global deltatempflimit
    deltatempflimit = config['SETTINGS']['deltatempflimit']

    # NOWE --- Strefy temperatur: Mrozu i Ciepła / Temperature zones: Frost and Warm---
    global zone_frost_enable
    zone_frost_enable = config['SETTINGS'].get('zone_frost_enable', '0')
    global zone_frost_temp
    zone_frost_temp = config['SETTINGS'].get('zone_frost_temp', '-99')
    global zone_frost_mode
    zone_frost_mode = normalize_zone_mode(config['SETTINGS'].get('zone_frost_mode', 'turbo'), 'turbo')

    global zone_warm_enable
    zone_warm_enable = config['SETTINGS'].get('zone_warm_enable', '0')
    global zone_warm_temp
    zone_warm_temp = config['SETTINGS'].get('zone_warm_temp', '99')

    # Warm zone behavior: user chooses one of:
    #   - turbo / eco / quiet
    #   - quiet_flimit (Quiet + FLimit)
    global zone_warm_mode
    zone_warm_mode = normalize_zone_mode(config['SETTINGS'].get('zone_warm_mode', 'quiet_flimit'), 'quiet_flimit')
    try:
        queue_pub('zone_frost_enable', zone_frost_enable)
        queue_pub('zone_frost_temp', zone_frost_temp)
        queue_pub('zone_frost_mode', zone_frost_mode)
        queue_pub('zone_warm_enable', zone_warm_enable)
        queue_pub('zone_warm_temp', zone_warm_temp)
        queue_pub('zone_warm_mode', zone_warm_mode)
    except Exception:
        pass

    # --- Custom antifreeze (circulation pump) ---
    # UI is prepared (settings + tooltip). Here we only load values from config and publish them.
    def _cfg_float_setting(key: str, default: str) -> str:
        """Read float-like setting from config.

        Important: configparser returns an empty string when the key exists but is blank.
        We treat blanks/invalid values as the provided default.
        """
        try:
            raw = str(config['SETTINGS'].get(key, default))
        except Exception:
            raw = str(default)
        raw = raw.strip().replace(',', '.')
        if raw == '':
            raw = str(default).strip().replace(',', '.')
        try:
            float(raw)
        except Exception:
            raw = str(default).strip().replace(',', '.')
        return raw

    global antifreeze_custom_enable
    antifreeze_custom_enable = '1' if str(config['SETTINGS'].get('antifreeze_custom_enable', '0')).strip() == '1' else '0'

    global antifreeze_custom_outtemp
    antifreeze_custom_outtemp = _cfg_float_setting('antifreeze_custom_outtemp', '0.0')

    global antifreeze_custom_twi
    antifreeze_custom_twi = _cfg_float_setting('antifreeze_custom_twi', '0.0')

    global antifreeze_custom_two
    antifreeze_custom_two = _cfg_float_setting('antifreeze_custom_two', '0.0')

    global antifreeze_custom_runtime_min
    antifreeze_custom_runtime_min = _cfg_float_setting('antifreeze_custom_runtime_min', '1.0')

    try:
        queue_pub('antifreeze_custom_enable', antifreeze_custom_enable)
        queue_pub('antifreeze_custom_outtemp', antifreeze_custom_outtemp)
        queue_pub('antifreeze_custom_twi', antifreeze_custom_twi)
        queue_pub('antifreeze_custom_two', antifreeze_custom_two)
        queue_pub('antifreeze_custom_runtime_min', antifreeze_custom_runtime_min)
    except Exception:
        pass


loadconfig()


# Create the stop event early so worker threads can safely reference it
def hpiapp(function='status'):
    global remote
    if function == 'status':
        if hpiatstart == '1':
            if not sio_remote.connected:
                try:
                    logging.info("Trying to reconnect...")
                    sio_remote.connect(SERVER_URL, headers=custom_headers, wait_timeout=10)
                except Exception as e:
                    logging.error(f"Reconnect failed: {e}")
            else:
                try:
                    sio_remote.emit("heartbeat", {"token": TOKEN})
                except Exception as e:
                    logging.warning(f"Emit failed: {e}")
        remote = bool(getattr(sio_remote, 'connected', False))

        status=sio_remote.sid
        ischanged('hpiconn', status)
    if function == 'disconnect':
        sio_remote.disconnect()
        remote = False
        status=sio_remote.connected
    if function == 'connect':
        try:
            sio_remote.connect(SERVER_URL,  headers=custom_headers, wait_timeout=10)
            status=sio_remote.connected
            remote = bool(status)
        except socketio.exceptions.ConnectionError as e:
            socketlocal.emit('return', {'info': e.args[0], 'status': 'danger'})
            logging.error(f"SERVER NIEDOSTEPNY: {e}")
            status=False
            remote = False

    socketlocal.emit('settings', {'hpiconn': status})
    return status

if hpiatstart == '1':
    try:
        sio_remote.connect(SERVER_URL,  headers=custom_headers, wait_timeout=10)
#        hpiapp('connect')
        remote=True
    except socketio.exceptions.ConnectionError as e:
        remote=False
        logging.error(type(e))
        logging.error(f"SERVER NIEDOSTEPNY: {e}")

newframe=[]
writed=""
needrestart=0
dead=0

# --- HPI Status/heartbeat for UI (service health) ---
last_pump_rx_ts = 0.0          # time.time() of last valid Modbus frame from pump
last_pump_rx_block = ""        # e.g. "R101", "R141", "R201", "R241"
last_pump_rx_len = 0           # register count in last frame
last_pump_error = ""           # last exception from ReadPump (if any)

datechart=collections.deque(8640*[''], 8640)
tankchart=collections.deque(8640*[''], 8640)
twichart=collections.deque(8640*[''], 8640)
twochart=collections.deque(8640*[''], 8640)
tdchart=collections.deque(8640*[''], 8640)
tschart=collections.deque(8640*[''], 8640)
thichart=collections.deque(8640*[''], 8640)
thochart=collections.deque(8640*[''], 8640)
taochart=collections.deque(8640*[''], 8640)
pdsetchart=collections.deque(8640*[''], 8640)
pdactchart=collections.deque(8640*[''], 8640)
pssetchart=collections.deque(8640*[''], 8640)
psactchart=collections.deque(8640*[''], 8640)
eevlevelchart=collections.deque(8640*[''], 8640)
fan1chart=collections.deque(8640*[''], 8640)
fan2chart=collections.deque(8640*[''], 8640)
tsatpdsetchart=collections.deque(8640*[''], 8640)
tsatpdactchart=collections.deque(8640*[''], 8640)
tsatpssetchart=collections.deque(8640*[''], 8640)
tsatpsactchart=collections.deque(8640*[''], 8640)
superheatchart=collections.deque(8640*[''], 8640)
subcoolingchart=collections.deque(8640*[''], 8640)
tdefchart=collections.deque(8640*[''], 8640)
defrostchart=collections.deque(8640*[0], 8640)
antifreezechart=collections.deque(8640*[0], 8640)
heaterchart=collections.deque(8640*[160], 8640)
intempchart=collections.deque(8640*[''], 8640)
outtempchart=collections.deque(8640*[''], 8640)
humidchart=collections.deque(8640*[''], 8640)
hcurvechart=collections.deque(8640*[''], 8640)
fsetchart=collections.deque(8640*[''], 8640)
factchart=collections.deque(8640*[''], 8640)
flimitonchart=collections.deque(8640*[''], 8640)
modechart_quiet = collections.deque(8640*[0], 8640)
modechart_eco = collections.deque(8640*[0], 8640)
modechart_turbo = collections.deque(8640*[0], 8640)
threewaychart = collections.deque(8640*[''], 8640)
try:
    with open('charts.pkl', 'rb') as f:
        _charts_data = pickle.load(f)

    if isinstance(_charts_data, (list, tuple)):
        # charts.pkl stores a list of deques; the list grew over time as new chart series were added.
        _charts_layouts = {
            37: ['datechart', 'tankchart', 'twichart', 'twochart', 'tdchart', 'tschart', 'thichart', 'thochart', 'taochart', 'pdsetchart', 'pdactchart', 'pssetchart', 'psactchart', 'eevlevelchart', 'fan1chart', 'fan2chart', 'tsatpdsetchart', 'tsatpdactchart', 'tsatpssetchart', 'tsatpsactchart', 'intempchart', 'outtempchart', 'humidchart', 'hcurvechart', 'fsetchart', 'factchart', 'flimitonchart', 'modechart_quiet', 'modechart_eco', 'modechart_turbo', 'threewaychart', 'superheatchart', 'subcoolingchart', 'tdefchart', 'defrostchart', 'antifreezechart', 'heaterchart'],
        }
        _layout = _charts_layouts.get(len(_charts_data))
        if _layout is None:
            raise ValueError(f"Unsupported charts.pkl format (len={len(_charts_data)})")
        for _name, _value in zip(_layout, _charts_data):
            globals()[_name] = _value
    elif isinstance(_charts_data, dict):
        # Future-proof format: charts stored as dict {name: deque/sequence}.
        # Keep all series as deques with maxlen=8640 and length=8640 (left-padded with defaults).
        _chart_names = [
            'datechart', 'tankchart', 'twichart', 'twochart', 'tdchart', 'tschart',
            'thichart', 'thochart', 'taochart',
            'pdsetchart', 'pdactchart', 'pssetchart', 'psactchart',
            'eevlevelchart', 'fan1chart', 'fan2chart',
            'tsatpdsetchart', 'tsatpdactchart', 'tsatpssetchart', 'tsatpsactchart',
            'superheatchart', 'subcoolingchart',
            'tdefchart', 'defrostchart', 'antifreezechart', 'heaterchart',
            'intempchart', 'outtempchart', 'humidchart', 'hcurvechart',
            'fsetchart', 'factchart', 'flimitonchart',
            'modechart_quiet', 'modechart_eco', 'modechart_turbo',
            'threewaychart',
        ]

        for _name in _chart_names:
            try:
                _val = _charts_data.get(_name)
                if _val is None:
                    continue

                if isinstance(_val, collections.deque):
                    _seq = list(_val)
                elif isinstance(_val, (list, tuple)):
                    _seq = list(_val)
                else:
                    continue

                _default = globals().get(_name)
                if not isinstance(_default, collections.deque):
                    continue

                # Ensure we always have exactly 8640 points.
                if len(_seq) >= 8640:
                    _seq = _seq[-8640:]
                else:
                    _pad = list(_default)[: (8640 - len(_seq))]
                    _seq = _pad + _seq

                globals()[_name] = collections.deque(_seq, maxlen=8640)
            except Exception:
                # Keep the pre-initialized default series if anything goes wrong
                continue
    else:
        raise ValueError(f"Unsupported charts.pkl type: {type(_charts_data)}")
except Exception:
    logging.info("Cannot load charts pickle")

modbus =  ModbusSerialClient(method = "rtu", port=modbusdev,stopbits=1, bytesize=8, parity='E', baudrate=9600)
ser = serial.Serial(port=modbusdev, baudrate = 9600, parity=serial.PARITY_EVEN,stopbits=serial.STOPBITS_ONE,bytesize=serial.EIGHTBITS,timeout=1)

# --- Sekcja: Flask / API / UI ---
app = Flask(__name__)


@app.context_processor
def inject_ui_font():
    """Inject ui_font into all templates (base.html reads it)."""
    return {'ui_font': globals().get('ui_font', 'inter')}


def _json_response(payload: dict, *, pretty_default: bool = False):
    """Return JSON response; supports ?pretty=1 for human-readable formatting."""
    try:
        q = request.args.get('pretty', '')
    except Exception:
        q = ''
    pretty = pretty_default or str(q).strip().lower() in ('1', 'true', 'yes', 'on')
    if pretty:
        return app.response_class(
            response=json.dumps(payload, indent=2, ensure_ascii=False),
            mimetype='application/json'
        )
    return jsonify(payload)

babel = Babel()
UPLOAD_FOLDER = '/opt/haier'
ALLOWED_EXTENSIONS = {'hpi'}
app.config['SECRET_KEY'] = '2bb80d537b1da3e38bd30361aa855686bde0eacd7162fef6a25fe97bf527a25b'
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
socketlocal = SocketIO(app, compression=True)

@app.before_request
def make_session_permanent():
    session.permanent = True
set_log_level = log_level_info.get(loglevel, logging.INFO)
apply_log_level(set_log_level)

GPIO.setup(modbuspin, GPIO.OUT) #modbus
GPIO.setup(freqlimitpin, GPIO.OUT) #freq limit
GPIO.setup(heatdemandpin, GPIO.OUT) # heat demand
GPIO.setup(cooldemandpin, GPIO.OUT) # cool demand

# --- Service test runtime (minutes) for MQTT/HA discovery ---
try:
    _service_test_duration_s = int(float(config['SETTINGS'].get('service_test_duration_s', 60)))
except Exception:
    _service_test_duration_s = 60
_service_test_duration_s = max(30, min(240 * 60, _service_test_duration_s))
_service_test_runtime_min = round(_service_test_duration_s / 60.0, 2)

#SŁOWNIK
statusdict={
'intemp':{'mqtt':'/sensores/intemp/state','value':'N.A.'},
'outtemp':{'mqtt':'/sensores/outtemp/state','value':'N.A.'},
'intemp_status':{'mqtt':'/sensores/intemp/status/state','value':'ok'},
'outtemp_status':{'mqtt':'/sensores/outtemp/status/state','value':'ok'},
'intempsrc':{'mqtt':'/sensores/intemp/src/state','value':'N.A.'},
'outtempsrc':{'mqtt':'/sensores/outtemp/src/state','value':'N.A.'},
'intempage':{'mqtt':'/sensores/intemp/age/state','value':'0'},
'outtempage':{'mqtt':'/sensores/outtemp/age/state','value':'0'},
'intemptime':{'mqtt':'/sensores/intemp/time/state','value':'0'},
'outtemptime':{'mqtt':'/sensores/outtemp/time/state','value':'0'},
'tempzone':{'mqtt':'/ch/zones/active/state','value':'normal'},
'settemp':{'mqtt':'/ch/target_temp/state','value':settemp},
'hcurve':{'mqtt':'/ch/heatingcurve/state','value':'N.A.'},
'tempcompensation':{'mqtt':'/service/temp_compenstations/ch/state','value':'N.A.'},
'tempcompensation_set':{'mqtt':'/service/temp_compenstations/ch/set/state','value':'N.A.'},
'dhwcompensation':{'mqtt':'/service/temp_compenstations/dhw/state','value':'N.A.'},
'dhwcompensation_set':{'mqtt':'/service/temp_compenstations/dhw/set/state','value':'N.A.'},
'heatcontrol':{'mqtt':'/ch/heatcontrol/state','value':('direct' if str(heatingcurve).strip().lower()=='directly' else 'curve')},
'heatingcurve_mode':{'mqtt':'/ch/heatingcurve_mode/state','value':(heatingcurve_last if str(heatingcurve).strip().lower()=='directly' else str(heatingcurve).strip().lower())},
'dhw':{'mqtt':'/dhw/target_temp/state','value':'N.A.'},
'tank':{'mqtt':'/dhw/tank_temp/state','value':'N.A.'},
'dhw_heater_assist_enable':{'mqtt':'/dhw/heater_assist/enabled/state','value':globals().get('dhw_heater_assist_enable','0')},
'dhw_heater_assist_below_temp':{'mqtt':'/dhw/heater_assist/outtemp_thr/state','value':globals().get('dhw_heater_assist_below_temp','')},
'dhw_heater_assist_active':{'mqtt':'/dhw/heater_assist/active/state','value':'off'},
'anti_legionella_enable':{'mqtt':'/dhw/anti_legionella/enabled/state','value':globals().get('anti_legionella_enable','0')},
'anti_legionella_run':{'mqtt':'/dhw/anti_legionella/run/state','value':globals().get('anti_legionella_run','0')},
'anti_legionella_temp':{'mqtt':'/dhw/anti_legionella/temp/state','value':globals().get('anti_legionella_temp','60.0')},
'anti_legionella_active':{'mqtt':'/dhw/anti_legionella/active/state','value':'off'},
'mode':{'mqtt':'/ch/preset/state','value':'N.A.'},
'humid':{'mqtt':'/sensores/humid/state','value':'N.A.'},
'pch':{'mqtt':'/ch/pch/state','value':'off'},
'pdhw':{'mqtt':'/dhw/pdhw/state','value':'off'},
'ch_heating':{'mqtt':'/ch/heating/state','value':'off'},
'dhw_heating':{'mqtt':'/dhw/heating/state','value':'off'},
'ch_cooling':{'mqtt':'/ch/cooling/state','value':'off'},
'dhw_ondemand':{'mqtt':'/dhw/ondemand/state','value':'off'},
'pcool':{'mqtt':'/ch/pcool/state','value':'off'},
'defrost':{'mqtt':'/haierunit/statuses/defrost/state','value':'off'},
'heater':{'mqtt':'/haierunit/statuses/heater/state','value':'off'},
'service_set_pump':{'mqtt':'/service/tests/pump/state','value':'off'},
'service_set_heater':{'mqtt':'/service/tests/heater/state','value':'off'},
'service_test_runtime_min':{'mqtt':'/service/tests/runtime_min/state','value':_service_test_runtime_min},
'antifreeze':{'mqtt':'/haierunit/statuses/antifreeze/state','value':'off'},
'antifreeze_custom':{'mqtt':'/ch/custom-antifreeze/active/state','value':'off'},
'antifreeze_custom_enable':{'mqtt':'/ch/custom-antifreeze/enabled/state','value':(globals().get('antifreeze_custom_enable', '0'))},
'antifreeze_custom_outtemp':{'mqtt':'/ch/custom-antifreeze/outtemp_thr/state','value':(globals().get('antifreeze_custom_outtemp', '0.0'))},
'antifreeze_custom_twi':{'mqtt':'/ch/custom-antifreeze/twi_thr/state','value':(globals().get('antifreeze_custom_twi', '0.0'))},
'antifreeze_custom_two':{'mqtt':'/ch/custom-antifreeze/two_thr/state','value':(globals().get('antifreeze_custom_two', '0.0'))},
'antifreeze_custom_runtime_min':{'mqtt':'/ch/custom-antifreeze/runtime_min/state','value':(globals().get('antifreeze_custom_runtime_min', '1.0'))},
'tdef':{'mqtt':'/haierunit/temperatures/tdef/state','value':'N.A.'},
'theme':{'mqtt':'0','value':'light'},
'tdts':{'mqtt':'/haierunit/temperatures/tdts/state','value':'N.A.'},
'archerror':{'mqtt':'/service/errors/arch/state','value':'N.A.'},
'error':{'mqtt':'/service/errors/error/state','value':'N.A'},
'lasterror':{'mqtt':'/service/errors/last/state','value':'N.A'},
'compinfo':{'mqtt':'/haierunit/compressor/info/state','value':'N.A.'},
'fans':{'mqtt':'/haierunit/fans/state','value':'N.A.'},
'tao':{'mqtt':'/haierunit/temperatures/tao/state','value':'N.A.'},
'twitwo':{'mqtt':'/haierunit/temperatures/twitwo/state','value':'N.A.'},
'thitho':{'mqtt':'/haierunit/temperatures/thitho/state','value':'N.A.'},
'pump':{'mqtt':'/haierunit/pump/state','value':'N.A.'},
'pdps':{'mqtt':'/haierunit/pressures/pdps/state','value':'N.A.'},
'eevlevel': {'mqtt':'/haierunit/eev/state', 'value':'N.A.'},
'tsatpd': {'mqtt':'/haierunit/temperatures/tsatpd/state', 'value':'N.A.'},
'tsatps': {'mqtt':'/haierunit/temperatures/tsatps/state', 'value':'N.A.'},
'superheat': {'mqtt':'/haierunit/temperatures/superheat/state', 'value':'N.A.'},
'subcooling': {'mqtt':'/haierunit/temperatures/subcooling/state', 'value':'N.A.'},
'firmware': {'mqtt':'/haierunit/statuses/firmware/state', 'value':'N.A.'},
'threeway':{'mqtt':'/haierunit/threeway/state','value':'N.A.'},
'chkwhpd':{'mqtt':'/haierunit/compressor/ch_kwhpd/state','value':'0'},
'dhwkwhpd':{'mqtt':'/haierunit/compressor/dhw_kwhpd/state','value':'0'},
'flimiton':{'mqtt':'/ch/flimit/on/state','value':'0'},
'antionoff':{'mqtt': '/ch/antionoff/state', 'value':'N.A'},
'presetautochange': {'mqtt': '/ch/preset/mode/state', 'value': presetautochange},
'presetquiet': {'mqtt': '/ch/preset/quiet_temp/state', 'value': presetquiet},
'presetturbo': {'mqtt': '/ch/preset/turbo_temp/state', 'value': presetturbo},
'flimit':{'mqtt': '/ch/flimit/mode/state', 'value': flimit},
'flimittemp': {'mqtt': '/ch/flimit/temp/state', 'value': flimittemp},
'thermostat_on': {'mqtt': '/ch/thermostat/enabled/state', 'value': thermostat_on},
'direct_inside_settemp': {'mqtt': '/ch/thermostat/target_temp/state', 'value': direct_inside_settemp},
'zone_frost_enable': {'mqtt': '/ch/zones/frost/enabled/state', 'value': zone_frost_enable},
'zone_frost_temp': {'mqtt': '/ch/zones/frost/temp/state', 'value': zone_frost_temp},
'zone_frost_mode': {'mqtt': '/ch/zones/frost/mode/state', 'value': zone_frost_mode},
'zone_warm_enable': {'mqtt': '/ch/zones/warm/enabled/state', 'value': zone_warm_enable},
'zone_warm_temp': {'mqtt': '/ch/zones/warm/temp/state', 'value': zone_warm_temp},
'zone_warm_mode': {'mqtt': '/ch/zones/warm/mode/state', 'value': zone_warm_mode},
'delta':{'mqtt':'/ch/antionoff/delta/state','value':'N.A.'},
'hpiconn':{'mqtt':'/service/statuses/hpiconn/state', 'value':'N.A.'},
'heatdemand':{'mqtt':'/ch/heatdemand/state','value':'N.A.'},
'cooldemand':{'mqtt':'/ch/cooldemand/state','value':'N.A.'},
'flrelay':{'mqtt':'/ch/flimit/relay/state','value':'N.A'},
'antionoffdeltatime':{'mqtt':'/ch/antionoff/delta_time/state','value':'N.A.'},
'deltatempflimit':{'mqtt':'/ch/antionoff/delta_temp_flimit/state','value':'N.A.'},
'deltatempquiet':{'mqtt':'/ch/antionoff/delta_temp_quiet/state','value':'N.A.'},
'deltatempturbo': {'mqtt':'/ch/antionoff/delta_temp_turbo/state', 'value':'N.A.'}
}
R101=[0,0,0,0,0,0]
R141=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
R201=[0]
R241=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
twocheck=[0,0]
last_check_time = 0
last_mode_active_ts = 0

# Track previous heatingcurve mode (for Direct sync)
last_heatingcurve_mode = None
# Zapamiętujemy zadaną (wewnątrz) sprzed wejścia w Direct, aby ją przywrócić po wyjściu
saved_settemp_before_direct = None


thermostat_on = '1'  # 0/1 global thermostat gating (curve + direct); 0 => always heatdemand ON
direct_inside_settemp = 21.0  # used when thermostat_on=1 in Direct mode (inside target)
# Track DHWWL temporary overrides (restore after DHW)
_dhwwl_active = False
_dhwwl_prev_mode = None
_dhwwl_prev_flimiton = None

# Debounce restore CH preset after DHW exit
DHWWL_RESTORE_DELAY_S = 30
_dhwwl_exit_since = None

# Zone tracking (for logging / avoiding redundant actions)
_current_zone = None

# TempZone: restore FLimit relay state after leaving a zone that forced Quiet+FLimit
_tz_forcing_flimit = False
_tz_prev_flimiton = None

# --- Custom antifreeze (circulation pump) runtime state ---
antifreeze_custom_active = False
antifreeze_custom_started_ts = 0.0
antifreeze_custom_min_end_ts = 0.0  # earliest time we are allowed to release pump
antifreeze_custom_request_stop = False  # set when disabled while running
antifreeze_custom_rearm_required = False  # prevent immediate re-trigger until conditions clear



# --- DHW electric heater features runtime state ---
# 1) "DHW heater assist": when outtemp is below threshold AND DHW heating is active (PDHW=ON),
#    turn on the electric heater as support after a short delay (pump/valve have time to start).
# 2) Anti-legionella: one-shot DHW cycle to a higher temperature, using PDHW + heater assist.
DHW_HEATER_ASSIST_DELAY_SEC = 10
ANTI_LEGIONELLA_DELAY_SEC = 10
ANTI_LEGIONELLA_MAX_SEC = 3 * 60 * 60

# Heater assist state
_dhw_assist_prev_pdhw = 'off'
dhw_heater_assist_active = False
_dhw_assist_started_ts = 0.0
_dhw_assist_forced_heater = False

# Anti-legionella state
anti_legionella_active = False
anti_legionella_started_ts = 0.0
anti_legionella_prev_pdhw = None
anti_legionella_prev_dhw_sp = None
anti_legionella_heater_started_ts = 0.0
anti_legionella_forced_heater = False


def _as_float(x):
    try:
        return float(x)
    except Exception:
        return None

def _as_int(x):
    try:
        return int(float(x))
    except Exception:
        return None

# --- Derived status: CH/DHW heating activity (matches dashboard fire icons) ---
_heating_activity_tls = threading.local()

def _parse_comp_hz(compinfo):
    """Return compressor frequency (Hz) from compinfo (list/tuple/JSON-string)."""
    try:
        if compinfo in (None, "", "N.A.", "na"):
            return 0.0
        if isinstance(compinfo, (list, tuple)) and len(compinfo) > 0:
            return float(compinfo[0] or 0.0)
        if isinstance(compinfo, str):
            s = compinfo.strip()
            if s.startswith('[') and s.endswith(']'):
                arr = json.loads(s)
                if isinstance(arr, list) and arr:
                    return float(arr[0] or 0.0)
            # fallback: single number string
            return float(s)
    except Exception:
        pass
    return 0.0

def _hvac_mode_from_threeway(tw_raw: str):
    """Map 3-way valve state to 'CH' / 'DHW' / None."""
    try:
        tw = str(tw_raw or '').strip().upper()
    except Exception:
        return None
    if not tw:
        return None
    if 'ERR' in tw:
        return None
    if 'DHW' in tw or 'CWU' in tw:
        return 'DHW'
    if 'CH' in tw or 'CO' in tw:
        return 'CH'
    return None

def update_heating_activity():
    """Update derived CH/DHW activity states (matches dashboard icons).

    Publishes to MQTT (retained):
      - ch_heating: on/off  (actual CH heating)
      - dhw_heating: on/off (actual DHW heating)
      - ch_cooling: on/off  (actual CH cooling)
    """
    if getattr(_heating_activity_tls, 'busy', False):
        return
    _heating_activity_tls.busy = True
    try:
        # Defrost => not heating/cooling CH/DHW (even if compressor runs)
        defrost_state = str(statusdict.get('defrost', {}).get('value', 'off')).strip().lower()
        if defrost_state == 'on':
            ch_heating = False
            dhw_heating = False
            ch_cooling = False
        else:
            tw = statusdict.get('threeway', {}).get('value', '')
            mode = _hvac_mode_from_threeway(tw)
            hz = _parse_comp_hz(statusdict.get('compinfo', {}).get('value', []))
            running = (hz > 0.0)

            pch = str(statusdict.get('pch', {}).get('value', 'off')).strip().lower()
            pdhw = str(statusdict.get('pdhw', {}).get('value', 'off')).strip().lower()
            pcool = str(statusdict.get('pcool', {}).get('value', 'off')).strip().lower()

            # Demand flags: for heating we require heatdemand=1 to avoid "blink" during switchover.
            hd = statusdict.get('heatdemand', {}).get('value', 0)
            try:
                heatdemand_on = int(str(hd).strip() or '0') == 1
            except Exception:
                heatdemand_on = False

            # Demand flag for cooling
            cd = statusdict.get('cooldemand', {}).get('value', 0)
            try:
                cooldemand_on = int(str(cd).strip() or '0') == 1
            except Exception:
                cooldemand_on = False

            ch_heating = (mode == 'CH') and running and (pch == 'on') and heatdemand_on
            dhw_heating = (mode == 'DHW') and running and (pdhw == 'on')
            # Cooling uses CH hydraulic circuit too.
            ch_cooling = (mode == 'CH') and running and (pcool == 'on') and cooldemand_on

        if 'ch_heating' in statusdict:
            ischanged('ch_heating', 'on' if ch_heating else 'off')
        if 'dhw_heating' in statusdict:
            ischanged('dhw_heating', 'on' if dhw_heating else 'off')
        if 'ch_cooling' in statusdict:
            ischanged('ch_cooling', 'on' if ch_cooling else 'off')
    finally:
        _heating_activity_tls.busy = False

def _get_emergency_intemp_value():
    """Return emergency inside temperature from config (float) or None if invalid.

    Intended as a fail-safe when no inside temperature is available after reboot / HA down.
    """
    try:
        v = float(emergency_intemp)
        if not math.isfinite(v) or math.isnan(v):
            return None
        # sanity range for inside emergency (user configurable but clamp to safe limits)
        if not (5.0 <= v <= 35.0):
            return None
        return round(v, 1)
    except Exception:
        return None

# Temperature status tracking (fallback + outdated detection)
#
# Goal:
# - Prefer configured source (DS18B20 / DHT22 / Home Assistant)
# - If missing -> use last good value for up to 30 minutes
# - If still missing -> for outtemp switch to Tao
# - Expose state to UI via statusdict keys: intemp_status/outtemp_status + src + time (minutes since last change) + age (minutes since last real read)

TEMP_CACHE_MAX_AGE_SEC = 30 * 60 #30 minut domyślnie

_temp_primary = {
    'intemp': {'value': None, 'ts': 0.0, 'src': None},
    'outtemp': {'value': None, 'ts': 0.0, 'src': None},
}

def _set_temp_meta(key, status, src=None, age_sec=None):
    """Update UI/meta fields for a temperature reading.

    status: 'ok' | 'forced' | 'outdated'
    src: string (e.g. 'dht22','ha','ds18b','cache','tao','emergency','missing')

    UI wants to know how long the CURRENT status/source has been active.
    We track that as "time" (minutes since last change of status/src).

    Additionally we expose "age" as minutes since the last real measurement for the
    currently displayed value (when available).
    """
    now = time.time()
    st = _temp_primary.get(key, {})

    # store meta state in _temp_primary under keys: meta_status/meta_src/meta_since
    meta_status = st.get('meta_status')
    meta_src = st.get('meta_src')
    meta_since = float(st.get('meta_since') or 0.0)

    if str(status) != str(meta_status) or str(src) != str(meta_src):
        meta_since = now
        st['meta_status'] = str(status)
        st['meta_src'] = str(src) if src is not None else None
        st['meta_since'] = meta_since

    # Duration since this meta state became active
    active_sec = max(0.0, now - meta_since) if meta_since else 0.0
    active_min = int(active_sec // 60)

    # Age of the currently displayed value (minutes since last real read)
    if age_sec is None:
        age_sec = _get_primary_age(key)
    age_min = None
    try:
        if age_sec is not None:
            age_min = int(max(0.0, float(age_sec)) // 60)
    except Exception:
        age_min = None

    # UI keys
    try:
        ischanged(f"{key}_status", str(status))
    except Exception:
        pass

    if src is not None:
        try:
            ischanged(f"{key}src", str(src))
        except Exception:
            pass

    # "time" = minutes since status/src became active
    try:
        ischanged(f"{key}time", str(active_min))
    except Exception:
        pass

    # "age" = minutes since last measurement (optional; used by MQTT / debugging)
    if age_min is not None:
        try:
            ischanged(f"{key}age", str(age_min))
        except Exception:
            pass

def _update_primary_temp(key, value, src):
    try:
        f = float(value)
        if not math.isfinite(f) or math.isnan(f):
            return False
    except Exception:
        return False
    _temp_primary[key]['value'] = round(f, 1)
    _temp_primary[key]['ts'] = time.time()
    _temp_primary[key]['src'] = src
    _set_temp_meta(key, 'ok', src=src, age_sec=0)
    return True

def _get_primary_age(key):
    ts = float(_temp_primary.get(key, {}).get('ts', 0.0) or 0.0)
    if ts <= 0:
        return None
    return max(0.0, time.time() - ts)

# NOWE - Get temp to Temperature zones
def get_temp_zone(outtemp_value):
    """Return active control zone based on outside temperature.

    Zones:
      - 'frost' if zone_frost_enable and Tzew <= zone_frost_temp
      - 'warm'  if zone_warm_enable  and Tzew >= zone_warm_temp
      - 'normal' otherwise

    Frost has priority over warm if thresholds overlap.
    """
    try:
        if outtemp_value is None:
            return 'normal'
        t = float(outtemp_value)
    except Exception:
        return 'normal'

    try:
        if str(zone_frost_enable) == '1' and isfloat(zone_frost_temp) and t <= float(zone_frost_temp):
            return 'frost'
    except Exception:
        pass

    try:
        if str(zone_warm_enable) == '1' and isfloat(zone_warm_temp) and t >= float(zone_warm_temp):
            return 'warm'
    except Exception:
        pass

    return 'normal'


def _zone_force_quiet_flimit(zone_name: str) -> bool:
    """True when a zone is configured as "Quiet + FLimit" (hard forced).

    Requirement (UI "Quiet + FLimit") for Frost/Warm zones:
      - preset must be Quiet
      - FLimit relay must be forced ON
      - no other automation should toggle FLimit while the zone is active
    """
    try:
        z = str(zone_name or '').strip().lower()
        if z == 'frost':
            return normalize_zone_mode(globals().get('zone_frost_mode', 'turbo'), 'turbo') == 'quiet_flimit'
        if z == 'warm':
            return normalize_zone_mode(globals().get('zone_warm_mode', 'quiet_flimit'), 'quiet_flimit') == 'quiet_flimit'
    except Exception:
        pass
    return False



def _tempzone_flimit_restore_guard(zone_name: str, dhw_active: bool = False) -> None:
    """TempZone FLimit override + restore (only when FLimit setting is AUTO).

    Requirement from field reports:
      - When in Frost/Warm zone and FLimit is set to auto:
          * Quiet+FLimit -> force FLimit relay ON
          * Quiet/Eco/Turbo -> force FLimit relay OFF
        (This must work even when AntiON-OFF is active, because outside-temp automation is then blocked.)

      - After leaving the zone (back to 'normal'), restore previous relay state so other automation
        can continue normally without "stuck" relay.

    Notes:
      - Never toggle during active DHW heating (consistent with DHW FLimit lock philosophy).
    """
    global _tz_forcing_flimit, _tz_prev_flimiton

    if dhw_active:
        return

    try:
        z = str(zone_name or '').strip().lower()
    except Exception:
        z = ''

    # Only act when the user selected FLimit=auto
    try:
        _fl_cfg = str(globals().get('flimit', '')).strip().lower()
    except Exception:
        _fl_cfg = ''

    override_now = (_fl_cfg == 'auto' and z in ('frost', 'warm'))
    desired = None

    if override_now:
        try:
            if z == 'frost':
                _zm = normalize_zone_mode(globals().get('zone_frost_mode', 'turbo'), 'turbo')
            else:
                _zm = normalize_zone_mode(globals().get('zone_warm_mode', 'quiet_flimit'), 'quiet_flimit')
            desired = '1' if _zm == 'quiet_flimit' else '0'
        except Exception:
            desired = '0'

    # Enter override: remember previous relay state
    if override_now and not _tz_forcing_flimit:
        try:
            _tz_prev_flimiton = str(statusdict.get('flimiton', {}).get('value', '0')).strip()
        except Exception:
            _tz_prev_flimiton = '0'
        _tz_forcing_flimit = True
        logging.info(f"TempZone: enter zone override ({z}) -> save flimiton={_tz_prev_flimiton}")

    # While override active: enforce desired state
    if override_now and desired in ('0', '1'):
        try:
            nowv = str(statusdict.get('flimiton', {}).get('value', '0')).strip()
        except Exception:
            nowv = '0'
        if nowv != desired:
            try:
                logging.info(f"TempZone: zone override ({z}) -> set flimiton={desired}")
                flimitchange(desired)
            except Exception:
                logging.exception('TempZone: zone override flimit relay failed')
        return

    # Exit override: restore previous relay state
    if (not override_now) and _tz_forcing_flimit:
        prev = _tz_prev_flimiton if _tz_prev_flimiton in ('0', '1') else '0'
        try:
            nowv = str(statusdict.get('flimiton', {}).get('value', '0')).strip()
        except Exception:
            nowv = '0'
        if nowv != prev:
            logging.info(f"TempZone: exit zone override -> restore flimiton={prev}")
            try:
                flimitchange(prev)
            except Exception:
                logging.exception('TempZone: restore flimit relay failed')
        _tz_prev_flimiton = None
        _tz_forcing_flimit = False


# NOWE - Function to calculate superheating / subcooling
def compute_superheat_subcooling(tdts, tsatps, tsatpd, thitho):
    
    def to_float(v):
        try:
            return float(v)
        except Exception:
            return None

    Ts = to_float(tdts[1]) if isinstance(tdts, (list, tuple)) and len(tdts) > 1 else None
    Thi = to_float(thitho[0]) if isinstance(thitho, (list, tuple)) and len(thitho) > 0 else None
    TsatPs_act = to_float(tsatps[1]) if isinstance(tsatps, (list, tuple)) and len(tsatps) > 1 else None
    TsatPd_act = to_float(tsatpd[1]) if isinstance(tsatpd, (list, tuple)) and len(tsatpd) > 1 else None

    superheat = f"{abs(Ts - TsatPs_act):.1f}" if (Ts is not None and TsatPs_act is not None) else "N.A."
    subcooling = f"{abs(TsatPd_act - Thi):.1f}" if (Thi is not None and TsatPd_act is not None) else "N.A."
    return superheat, subcooling

def get_locale():

     return request.accept_languages.best_match(['en', 'pl'])

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def handler(signum, frame):
    logging.info(str(signum)+" "+str(signal.Signals(signum).name))
    print(colored("\rCtrl-C - Closing... please wait, this can take a while.", 'red', attrs=["bold"]))
    logging.info("writing charts to file")
    
    with open('charts.pkl', 'wb') as f:
        pickle.dump([datechart, tankchart, twichart, twochart, tdchart, tschart, thichart, thochart, taochart, pdsetchart, pdactchart, pssetchart, psactchart, eevlevelchart, fan1chart, fan2chart, tsatpdsetchart, tsatpdactchart, tsatpssetchart, tsatpsactchart, intempchart, outtempchart, humidchart, hcurvechart, fsetchart, factchart, flimitonchart, modechart_quiet, modechart_eco, modechart_turbo, threewaychart, superheatchart, subcoolingchart, tdefchart, defrostchart, antifreezechart, heaterchart], f)

    GPIO.cleanup(modbuspin)
    GPIO.cleanup(freqlimitpin)
    GPIO.cleanup(heatdemandpin)
    GPIO.cleanup(cooldemandpin)
    if use_mqtt == '1':
        # Publish offline + disconnect from all MQTT clients (local + remote if configured)
        for clnt in list(globals().get('services', []) or []):
            try:
                topic = str(clnt._client_id.decode())
                clnt.publish(mqtt_topic + "/haierpi/connected", "offline", qos=1, retain=True)
                clnt.disconnect()
            except Exception:
                pass
    event.set()
    clear()
    sys.exit()

def b2s(value):
    return (value and 'success') or 'error'

def is_raspberrypi():
    try:
        with io.open('/sys/firmware/devicetree/base/model', 'r') as m:
            if 'raspberry pi' in m.read().lower(): return True
    except Exception: pass
    return False

def isfloat(num):
    try:
        float(num)
        return True
    except (ValueError, TypeError):
        return False


def safe_float(num, default=0.0):
    """Convert to float safely (accepts '', None, comma decimals)."""
    try:
        if num is None:
            return float(default)
        raw = str(num).strip().replace(',', '.')
        if raw == '':
            return float(default)
        return float(raw)
    except Exception:
        return float(default)

def check_my_users(user):
    my_users = json.load(open("users.json"))
    if not my_users.get(user["username"]):
        return False
    stored_password = my_users[user["username"]]["password"]
    if check_password_hash(stored_password, user["password"]):
        return True
    return False
simple_login = SimpleLogin(app, login_checker=check_my_users)

def gpiocontrol(control, value):
    if control == "modbus":
        if value == "1":
            GPIO.output(modbuspin, GPIO.HIGH)
        elif value == "0":
            GPIO.output(modbuspin, GPIO.LOW)
    if control == "heatdemand":
        if value == "1":
            GPIO.output(heatdemandpin, GPIO.HIGH)
        if value == "0":
            GPIO.output(heatdemandpin, GPIO.LOW)
    if control == "cooldemand":
        if value == "1":
            GPIO.output(cooldemandpin, GPIO.HIGH)
        if value == "0":
            GPIO.output(cooldemandpin, GPIO.LOW)
    if control == "freqlimit":
        if value == "1":
            GPIO.output(freqlimitpin, GPIO.HIGH)
        if value == "0":
            GPIO.output(freqlimitpin, GPIO.LOW)

def _mqtt_serialize_value(value):
    """Serialize values for MQTT (safe for HA templates).
    Lists/tuples/dicts are encoded as JSON; everything else as str().
    """
    try:
        if isinstance(value, (dict, list, tuple)):
            return json.dumps(value)
    except Exception:
        pass
    try:
        return str(value)
    except Exception:
        return ""

def queue_pub(dtopic, value):
    """Queue/publish value to all MQTT clients.
    Safe to call before MQTT thread finishes init.
    """
    global services
    try:
        sd = statusdict.get(dtopic, None)
        if not isinstance(sd, dict):
            return
        mpath = sd.get('mqtt', None)
        if not mpath or mpath == '0':
            return
    except Exception:
        return

    payload = _mqtt_serialize_value(value)

    try:
        clients = services
    except NameError:
        clients = []
    for clnt in list(clients):
        try:
            topic = str(clnt._client_id.decode() + mpath)
            clnt.publish(topic, payload, qos=1, retain=True)
        except Exception:
            logging.error("MQTT: cannot publish %s", dtopic)




def mqtt_publish_raw(mpath, value, qos=1, retain=True):
    """Publish a raw MQTT topic suffix to all configured MQTT clients.

    Use this for topics that are *not* represented in statusdict (so queue_pub()
    can't be used), e.g. the legacy /mode/state topics.
    """
    payload = _mqtt_serialize_value(value)
    try:
        clients = list(globals().get('services', []) or [])
    except Exception:
        clients = []

    # Fallback for legacy code paths where only 'client' exists.
    if not clients:
        c = globals().get('client', None)
        if c is not None:
            clients = [c]

    for clnt in list(clients):
        try:
            prefix = str(clnt._client_id.decode())
            clnt.publish(prefix + str(mpath), payload, qos=qos, retain=retain)
        except Exception:
            pass



# --- MQTT snapshot publish helpers ---
def mqtt_publish_snapshot():
    """Publish (republish) all MQTT state topics from statusdict.

    This is useful for MQTT subscribers like HA that reconnect and want to be sure
    they have fresh values even if some keys rarely change (ischanged()).
    """
    # Only if MQTT is enabled
    if str(globals().get('use_mqtt', '0')).strip() != '1':
        return
    try:
        clients = list(globals().get('services', []) or [])
    except Exception:
        clients = []
    if not clients:
        return

    try:
        for _k, _sd in statusdict.items():
            if not isinstance(_sd, dict):
                continue
            _mpath = _sd.get('mqtt', None)
            if not _mpath or _mpath == '0':
                continue
            queue_pub(_k, _sd.get('value', ''))
    except Exception:
        logging.exception("MQTT snapshot publish failed")


def mqtt_snapshot_tick():
    """Scheduler tick: publish snapshot every mqtt_snapshot_interval_s seconds (0 disables)."""
    global _mqtt_snapshot_last_ts
    try:
        interval = int(float(globals().get('mqtt_snapshot_interval_s', 0) or 0))
    except Exception:
        interval = 0

    if interval <= 0:
        _mqtt_snapshot_last_ts = 0.0
        return

    interval = max(2, min(3600, interval))
    now = time.time()
    if _mqtt_snapshot_last_ts and (now - _mqtt_snapshot_last_ts) < interval:
        return

    _mqtt_snapshot_last_ts = now
    mqtt_publish_snapshot()


def WritePump(newframe): #rewrited
    logging.info(f"Write pump, new frame: {newframe}")
    def WriteRegisters(count):
        global writed
        if count == 6:
            register = 101
        elif count == 1:
            register = 201
        time.sleep(1)
        modbus.connect()
        for x in range(5):
            time.sleep(1)
            logging.info("MODBUS: write register "+str(register)+", attempt: "+str(x)+" of 5")
            try:
                result=modbus.write_registers(register, newframe[1], unit=17)
                logging.info(f"Modbus write result: {result}")
                time.sleep(0.1)
                result=modbus.read_holding_registers(register, count, unit=17)
                logging.info(f"Newframe[0]: {newframe[0]}")
                logging.info(f"result.registers: {result.registers}")
                # Success criteria:
                # 1) registers changed compared to the snapshot we used as "old" (newframe[0])
                # 2) OR (for R101) the controller is already in the requested state (same low byte)
                #    This avoids pointless retries when we send a redundant mode command
                #    (e.g. OFF -> ON already switches to H/CH and the next 0x86xx does not change R101).
                _changed = (result.registers != newframe[0])
                _already_target = False
                try:
                    if register == 101 and count >= 1 and isinstance(newframe[1], (list, tuple)) and len(newframe[1]) >= 1:
                        _already_target = (int(result.registers[0]) & 0xFF) == (int(newframe[1][0]) & 0xFF)
                    elif register == 201 and count == 1:
                        # For single-register writes we can also accept "already desired".
                        _already_target = (int(result.registers[0]) == int(newframe[1][0]))
                except Exception:
                    _already_target = False

                if _changed or _already_target:
                    if _changed:
                        logging.info("MODBUS: Registers changed (command accepted)")
                    else:
                        logging.info("MODBUS: Target state already present (no change needed)")
                    writed = "1"
                    break
            except:
                logging.info("MODBUS: Writing error, make another try...")
        modbus.close()
        gpiocontrol("modbus","0")
        return True
    logging.info("Writing Modbus Frame: "+str(newframe[1]))
    while True:
        rs = ser.read(1).hex()
        if rs == "032c":
            for ind in range(22):
                ser.read(2).hex()
        gpiocontrol("modbus", "1")
        break;
    if isinstance(newframe[1], (list, tuple, str)) and len(newframe[1]) in [1, 6]:
        try:
            WriteRegisters(len(newframe[1]))
        except:
            gpiocontrol("modbus", "0")
    else:
        logging.info("MODBUS: New frame has wrong length, exit")
        gpiocontrol("modbus", "0")
        return False

def ReadPump():
    global R101
    global R141
    global R201
    global R241
    global newframe
    global last_pump_rx_ts, last_pump_rx_block, last_pump_rx_len, last_pump_error
    T101=[]
    T141=[]
    T201=[]
    T241=[]
    time.sleep(0.2)
    while (1):
        if (ser.isOpen() == False):
            logging.warning(colored("Closed serial connection.", 'red', attrs=["bold"]))
            break
        if event.is_set():
            ser.reset_input_buffer()
            ser.reset_output_buffer()
            ser.close()
            break
        if newframe:
            WritePump(newframe)
            newframe=[]
        try:
            rs = ser.read(1).hex()
            if rs == "11":
                rs = ser.read(2).hex()
                if rs == "030c":
                    T101 = []
                    D101 = []
                    for ind in range(6):
                        rs = ser.read(2).hex()
                        if rs:
                            T101.append(int(rs, 16))
                            m, l = divmod(int(rs, 16), 256)
                            D101.append(m)
                            D101.append(l)
                    R101=T101
                    last_pump_rx_ts = time.time()
                    last_pump_rx_block = "R101"
                    last_pump_rx_len = 6
                    last_pump_error = ""
                    now_ts = time.time()
                    if now_ts - _last_block_ts[6] >= UPDATE_INTERVAL_SEC:
                        _last_block_ts[6] = now_ts
                        threading.Thread(target=GetParametersNEW, args=(R101,), daemon=True).start()
                    logging.debug(D101)
                if rs == "0320":
                    T141 = []
                    D141 = []
                    for ind in range(16):
                        rs = ser.read(2).hex()
                        if rs:
                            T141.append(int(rs, 16))
                            m, l = divmod(int(rs, 16), 256)
                            D141.append(m)
                            D141.append(l)
                    R141=T141
                    last_pump_rx_ts = time.time()
                    last_pump_rx_block = "R141"
                    last_pump_rx_len = 16
                    last_pump_error = ""
                    now_ts = time.time()
                    if now_ts - _last_block_ts[16] >= UPDATE_INTERVAL_SEC:
                        _last_block_ts[16] = now_ts
                        threading.Thread(target=GetParametersNEW, args=(R141,), daemon=True).start()
                    logging.debug(D141)
                if rs == "0302":
                    T201 = []
                    for ind in range(1):
                        rs = ser.read(2).hex()
                        if rs:
                            T201.append(int(rs, 16))
                    logging.debug(R201)
                    R201=T201
                    last_pump_rx_ts = time.time()
                    last_pump_rx_block = "R201"
                    last_pump_rx_len = 1
                    last_pump_error = ""
                    now_ts = time.time()
                    if now_ts - _last_block_ts[1] >= UPDATE_INTERVAL_SEC:
                        _last_block_ts[1] = now_ts
                        threading.Thread(target=GetParametersNEW, args=(R201,), daemon=True).start()
                if rs == "032c":
                    T241 = []
                    D241 = []
                    for ind in range(22):
                        rs = ser.read(2).hex()
                        if rs:
                            T241.append(int(rs, 16))
                            m, l = divmod(int(rs, 16), 256)
                            D241.append(m)
                            D241.append(l)
                    R241=T241
                    last_pump_rx_ts = time.time()
                    last_pump_rx_block = "R241"
                    last_pump_rx_len = 22
                    last_pump_error = ""
                    now_ts = time.time()
                    if now_ts - _last_block_ts[22] >= UPDATE_INTERVAL_SEC:
                        _last_block_ts[22] = now_ts
                        threading.Thread(target=GetParametersNEW, args=(R241,), daemon=True).start()
                    logging.debug(D241)
        except:
            try:
                last_pump_error = traceback.format_exc()
            except Exception:
                last_pump_error = "ReadPump exception"
            logging.error("ERROR ReadPump:")
            logging.error(last_pump_error)
            break

def on_connect(client, userdata, flags, rc):
    topic=str(client._client_id.decode())
    logging.info(colored("MQTT - Connected - "+topic, "green", attrs=['bold']))
    client.subscribe(mqtt_topic + '/#')
    client.publish(mqtt_topic + "/haierpi/connected","online", qos=1, retain=True)


    # Snapshot: publish all known states as retained so HA/UI can read them after reconnect/reboot
    try:
        for _k, _sd in statusdict.items():
            if not isinstance(_sd, dict):
                continue
            _mpath = _sd.get('mqtt', None)
            if not _mpath or _mpath == '0':
                continue
            _val = _sd.get('value', '')
            try:
                client.publish(topic + str(_mpath), _mqtt_serialize_value(_val), qos=1, retain=True)
            except Exception:
                pass
    except Exception:
        pass

    # Home Assistant MQTT discovery subscriptions/config (only for local broker)
    if ha_mqtt_discovery == "1":
        try:
            if getattr(client, "_host", None) != "haierpi.pl":
                client.subscribe(ha_mqtt_discovery_prefix + "/status")
                client.subscribe("hass/status")
                configure_ha_mqtt_discovery()
        except Exception:
            pass


def on_disconnect(client, userdata, rc):  # The callback for when
    logging.warning(colored("Disconnected from MQTT with code: {0}".format(str(rc)), 'red', attrs=['bold']))

def on_message(client, userdata, msg):  # The callback for when a PUBLISH 
    topic = str(client._client_id.decode())

    # Decode payload once
    try:
        payload_raw = msg.payload.decode('utf-8')
    except Exception:
        payload_raw = str(msg.payload)

    def _bool01(raw: str) -> str:
        s = str(raw).strip().lower()
        return "1" if s in ("1", "on", "true", "yes") else "0"

    def _float(raw: str):
        s = str(raw).strip().replace(',', '.')
        try:
            return float(s)
        except Exception:
            return None

    if msg.topic == topic + "/power/set":
        logging.info("New power state from mqtt:")
        client.publish(topic + "/power/state", payload_raw, qos=1, retain=True)

    elif msg.topic == topic + "/ch/preset/set":
        logging.info("New preset mode")
        payload = str(payload_raw).strip().lower()
        presets = ['quiet', 'eco', 'turbo']
        if payload in presets:
            new_presetchange(payload)

    elif msg.topic == topic + "/ch/flimit/relay/set":
        logging.info("Frequency limit relay")
        try:
            flimitchange(payload_raw)
        except Exception:
            logging.exception("MQTT: cannot set flimit relay")

    elif msg.topic == topic + "/ch/mode/set":
        logging.info("New mode")
        newmode = str(payload_raw).strip().lower()
        if newmode == "heat":
            try:
                statechange("pch", "on", "1")
                client.publish(topic + "/ch/mode/state", newmode, qos=1, retain=True)
            except Exception:
                logging.exception("MQTT: cannot set mode=heat")
        elif newmode == "cool":
            try:
                statechange("pcool", "on", "1")
                client.publish(topic + "/ch/mode/state", newmode, qos=1, retain=True)
            except Exception:
                logging.exception("MQTT: cannot set mode=cool")
        elif newmode == "off":
            try:
                statechange("off", "off", "1")
                client.publish(topic + "/ch/mode/state", newmode, qos=1, retain=True)
            except Exception:
                logging.exception("MQTT: cannot set mode=off")
        else:
            logging.error("MQTT: mode unsupported: %s", newmode)
    elif msg.topic == topic + "/ch/pch/set":
        payload = str(payload_raw).strip().lower()
        newval = "on" if payload in ("1", "on", "true", "yes") else "off"
        try:
            statechange("pch", newval, "1")
        except Exception:
            logging.exception("MQTT: cannot set PCH - payload=%r", payload_raw)

    elif msg.topic == topic + "/ch/pcool/set":
        payload = str(payload_raw).strip().lower()
        newval = "on" if payload in ("1", "on", "true", "yes") else "off"
        try:
            statechange("pcool", newval, "1")
        except Exception:
            logging.exception("MQTT: cannot set PCool - payload=%r", payload_raw)

    elif msg.topic == topic + "/dhw/pdhw/set":
        payload = str(payload_raw).strip().lower()
        newval = "on" if payload in ("1", "on", "true", "yes") else "off"
        try:
            statechange("pdhw", newval, "1")
        except Exception:
            logging.exception("MQTT: cannot set PDHW - payload=%r", payload_raw)


    elif msg.topic == topic + "/ch/target_temp/set":
        try:
            v = _float(payload_raw)
            if v is None:
                raise ValueError(f"bad payload: {payload_raw!r}")
            mesg, response = new_tempchange("heat", format(float(v)), "0")
            # Direct: natychmiastowa aktualizacja (żeby UI i pompa reagowały od razu)
            if str(heatingcurve).strip().lower() == 'directly':
                try:
                    curvecalc()
                except Exception:
                    logging.exception("Direct: immediate curvecalc after MQTT tempchange failed")
            if response:
                client.publish(topic + "/ch/target_temp/state", str(float(v)), qos=1, retain=True)
        except Exception:
            logging.exception("MQTT: cannot set CH temperature (payload=%r)", payload_raw)

    elif msg.topic == topic + "/service/temp_compenstations/ch/set":
        try:
            mesg, response = new_tempcompchange(payload_raw)
            if response:
                client.publish(topic + "/service/temp_compenstations/ch/set/state",
                               str(statusdict.get("tempcompensation_set", {}).get("value", "N.A.")),
                               qos=1, retain=True)
        except Exception:
            logging.exception("MQTT: cannot set temp compensation")

    elif msg.topic == topic + "/service/temp_compenstations/dhw/set":
        try:
            mesg, response = new_dhwcompchange(payload_raw)
            if response:
                client.publish(topic + "/service/temp_compenstations/dhw/set/state",
                               str(statusdict.get("dhwcompensation_set", {}).get("value", "N.A.")),
                               qos=1, retain=True)
        except Exception:
            logging.exception("MQTT: cannot set DHW compensation")

    elif msg.topic == topic + "/ch/heatcontrol/set":
        try:
            mesg, response = new_heatcontrol_change(payload_raw)
            if response:
                client.publish(topic + "/ch/heatcontrol/state",
                               str(statusdict.get("heatcontrol", {}).get("value", "N.A.")),
                               qos=1, retain=True)
        except Exception:
            logging.exception("MQTT: cannot set heat control")

    elif msg.topic == topic + "/ch/heatingcurve_mode/set":
        try:
            mesg, response = new_heatingcurve_mode_change(payload_raw)
            if response:
                client.publish(topic + "/ch/heatingcurve_mode/state",
                               str(statusdict.get("heatingcurve_mode", {}).get("value", "N.A.")),
                               qos=1, retain=True)
        except Exception:
            logging.exception("MQTT: cannot set heating curve mode")

    elif msg.topic == topic + "/ch/flimit/mode/set":
        # NOTE: config key is SETTINGS.flimit (legacy), HA entity state is statusdict.flimit
        payload = str(payload_raw).strip().lower()
        if payload in ("auto", "manual"):
            try:
                global flimit
                flimit = payload
                statusdict.setdefault('flimit', {})['value'] = payload
                config['SETTINGS']['flimit'] = payload
                with open('/opt/config.ini', 'w') as configfile:
                    config.write(configfile)
                queue_pub('flimit', payload)
            except Exception:
                logging.exception("MQTT: cannot set flimit")
        else:
            logging.error("MQTT: flimit unsupported: %s", payload)

    elif msg.topic == topic + "/ch/preset/mode/set":
        payload = str(payload_raw).strip().lower()
        if payload in ("auto", "manual"):
            try:
                global presetautochange
                presetautochange = payload
                saveconfig('SETTINGS', 'presetautochange', payload)
                queue_pub('presetautochange', payload)
            except Exception:
                logging.exception("MQTT: cannot set presetautochange")
        else:
            logging.error("MQTT: presetautochange unsupported: %s", payload)

    elif msg.topic == topic + "/ch/flimit/temp/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global flimittemp
                flimittemp = v
                saveconfig('SETTINGS', 'flimittemp', v)
                queue_pub('flimittemp', v)
            except Exception:
                logging.exception("MQTT: cannot set flimittemp")
        else:
            logging.error("MQTT: bad flimittemp payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/preset/quiet_temp/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global presetquiet
                presetquiet = v
                saveconfig('SETTINGS', 'presetquiet', v)
                queue_pub('presetquiet', v)
            except Exception:
                logging.exception("MQTT: cannot set presetquiet")
        else:
            logging.error("MQTT: bad presetquiet payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/preset/turbo_temp/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global presetturbo
                presetturbo = v
                saveconfig('SETTINGS', 'presetturbo', v)
                queue_pub('presetturbo', v)
            except Exception:
                logging.exception("MQTT: cannot set presetturbo")
        else:
            logging.error("MQTT: bad presetturbo payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/thermostat/enabled/set":
        try:
            global thermostat_on
            thermostat_on = _bool01(payload_raw)
            saveconfig('SETTINGS', 'thermostat_on', thermostat_on)
            queue_pub('thermostat_on', thermostat_on)
            # If Direct, apply immediately
            if str(heatingcurve).strip().lower() == 'directly':
                try:
                    curvecalc()
                except Exception:
                    logging.exception("Direct: curvecalc after thermostat_on change failed")
        except Exception:
            logging.exception("MQTT: cannot set thermostat_on")

    elif msg.topic == topic + "/ch/thermostat/target_temp/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global direct_inside_settemp
                direct_inside_settemp = v
                saveconfig('SETTINGS', 'direct_inside_settemp', v)
                queue_pub('direct_inside_settemp', v)
                if str(heatingcurve).strip().lower() == 'directly':
                    try:
                        curvecalc()
                    except Exception:
                        logging.exception("Direct: curvecalc after inside target change failed")
            except Exception:
                logging.exception("MQTT: cannot set direct_inside_settemp")
        else:
            logging.error("MQTT: bad direct_inside_settemp payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/zones/frost/enabled/set":
        try:
            global zone_frost_enable
            zone_frost_enable = _bool01(payload_raw)
            saveconfig('SETTINGS', 'zone_frost_enable', zone_frost_enable)
            queue_pub('zone_frost_enable', zone_frost_enable)
        except Exception:
            logging.exception("MQTT: cannot set zone_frost_enable")

    elif msg.topic == topic + "/ch/zones/frost/temp/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global zone_frost_temp
                zone_frost_temp = v
                saveconfig('SETTINGS', 'zone_frost_temp', v)
                queue_pub('zone_frost_temp', v)
            except Exception:
                logging.exception("MQTT: cannot set zone_frost_temp")
        else:
            logging.error("MQTT: bad zone_frost_temp payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/zones/frost/mode/set":
        try:
            global zone_frost_mode
            zone_frost_mode = normalize_zone_mode(payload_raw, zone_frost_mode)
            saveconfig('SETTINGS', 'zone_frost_mode', zone_frost_mode)
            queue_pub('zone_frost_mode', zone_frost_mode)
        except Exception:
            logging.exception("MQTT: cannot set zone_frost_mode")

    elif msg.topic == topic + "/ch/zones/warm/enabled/set":
        try:
            global zone_warm_enable
            zone_warm_enable = _bool01(payload_raw)
            saveconfig('SETTINGS', 'zone_warm_enable', zone_warm_enable)
            queue_pub('zone_warm_enable', zone_warm_enable)
        except Exception:
            logging.exception("MQTT: cannot set zone_warm_enable")

    elif msg.topic == topic + "/ch/zones/warm/temp/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global zone_warm_temp
                zone_warm_temp = v
                saveconfig('SETTINGS', 'zone_warm_temp', v)
                queue_pub('zone_warm_temp', v)
            except Exception:
                logging.exception("MQTT: cannot set zone_warm_temp")
        else:
            logging.error("MQTT: bad zone_warm_temp payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/zones/warm/mode/set":
        try:
            global zone_warm_mode
            zone_warm_mode = normalize_zone_mode(payload_raw, zone_warm_mode)
            saveconfig('SETTINGS', 'zone_warm_mode', zone_warm_mode)
            queue_pub('zone_warm_mode', zone_warm_mode)
        except Exception:
            logging.exception("MQTT: cannot set zone_warm_mode")

    elif msg.topic == topic + "/ch/custom-antifreeze/enabled/set":
        try:
            global antifreeze_custom_enable
            antifreeze_custom_enable = _bool01(payload_raw)
            saveconfig('SETTINGS', 'antifreeze_custom_enable', antifreeze_custom_enable)
            queue_pub('antifreeze_custom_enable', antifreeze_custom_enable)
        except Exception:
            logging.exception("MQTT: cannot set antifreeze_custom_enable")

    elif msg.topic == topic + "/ch/custom-antifreeze/outtemp_thr/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global antifreeze_custom_outtemp
                antifreeze_custom_outtemp = v
                saveconfig('SETTINGS', 'antifreeze_custom_outtemp', v)
                queue_pub('antifreeze_custom_outtemp', v)
            except Exception:
                logging.exception("MQTT: cannot set antifreeze_custom_outtemp")
        else:
            logging.error("MQTT: bad antifreeze_custom_outtemp payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/custom-antifreeze/twi_thr/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global antifreeze_custom_twi
                antifreeze_custom_twi = v
                saveconfig('SETTINGS', 'antifreeze_custom_twi', v)
                queue_pub('antifreeze_custom_twi', v)
            except Exception:
                logging.exception("MQTT: cannot set antifreeze_custom_twi")
        else:
            logging.error("MQTT: bad antifreeze_custom_twi payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/custom-antifreeze/two_thr/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global antifreeze_custom_two
                antifreeze_custom_two = v
                saveconfig('SETTINGS', 'antifreeze_custom_two', v)
                queue_pub('antifreeze_custom_two', v)
            except Exception:
                logging.exception("MQTT: cannot set antifreeze_custom_two")
        else:
            logging.error("MQTT: bad antifreeze_custom_two payload: %r", payload_raw)

    elif msg.topic == topic + "/ch/custom-antifreeze/runtime_min/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                v = max(0.5, float(v))
                # snap to 0.5 min
                v = round(v * 2.0) / 2.0
                global antifreeze_custom_runtime_min
                antifreeze_custom_runtime_min = v
                saveconfig('SETTINGS', 'antifreeze_custom_runtime_min', v)
                queue_pub('antifreeze_custom_runtime_min', v)
            except Exception:
                logging.exception("MQTT: cannot set antifreeze_custom_runtime_min")
        else:
            logging.error("MQTT: bad antifreeze_custom_runtime_min payload: %r", payload_raw)

    elif msg.topic == topic + "/dhw/mode/set":
        logging.info("New DHW mode")
        payload = str(payload_raw).strip().lower()
        newmode = "on" if payload == "heat" else payload
        try:
            statechange("pdhw", str(newmode), "1")
            client.publish(topic + "/dhw/mode/state", str(payload), qos=1, retain=True)
        except Exception:
            logging.exception("MQTT: cannot change DHW mode - payload=%s", newmode)

    elif msg.topic == topic + "/dhw/target_temp/set":
        logging.info("New DHW temperature")
        try:
            v = _float(payload_raw)
            if v is None:
                raise ValueError(f"bad payload: {payload_raw!r}")
            # allow 0.5°C steps; new_tempchange will normalize anyway
            msg_txt, response = new_tempchange("dhw", str(v), "1")
            if response:
                # publish normalized (0.5°C step)
                v_norm = round(float(v) * 2.0) / 2.0
                client.publish(topic + "/dhw/target_temp/state", f"{v_norm:.1f}", qos=1, retain=True)
        except Exception:
            logging.exception("MQTT: cannot change DHW temperature - payload=%r", payload_raw)



    elif msg.topic == topic + "/dhw/ondemand/set":
        # One-shot DHW heating request (bypass). ON starts; OFF cancels bypass.
        payload = str(payload_raw).strip().lower()
        if payload in ("1", "on", "true", "yes", "start"):
            try:
                dhw_ondemand_start()
            except Exception:
                logging.exception("MQTT: cannot start DHW on-demand")
        else:
            try:
                global dhw_ondemand_active, dhw_ondemand_seen_dhw, dhw_ondemand_started_ts
                with dhw_ondemand_lock:
                    dhw_ondemand_active = False
                    dhw_ondemand_seen_dhw = False
                    dhw_ondemand_started_ts = 0.0
                try:
                    ischanged('dhw_ondemand', 'off')
                except Exception:
                    pass
            except Exception:
                logging.exception("MQTT: cannot stop DHW on-demand")

    elif msg.topic == topic + "/dhw/heater_assist/enabled/set":
        try:
            global dhw_heater_assist_enable
            dhw_heater_assist_enable = _bool01(payload_raw)
            saveconfig('SETTINGS', 'dhw_heater_assist_enable', dhw_heater_assist_enable)
            queue_pub('dhw_heater_assist_enable', dhw_heater_assist_enable)
            # Kick controller immediately
            try:
                dhw_heater_assist_tick()
            except Exception:
                pass
            # If turned off, stop immediately
            if dhw_heater_assist_enable != '1':
                try:
                    _dhw_heater_assist_stop('switch_off')
                except Exception:
                    pass
        except Exception:
            logging.exception("MQTT: cannot set dhw_heater_assist_enable")

    elif msg.topic == topic + "/dhw/heater_assist/outtemp_thr/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                global dhw_heater_assist_below_temp
                dhw_heater_assist_below_temp = v
                saveconfig('SETTINGS', 'dhw_heater_assist_below_temp', v)
                queue_pub('dhw_heater_assist_below_temp', v)
                try:
                    dhw_heater_assist_tick()
                except Exception:
                    pass
            except Exception:
                logging.exception("MQTT: cannot set dhw_heater_assist_below_temp")
        else:
            logging.error("MQTT: bad dhw_heater_assist_below_temp payload: %r", payload_raw)

    elif msg.topic == topic + "/dhw/anti_legionella/enabled/set":
        try:
            global anti_legionella_enable
            anti_legionella_enable = _bool01(payload_raw)
            saveconfig('SETTINGS', 'anti_legionella_enable', anti_legionella_enable)
            queue_pub('anti_legionella_enable', anti_legionella_enable)
            # Kick controller immediately
            try:
                anti_legionella_tick()
            except Exception:
                pass
        except Exception:
            logging.exception("MQTT: cannot set anti_legionella_enable")

    elif msg.topic == topic + "/dhw/anti_legionella/run/set":
        # Runtime run/abort (not stored in config.ini)
        try:
            global anti_legionella_run
            anti_legionella_run = _bool01(payload_raw)
            globals()['anti_legionella_run'] = anti_legionella_run
            try:
                queue_pub('anti_legionella_run', anti_legionella_run)
            except Exception:
                pass
            try:
                anti_legionella_tick()
            except Exception:
                pass
        except Exception:
            logging.exception("MQTT: cannot set anti_legionella_run")

    elif msg.topic == topic + "/dhw/anti_legionella/temp/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                v = max(40.0, min(75.0, float(v)))
                global anti_legionella_temp
                anti_legionella_temp = v
                saveconfig('SETTINGS', 'anti_legionella_temp', v)
                queue_pub('anti_legionella_temp', v)
            except Exception:
                logging.exception("MQTT: cannot set anti_legionella_temp")
        else:
            logging.error("MQTT: bad anti_legionella_temp payload: %r", payload_raw)

    elif msg.topic == topic + "/service/tests/pump/set":
        payload = str(payload_raw).strip().lower()
        if payload in ("1", "on", "true", "yes"):
            service_set_pump(True)
        else:
            service_set_pump(False)

    elif msg.topic == topic + "/service/tests/heater/set":
        payload = str(payload_raw).strip().lower()
        if payload in ("1", "on", "true", "yes"):
            service_set_heater(True)
        else:
            service_set_heater(False)
    elif msg.topic == topic + "/service/tests/runtime_min/set":
        v = _float(payload_raw)
        if v is not None:
            try:
                minutes = max(0.5, min(240.0, float(v)))
                # snap to 0.5 min
                minutes = round(minutes * 2.0) / 2.0
                seconds = int(round(minutes * 60.0))
                seconds = int(round(seconds / 30.0) * 30)
                seconds = max(30, min(240 * 60, seconds))
                minutes = round(seconds / 60.0, 2)
                ok = bool(saveconfig('SETTINGS', 'service_test_duration_s', str(seconds)))
                if ok:
                    statusdict.setdefault('service_test_runtime_min', {})['value'] = minutes
                    queue_pub('service_test_runtime_min', minutes)
                    try:
                        socketlocal.emit("data_update", {
                            'service_test_duration_s': seconds,
                            'service_test_duration_min': minutes,
                        })
                    except Exception:
                        pass
            except Exception:
                logging.exception("MQTT: cannot set service test runtime")
        else:
            logging.error("MQTT: bad service runtime payload: %r", payload_raw)


    elif msg.topic == ha_mqtt_discovery_prefix + "/status" or msg.topic == "hass/status":
        if ha_mqtt_discovery == "1":
            logging.info(msg.topic + " | " + str(payload_raw))
            if str(payload_raw).strip() == "online":
                logging.info("Home Assistant online")
                configure_ha_mqtt_discovery()

def set_newframe(register, frame):
    global newframe
    global writed
    newframe = [register, frame]
    for i in range(50):
        if writed=="1":
            writed="0"
            return True
        time.sleep(0.2)
    return False



def _svc_is_on(val) -> bool:
    try:
        if isinstance(val, (int, float)):
            return int(val) != 0
        s = str(val).strip().lower()
        return s in ("1", "on", "true", "yes")
    except Exception:
        return False


def _svc_compressor_stopped(compinfo) -> bool:
    try:
        if compinfo in (None, "", "N.A.", "na"):
            return True
        if isinstance(compinfo, (list, tuple)) and len(compinfo) > 0:
            return float(compinfo[0]) == 0.0
        return float(compinfo) == 0.0
    except Exception:
        # Be conservative: if unknown, treat as running
        return False


def service_test_duration_s() -> int:
    """Return service test auto-off duration in seconds (>=30)."""
    try:
        s = int(float(config['SETTINGS'].get('service_test_duration_s', 60)))
    except Exception:
        s = 60
    return max(30, s)


def service_test_allowed_snapshot() -> dict:
    """Compute current service-test conditions (best-effort)."""
    try:
        pump = statusdict.get('pump', {}).get('value', 'N.A.')
        heater = statusdict.get('heater', {}).get('value', 'off')
        compinfo = statusdict.get('compinfo', {}).get('value', [])
        heatd = None
        try:
            heatd = int(GPIO.input(heatdemandpin))
        except Exception:
            pass

        allowed = (
            (not _svc_is_on(pump)) and
            (not _svc_is_on(heater)) and
            (heatd in (0, None)) and  # None if GPIO not available
            _svc_compressor_stopped(compinfo)
        )

        return {
            "allowed": bool(allowed),
            "pump": pump,
            "heater": heater,
        "set_pump": statusdict.get("service_set_pump", {}).get("value", "off"),
        "set_heater": statusdict.get("service_set_heater", {}).get("value", "off"),
        # keep as float (allows 0.5 min etc.)
        "service_test_duration_min": round(service_test_duration_s() / 60.0, 2),
            "heatdemand": heatd,
            "compinfo": compinfo,
        }
    except Exception:
        return {"allowed": False}


def _publish_service_states():
    try:
        queue_pub('service_set_pump', statusdict['service_set_pump']['value'])
        queue_pub('service_set_heater', statusdict['service_set_heater']['value'])
    except Exception:
        pass


def service_set_pump(on: bool, *, allow_force_off: bool = True, by_heater: bool = False) -> tuple[bool, str]:
    """Start/stop Pump service test."""
    global R101, service_set_pump_until_ts, service_pump_forced_by_heater

    if not on and not allow_force_off:
        return False, "force_off_disabled"

    if on:
        snap = service_test_allowed_snapshot()
        if not snap.get("allowed", False):
            return False, "not_allowed"
        frame = PyHaier.SetPump(R101, 1)
        if frame == "ERROR":
            return False, "frame_error"
        if not set_newframe(R101, frame):
            return False, "write_timeout"
        statusdict['service_set_pump']['value'] = 'on'
        service_set_pump_until_ts = time.time() + service_test_duration_s()
        service_pump_forced_by_heater = bool(by_heater)
        _publish_service_states()
        return True, "ok"

    # OFF
    frame = PyHaier.SetPump(R101, 0)
    if frame == "ERROR":
        return False, "frame_error"
    if not set_newframe(R101, frame):
        return False, "write_timeout"
    statusdict['service_set_pump']['value'] = 'off'
    service_set_pump_until_ts = 0.0
    service_pump_forced_by_heater = False
    _publish_service_states()
    return True, "ok"


def service_set_heater(on: bool, *, allow_force_off: bool = True) -> tuple[bool, str]:
    """Start/stop Heater service test. Turning ON also starts the pump."""
    global R101, service_set_heater_until_ts

    if not on and not allow_force_off:
        return False, "force_off_disabled"

    if on:
        snap = service_test_allowed_snapshot()
        if not snap.get("allowed", False):
            return False, "not_allowed"

        # Safety: ensure pump is running before heater (overheat protection)
        ok, msg = service_set_pump(True, by_heater=True)
        if not ok:
            return False, f"pump_{msg}"

        frame = PyHaier.SetHeater(R101, 1)
        if frame == "ERROR":
            # Best-effort rollback
            service_set_pump(False)
            return False, "frame_error"
        if not set_newframe(R101, frame):
            service_set_pump(False)
            return False, "write_timeout"

        statusdict['service_set_heater']['value'] = 'on'
        service_set_heater_until_ts = time.time() + service_test_duration_s()
        _publish_service_states()
        return True, "ok"

    # OFF (heater first, then pump if it was started by heater)
    frame = PyHaier.SetHeater(R101, 0)
    if frame == "ERROR":
        return False, "frame_error"
    if not set_newframe(R101, frame):
        return False, "write_timeout"

    statusdict['service_set_heater']['value'] = 'off'
    service_set_heater_until_ts = 0.0
    _publish_service_states()

    # Stop pump only if it was started by heater test (and not manually forced)
    try:
        if bool(globals().get('service_pump_forced_by_heater', False)) and statusdict['service_set_pump']['value'] == 'on':
            service_set_pump(False)
    except Exception:
        pass

    return True, "ok"


def service_test_tick():
    """Auto-off for service tests."""
    try:
        now = time.time()
        if statusdict.get('service_set_heater', {}).get('value') == 'on':
            if globals().get('service_set_heater_until_ts', 0.0) and now >= globals().get('service_set_heater_until_ts', 0.0):
                service_set_heater(False)
        if statusdict.get('service_set_pump', {}).get('value') == 'on':
            if globals().get('service_set_pump_until_ts', 0.0) and now >= globals().get('service_set_pump_until_ts', 0.0):
                service_set_pump(False)
    except Exception:
        logging.exception("service_test_tick failed")


# --- Custom antifreeze (pump run on freeze conditions) ---
def _afc_float(raw, default=None):
    try:
        s = str(raw).strip().replace(',', '.')
        if s == '' or s.lower() in ('n.a.', 'na', 'none'):
            return default
        return float(s)
    except Exception:
        return default


def _afc_set_pump(force_on: bool) -> bool:
    """Force pump ON/OFF using the same mechanism as service test (PyHaier.SetPump)."""
    global R101
    if not (isinstance(R101, list) and len(R101) == 6):
        logging.warning("Custom antifreeze: R101 not ready")
        return False
    try:
        frame = PyHaier.SetPump(R101, 1 if force_on else 0)
        return bool(set_newframe(R101, frame))
    except Exception:
        logging.exception("Custom antifreeze: SetPump failed")
        return False


def antifreeze_custom_tick():
    """Run custom antifreeze logic (custom_antifreeze).

    Variant 1:
      - When enabled and trigger conditions are met, force circulation pump ON
        for antifreeze_custom_runtime_min minutes.
      - After that time, return pump to OFF when safe.
      - It will NOT start again until the trigger conditions stop being met
        (re-arm).

    Start conditions (must all be true):
      - antifreeze_custom_enable == 1
      - heatdemand GPIO == 0 (or unavailable)
      - compressor stopped (compinfo[0] == 0)
      - pump currently OFF
      - not in defrost
      - outtemp <= antifreeze_custom_outtemp
      - twi <= antifreeze_custom_twi
      - two <= antifreeze_custom_two
    """
    global antifreeze_custom_active, antifreeze_custom_started_ts, antifreeze_custom_min_end_ts
    global antifreeze_custom_request_stop, antifreeze_custom_rearm_required

    try:
        enabled = str(globals().get('antifreeze_custom_enable', '0')).strip() == '1'

        # If disabled and not running, clear internal latches.
        if (not enabled) and (not antifreeze_custom_active):
            antifreeze_custom_request_stop = False
            antifreeze_custom_rearm_required = False

        # If service tests are running, do not interfere (and do not force OFF).
        # Keep our internal state; once the service test ends, we'll decide what to do.
        if (
            str(statusdict.get('service_set_pump', {}).get('value', 'off')).lower() == 'on' or
            str(statusdict.get('service_set_heater', {}).get('value', 'off')).lower() == 'on'
        ):
            return

        # Read current states
        pump_state = statusdict.get('pump', {}).get('value', 'N.A.')
        compinfo = statusdict.get('compinfo', {}).get('value', [])
        defrost_state = str(statusdict.get('defrost', {}).get('value', 'off')).strip().lower()

        # GPIO heatdemand
        heatd = None
        try:
            heatd = int(GPIO.input(heatdemandpin))
        except Exception:
            heatd = None

        comp_stopped = _svc_compressor_stopped(compinfo)
        pump_on = _svc_is_on(pump_state)

        now = time.time()

        # If disabled while running, request stop (but we still respect minimum runtime).
        if (not enabled) and antifreeze_custom_active:
            antifreeze_custom_request_stop = True

        # ACTIVE: keep pump forced ON at least until min_end_ts, then release when safe.
        if antifreeze_custom_active:
            # If pump went OFF unexpectedly, clear our state and latch rearm.
            if not pump_on:
                antifreeze_custom_active = False
                antifreeze_custom_request_stop = False
                antifreeze_custom_started_ts = 0.0
                antifreeze_custom_min_end_ts = 0.0
                antifreeze_custom_rearm_required = True
                try:
                    ischanged('antifreeze_custom', 'off')
                except Exception:
                    pass
                return

            can_release = (
                (heatd in (0, None)) and
                comp_stopped and
                defrost_state != 'on'
            )

            # Variant 1: release after runtime when safe (regardless of whether thresholds still hold).
            if now >= antifreeze_custom_min_end_ts and can_release:
                if _afc_set_pump(False):
                    antifreeze_custom_active = False
                    antifreeze_custom_request_stop = False
                    antifreeze_custom_started_ts = 0.0
                    antifreeze_custom_min_end_ts = 0.0
                    antifreeze_custom_rearm_required = True
                    try:
                        ischanged('antifreeze_custom', 'off')
                    except Exception:
                        pass
                return

            # still active
            return

        # INACTIVE: nothing to do if disabled
        if not enabled:
            return


        # Evaluate start/re-arm conditions only when compressor is STOPPED and the circulation pump is OFF.
        # Requested: check custom antifreeze conditions every 30s, but only if comp=STOP and pump=OFF.
        # This also prevents the Variant-1 re-arm latch from clearing just because normal heating is running.
        if (not comp_stopped) or pump_on or defrost_state == 'on':
            return

        # Build trigger_ok (whether we WOULD start right now)
        out_thr = _afc_float(globals().get('antifreeze_custom_outtemp', '0.0'), None)
        twi_thr = _afc_float(globals().get('antifreeze_custom_twi', '0.0'), None)
        two_thr = _afc_float(globals().get('antifreeze_custom_two', '0.0'), None)
        runtime_min = _afc_float(globals().get('antifreeze_custom_runtime_min', '1.0'), 1.0)
        runtime_min = max(0.5, float(runtime_min))

        outtemp_val = _afc_float(statusdict.get('outtemp', {}).get('value', None), None)
        twitwo_val = statusdict.get('twitwo', {}).get('value', [None, None])
        twi_val = None
        two_val = None
        try:
            if isinstance(twitwo_val, (list, tuple)) and len(twitwo_val) >= 2:
                twi_val = _afc_float(twitwo_val[0], None)
                two_val = _afc_float(twitwo_val[1], None)
        except Exception:
            twi_val = two_val = None

        thresholds_ok = (
            out_thr is not None and twi_thr is not None and two_thr is not None and
            outtemp_val is not None and twi_val is not None and two_val is not None and
            (outtemp_val <= out_thr) and (twi_val <= twi_thr) and (two_val <= two_thr)
        )

        trigger_ok = (
            defrost_state != 'on' and
            (heatd in (0, None)) and
            comp_stopped and
            (not pump_on) and
            thresholds_ok
        )

        # Variant 1 latch: after a completed run, wait until trigger_ok becomes False once.
        if antifreeze_custom_rearm_required:
            if not trigger_ok:
                antifreeze_custom_rearm_required = False
            return

        if not trigger_ok:
            return

        # Start: force pump ON
        if _afc_set_pump(True):
            antifreeze_custom_active = True
            antifreeze_custom_request_stop = False
            antifreeze_custom_started_ts = now
            antifreeze_custom_min_end_ts = now + (runtime_min * 60.0)
            try:
                ischanged('antifreeze_custom', 'on')
            except Exception:
                pass
            logging.info(
                "Custom antifreeze: started (out=%.1f<=%.1f, twi=%.1f<=%.1f, two=%.1f<=%.1f, runtime=%.1fmin)",
                outtemp_val, out_thr, twi_val, twi_thr, two_val, two_thr, runtime_min
            )
        else:
            logging.warning("Custom antifreeze: failed to start pump")

    except Exception:
        logging.exception("Custom antifreeze tick failed")

def saveconfig(block, name, value):
    if name not in statusdict:
        statusdict[name] = {}
    statusdict[name]['value'] = value
    config[block][name] = str(value)
    try:
        with open('/opt/config.ini', 'w') as configfile:
            config.write(configfile)
        return True
    except:
        return False

def new_tempchange(which, value, curve):
    global R101
    if curve == "1":
        if which == "heat":
            logging.info("Central heating: "+str(value))
            chframe = PyHaier.SetCHTemp(R101, float(value))
            response=set_newframe(R101,chframe)
            return 'Central Heating', response
        elif which == "dhw":
            # DHW setpoint: allow 0.5°C steps (UI), keep backward compatibility with integer-only firmwares
            raw = str(value).strip().replace(',', '.')
            try:
                v = float(raw)
            except Exception:
                v = 0.0
            # normalize to 0.5°C
            v = round(v * 2.0) / 2.0
            logging.info(f"Domestic Hot Water: {v:.1f}")
            try:
                # Newer PyHaier / firmwares may accept float (0.5°C resolution)
                dhwframe = PyHaier.SetDHWTemp(R101, v)
            except Exception:
                # Fallback: integer resolution
                dhwframe = PyHaier.SetDHWTemp(R101, int(round(v)))
                v = float(int(round(v)))
            response=set_newframe(R101,dhwframe)
            queue_pub('dhw', f"{v:.1f}")
            return 'Domestic Hot Water', response
    elif curve == "0":
        if which == "heat":
            response = saveconfig('SETTINGS', 'settemp', float(value))
            queue_pub("settemp", value)
            if ha_mqtt_discovery=="1":
                Settemp_number.set_value(float(value))
            return 'Central Heating', response

def _compensation_from_frame(frame, reg_index):
    """Decode compensation value (°C) from a 6-register frame."""
    try:
        b = int(frame[reg_index] & 0xFF)
        return (b - 30) / 2.0
    except Exception:
        return None


def new_tempcompchange(value):
    """Set Temperature Compensation (A03) via PyHaier (R101 frame).

    Assumes current PyHaier expects value in °C (0.5°C resolution).
    Value is clamped to [-15.0, 15.0] and normalized to 0.5°C steps.
    """
    global R101
    raw = str(value).strip().replace(",", ".")
    try:
        v = float(raw)
    except Exception:
        v = 0.0

    # Clamp & normalize to 0.5°C steps
    v = max(-15.0, min(15.0, v))
    v = round(v * 2.0) / 2.0

    if not isinstance(R101, list) or len(R101) != 6:
        logging.error("Temp compensation set: R101 not ready")
        return gettext("R101 not ready"), False

    try:
        frame = PyHaier.SetTempCompensation(R101, v)
    except Exception:
        logging.exception("Temp compensation (A03) set: setter failed")
        return gettext("Temp compensation"), False

    if not (isinstance(frame, list) and len(frame) == 6):
        logging.error("Temp compensation (A03) set: invalid frame returned: %r", frame)
        return gettext("Temp compensation"), False

    got = _compensation_from_frame(frame, 1)
    if got is None or abs(got - v) > 0.001:
        logging.error("Temp compensation (A03) set: frame value mismatch (wanted=%s, got=%s)", v, got)
        return gettext("Temp compensation"), False

    response = set_newframe(R101, frame)
    if response:
        ischanged("tempcompensation_set", v)
    return gettext("Temp compensation"), response



def new_dhwcompchange(value):
    """Set DHW Temperature Compensation (A0d) via PyHaier (R101 frame).

    Assumes current PyHaier expects value in °C (0.5°C resolution).
    Value is clamped to [-15.0, 15.0] and normalized to 0.5°C steps.
    """
    global R101
    raw = str(value).strip().replace(",", ".")
    try:
        v = float(raw)
    except Exception:
        v = 0.0

    # Clamp & normalize to 0.5°C steps
    v = max(-15.0, min(15.0, v))
    v = round(v * 2.0) / 2.0

    if not isinstance(R101, list) or len(R101) != 6:
        logging.error("DHW compensation set: R101 not ready")
        return gettext("R101 not ready"), False

    try:
        frame = PyHaier.SetDHWCompensation(R101, v)
    except Exception:
        logging.exception("DHW compensation (A0d) set: setter failed")
        return gettext("DHW compensation"), False

    if not (isinstance(frame, list) and len(frame) == 6):
        logging.error("DHW compensation (A0d) set: invalid frame returned: %r", frame)
        return gettext("DHW compensation"), False

    got = _compensation_from_frame(frame, 5)
    if got is None or abs(got - v) > 0.001:
        logging.error("DHW compensation (A0d) set: frame value mismatch (wanted=%s, got=%s)", v, got)
        return gettext("DHW compensation"), False

    response = set_newframe(R101, frame)
    if response:
        ischanged("dhwcompensation_set", v)
    return gettext("DHW compensation"), response


def _sync_heatcontrol_status():
    # Update and publish Heat Control / Curve Mode status.
    try:
        hc = str(config['SETTINGS'].get('heatingcurve', '')).strip().lower()
        last = str(config['SETTINGS'].get('heatingcurve_last', 'auto')).strip().lower()
    except Exception:
        hc = str(globals().get('heatingcurve', '')).strip().lower()
        last = 'auto'

    if last not in ('auto', 'static', 'manual'):
        last = 'auto'

    heatcontrol_state = 'direct' if hc == 'directly' else 'curve'
    mode_state = last if hc == 'directly' else hc
    if mode_state not in ('auto', 'static', 'manual'):
        mode_state = 'auto'

    try:
        ischanged('heatcontrol', heatcontrol_state)
    except Exception:
        pass
    try:
        ischanged('heatingcurve_mode', mode_state)
    except Exception:
        pass


def new_heatcontrol_change(value):
    # Switch Heat Control between curve and direct (curve/direct).
    global heatingcurve

    raw = str(value).strip().lower()
    want_direct = raw in ('direct', 'directly')
    want_curve = raw in ('curve',)

    if not want_direct and not want_curve:
        logging.error('Heat control: unsupported payload: %s', value)
        return gettext('Heat control'), False

    try:
        current = str(heatingcurve).strip().lower()

        if want_direct:
            if current in ('auto', 'static', 'manual'):
                config['SETTINGS']['heatingcurve_last'] = current
            config['SETTINGS']['heatingcurve'] = 'directly'
        else:
            # curve requested
            if current in ('directly', 'direct'):
                restore = str(config['SETTINGS'].get('heatingcurve_last', 'auto')).strip().lower()
                if restore not in ('auto', 'static', 'manual'):
                    restore = 'auto'
                config['SETTINGS']['heatingcurve'] = restore

        with open('/opt/config.ini', 'w') as configfile:
            config.write(configfile)

        loadconfig()

        _sync_heatcontrol_status()

        try:
            curvecalc()
        except Exception:
            logging.exception('Immediate curvecalc after heatcontrol change failed')

        return gettext('Heat control'), True
    except Exception:
        logging.exception('Heat control: cannot save config')
        return gettext('Heat control'), False


def new_heatingcurve_mode_change(value):
    # Set curve type (auto/static/manual) without touching Heat Control.
    global heatingcurve

    mode = str(value).strip().lower()
    if mode not in ('auto', 'static', 'manual'):
        logging.error('Heating curve mode: unsupported payload: %s', value)
        return gettext('Heating curve mode'), False

    try:
        current = str(heatingcurve).strip().lower()

        # Always remember last selected curve mode
        config['SETTINGS']['heatingcurve_last'] = mode

        if current != 'directly':
            # In curve mode: apply immediately
            config['SETTINGS']['heatingcurve'] = mode

        with open('/opt/config.ini', 'w') as configfile:
            config.write(configfile)

        loadconfig()
        _sync_heatcontrol_status()

        if str(heatingcurve).strip().lower() != 'directly':
            try:
                curvecalc()
            except Exception:
                logging.exception('Immediate curvecalc after heatingcurve_mode change failed')

        return gettext('Heating curve mode'), True
    except Exception:
        logging.exception('Heating curve mode: cannot save config')
        return gettext('Heating curve mode'), False
def new_presetchange(mode):
    global R201
    logging.info("PRESET MODE: changed to: "+str(mode))
    response=set_newframe(R201,PyHaier.SetMode(mode))
    queue_pub('mode', mode)
    return 'Preset Mode', response

def new_flimitchange(mode):
    try:
        gpiocontrol("freqlimit", mode)
    except:
        return False

def flimitchange(mode):
    # Accept common boolean payloads (HA sometimes sends ON/OFF)
    mode_raw = str(mode).strip()
    mode_lc = mode_raw.lower()
    if mode_lc in ("1", "on", "true", "yes"):
        mode = "1"
    elif mode_lc in ("0", "off", "false", "no"):
        mode = "0"
    else:
        mode = mode_raw  # fallback (keeps legacy behaviour)

    try:
        gpiocontrol("freqlimit", mode)
        msg = "Frequency limit relay: " + str(mode)
        state = "success"
        logging.info("Frequency limit relay changed to: " + str(mode))

        # IMPORTANT:
        # Don't update statusdict directly here without emitting a WebSocket update.
        # Otherwise the periodic GPIO sync (ischanged()) won't detect the change and
        # UI will stay stale until a hard refresh.
        try:
            ischanged("flimiton", mode)
            ischanged("flrelay", mode)
        except Exception:
            # Fallback: keep cached values at least, even if socket emit fails
            try:
                if "flimiton" in statusdict:
                    statusdict["flimiton"]["value"] = mode
                if "flrelay" in statusdict:
                    statusdict["flrelay"]["value"] = mode
            except Exception:
                pass

        if use_mqtt == "1":
            # HA/state topics (retained) are already published via ischanged()->queue_pub().
            pass

        return msg, state
    except Exception:
        msg = "Frequency limit not changed"
        state = "error"
        logging.error("Cannot change frequency limit relay")
        # MQTT state topics are handled elsewhere (ischanged()->queue_pub()).
        return msg, state
def statechange(mode,value,mqtt):
    logging.info(f"passed values: mode - {mode}, value - {value}")
    def calculate_newstate(pdhw, pch, pcool, mode, value):
        if mode == 'pch':
            is_heating_on = (value == 'on')
        elif mode == 'off':
            is_heating_on = False
        else:
            is_heating_on = (pch == 'on')

        if mode == 'pcool':
            is_cooling_on = (value == 'on')
        elif mode == 'off': 
            is_cooling_on = False
        else:
            is_cooling_on = (pcool == 'on')

        if mode == 'pdhw':
            is_dhw_on = (value == 'on')
        else:
            is_dhw_on = (pdhw == 'on')
        
        if mode == 'pdhw' and value == 'off':
            is_dhw_on = False

        if mode == 'pch' and value == 'on':
            is_cooling_on = False
    
        if mode == 'pcool' and value == 'on':
            is_heating_on = False

        final_state = ""
        if is_heating_on:
            final_state += "H"
        elif is_cooling_on:
            final_state += "C"
    
        if is_dhw_on:
            final_state += "T"

        if not final_state:
            return "off"
    
        return final_state

    def _human_state_label(mode: str, value: str, newstate: str) -> str:
        """Return a human-friendly target state label in English."""
        m = str(mode or '').strip().lower()
        v = str(value or '').strip().lower()
        ns = str(newstate or '').strip().lower()

        # Explicit OFF request
        if ns == 'off' or m == 'off' or v == 'off':
            return "OFF"

        # Explicit single-mode request
        if m in ('pch', 'heat', 'heating', 'ch') and v == 'on':
            return "PCH"
        if m in ('pcool', 'cool', 'cooling') and v == 'on':
            return "PCOOL"
        if m in ('pdhw', 'pddhw', 'dhw') and v == 'on':
            return "PDDHW"

        # Fallback: decode flags in newstate (H/C + optional T)
        ns_up = ns.upper()
        if ns_up == 'H':
            return "PCH"
        if ns_up == 'C':
            return "PCOOL"
        if ns_up == 'T':
            return "PDDHW"
        if ns_up == 'HT':
            return "PCH+PDDHW"
        if ns_up == 'CT':
            return "PCOOL+PDDHW"

        return ns_up or "UNKNOWN"

    global R101
    pcool=statusdict['pcool']['value']
    defrost=statusdict.get('defrost', {}).get('value','off')
    pch=statusdict['pch']['value']
    pdhw=statusdict['pdhw']['value']
    newstate=""
    newstate = calculate_newstate(pdhw, pch, pcool, mode, value)
    target_label = _human_state_label(mode, value, newstate)
    logging.info(f"Target state label: {target_label} (raw: {newstate})")
    global newframe
    global writed
    logging.info(f"statechange: {newframe}")
    logging.info(f"statechange values: {mode}, {value}")
    logging.info(f"statechange: {writed}")
    logging.info(f"statechange R101: {R101}")
    logging.info(f"statechange: {newstate}")
    if len(R101) > 1:
        # NOTE: R101[0] low byte contains state flags (bit0 = ON/OFF).
        try:
            _state_byte = int(R101[0]) & 0xFF
        except Exception:
            _state_byte = 0
        _is_on = bool(_state_byte & 0x01)

        def _send_and_wait(frame, timeout_s: float = 12.0) -> bool:
            """Send a single Modbus frame via global newframe and wait for WritePump() confirmation."""
            global newframe, writed, R101
            writed = "0"
            # Use a fresh snapshot of R101 as the "old" frame for WritePump() comparison.
            newframe = [R101, frame]
            start_ts = time.time()
            while (time.time() - start_ts) < timeout_s:
                logging.info(f"writed: {writed}")
                if writed == "1":
                    writed = "0"
                    return True
                time.sleep(0.2)
            writed = "0"
            return False

        # If we are already OFF and requested state is OFF, do nothing (important: SetState('off') would toggle!).
        if str(newstate).strip().lower() == 'off' and (not _is_on):
            msg = gettext("State is already OFF")
            state = "success"
        else:
            # Some pumps ignore direct mode set (0x86xx) when controller is OFF.
            # So: 1) wake up (0x01xx) in a blocking way, 2) immediately send the target mode (0x86xx).
            ok = True
            if (not _is_on) and str(newstate).strip().lower() != 'off':
                ok = _send_and_wait(PyHaier.SetState(R101, "on"), timeout_s=12.0)
                # tiny pause so ReadPump can refresh R101; not required but helps with stability
                time.sleep(0.3)

            if ok:
                ok = _send_and_wait(PyHaier.SetState(R101, newstate), timeout_s=12.0)

            if ok:
                msg = gettext(f"State successfully set to {target_label}")
                state = "success"
            else:
                msg = gettext(f"Failed to set state to {target_label}: Modbus connection timeout.")
                state = "error"
    if mqtt == "1":
        return "OK"
    else:
        return jsonify(msg=msg, state=state)

def curvecalc():
    global heatdemand_hi_since
    global heatingcurve
    global saved_settemp_before_direct, last_heatingcurve_mode
    insidetemp = None
    outsidetemp = None
    settemp = None
    heatcurve = None

    # Wyjście z trybu Direct: przywróć poprzednią "zadaną wewnątrz" (settemp)
    # Uwaga: settemp (curve=0) nie jest wysyłane bezpośrednio do pompy,
    # ale wpływa na obliczenie krzywej (hcurve) w dalszej części tej funkcji.
    if heatingcurve != 'directly' and last_heatingcurve_mode == 'directly' and saved_settemp_before_direct is not None:
        try:
            logging.info(f"EXIT DIRECT: restore settemp={saved_settemp_before_direct}")
            new_tempchange('heat', float(saved_settemp_before_direct), '0')  # tylko UI/config
            settemp = float(saved_settemp_before_direct)  # użyj od razu do obliczeń krzywej
        except Exception:
            logging.exception('Restore settemp after Direct failed')
        saved_settemp_before_direct = None
    # NOWE Pause curve calculation during defrost (disturbance)
    try:
        _threeway = str(statusdict.get('threeway', {}).get('value', '')).strip().upper()
        _defrost = str(statusdict.get('defrost', {}).get('value', 'off')).strip().lower()
        if _defrost == 'on':
            logging.info('Defrost active: pausing curvecalc')
            return statusdict.get('hcurve', {}).get('value', None)
    except Exception:
        pass

    if expert_mode == "1":
        mintemp=float(20)
        maxtemp=float(55)
    else:
        mintemp=float(25)
        maxtemp=float(55)
    if isfloat(statusdict['intemp']['value']):
        insidetemp = float(statusdict['intemp']['value'])
    if isfloat(statusdict['outtemp']['value']):
        outsidetemp=float(statusdict['outtemp']['value'])
    if isfloat(statusdict['settemp']['value']):
        settemp=float(statusdict['settemp']['value'])
    # Safety: if required inputs are missing, do not proceed (avoids TypeError crashes)
    if heatingcurve in ('auto', 'static', 'manual'):
        if outsidetemp is None or settemp is None or (heatingcurve == 'auto' and insidetemp is None):
            logging.warning(f"curvecalc: missing temp input(s) (int={insidetemp}, out={outsidetemp}, set={settemp}); skipping")
            return statusdict.get('hcurve', {}).get('value', None)
    # Direct mode (bezpośrednia):
    # - po przełączeniu: kopiujemy ostatnią wartość hcurve do settemp (żeby nie było skoku),
    # - w trybie Direct: settemp traktujemy jako zadaną CO (temp. zasilania) i wysyłamy ją na pompę,
    # - aktualizujemy hcurve w UI, żeby niebieska wartość była spójna z regulacją +/-.
    if heatingcurve == 'directly':
        # 1) Wejście w Direct -> jednorazowa synchronizacja settemp := hcurve (z krzywej)
        if last_heatingcurve_mode != 'directly':
            # zapisz bieżącą zadaną (wewnątrz) zanim nadpiszemy settemp wartością z krzywej
            _st_prev = statusdict.get('settemp', {}).get('value', None)
            if _st_prev is not None and isfloat(_st_prev):
                saved_settemp_before_direct = float(_st_prev)
            logging.info(f"ENTER DIRECT: saved settemp={saved_settemp_before_direct}")
            try:
                _hc_prev = statusdict.get('hcurve', {}).get('value', None)
                if _hc_prev is not None and isfloat(_hc_prev):
                    _hc_prev = float(_hc_prev)
                    new_tempchange('heat', _hc_prev, '0')  # zapis do config + UI
                    settemp = _hc_prev
                    logging.info(f"ENTER DIRECT: sync settemp:=hcurve ({_hc_prev})")
            except Exception:
                logging.exception('Direct sync: failed to copy hcurve to settemp')

        # 2) W Direct wartość zadana CO pochodzi z settemp
        if settemp is None:
            _st = statusdict.get('settemp', {}).get('value', None)
            if _st is not None and isfloat(_st):
                settemp = float(_st)

        if settemp is None:
            # Brak sensownej wartości - nie ruszamy niczego
            last_heatingcurve_mode = 'directly'
            return statusdict.get('hcurve', {}).get('value', None)

        heatcurve = float(settemp)        # 3) Wysyłka zadanej CO na pompę + sterowanie zapotrzebowaniem:
        #    - default: jak dotąd (Direct = praca ciągła -> heatdemand ON w zakresie)
        #    - thermostat_on=1 -> heatdemand sterowany termostatem (intemp vs direct_inside_settemp)
        #    - thermostat_on=0 -> heatdemand wymuszone ON (ciągłe grzanie)
        try:
            if mintemp <= heatcurve <= maxtemp:
                # Always push updated CH setpoint to pump (independent from heatdemand)
                if str(statusdict.get('hcurve', {}).get('value')) != str(heatcurve):
                    new_tempchange('heat', heatcurve, '1')

                zone = get_temp_zone(outsidetemp) if outsidetemp is not None else 'normal'
                use_thermostat = (str(globals().get('thermostat_on', '1')).strip() == '1')

                # Frost zone keeps continuous behaviour (safety) – thermostat is ignored there.
                if use_thermostat and zone != 'frost':
                    target = globals().get('direct_inside_settemp', None)
                    if target is None or not isfloat(target):
                        target = None
                    else:
                        target = float(target)

                    if insidetemp is None or target is None:
                        # No sensor/target -> fallback to continuous operation
                        heatdemand_hi_since = None
                        if GPIO.input(heatdemandpin) != 1:
                            logging.info('Direct(thermostat): sensor/target missing -> forcing heat demand ON')
                            gpiocontrol('heatdemand', '1')
                    else:
                        # Thermostat hysteresis uses global lohysteresis/hihysteresis
                        low_th = target - safe_float(lohysteresis, 0.0)
                        high_th = target + safe_float(hihysteresis, 0.1)

                        if insidetemp < low_th:
                            heatdemand_hi_since = None
                            if GPIO.input(heatdemandpin) != 1:
                                logging.info('Direct(thermostat): Turn on heat demand')
                                gpiocontrol('heatdemand', '1')

                        elif insidetemp > high_th:
                            now_ts = time.time()
                            if heatdemand_hi_since is None:
                                heatdemand_hi_since = now_ts
                            elif (now_ts - heatdemand_hi_since) >= HEATDEMAND_OFF_DELAY_S:
                                if GPIO.input(heatdemandpin) != 0:
                                    logging.info('Direct(thermostat): Turn off heat demand (confirmed)')
                                    gpiocontrol('heatdemand', '0')
                        else:
                            heatdemand_hi_since = None
                            logging.info("Direct(thermostat): Don't do anything (within hysteresis)")
                else:
                    # Continuous operation in Direct (legacy behaviour)
                    heatdemand_hi_since = None
                    if GPIO.input(heatdemandpin) != 1:
                        logging.info('Direct: Turn on heat demand')
                        gpiocontrol('heatdemand', '1')
            else:
                heatdemand_hi_since = None
                if GPIO.input(heatdemandpin) != 0:
                    logging.info('Direct: Turn off heat demand (heatcurve out of range)')
                    gpiocontrol('heatdemand', '0')
        except Exception:
            logging.exception('Direct: Set chtemp / heatdemand ERROR')
        ischanged('hcurve', heatcurve)

        # Direct: allow FLimit auto-change by outside temperature (same logic as non-Direct mode)
        try:
            zone = get_temp_zone(outsidetemp) if outsidetemp is not None else 'normal'

            # TempZone exclusion during active DHW heating (avoid forcing CH modes while heating water)
            try:
                _tw = str(statusdict.get('threeway', {}).get('value', '')).strip().upper()
                _ci = statusdict.get('compinfo', {}).get('value', [])
                _dhw_active = (_tw == "DHW")
            except Exception:
                _dhw_active = False

            # Restore FLimit relay state after leaving Quiet+FLimit zone
            _tempzone_flimit_restore_guard(zone, _dhw_active)

            if _dhw_active and zone in ('frost', 'warm'):
                logging.info(f"Direct: TempZone({zone}): skipped during DHW heating")

            if outsidetemp is not None and zone == 'frost' and not _dhw_active:
                # Force selected preset mode (Turbo/Eco/Quiet/Quiet+FLimit)
                try:
                    _zm = normalize_zone_mode(zone_frost_mode, 'turbo')
                    desired_preset = 'quiet' if _zm == 'quiet_flimit' else _zm
                    flimit_allowed = (_zm != 'quiet')
                    force_flimit_on = (_zm == 'quiet_flimit')

                    current_mode = str(statusdict.get('mode', {}).get('value', '')).strip().lower()
                    if current_mode != desired_preset:
                        logging.info(f"Direct: TempZone(frost): forcing mode {desired_preset}")
                        new_presetchange(desired_preset)
                except Exception as e:
                    logging.warning(f"Direct: TempZone(frost): cannot set mode: {e}")
                # FLimit relay in TempZone is enforced centrally by _tempzone_flimit_restore_guard() when FLimit=auto.

            else:
                # TempZone warm should also work in Direct (Turbo/Eco/Quiet/Quiet+FLimit)
                allow_auto_flimit = True

                if outsidetemp is not None and zone == 'warm' and not _dhw_active:
                    try:
                        _zm = normalize_zone_mode(zone_warm_mode, 'quiet_flimit')
                        desired_preset = 'quiet' if _zm == 'quiet_flimit' else _zm
                        flimit_allowed = (_zm != 'quiet')
                        force_flimit_on = (_zm == 'quiet_flimit')

                        current_mode = str(statusdict.get('mode', {}).get('value', '')).strip().lower()
                        if current_mode != desired_preset:
                            logging.info(f"Direct: TempZone(warm): forcing mode {desired_preset}")
                            new_presetchange(desired_preset)
                        # FLimit relay in TempZone is enforced centrally by _tempzone_flimit_restore_guard() when FLimit=auto.

                    except Exception as e:
                        logging.warning(f"Direct: TempZone(warm): cannot apply zone mode: {e}")

                if flimit == "auto" and antionoff != "1" and outsidetemp is not None and zone == 'normal':
                    threeway = statusdict.get('threeway', {}).get('value', '')
                    compinfo = statusdict.get('compinfo', {}).get('value', [])

                    # Keep the same DHW lock behaviour as in non-Direct mode
                    if isinstance(compinfo, list) and len(compinfo) > 0:
                        if not (dhwwl == "1" and compinfo[0] != 0 and str(threeway).strip().upper() == "DHW"):
                            if outsidetemp >= float(flimittemp):
                                logging.info("Direct: Turn on freq limit")
                                flimitchange("1")
                            elif outsidetemp <= float(flimittemp) + 0.5:
                                logging.info("Direct: Turn off freq limit")
                                flimitchange("0")
        except Exception:
            logging.exception('Direct: flimit auto-change failed')

        # Direct: allow preset auto-change (Quiet/Eco/Turbo) by outside temperature
        # when Anti ON-OFF is disabled (to avoid conflicting mode logic).
        try:
            if presetautochange == "auto" and antionoff != "1" and outsidetemp is not None and get_temp_zone(outsidetemp) == 'normal':
                threeway = statusdict.get('threeway', {}).get('value', '')
                compinfo = statusdict.get('compinfo', {}).get('value', [])

                # Keep the same DHW lock behaviour as in non-Direct mode
                if isinstance(compinfo, list) and len(compinfo) > 0:
                    if not (dhwwl == "1" and compinfo[0] != 0 and str(threeway).strip().upper() == "DHW"):
                        mode = str(statusdict.get('mode', {}).get('value', '')).strip().lower()
                        if outsidetemp >= float(presetquiet) and mode != "quiet":
                            new_presetchange("quiet")
                        elif outsidetemp <= float(presetturbo) and mode != "turbo":
                            new_presetchange("turbo")
                        elif float(presetturbo) < outsidetemp < float(presetquiet) and mode != "eco":
                            new_presetchange("eco")
        except Exception:
            logging.exception('Direct: preset auto-change failed')

        last_heatingcurve_mode = 'directly'
        return heatcurve
    elif heatingcurve == 'auto':
        t1=(outsidetemp/(320-(outsidetemp*4)))
        t2=pow(settemp,t1)
        sslope=float(slope)
        ps=float(pshift)
        amp=float(hcamp)
        _hc = ((0.55*sslope*t2)*(((-outsidetemp+20)*2)+settemp+ps)+((settemp-insidetemp)*amp))+ps
        heatcurve = round(_hc*2)/2
    elif heatingcurve == 'static':
        sslope=float(slope)
        heatcurve = round((settemp+(sslope*20)*pow(((settemp-outsidetemp)/20), 0.7))*2)/2
    elif heatingcurve == 'manual':
        if outsidetemp is not None:
            if float(outsidetemp) < -15:
                heatcurve=float(hcman[0])
            elif -15 <= outsidetemp < -10:
                heatcurve=float(hcman[1])
            elif -10 <= outsidetemp < -8:
                heatcurve=float(hcman[2])
            elif -8 <= outsidetemp < -6:
                heatcurve=float(hcman[3])
            elif -6 <= outsidetemp < -4:
                heatcurve=float(hcman[4])
            elif -4 <= outsidetemp < -2:
                heatcurve=float(hcman[5])
            elif -2 <= outsidetemp < 0:
                heatcurve=float(hcman[6])
            elif 0 <= outsidetemp < 2:
                heatcurve=float(hcman[7])
            elif 2 <= outsidetemp < 4:
                heatcurve=float(hcman[8])
            elif 4 <= outsidetemp < 6:
                heatcurve=float(hcman[9])
            elif 6 <= outsidetemp < 8:
                heatcurve=float(hcman[10])
            elif 8 <= outsidetemp < 10:
                heatcurve=float(hcman[11])
            elif 10 <= outsidetemp < 15:
                heatcurve=float(hcman[12])
            elif outsidetemp >= 15:
                heatcurve=float(hcman[13])
        else:
            logging.warning("Cannot calculate 'manual' heatcurve, no outside temperature reading.")

    # Safety: if heatcurve still not calculated, keep last value and exit
    if heatcurve is None:
        logging.warning("curvecalc: heatcurve is None -> keep last and skip control")
        return statusdict.get('hcurve', {}).get('value', None)

    # NOWE Temperature zones logic
    global _current_zone
    zone = get_temp_zone(outsidetemp)
    if zone != _current_zone:
        logging.info(f"TempZone: {_current_zone} -> {zone} (outtemp={outsidetemp})")
        _current_zone = zone

    # TempZone exclusion during active DHW heating (avoid forcing CH modes while heating water)
    try:
        _tw = str(statusdict.get('threeway', {}).get('value', '')).strip().upper()
        _ci = statusdict.get('compinfo', {}).get('value', [])
        _dhw_active = (_tw == "DHW")
    except Exception:
        _dhw_active = False

    # Restore FLimit relay state after leaving Quiet+FLimit zone
    _tempzone_flimit_restore_guard(zone, _dhw_active)
    if _dhw_active and zone in ('frost', 'warm'):
        logging.info(f"TempZone({zone}): skipped during DHW heating")

    # Zone 1: Frost - continuous work without thermostat.
    # Preset is forced according to zone_frost_mode (Turbo/Eco/Quiet/Quiet+FLimit).
    if zone == 'frost' and not _dhw_active:
        # Force selected preset mode
        flimit_allowed = True
        force_flimit_on = False
        try:
            _zm = normalize_zone_mode(zone_frost_mode, 'turbo')
            desired_preset = 'quiet' if _zm == 'quiet_flimit' else _zm
            flimit_allowed = (_zm != 'quiet')
            force_flimit_on = (_zm == 'quiet_flimit')

            current_mode = str(statusdict.get('mode', {}).get('value', '')).strip().lower()
            if current_mode != desired_preset:
                logging.info(f"TempZone(frost): forcing mode {desired_preset}")
                new_presetchange(desired_preset)
        except Exception as e:
            logging.warning(f"TempZone(frost): cannot set mode: {e}")
        # FLimit relay in TempZone is enforced centrally by _tempzone_flimit_restore_guard() when FLimit=auto.

        # Force heat demand ON (ignore thermostat), but keep safety range check
        heatdemand_hi_since = None
        if mintemp <= heatcurve <= maxtemp:
            try:
                if GPIO.input(heatdemandpin) != 1:
                    logging.info('TempZone(frost): Turn on heat demand (forced)')
                    gpiocontrol('heatdemand', '1')
                if str(statusdict.get('hcurve', {}).get('value')) != str(heatcurve):
                    new_tempchange('heat', heatcurve, '1')
            except Exception:
                logging.error('TempZone(frost): Set chtemp ERROR')
        else:
            if GPIO.input(heatdemandpin) != 0:
                logging.info('TempZone(frost): Turn off heat demand (heatcurve out of range)')
                gpiocontrol('heatdemand', '0')

        ischanged('hcurve', heatcurve)
        last_heatingcurve_mode = heatingcurve
        return heatcurve

    # Zone 2: Warm - thermostat still works, but preset is forced according to zone_warm_mode
    # (Turbo/Eco/Quiet/Quiet+FLimit). Quiet-only disables FLimit relay.
    if zone == 'warm' and not _dhw_active:
        try:
            _zm = normalize_zone_mode(zone_warm_mode, 'quiet_flimit')
            desired_preset = 'quiet' if _zm == 'quiet_flimit' else _zm
            flimit_allowed = (_zm != 'quiet')
            force_flimit_on = (_zm == 'quiet_flimit')

            current_mode = str(statusdict.get('mode', {}).get('value', '')).strip().lower()
            if current_mode != desired_preset:
                logging.info(f"TempZone(warm): forcing mode {desired_preset}")
                new_presetchange(desired_preset)
                        # FLimit relay in TempZone is enforced centrally by _tempzone_flimit_restore_guard() when FLimit=auto.

        except Exception as e:
            logging.warning(f"TempZone(warm): cannot apply zone mode: {e}")

    # Thermostat mode
    if mintemp <= heatcurve <= maxtemp:
        # Always push updated curve value to the pump (no need to wait for heatdemand)
        try:
            if str(statusdict.get('hcurve', {}).get('value')) != str(heatcurve):
                logging.info("Curve update: write CH setpoint to pump")
                new_tempchange("heat", heatcurve, "1")
        except:
            logging.error("Set chtemp ERROR")
        # thermostat_on=0 => always heat demand ON (continuous curve)
        if str(globals().get('thermostat_on', '1')).strip() != '1':
            heatdemand_hi_since = None
            try:
                if GPIO.input(heatdemandpin) != 1:
                    logging.info('Thermostat OFF: forcing heat demand ON')
                    gpiocontrol('heatdemand', '1')
            except Exception:
                logging.exception('Thermostat OFF: cannot force heatdemand')
        elif insidetemp is not None and isfloat(insidetemp):
            low_th  = settemp - safe_float(lohysteresis, 0.0)
            high_th = settemp + safe_float(hihysteresis, 0.1)

            # Turn ON immediately
            if insidetemp < low_th:
                heatdemand_hi_since = None
                try:
                    if GPIO.input(heatdemandpin) != 1:
                        logging.info("Turn on heat demand")
                        gpiocontrol("heatdemand", "1")
                except:
                    logging.error("Set chtemp ERROR")

            # Turn OFF only if above high threshold long enough (debounce)
            elif insidetemp > high_th:
                now_ts = time.time()
                if heatdemand_hi_since is None:
                    heatdemand_hi_since = now_ts
                elif (now_ts - heatdemand_hi_since) >= HEATDEMAND_OFF_DELAY_S:
                    if GPIO.input(heatdemandpin) != 0:
                        logging.info("Turn off heat demand (confirmed)")
                        gpiocontrol("heatdemand", "0")

            else:
                heatdemand_hi_since = None
                logging.info("Thermostat Mode: Don't do anything, the temperature is within the limits of the hysteresis")
    else:
        heatdemand_hi_since = None
        if GPIO.input(heatdemandpin) != 0:
            logging.info("Turn off heat demand")
            gpiocontrol("heatdemand", "0")
    ischanged("hcurve", heatcurve)
    threeway=statusdict['threeway']['value']
    compinfo=statusdict['compinfo']['value']
    pdhw=statusdict['pdhw']['value']
    if len(compinfo) > 0:
        if dhwwl=="1" and compinfo[0] != 0 and threeway == "DHW":
            logging.info("Dont change flimit in DHW mode")
        else:
            tempzone = get_temp_zone(outsidetemp)
            # In warm zone, Quiet-only disables any FLimit automation.
            # In warm zone with Quiet+FLimit, FLimit is forced ON and we disable automation too.
            flimit_allowed_here = True
            if tempzone == 'warm':
                try:
                    _wzm = normalize_zone_mode(zone_warm_mode, 'quiet_flimit')
                    if _wzm == 'quiet':
                        flimit_allowed_here = False
                    elif _wzm == 'quiet_flimit':
                        flimit_allowed_here = False
                except Exception:
                    flimit_allowed_here = True

            if flimit_allowed_here and flimit == "auto" and antionoff != "1" and tempzone == 'normal':
                if outsidetemp >= float(flimittemp):
                    logging.info("Turn on freq limit")
                    flimitchange("1")
                elif outsidetemp <= float(flimittemp)+0.5:
                    logging.info("Turn off freq limit")
                    flimitchange("0")
            # Do not allow automatic preset switching inside Frost/Warm zones
            if presetautochange == "auto" and antionoff != "1" and tempzone == 'normal':
                mode=statusdict['mode']['value']
                if outsidetemp >= float(presetquiet) and mode != "quiet":
                    new_presetchange("quiet")
                elif outsidetemp <= float(presetturbo) and mode != "turbo":
                    new_presetchange("turbo")
                elif outsidetemp > float(presetturbo) and outsidetemp < float(presetquiet) and mode != "eco":
                    new_presetchange("eco")
    last_heatingcurve_mode = heatingcurve
    return heatcurve

def updatecheck():
    gitver=subprocess.run(['git', 'ls-remote', 'origin', '-h', 'refs/heads/'+release ], stdout=subprocess.PIPE).stdout.decode('utf-8')[0:40]
    localver=subprocess.run(['cat', '.git/refs/heads/'+release], stdout=subprocess.PIPE).stdout.decode('utf-8')[0:40]
    if localver != gitver:
        msg=gettext("Available")
    else:
        msg=gettext("Not Available")
    return jsonify(update=msg)

def restart():
    subprocess.Popen("systemctl restart haier.service", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return jsonify(restarted="OK")

def getparams():
    isr241 = 1
    isr141 = 1

    while isr241:
        if len(R241) == 22:
            r241_work = list(R241)
            tdts = PyHaier.GetTdTs(r241_work)
            archerror = PyHaier.GetArchError(r241_work)
            compinfo = PyHaier.GetCompInfo(r241_work)
            fans = PyHaier.GetFanRpm(r241_work)
            pdps = PyHaier.GetPdPs(r241_work)
            eevlevel = PyHaier.GetEEVLevel(r241_work)
            tsatpd = PyHaier.GetTSatPd(r241_work)
            tsatps = PyHaier.GetTSatPs(r241_work)
            tao = PyHaier.GetTao(r241_work)
            tdef = PyHaier.GetTdef(r241_work)
            firmware = PyHaier.GetFirmware(r241_work)
            isr241 = 0

    while isr141:
        if len(R141) == 16:
            r141_work = list(R141)
            twitwo = PyHaier.GetTwiTwo(r141_work)
            thitho = PyHaier.GetThiTho(r141_work)
            pump = PyHaier.GetPump(r141_work)
            threeway = PyHaier.Get3way(r141_work)
            isr141 = 0

    # Error + LastError: z cache (statusdict), aktualizowane w wątku odczytu pompy
    error = statusdict.get('error', {}).get('value', 'N.A.')
    lasterror = statusdict.get('lasterror', {}).get('value', 'N.A.')

    # Superheat/Subcooling: bierzemy z cache (statusdict), żeby nie liczyć drugi raz w /getparams
    superheat = statusdict.get('superheat', {}).get('value', 'N.A.')
    subcooling = statusdict.get('subcooling', {}).get('value', 'N.A.')

    return twitwo, thitho, tdts, archerror, compinfo, fans, pdps, eevlevel, tsatpd, tsatps, tao, tdef, pump, threeway, error, lasterror, superheat, subcooling, firmware


def getdata():
    """Basic (UI) status payload.

    Intentionally excludes low-level diagnostic fields (archerror/compinfo/error/firmware/etc.).
    For diagnostics use /getparams (and /get_json_data).
    """

    heatdemand = GPIO.input(heatdemandpin)
    cooldemand = GPIO.input(cooldemandpin)
    flimiton = GPIO.input(freqlimitpin)
    flrelay = flimiton

    # --- Current values (cached in statusdict) ---
    intemp = statusdict['intemp']['value']
    outtemp = statusdict['outtemp']['value']
    tempzone = get_temp_zone(outtemp)

    stemp = statusdict['settemp']['value']
    hcurve = statusdict['hcurve']['value']

    dhw = statusdict['dhw']['value']
    tank = statusdict['tank']['value']

    # --- DHW extra cycle indicators (for dashboard notes / button gating) ---
    dhw_ondemand = statusdict.get('dhw_ondemand', {}).get('value', 'off')
    dhw_heater_assist_active = statusdict.get('dhw_heater_assist_active', {}).get('value', 'off')
    anti_legionella_active_state = statusdict.get('anti_legionella_active', {}).get('value', 'off')
    anti_legionella_run_state = statusdict.get('anti_legionella_run', {}).get('value', globals().get('anti_legionella_run', '0'))

    mode = statusdict['mode']['value']
    humid = statusdict['humid']['value']

    pch = statusdict['pch']['value']
    pdhw = statusdict['pdhw']['value']
    pcool = statusdict['pcool']['value']

    # --- Flags from pump (R141/R241 decoded elsewhere) ---
    defrost = statusdict.get('defrost', {}).get('value', 'off')
    antifreeze = statusdict.get('antifreeze', {}).get('value', 'off')
    heater = statusdict.get('heater', {}).get('value', 'off')

    # --- Settings / control ---
    heatingcurve = config['SETTINGS']['heatingcurve']
    flimit = config['SETTINGS']['flimit']
    antionoff = config['SETTINGS']['antionoff']

    # Heat control summary (direct vs curve)
    heatcontrol_state = statusdict.get('heatcontrol', {}).get(
        'value',
        'direct' if str(heatingcurve).strip().lower() == 'directly' else 'curve'
    )

    # Global thermostat gating (0/1)
    thermostat_on_state = str(config['SETTINGS'].get('thermostat_on', globals().get('thermostat_on', '1'))).strip()
    thermostat_on_state = '1' if thermostat_on_state == '1' else '0'

    presetch = presetautochange

    # flimit temperature threshold (rename: ltemp -> fltemp)
    fltemp = flimittemp
    ltemp = fltemp  # backward compatibility for older UI/clients

    # Temp compensation (UI)
    tempcompensation = statusdict.get('tempcompensation', {}).get('value', 'N.A.')
    tempcompensation_set = statusdict.get('tempcompensation_set', {}).get('value', 'N.A.')

    dhwcompensation = statusdict.get('dhwcompensation', {}).get('value', 'N.A.')
    dhwcompensation_set = statusdict.get('dhwcompensation_set', {}).get('value', 'N.A.')

    # Delta (hide when not meaningful)
    # Δt is useful only when the refrigeration circuit is active and the
    # unit is in CH (not DHW) and not defrosting. In these cases we return "N.A.",
    # so the frontend can use a single rule: show Δt only when it's numeric.
    delta = statusdict.get("delta", {}).get("value", "N.A.")
    compinfo = statusdict.get('compinfo', {}).get('value', 'N.A.')
    archerror = statusdict.get('archerror', {}).get('value', 'N.A.')
    error = statusdict.get('error', {}).get('value', 'N.A.')
    lasterror = statusdict.get('lasterror', {}).get('value', 'N.A.')
    firmware = statusdict.get('firmware', {}).get('value', 'N.A.')
    tdef = statusdict.get('tdef', {}).get('value', 'N.A.')
    threeway = statusdict.get('threeway', {}).get('value', 'N.A.')
    defrost = statusdict.get('defrost', {}).get('value', 'off')

    # compressor off
    if isinstance(compinfo, list) and len(compinfo) > 0 and compinfo[0] == 0:
        delta = "N.A."

    # DHW valve position
    try:
        tw = str(threeway).strip().upper()
        if "DHW" in tw or "CWU" in tw:
            delta = "N.A."
    except Exception:
        pass

    # defrost
    if str(defrost).strip().lower() == 'on':
        delta = "N.A."

    # AntiON-OFF disabled
    try:
        if str(antionoff).strip() != '1':
            delta = "N.A."
    except Exception:
        pass

    # Frost/Warm zones (delta is misleading in these modes)
    try:
        tz = get_temp_zone(outsidetemp)
        if tz in ('frost', 'warm'):
            delta = "N.A."
    except Exception:
        pass

    # Keep last numeric delta instead of clearing it. This prevents the UI from
    # showing Δt only for a split second right after a delta recalculation.
    if delta == "N.A.":
        try:
            _last_delta = statusdict.get("delta", {}).get("value", "N.A.")
            if isfloat(_last_delta):
                delta = _last_delta
        except Exception:
            pass

    # --- Push selected values through ischanged() (websocket/MQTT) ---
    ischanged("deltatempturbo", deltatempturbo)
    ischanged("deltatempquiet", deltatempquiet)
    ischanged("deltatempflimit", deltatempflimit)
    ischanged("heatdemand", heatdemand)
    ischanged("cooldemand", cooldemand)
    ischanged("flrelay", flrelay)
    ischanged("pch", pch)
    ischanged("pcool", pcool)
    ischanged("pdhw", pdhw)
    ischanged("antionoff", antionoff)
    ischanged("antionoffdeltatime", antionoffdeltatime)
    ischanged("flimit", flimit)
    ischanged("flimiton", flimiton)
    ischanged("hcurve", hcurve)
    ischanged("humid", humid)
    ischanged("intemp", intemp)
    ischanged("mode", mode)
    ischanged("outtemp", outtemp)
    ischanged("tempzone", tempzone)
    ischanged("settemp", stemp)
    ischanged("tank", tank)
    ischanged("dhw", dhw)
    ischanged("dhw_ondemand", dhw_ondemand)
    ischanged("dhw_heater_assist_active", dhw_heater_assist_active)
    ischanged("anti_legionella_run", anti_legionella_run_state)
    ischanged("anti_legionella_active", anti_legionella_active_state)
    ischanged("delta", delta)
    ischanged("tempcompensation", tempcompensation)
    ischanged("dhwcompensation", dhwcompensation)
    ischanged("defrost", defrost)
    ischanged("antifreeze", antifreeze)
    ischanged("heater", heater)
    ischanged("heatcontrol", heatcontrol_state)

    # NOTE: thermostat_on_state is a config-only flag (not in statusdict), so we don't call ischanged() for it.
    payload = {

        "intemp": intemp,
        "outtemp": outtemp,
        "tempzone": tempzone,
        "setpoint": stemp,
        "hcurve": hcurve,
        "dhw": dhw,
        "tank": tank,
        "dhw_ondemand": dhw_ondemand,
        "dhw_heater_assist_active": dhw_heater_assist_active,
        "anti_legionella_run": anti_legionella_run_state,
        "anti_legionella_active": anti_legionella_active_state,
        "mode": mode,
        "humid": humid,
        "pch": pch,
        "pdhw": pdhw,
        "pcool": pcool,
        "defrost": defrost,
        "antifreeze": antifreeze,
        "heater": heater,
        # settings / control
        "heatingcurve": heatingcurve,
        "heatcontrol": heatcontrol_state,
        "thermostat_on": thermostat_on_state,
        # anti on/off + presets
        "presetch": presetch,
        "presetquiet": presetquiet,
        "presetturbo": presetturbo,
        # flimit
        "flimit": flimit,
        "flimiton": flimiton,
        "flrelay": flrelay,
        "fltemp": fltemp,
        "ltemp": ltemp,  # legacy alias
        # demand + deltas
        "heatdemand": heatdemand,
        "cooldemand": cooldemand,
        "deltatempturbo": deltatempturbo,
        "deltatempquiet": deltatempquiet,
        "deltatempflimit": deltatempflimit,
        "antionoff": antionoff,
        "antionoffdeltatime": antionoffdeltatime,
        "delta": delta,
        # compensation
                "tempcompensation": tempcompensation,
        "dhwcompensation": dhwcompensation,
        "tempcompensation_set": tempcompensation_set,
        "dhwcompensation_set": dhwcompensation_set,
        # diagnostics (compat for older clients)
        "archerror": archerror,
        "compinfo": compinfo,
        "error": error,
        "lasterror": lasterror,
        "firmware": firmware,
        "tdef": tdef,
    }
    return _json_response(payload)

def get_json_data():
    heatdemand = GPIO.input(heatdemandpin)
    cooldemand = GPIO.input(cooldemandpin)
    flimiton = GPIO.input(freqlimitpin)
    flrelay = flimiton
    intemp = statusdict['intemp']['value']
    outtemp = statusdict['outtemp']['value']
    tempzone = get_temp_zone(outtemp)
    stemp = statusdict['settemp']['value']
    hcurve = statusdict['hcurve']['value']
    dhw = statusdict['dhw']['value']
    tank = statusdict['tank']['value']
    mode = statusdict['mode']['value']
    humid = statusdict['humid']['value']
    pch = statusdict['pch']['value']
    pdhw = statusdict['pdhw']['value']
    pcool = statusdict['pcool']['value']

    defrost = statusdict.get('defrost', {}).get('value', 'off')
    antifreeze = statusdict.get('antifreeze', {}).get('value', 'off')
    heater = statusdict.get('heater', {}).get('value', 'off')
    tdef = statusdict.get('tdef', {}).get('value', 'N.A.')
    error = statusdict.get('error', {}).get('value', 'N.A.')
    lasterror = statusdict.get('lasterror', {}).get('value', 'N.A.')
    tempcompensation = statusdict.get('tempcompensation', {}).get('value', 'N.A.')
    tempcompensation_set = statusdict.get('tempcompensation_set', {}).get('value', 'N.A.')

    dhwcompensation = statusdict.get('dhwcompensation', {}).get('value', 'N.A.')
    dhwcompensation_set = statusdict.get('dhwcompensation_set', {}).get('value', 'N.A.')

    presetch = presetautochange
    ltemp = flimittemp

    heatingcurve = config['SETTINGS']['heatingcurve']
    antionoff = config['SETTINGS']['antionoff']
    flimit = config['SETTINGS']['flimit']

    # --- snapshots (spójnie: pracujemy na kopiach list) ---
    r241_work = list(R241) if isinstance(R241, list) else []
    r141_work = list(R141) if isinstance(R141, list) else []

    # R241
    tdts = archerror = compinfo = fans = pdps = eevlevel = tsatpd = tsatps = tao = lasterror = 'N.A.'
    if len(r241_work) == 22:
        tdts = PyHaier.GetTdTs(r241_work)
        archerror = PyHaier.GetArchError(r241_work)
        compinfo = PyHaier.GetCompInfo(r241_work)
        fans = PyHaier.GetFanRpm(r241_work)
        pdps = PyHaier.GetPdPs(r241_work)
        eevlevel = PyHaier.GetEEVLevel(r241_work)
        tsatpd = PyHaier.GetTSatPd(r241_work)
        tsatps = PyHaier.GetTSatPs(r241_work)
        tao = PyHaier.GetTao(r241_work)
        lasterror = PyHaier.GetLastError(r241_work)

    # R141
    twitwo = thitho = pump = threeway = error = 'N.A.'
    if len(r141_work) == 16:
        twitwo = PyHaier.GetTwiTwo(r141_work)
        thitho = PyHaier.GetThiTho(r141_work)
        pump = PyHaier.GetPump(r141_work)
        threeway = PyHaier.Get3way(r141_work)
        error = PyHaier.GetError(r141_work)
        defrost = 'on' if str(PyHaier.GetDefrost(r141_work)).strip().upper() == 'DEFROST' else 'off'
        antifreeze = 'on' if str(PyHaier.GetAntifreeze(r141_work)).strip().upper() == 'ANTIFREEZE' else 'off'

    chkwhpd = statusdict['chkwhpd']['value']
    dhwkwhpd = statusdict['dhwkwhpd']['value']

    # Push selected values through ischanged() (for MQTT/websocket)
    ischanged('deltatempturbo', deltatempturbo)
    ischanged('deltatempquiet', deltatempquiet)
    ischanged('deltatempflimit', deltatempflimit)
    ischanged('heatdemand', heatdemand)
    ischanged('cooldemand', cooldemand)
    ischanged('flrelay', flrelay)
    ischanged('pch', pch)
    ischanged('pcool', pcool)
    ischanged('pdhw', pdhw)
    ischanged('antionoff', antionoff)
    ischanged('antionoffdeltatime', antionoffdeltatime)
    ischanged('flimit', flimit)
    ischanged('flimiton', flimiton)
    ischanged('hcurve', hcurve)
    ischanged('humid', humid)
    ischanged('intemp', intemp)
    ischanged('mode', mode)
    ischanged('outtemp', outtemp)
    ischanged('tempzone', tempzone)
    ischanged('settemp', stemp)
    ischanged('tank', tank)
    ischanged('defrost', defrost)
    ischanged('antifreeze', antifreeze)
    ischanged('heater', heater)
    ischanged('tdef', tdef)
    ischanged('error', error)
    ischanged('lasterror', lasterror)

    return jsonify(locals())

def ischanged(old, new):
    old_value = statusdict[old]['value']
    if old_value != new:
        logging.info("ischanged: status "+str(old)+" has changed. Set new value - "+str(new))
        semit = {str(old): new}
        socketlocal.emit('data_update', semit)
        if remote:
            try:
                semit_remote = dict(semit)
                # Remote-only normalization: keep local types intact, but send strings for GPIO states
                # so frontends don't treat 0 as missing.
                for _k in ('flimiton', 'flrelay', 'heatdemand', 'cooldemand'):
                    if _k in semit_remote:
                        semit_remote[_k] = str(semit_remote[_k])
                sio_emit = {'data_update': semit_remote}
                sio_remote.emit('data_from_device', sio_emit)
            except Exception:
                logging.error("Brak połączenia ze zdalnym serwerem")

            if old == 'pch':
                try:
                    sio_remote.emit('notify_changes', {old: new})
                except Exception:
                    logging.error("Brak połączenia ze zdalnym serwerem")

        statusdict[old]['value'] = new
        queue_pub(old, new)

        # Keep tempzone in sync with outside temperature even when UI does not poll /getdata.
        # This makes Frost/Warm zone UI work purely via WebSocket updates.
        if old == 'outtemp':
            try:
                tz = get_temp_zone(new)
                if 'tempzone' in statusdict:
                    ischanged('tempzone', tz)
            except Exception:
                pass

        # Derived CH/DHW heating activity (for MQTT/HA)
        try:
            if old in ('threeway', 'compinfo', 'pch', 'pdhw', 'pcool', 'heatdemand', 'cooldemand', 'defrost'):
                update_heating_activity()
        except Exception:
            pass


def GetDHT22():
    """Read DHT22 (builtin) values.

    Important: if inside temperature is configured to come from HA (insidetemp != 'builtin'),
    we still read DHT22 to obtain HUMIDITY (when humidity == 'builtin'), but we do NOT overwrite
    the inside temperature value nor its meta/status. This prevents source/status flapping.
    """
    # NOWE Pause DHT22 sampling during defrost: keep the last good values.
    defrost_state = str(statusdict.get("defrost", {}).get("value", "off")).strip().lower()
    threeway_state = str(statusdict.get("threeway", {}).get("value", "")).strip().upper()
    if defrost_state == "on":
        # Keep last good values without marking them as a sensor failure
        return statusdict['intemp']['value'], statusdict['humid']['value']

    if is_raspberrypi():
        dhtexec = 'dht22r'
    else:
        dhtexec = 'dht22n'

    use_intemp = (str(insidetemp).strip().lower() == 'builtin')

    try:
        result = subprocess.check_output('./bin/' + dhtexec)
        parts = result.decode('utf-8').strip().split('#')
        humid_raw = parts[0]
        intemp_raw = parts[1]

        intemp_read = round(float(intemp_raw), 1)
        humid = round(float(humid_raw), 1)

        # Basic sanity checks (DHT22 glitches can return absurd values)
        if not (-30.0 <= intemp_read <= 60.0):
            raise ValueError("DHT22 temp out of range")
        if not (0.0 <= humid <= 100.0):
            raise ValueError("DHT22 humidity out of range")

        # Update inside temperature ONLY when configured to use builtin
        if use_intemp:
            _update_primary_temp('intemp', intemp_read, 'dht22')
            intemp = intemp_read
        else:
            intemp = statusdict['intemp']['value']

    except Exception:
        # Keep last values
        humid = statusdict['humid']['value']
        intemp = statusdict['intemp']['value']

        # Update inside temperature meta ONLY when configured to use builtin
        if use_intemp:
            age = _get_primary_age('intemp')
            # If we have no last-good value (e.g. after reboot) -> use emergency_intemp from config
            emerg = _get_emergency_intemp_value()
            if (age is None or _temp_primary['intemp']['value'] is None) and emerg is not None:
                intemp = emerg
                _set_temp_meta('intemp', 'outdated', src='emergency', age_sec=(TEMP_CACHE_MAX_AGE_SEC + 1))
            else:
                if age is None:
                    _set_temp_meta('intemp', 'outdated', src='missing', age_sec=TEMP_CACHE_MAX_AGE_SEC + 1)
                elif age <= TEMP_CACHE_MAX_AGE_SEC:
                    _set_temp_meta('intemp', 'forced', src='cache', age_sec=age)
                else:
                    _set_temp_meta('intemp', 'outdated', src='cache', age_sec=age)

    # Publish values
    if use_intemp:
        ischanged("intemp", intemp)
    ischanged("humid", humid)

    return intemp, humid


def GetInsideTemp(param):
    if param == "builtin":
        intemp=statusdict['intemp']['value']
        return intemp
    elif param == "ha":
        # connect to Home Assistant API and get status of inside temperature entity
        url=config['HOMEASSISTANT']['HAADDR']+":"+config['HOMEASSISTANT']['HAPORT']+"/api/states/"+config['HOMEASSISTANT']['insidesensor']
        headers = requests.structures.CaseInsensitiveDict()
        headers["Accept"] = "application/json"
        headers["Authorization"] = "Bearer "+config['HOMEASSISTANT']['KEY']
        try:
            resp=requests.get(url, headers=headers)
            json_str = json.dumps(resp.json())
        except requests.exceptions.RequestException as e:
            logging.error(e)
        try:
            if 'state' in json_str:
                raw = json.loads(json_str).get('state', None)

                # HA can briefly return "NaN" / "unknown" (e.g. during defrost) – keep last good value.
                f = float(raw)
                if (not math.isfinite(f)) or math.isnan(f):
                    raise ValueError("HA returned NaN/inf")
                # Sanity range (inside air)
                if not (-40.0 <= f <= 80.0):
                    raise ValueError("Inside temp out of range")
                response = round(f, 1)
            else:
                logging.error("Entity state not found")
                return statusdict['intemp']['value']
        except Exception as e:
            logging.warning(f"GetInsideTemp(ha): keeping last value (invalid state): {e}")
            age = _get_primary_age('intemp')
            if age is None:
                emerg = _get_emergency_intemp_value()
                if emerg is not None:
                    _set_temp_meta('intemp', 'outdated', src='emergency', age_sec=(TEMP_CACHE_MAX_AGE_SEC + 1))
                    ischanged('intemp', emerg)
                    return emerg
                _set_temp_meta('intemp', 'outdated', src='missing', age_sec=TEMP_CACHE_MAX_AGE_SEC + 1)
                return statusdict['intemp']['value']
            if age <= TEMP_CACHE_MAX_AGE_SEC:
                _set_temp_meta('intemp', 'forced', src='cache', age_sec=age)
                return _temp_primary['intemp']['value'] if _temp_primary['intemp']['value'] is not None else statusdict['intemp']['value']
            _set_temp_meta('intemp', 'outdated', src='cache', age_sec=age)
            return _temp_primary['intemp']['value'] if _temp_primary['intemp']['value'] is not None else statusdict['intemp']['value']

        _update_primary_temp('intemp', response, 'ha')
        ischanged("intemp", response)
        return response
    else:
        return statusdict['intemp']['value']

def GetDHWTemp(param):
    """Get DHW (CWU) current temperature for indication.

    Sources:
      - 'builtin' (default): value from heat pump registers (PyHaier.GetDHWCurTemp)
      - 'ha': Home Assistant REST API entity (config[HOMEASSISTANT]['dhwsensor'])
    """
    try:
        mode = str(param).strip().lower()
    except Exception:
        mode = 'builtin'

    if mode != "ha":
        return statusdict.get('tank', {}).get('value', 'N.A.')

    # Read entity from HA
    entity = ""
    try:
        entity = config['HOMEASSISTANT'].get('dhwsensor', '').strip()
        
    except Exception:
        entity = ""

    if not entity:
        logging.error("GetDHWTemp(ha): missing HOMEASSISTANT.dhwsensor in config - keeping last value")
        return statusdict.get('tank', {}).get('value', 'N.A.')

    url = config['HOMEASSISTANT']['HAADDR']+":"+config['HOMEASSISTANT']['HAPORT']+"/api/states/"+entity
    headers = requests.structures.CaseInsensitiveDict()
    headers["Accept"] = "application/json"
    headers["Authorization"] = "Bearer "+config['HOMEASSISTANT']['KEY']

    try:
        resp = requests.get(url, headers=headers, timeout=3)
        j = resp.json()
        raw = j.get('state', None)
        f = float(raw)
        if (not math.isfinite(f)) or math.isnan(f):
            raise ValueError("HA returned NaN/inf")
        # Sanity range for DHW tank temp
        if not (-10.0 <= f <= 110.0):
            raise ValueError("DHW temp out of range")
        response = round(f, 1)
        ischanged("tank", response)
        return response
    except Exception as e:
        logging.warning(f"GetDHWTemp(ha): keeping last value (invalid state): {e}")
        return statusdict.get('tank', {}).get('value', 'N.A.')

def GetOutsideTemp(param):
    def _try_ds18b20():
        try:
            sensor = W1ThermSensor()
            temperature = sensor.get_temperature()
            if -55.0 <= float(temperature) <= 125.0:
                return round(float(temperature), 1)
            logging.error("DS18b20: temperature out of range -55 to 125°C")
        except Exception:
            logging.error("Error: cannot read outside temperature (DS18B20)")
        return None

    def _try_ha():
        try:
            # connect to Home Assistant API and get status of outside temperature entity
            url = config['HOMEASSISTANT']['HAADDR']+":"+config['HOMEASSISTANT']['HAPORT']+"/api/states/"+config['HOMEASSISTANT']['outsidesensor']
            headers = requests.structures.CaseInsensitiveDict()
            headers["Accept"] = "application/json"
            headers["Authorization"] = "Bearer "+config['HOMEASSISTANT']['KEY']
            resp = requests.get(url, headers=headers, timeout=3)
            j = resp.json()
            raw = j.get('state', None)
            f = float(raw)
            if (not math.isfinite(f)) or math.isnan(f):
                raise ValueError("HA returned NaN/inf")
            if not (-55.0 <= f <= 125.0):
                raise ValueError("Outside temp out of range")
            return round(f, 1)
        except Exception as e:
            logging.warning(f"GetOutsideTemp(ha): invalid/missing state: {e}")
            return None

    def _try_tao():
        v = statusdict.get('tao', {}).get('value', None)
        try:
            f = float(v)
            if math.isfinite(f) and (not math.isnan(f)) and (-55.0 <= f <= 125.0):
                return round(f, 1)
        except Exception:
            pass
        return None

    # Determine priority order from configured param
    order = []
    if param == 'ha':
        order = ['ha', 'ds18b']
    elif param == 'builtin':
        order = ['ds18b', 'ha']
    elif param == 'tao':
        order = ['tao']
    else:
        # other modes (e.g. openmeteo) keep existing value + meta only
        order = []

    # 1) Try configured source + secondary (ds18b/ha)
    for src in order:
        if src == 'ds18b':
            t = _try_ds18b20()
            if t is not None:
                _update_primary_temp('outtemp', t, 'ds18b')
                primary_src = 'ha' if param == 'ha' else ('ds18b' if param == 'builtin' else ('tao' if param == 'tao' else None))
                if primary_src is not None and primary_src != 'ds18b':
                    _set_temp_meta('outtemp', 'forced', src='ds18b', age_sec=0)
                ischanged('outtemp', t)
                return t
        elif src == 'ha':
            t = _try_ha()
            if t is not None:
                _update_primary_temp('outtemp', t, 'ha')
                primary_src = 'ha' if param == 'ha' else ('ds18b' if param == 'builtin' else ('tao' if param == 'tao' else None))
                if primary_src is not None and primary_src != 'ha':
                    _set_temp_meta('outtemp', 'forced', src='ha', age_sec=0)
                ischanged('outtemp', t)
                return t
        elif src == 'tao':
            t = _try_tao()
            if t is not None:
                # Tao explicitly configured as a primary source
                _update_primary_temp('outtemp', t, 'tao')
                ischanged('outtemp', t)
                return t

    # 2) Fallback to last primary for up to 30 minutes
    age = _get_primary_age('outtemp')
    if age is not None and _temp_primary['outtemp']['value'] is not None and age <= TEMP_CACHE_MAX_AGE_SEC:
        _set_temp_meta('outtemp', 'forced', src='cache', age_sec=age)
        return _temp_primary['outtemp']['value']

    # 3) After 30 minutes without primary -> use Tao (if available) and mark as stale (blink)
    tao = _try_tao()
    if tao is not None:
        # Store last seen Tao so we don't revert to an older DS/HA value if Tao disappears later
        _update_primary_temp('outtemp', tao, 'tao')
        # _update_primary_temp set status=ok; override with outdated because Tao is a fallback here
        _set_temp_meta('outtemp', 'outdated', src='tao', age_sec=0)
        ischanged('outtemp', tao)
        return tao

    # 4) If Tao missing too: keep last known value but mark stale
    if age is None:
        _set_temp_meta('outtemp', 'outdated', src='missing', age_sec=TEMP_CACHE_MAX_AGE_SEC + 1)
        return statusdict['outtemp']['value']

    _set_temp_meta('outtemp', 'outdated', src='cache', age_sec=age)
    return _temp_primary['outtemp']['value'] if _temp_primary['outtemp']['value'] is not None else statusdict['outtemp']['value']

def GetHumidity(param):
    if param == "builtin":
        humid=statusdict['humid']['value']
        return humid
    elif param == "ha":
        # connect to Home Assistant API and get status of inside humidity entity
        url=config['HOMEASSISTANT']['HAADDR']+":"+config['HOMEASSISTANT']['HAPORT']+"/api/states/"+config['HOMEASSISTANT']['humiditysensor']
        headers = requests.structures.CaseInsensitiveDict()
        headers["Accept"] = "application/json"
        headers["Authorization"] = "Bearer "+config['HOMEASSISTANT']['KEY']
        try:
            resp = requests.get(url, headers=headers)
            json_str = json.dumps(resp.json())
        except requests.exceptions.RequestException as e:
            logging.error(e)
        try:
            if 'state' in json_str:
                raw = json.loads(json_str).get('state', None)

                # Keep last good value if HA returns non-numeric ("unknown", "unavailable", "N.A.")
                f = float(raw)
                if (not math.isfinite(f)) or math.isnan(f):
                    raise ValueError("HA returned NaN/inf")
                if not (0.0 <= f <= 100.0):
                    raise ValueError("Humidity out of range")
                response = round(f, 1)
            else:
                logging.error("GetHumidity: Entity state not found")
                return statusdict['humid']['value']
        except Exception as e:
            logging.warning(f"GetHumidity(ha): keeping last value (invalid state): {e}")
            return statusdict['humid']['value']

        ischanged("humid", response)
        return response
    else:
        return statusdict['humid']['value']

def settheme(theme):
    statusdict['theme']['value']=theme
    return theme
        
def flimitreset():
    """ 
    Wyłączanie ograniczenia częstotliwości, jeśli kompresor nie pracuje 
    i anty on-off jest aktywne.
    """

    # When TempZone is configured as "Quiet + FLimit" we *force* FLimit relay ON,
    # so this helper must not override it.
    try:
        _z = get_temp_zone(statusdict.get('outtemp', {}).get('value', None))
        if _z in ('frost', 'warm') and _zone_force_quiet_flimit(_z):
            return
    except Exception:
        pass

    # Pobranie wartości z statusdict
    compinfo = statusdict.get('compinfo', {}).get('value', "N.A")
    pump_info = statusdict.get('pump', {})

    # Pobranie pierwszego elementu z listy compinfo (jeśli istnieje)
    if isinstance(compinfo, list) and len(compinfo) > 0:
        comp_status = compinfo[0]  # Pobieramy pierwszy element
    else:
        comp_status = "N.A"  # Jeśli `compinfo` nie jest listą lub jest puste, zwracamy "N.A"

    # Jeśli kompresor pracuje (comp_status != 0), kończymy funkcję natychmiast
    if comp_status != 0:
        logging.info(f"Flimitreset: Function inactive.")
        return
        
    # Sprawdzenie czy klucze istnieją w statusdict
    if 'flimiton' in statusdict:
        flimiton = str(statusdict['flimiton'].get('value', "N.A"))
    else:
        logging.warning("Flimitreset: Brak klucza 'flimiton' w statusdict!")
        flimiton = "N.A"

    if 'antionoff' in statusdict:
        antionoff = str(statusdict['antionoff'].get('value', "N.A"))
    else:
        logging.warning("Flimitreset: Brak klucza 'antionoff' w statusdict!")
        antionoff = "N.A"

    if 'flimit' in statusdict:
        flimit = str(statusdict['flimit'].get('value', "N.A"))
    else:
        logging.warning("Flimitreset: Brak klucza 'flimit' w statusdict!")
        flimit = "N.A"
        
    if isinstance(pump_info, dict) and 'value' in pump_info:
        pump = pump_info['value']
    else:
        logging.warning("Flimitreset: Brak klucza 'pump' w statusdict!")
        pump = "N.A."
        

    # Sprawdzenie warunków i wyłączenie ograniczenia częstotliwości
    if flimiton == "1" and antionoff == "1" and flimit != "manual" and pump == "OFF":
        logging.info("Flimitreset: Forcing OFF frequency limit")
        flimitchange("0")
    else:
        logging.info("Flimitreset: No action needed.")

def deltacheck(temps):  # AntiON-OFF, Delta liczona z Zadanej CO i temp. powrotu (Twi)
    global last_check_time, antionoff, antionoffdeltatime, deltatempturbo, deltatempquiet, deltatempflimit

    try:  # Pobranie wartości:
        twitwo = statusdict.get('twitwo', {}).get('value', [None])  # Pobranie temperatury z listy Twi-Two
        compinfo = statusdict.get('compinfo', {}).get('value', [0])  # Status kompresora
        mode = statusdict.get('mode', {}).get('value', "")  # Tryb pracy pompy
        threeway = statusdict.get('threeway', {}).get('value', "")  # Status zaworu 3-drożnego
        flimiton = statusdict.get('flimiton', {}).get('value', "0")  # Status przekaźnika
        current_time = time.time()

        mode = str(mode).strip().lower()
        threeway = str(threeway).strip().upper()

        # Temperature zones
        outtemp_val = statusdict.get('outtemp', {}).get('value', None)
        zone = get_temp_zone(outtemp_val)
        if zone in ('frost', 'warm'):
            # In frost & warm zones we do not run Anti ON-OFF / delta logic at all
            last_check_time = current_time
            return

        # NOWE Pause AntiON-OFF / DeltaCheck during defrost (disturbance)
        _defrost = str(statusdict.get('defrost', {}).get('value', 'off')).strip().lower()
        if _defrost == 'on':
            logging.info('AntiON-OFF: Defrost active - paused')
            last_check_time = current_time
            return

        if threeway != "CH":
            last_check_time = current_time
            return

        if compinfo[0] == 0:
            last_check_time = current_time
            return

        hcurve = None
        if isfloat(statusdict.get('hcurve', {}).get('value', "N.A")):
            hcurve = float(statusdict['hcurve']['value'])
            
                     
        # Sprawdzenie warunków do uruchomienia funkcji:
        if antionoff == '1' and compinfo[0] != 0 and threeway == "CH" and hcurve is not None and twitwo[0] is not None:
            logging.info("AntiON-OFF: Function is active")
            

            # Sprawdzenie, czy minął wymagany czas:
            if current_time - last_check_time >= float(antionoffdeltatime) * 60:  # Czas w minutach podawany w Ustawieniach
                logging.info(f"AntiON-OFF: Taken values ​​to calculate the delta: Twi: {twitwo[0]}, Set temp: {hcurve}")  # Jakie wartości są pobierane do liczenia delty.
                delta = round(hcurve - twitwo[0], 1)  # Wynik
                logging.info(f"AntiON-OFF: Delta is: {delta} and current mode: {mode} and frequency limit: {flimiton}")  # Informacja o wyniku i trybie jednostki
                ischanged("delta", delta)
                ischanged("deltatempquiet", deltatempquiet)
                ischanged("deltatempturbo", deltatempturbo)
                ischanged("deltatempflimit", deltatempflimit)

                # Sprawdzanie czy wartości są liczbami:
                if isfloat(deltatempflimit) and isfloat(deltatempturbo) and isfloat(deltatempquiet):
                    deltatempflimit = float(deltatempflimit)
                    deltatempturbo = float(deltatempturbo)
                    deltatempquiet = float(deltatempquiet)

                    # Zmiana trybu pracy pompy
                    if delta > deltatempturbo:
                        if mode != 'turbo':
                            logging.info(f"AntiON-OFF: Delta {delta} > {deltatempturbo}, changing mode to Turbo")
                            new_presetchange('turbo')
                        else:
                            logging.info('AntiON-OFF: No need to change mode (already Turbo).')

                    elif deltatempquiet <= delta <= deltatempturbo:
                        if mode != 'eco':
                            logging.info(f"AntiON-OFF: Delta {delta} is in range ({deltatempquiet}, {deltatempturbo}), changing mode to Eco")
                            new_presetchange('eco')
                        else:
                            logging.info(f"AntiON-OFF: Delta is {delta}, no need to change mode (already Eco).")

                    elif delta < deltatempquiet:
                        if mode != 'quiet':
                            logging.info(f"AntiON-OFF: Delta {delta} is in range ({deltatempflimit}, {deltatempquiet}), changing mode to Quiet")
                            new_presetchange('quiet')
                        else:
                            logging.info('AntiON-OFF: No need to change mode (already Quiet).')

                    # Sterowanie ograniczeniem częstotliwości (FLimit) deltą.
                    if str(flimit).strip().lower() not in ('manual','off'):
                        if delta < deltatempflimit:
                            if flimiton != "1":
                                logging.info(f"AntiON-OFF: Delta {delta} < {deltatempflimit}, turning ON frequency limit")
                                flimitchange("1")
                            else:
                                logging.info(f"AntiON-OFF: Frequency limit already ON, no action needed.")
                        elif delta > deltatempflimit:
                            if flimiton != "0":
                                logging.info(f"AntiON-OFF: Delta {delta} > {deltatempflimit}, turning OFF frequency limit")
                                flimitchange("0")
                            else:
                                logging.info(f"AntiON-OFF: Frequency limit already OFF, no action needed.")

                else:
                    logging.error("AntiON-OFF: One or more delta values are not valid numbers!")

                last_check_time = current_time

    except (KeyError, ValueError, TypeError) as e:
        logging.info(f"Error in deltacheck: {e}")

def schedule_write(which, data):
    if which == "ch":
        try:
            f = open("schedule_ch.json", "w")
            f.write(data)
            f.close()
            msg = gettext("Central Heating chedule saved")
            state = "success"
            return msg, state
        except:
            msg = gettext("ERROR: Central Heating not saved")
            state = "error"
            return msg, state
    if which == "dhw":
        try:
            f = open("schedule_dhw.json", "w")
            f.write(data)
            f.close()
            msg = gettext("Domestic Hot Water chedule saved")
            state = "success"
            return msg, state
        except:
            msg = gettext("ERROR: Domestic Hot Water not saved")
            state = "error"
            return msg, state


# --- DHW on-demand helpers ---
def dhw_ondemand_start():
    """Start one-shot DHW heating (bypass DHW scheduler until DHW cycle ends)."""
    global dhw_ondemand_active, dhw_ondemand_seen_dhw, dhw_ondemand_started_ts
    if str(dhwscheduler).strip() != "1":
        return {"ok": False, "msg": "dhwondemand.unavailable", "state": "warning"}
    if str(dhwuse).strip() != "1":
        return {"ok": False, "msg": "dhwondemand.disabled", "state": "warning"}
    # Do not start on-demand if the tank is already near the setpoint (prevents stuck cycle when valve never goes DHW)
    def _parse_temp(v):
        try:
            if v is None: return None
            s = str(v).strip().replace(',', '.')
            if not s: return None
            # extract leading numeric part without regex (e.g. '45.0°C' -> 45.0)
            buf = []
            seen_digit = False
            for ch in s:
                if ch.isdigit() or ch in '+-.':
                    buf.append(ch)
                    if ch.isdigit():
                        seen_digit = True
                elif seen_digit:
                    break
            if not buf: return None
            return float(''.join(buf))
        except Exception:
            return None

    try:
        sp = _parse_temp(statusdict.get('dhw', {}).get('value', None))
        cur = _parse_temp(statusdict.get('tank', {}).get('value', None))
        if sp is not None and cur is not None:
            if (sp - cur) < float(DHW_ONDEMAND_MIN_DELTA):
                return {"ok": False, "msg": "dhwondemand.too_warm", "state": "warning"}
    except Exception:
        pass

    with dhw_ondemand_lock:
        if dhw_ondemand_active:
            return {"ok": True, "msg": "dhwondemand.already", "state": "info"}
        dhw_ondemand_active = True
        dhw_ondemand_seen_dhw = False
        dhw_ondemand_started_ts = time.time()
    try:
        ischanged('dhw_ondemand', 'on')
    except Exception:
        pass
    try:
        # Force DHW ON now (scheduler is bypassed while on-demand is active).
        statechange("pdhw", "on", "1")
    except Exception:
        logging.exception("DHW on-demand: failed to start PDHW")
        with dhw_ondemand_lock:
            dhw_ondemand_active = False
            dhw_ondemand_seen_dhw = False
            dhw_ondemand_started_ts = 0.0
        try:
            ischanged('dhw_ondemand', 'off')
        except Exception:
            pass
        return {"ok": False, "msg": "dhwondemand.error", "state": "danger"}
    logging.info("DHW on-demand: started")
    return {"ok": True, "msg": "dhwondemand.started", "state": "success"}

def dhw_ondemand_tick(current_threeway=None):
    """Called periodically. Ends on-demand when 3-way valve leaves DHW (DHW -> CH)."""
    global dhw_ondemand_active, dhw_ondemand_seen_dhw, dhw_ondemand_started_ts
    # If DHW scheduler is disabled at runtime, immediately drop on-demand.
    if str(dhwscheduler).strip() != "1":
        with dhw_ondemand_lock:
            dhw_ondemand_active = False
            dhw_ondemand_seen_dhw = False
            dhw_ondemand_started_ts = 0.0
        try:
            ischanged('dhw_ondemand', 'off')
        except Exception:
            pass
        return

    with dhw_ondemand_lock:
        if not dhw_ondemand_active:
            return
        started_ts = float(dhw_ondemand_started_ts or 0.0)
        seen_dhw = bool(dhw_ondemand_seen_dhw)

    # Safety timeout (avoid being stuck forever).
    if started_ts and (time.time() - started_ts) > DHW_ONDEMAND_MAX_SEC:
        logging.warning("DHW on-demand: safety timeout -> stopping bypass")
        with dhw_ondemand_lock:
            dhw_ondemand_active = False
            dhw_ondemand_seen_dhw = False
            dhw_ondemand_started_ts = 0.0
        try:
            ischanged('dhw_ondemand', 'off')
        except Exception:
            pass
        return

    if current_threeway is None:
        current_threeway = statusdict.get('threeway', {}).get('value', '')
    tw = str(current_threeway).strip().upper()

    if tw == 'DHW':
        if not seen_dhw:
            logging.info('DHW on-demand: valve switched to DHW (cycle running)')
        with dhw_ondemand_lock:
            dhw_ondemand_seen_dhw = True
        return

    # End condition: we have observed DHW mode at least once, and now valve is no longer DHW.
    if seen_dhw and tw != 'DHW':
        logging.info('DHW on-demand: cycle finished (valve left DHW) -> return to schedule')
        with dhw_ondemand_lock:
            dhw_ondemand_active = False
            dhw_ondemand_seen_dhw = False
            dhw_ondemand_started_ts = 0.0
        try:
            ischanged('dhw_ondemand', 'off')
        except Exception:
            pass


# --- DHW electric heater control: heater assist + Anti-legionella ---
def _parse_temp_token(v):
    """Parse temperature from various string forms (e.g. '45.0', '45.0°C', 'N.A.')."""
    try:
        if v is None:
            return None
        s = str(v).strip().replace(',', '.')
        if s == '' or s.lower() in ('n.a.', 'na', 'none', 'nan'):
            return None
        # extract leading numeric part without regex (keep lightweight)
        buf = []
        seen_digit = False
        for ch in s:
            if ch.isdigit() or ch in '+-.':
                buf.append(ch)
                if ch.isdigit():
                    seen_digit = True
            elif seen_digit:
                break
        if not buf:
            return None
        val = float(''.join(buf))
        if not math.isfinite(val):
            return None
        return val
    except Exception:
        return None


def _hp_ready_for_setters() -> bool:
    try:
        return isinstance(R101, list) and len(R101) == 6
    except Exception:
        return False


def _set_pump_direct(on: bool) -> bool:
    """Force circulation pump ON/OFF (best-effort)."""
    global R101
    if not _hp_ready_for_setters():
        return False
    try:
        frame = PyHaier.SetPump(R101, 1 if on else 0)
        if frame == "ERROR":
            return False
        return bool(set_newframe(R101, frame))
    except Exception:
        logging.exception("SetPump failed")
        return False


def _set_heater_direct(on: bool) -> bool:
    """Force electric heater ON/OFF (best-effort). Turning ON expects pump running."""
    global R101
    if not _hp_ready_for_setters():
        return False
    try:
        frame = PyHaier.SetHeater(R101, 1 if on else 0)
        if frame == "ERROR":
            return False
        return bool(set_newframe(R101, frame))
    except Exception:
        logging.exception("SetHeater failed")
        return False


def _service_tests_active() -> bool:
    try:
        return (
            str(statusdict.get('service_set_pump', {}).get('value', 'off')).lower() == 'on' or
            str(statusdict.get('service_set_heater', {}).get('value', 'off')).lower() == 'on'
        )
    except Exception:
        return False


def _dhw_heater_assist_stop(reason: str = '') -> None:
    """Stop heater assist and (only if we forced the heater ON) turn it OFF."""
    global dhw_heater_assist_active, _dhw_assist_started_ts, _dhw_assist_forced_heater
    try:
        if _dhw_assist_forced_heater:
            _set_heater_direct(False)
    except Exception:
        pass

    _dhw_assist_started_ts = 0.0
    _dhw_assist_forced_heater = False

    if dhw_heater_assist_active:
        dhw_heater_assist_active = False
        try:
            ischanged('dhw_heater_assist_active', 'off')
        except Exception:
            pass
        logging.info('DHW heater assist: stopped%s', f' ({reason})' if reason else '')


def dhw_heater_assist_tick() -> None:
    """Periodic loop: if PDHW is ON and outtemp is below threshold, enable heater after delay."""
    global dhw_heater_assist_active, _dhw_assist_prev_pdhw, _dhw_assist_started_ts, _dhw_assist_forced_heater

    try:
        # Do not interfere with service tests
        if _service_tests_active():
            _dhw_heater_assist_stop('service_test')
            _dhw_assist_prev_pdhw = str(statusdict.get('pdhw', {}).get('value', 'off')).lower()
            return

        # Anti-legionella has priority over assist
        if bool(globals().get('anti_legionella_active', False)) or str(globals().get('anti_legionella_run', '0')).strip() == '1':
            # Do not fight heater state here; anti-legionella controls it.
            if dhw_heater_assist_active or _dhw_assist_forced_heater:
                _dhw_heater_assist_stop('anti_legionella')
            _dhw_assist_prev_pdhw = str(statusdict.get('pdhw', {}).get('value', 'off')).lower()
            return

        enabled = str(globals().get('dhw_heater_assist_enable', '0')).strip() == '1'
        if not enabled:
            _dhw_heater_assist_stop('disabled')
            _dhw_assist_prev_pdhw = str(statusdict.get('pdhw', {}).get('value', 'off')).lower()
            return

        if str(globals().get('dhwuse', '1')).strip() != '1':
            _dhw_heater_assist_stop('dhwuse_off')
            _dhw_assist_prev_pdhw = str(statusdict.get('pdhw', {}).get('value', 'off')).lower()
            return

        pdhw = str(statusdict.get('pdhw', {}).get('value', 'off')).lower()

        # OUTTEMP threshold is REQUIRED when enabled.
        thr = _parse_temp_token(str(globals().get('dhw_heater_assist_below_temp', '')).strip())
        outtemp = _parse_temp_token(statusdict.get('outtemp', {}).get('value', None))

        cond = (pdhw == 'on') and (thr is not None) and (outtemp is not None) and (outtemp <= thr)

        # Detect start edge (PDHW OFF->ON or cond false->true)
        if cond and (_dhw_assist_started_ts <= 0.0):
            _dhw_assist_started_ts = time.time()
        if not cond:
            _dhw_heater_assist_stop('conditions_off')
            _dhw_assist_prev_pdhw = pdhw
            return

        # Restart delay on PDHW rising edge
        if cond and _dhw_assist_prev_pdhw != 'on':
            _dhw_assist_started_ts = time.time()

        # After delay, turn heater ON (only if pump is already running)
        if _dhw_assist_started_ts and (time.time() - float(_dhw_assist_started_ts)) >= float(DHW_HEATER_ASSIST_DELAY_SEC):
            pump_on = _svc_is_on(statusdict.get('pump', {}).get('value', 'N.A.'))
            if not pump_on:
                # wait until pump starts (PDHW implies pump/valve should engage)
                if _dhw_assist_forced_heater:
                    _dhw_heater_assist_stop('pump_off')
                    _dhw_assist_prev_pdhw = pdhw
                    return
                _dhw_assist_prev_pdhw = pdhw
                return

            heater_state = str(statusdict.get('heater', {}).get('value', 'off')).lower()
            if heater_state != 'on':
                if _set_heater_direct(True):
                    _dhw_assist_forced_heater = True

            if _dhw_assist_forced_heater and (not dhw_heater_assist_active):
                dhw_heater_assist_active = True
                try:
                    ischanged('dhw_heater_assist_active', 'on')
                except Exception:
                    pass
                logging.info('DHW heater assist: active (outtemp<=thr, PDHW=ON)')

        _dhw_assist_prev_pdhw = pdhw

    except Exception:
        logging.exception('dhw_heater_assist_tick failed')


# ---- Anti-legionella: one-shot DHW cycle to a higher temperature, with heater after delay ----

def _anti_legionella_start() -> None:
    global anti_legionella_active, anti_legionella_started_ts
    global anti_legionella_prev_pdhw, anti_legionella_prev_dhw_sp
    global anti_legionella_heater_started_ts, anti_legionella_forced_heater

    if anti_legionella_active:
        return

    anti_legionella_prev_pdhw = str(statusdict.get('pdhw', {}).get('value', 'off')).lower()
    anti_legionella_prev_dhw_sp = statusdict.get('dhw', {}).get('value', None)
    anti_legionella_forced_heater = False
    anti_legionella_started_ts = time.time()
    anti_legionella_heater_started_ts = 0.0

    # Set DHW setpoint to anti-legionella target
    try:
        target = _parse_temp_token(globals().get('anti_legionella_temp', '60.0'))
        if target is None:
            target = 60.0
        new_tempchange('dhw', f"{float(target):.1f}", '1')
    except Exception:
        logging.exception('Anti-legionella: failed to set DHW target')

    # Force PDHW ON (scheduler is bypassed while active)
    try:
        statechange('pdhw', 'on', '1')
        anti_legionella_heater_started_ts = time.time()
    except Exception:
        logging.exception('Anti-legionella: failed to force PDHW ON')

    anti_legionella_active = True
    try:
        ischanged('anti_legionella_active', 'on')
    except Exception:
        pass
    logging.info('Anti-legionella: started')


def _anti_legionella_finish(reason: str = '') -> None:
    global anti_legionella_active, anti_legionella_started_ts
    global anti_legionella_prev_pdhw, anti_legionella_prev_dhw_sp
    global anti_legionella_heater_started_ts, anti_legionella_forced_heater
    global anti_legionella_run

    # Always reset RUN request to OFF (one-shot). Master enable stays unchanged.
    try:
        if str(globals().get('anti_legionella_run', '0')).strip() == '1':
            globals()['anti_legionella_run'] = '0'
            anti_legionella_run = '0'
            try:
                ischanged('anti_legionella_run', '0')
            except Exception:
                try:
                    queue_pub('anti_legionella_run', '0')
                except Exception:
                    pass
    except Exception:
        pass

    if not anti_legionella_active:
        return

    # Heater OFF (only if we forced it ON)
    try:
        if anti_legionella_forced_heater:
            _set_heater_direct(False)
    except Exception:
        pass

    # Restore previous DHW setpoint
    try:
        prev = _parse_temp_token(anti_legionella_prev_dhw_sp)
        if prev is not None:
            new_tempchange('dhw', f"{float(prev):.1f}", '1')
    except Exception:
        logging.exception('Anti-legionella: failed to restore DHW setpoint')

    # Restore PDHW state (as before start)
    try:
        if str(anti_legionella_prev_pdhw or '').lower() == 'off':
            statechange('pdhw', 'off', '1')
    except Exception:
        logging.exception('Anti-legionella: failed to restore PDHW')

    anti_legionella_active = False
    try:
        ischanged('anti_legionella_active', 'off')
    except Exception:
        pass

    anti_legionella_started_ts = 0.0
    anti_legionella_heater_started_ts = 0.0
    anti_legionella_prev_pdhw = None
    anti_legionella_prev_dhw_sp = None
    anti_legionella_forced_heater = False

    logging.info('Anti-legionella: finished%s', f' ({reason})' if reason else '')


def anti_legionella_tick() -> None:
    """Periodic control loop for one-shot anti-legionella cycle."""
    global anti_legionella_started_ts, anti_legionella_heater_started_ts, anti_legionella_forced_heater

    try:
        # Do not interfere with service tests
        if _service_tests_active():
            if bool(globals().get('anti_legionella_active', False)):
                _anti_legionella_finish('service_test')
            # also clear run request
            try:
                if str(globals().get('anti_legionella_run', '0')).strip() == '1':
                    globals()['anti_legionella_run'] = '0'
                    ischanged('anti_legionella_run', '0')
            except Exception:
                pass
            return

        # Master enable/disable
        enabled = str(globals().get('anti_legionella_enable', '0')).strip() == '1'
        requested = str(globals().get('anti_legionella_run', '0')).strip() == '1'

        # If feature disabled: abort running cycle and clear request
        if not enabled:
            if bool(globals().get('anti_legionella_active', False)):
                _anti_legionella_finish('disabled')
            if requested:
                globals()['anti_legionella_run'] = '0'
                try:
                    ischanged('anti_legionella_run', '0')
                except Exception:
                    pass
            return

        # Manual OFF aborts the cycle
        if (not requested) and bool(globals().get('anti_legionella_active', False)):
            _anti_legionella_finish('switch_off')
            return

        if requested and (not bool(globals().get('anti_legionella_active', False))):
            _anti_legionella_start()

        if not bool(globals().get('anti_legionella_active', False)):
            return

        # Need tank temp
        tank_t = _parse_temp_token(statusdict.get('tank', {}).get('value', None))
        if tank_t is None:
            _anti_legionella_finish('no_tank')
            return

        target = _parse_temp_token(globals().get('anti_legionella_temp', '60.0'))
        if target is None:
            target = 60.0

        # Safety timeout
        if anti_legionella_started_ts and (time.time() - float(anti_legionella_started_ts)) >= float(ANTI_LEGIONELLA_MAX_SEC):
            _anti_legionella_finish('timeout')
            return

        # Ensure PDHW remains ON during the cycle
        try:
            if str(statusdict.get('pdhw', {}).get('value', 'off')).lower() != 'on':
                statechange('pdhw', 'on', '1')
        except Exception:
            pass

        # Heater ON after delay (and only when pump is running)
        if anti_legionella_heater_started_ts and (time.time() - float(anti_legionella_heater_started_ts)) >= float(ANTI_LEGIONELLA_DELAY_SEC):
            if not anti_legionella_forced_heater:
                pump_on = _svc_is_on(statusdict.get('pump', {}).get('value', 'N.A.'))
                if pump_on:
                    heater_state = str(statusdict.get('heater', {}).get('value', 'off')).lower()
                    if heater_state != 'on':
                        if _set_heater_direct(True):
                            anti_legionella_forced_heater = True

        # End condition
        if float(tank_t) >= float(target):
            _anti_legionella_finish('reached')
            return

    except Exception:
        logging.exception('anti_legionella_tick failed')

def scheduler():
    if chscheduler == "1":
        f=open('schedule_ch.json', 'r')
        data = json.load(f)
        now=datetime.now().strftime("%H:%M")
        weekday=datetime.weekday(datetime.now())
        pch=statusdict['pch']['value']
        schedulestart=[]
        for x in range(len(data[weekday]['periods'])):
            y=x-1
            start=data[weekday]['periods'][y]['start']
            end=data[weekday]['periods'][y]['end']
            if end >= now >= start:
                if pch == 'off':
                    schedulestart.append('on')
                    temp=data[weekday]['periods'][y]['title']
                else:
                    schedulestart.append('aon')
                    temp=data[weekday]['periods'][y]['title']
            else:
                if pch == 'on':
                    schedulestart.append('off')
                else:
                    schedulestart.append('aoff')
        if 'on' in schedulestart:
            logging.info("Scheduler: START CH")
            statechange("pch", "on", "1")
            if not temp == "":
                logging.info(f"Scheduler: Set new temp: {temp}")
                new_tempchange("heat",format(float(temp)),"0")
        elif 'aon' in schedulestart:
            logging.info("Scheduler: CH ALREADY ON")
            if not temp == "":
                stemp=statusdict['settemp']['value']
                if not stemp == temp:
                    logging.info(f"Scheduler: Set new temp: {temp}")
                    new_tempchange("heat",format(float(temp)),"0")
        elif 'aoff' in schedulestart:
            logging.info("Scheduler: CH ALREADY OFF")
        else:
            if pch != 'off':
                logging.info("Scheduler: STOP CH")
                statechange("off", "off", "1")
    if dhwscheduler == "1":
        # DHW on-demand: bypass DHW scheduler until the DHW cycle ends (3-way valve leaves DHW)
        with dhw_ondemand_lock:
            _od = bool(dhw_ondemand_active)
        if _od:
            logging.debug('Scheduler: DHW on-demand active, skipping DHW schedule')
        else:
            # Skip DHW schedule while anti-legionella is active/requested
            if bool(globals().get('anti_legionella_active', False)) or str(globals().get('anti_legionella_run', '0')).strip() == '1':
                logging.debug('Scheduler: anti-legionella active/requested, skipping DHW schedule')
                return

            f=open('schedule_dhw.json', 'r')
            data = json.load(f)
            now=datetime.now().strftime("%H:%M")
            weekday=datetime.weekday(datetime.now())
            pdhw=statusdict['pdhw']['value']
            schedulestart=[]
            for x in range(len(data[weekday]['periods'])):
                y=x-1
                start=data[weekday]['periods'][y]['start']
                end=data[weekday]['periods'][y]['end']
                if end >= now >= start:
                    if pdhw == 'off':
                        schedulestart.append('on')
                    else:
                        schedulestart.append('aon')
                else:
                    if pdhw == 'on':
                        schedulestart.append('off')
                    else:
                        schedulestart.append('aoff')
            if 'on' in schedulestart:
                logging.info("Scheduler: START DHW")
                statechange("pdhw", "on", "1")
            elif 'aon' in schedulestart:
                logging.info("Scheduler: DHW ALREADY ON")
            elif 'aoff' in schedulestart:
                logging.info("Scheduler: DHW ALREADY OFF")
            else:
                logging.info("Scheduler: STOP DHW")
                statechange("pdhw", "off", "1")


def GetParametersNEW(reg):
    regnum = len(reg)
    logging.debug(reg)
    
    if regnum == 6:
        dhw = PyHaier.GetDHWTemp(reg)
        powerstate = PyHaier.GetState(reg)
        ischanged("dhw", dhw)
        
        tempcomp = PyHaier.GetTempCompensation(reg)
        ischanged("tempcompensation", tempcomp)

        dhwcomp = PyHaier.GetDHWCompensation(reg)
        ischanged("dhwcompensation", dhwcomp)

        # Determine active requests from raw state bits (avoid treating "Heat OFF" as active heating)
        try:
            state_byte = int(reg[0]) & 0xFF
        except Exception:
            state_byte = 0

        is_on = bool(state_byte & 0x01)
        is_cool_req = bool(state_byte & 0x02)
        is_heat_req = bool(state_byte & 0x04)
        is_tank_req = bool(state_byte & 0x80)

        # If both HEAT and COOL are set, treat it as neither (commonly Tank-only transitions)
        heat_on = is_on and is_heat_req and (not is_cool_req)
        cool_on = is_on and is_cool_req and (not is_heat_req)
        tank_on = is_on and is_tank_req

        ischanged("pch", "on" if heat_on else "off")
        ischanged("pcool", "on" if cool_on else "off")
        ischanged("pdhw", "on" if tank_on else "off")

        # Publish consolidated HVAC/DHW modes for HA (and other MQTT clients)
        global last_mode_active_ts
        if use_mqtt == "1":
            now_ts = time.time()
            if heat_on:
                last_mode_active_ts = now_ts
                mqtt_publish_raw("/ch/mode/state", "heat", qos=1, retain=True)
            elif cool_on:
                last_mode_active_ts = now_ts
                mqtt_publish_raw("/ch/mode/state", "cool", qos=1, retain=True)
            else:
                # publish OFF only after a short debounce (prevents 1-frame glitches)
                if now_ts - last_mode_active_ts > 5:
                    mqtt_publish_raw("/ch/mode/state", "off", qos=1, retain=True)

            mqtt_publish_raw("/dhw/mode/state", "heat" if tank_on else "off", qos=1, retain=True)

    elif regnum == 16:
        tank = PyHaier.GetDHWCurTemp(reg)
        twitwo = PyHaier.GetTwiTwo(reg)
        thitho = PyHaier.GetThiTho(reg)
        pump = PyHaier.GetPump(reg)
        threeway = PyHaier.Get3way(reg)
        heater = PyHaier.GetHeater(reg)
        heater = 'on' if str(heater).strip().upper() == 'ON' else 'off'
        
        # If DHW temperature indication comes from Home Assistant, do not overwrite it with the value read from pump registers.
        if str(dhwtemp).strip().lower() != "ha":
            ischanged("tank", tank)
        ischanged("twitwo", twitwo)
        ischanged("thitho", thitho)
        ischanged("pump", pump)
        ischanged("threeway", threeway)
        ischanged("heater", heater)
        
        # R141 flags (now separate in PyHaier): defrost / antifreeze / active error
        defrost = PyHaier.GetDefrost(reg)
        antifreeze = PyHaier.GetAntifreeze(reg)

        ischanged("defrost", "on" if str(defrost).strip().upper() == "DEFROST" else "off")
        ischanged("antifreeze", "on" if str(antifreeze).strip().upper() == "ANTIFREEZE" else "off")

        # Active error (current)
        err = PyHaier.GetError(reg)
        if isinstance(err, (int, float)):
            err = int(err)
        ischanged("error", err)

    elif regnum == 1:
        mode = PyHaier.GetMode(reg)
        ischanged("mode", mode)

    elif regnum == 22:
        reg_work = list(reg)

        firmware = PyHaier.GetFirmware(reg_work)
        tdef = PyHaier.GetTdef(reg_work)

        # Last (confirmed) error from R241 block
        lasterror = PyHaier.GetLastError(reg_work)
        ischanged("lasterror", lasterror)

        tdts = PyHaier.GetTdTs(reg_work)
        archerror = PyHaier.GetArchError(reg_work)
        compinfo = PyHaier.GetCompInfo(reg_work)
        fans = PyHaier.GetFanRpm(reg_work)
        pdps = PyHaier.GetPdPs(reg_work)
        eevlevel = PyHaier.GetEEVLevel(reg_work)
        tsatpd = PyHaier.GetTSatPd(reg_work)
        tsatps = PyHaier.GetTSatPs(reg_work)
        tao = PyHaier.GetTao(reg_work)
        if isinstance(tdef, (int, float)):
            ischanged("tdef", tdef)

        # NOWE Superheating / Subcooling
        thitho = statusdict.get("thitho", {}).get("value", [None, None])
        superheat, subcooling = compute_superheat_subcooling(tdts, tsatps, tsatpd, thitho)

        ischanged("superheat", superheat)
        ischanged("subcooling", subcooling)
        ischanged("tdef", tdef)
        ischanged("tdts", tdts)
        ischanged("archerror", archerror)
        ischanged("compinfo", compinfo)
        ischanged("pdps", pdps)
        ischanged("eevlevel", eevlevel)
        ischanged("tsatpd", tsatpd)
        ischanged("tsatps", tsatps)
        ischanged("fans", fans)
        ischanged("tao", tao)
        ischanged("firmware", firmware)


def GetParameters():
    global datechart
    global tankchart
    global twichart
    global twochart
    global thichart
    global thochart
    global taochart
    global pdsetchart
    global pdactchart
    global pssetchart
    global psactchart
    global intempchart
    global outtempchart
    global humidchart
    global hcurvechart
    global fsetchart
    global factchart
    global flimitonchart
    global modechart_quiet
    global modechart_eco
    global modechart_turbo
    global threeway_chart

    if insidetemp == 'builtin' or humidity == 'builtin':
        threading.Thread(target=GetDHT22, daemon=True).start()
    threading.Thread(target=GetInsideTemp, args=(insidetemp,), daemon=True).start()
    threading.Thread(target=GetOutsideTemp, args=(outsidetemp,), daemon=True).start()
    threading.Thread(target=GetHumidity, args=(humidity,), daemon=True).start()
    threading.Thread(target=GetDHWTemp, args=(dhwtemp,), daemon=True).start()
    threading.Thread(target=hpiapp, daemon=True).start()
    now=datetime.now().strftime("%d %b %H:%M:%S")
    # Ograniczamy liczbę punktów na wykresach: dopisujemy maksymalnie raz na CHART_INTERVAL_SEC.
    global _last_chart_ts
    _now_ts = time.time()
    _do_chart = (_now_ts - _last_chart_ts) >= CHART_INTERVAL_SEC
    if _do_chart:
        _last_chart_ts = _now_ts

    if _do_chart: datechart.append(str(now))
    tank=statusdict['tank']['value']
    twitwo=statusdict['twitwo']['value']
    thitho=statusdict['thitho']['value']
    pump=statusdict['pump']['value']
    threeway=statusdict['threeway']['value']
    mode=statusdict['mode']['value']
    dhwkwhpd=statusdict['dhwkwhpd']['value']
    chkwhpd=statusdict['chkwhpd']['value']
    tdts=statusdict['tdts']['value']
    archerror=statusdict['archerror']['value']
    compinfo=compinfo=statusdict['compinfo']['value']
    preset=statusdict['mode']['value']
    pdps=statusdict['pdps']['value']
    eevlevel=statusdict['eevlevel']['value']
    tsatpd=statusdict['tsatpd']['value']
    tsatps=statusdict['tsatps']['value']
    fans=statusdict['fans']['value']

    # Wykresy: część pomp ma 2 wentylatory. Normalizujemy do dwóch liczb.
    def _fans_to_two(v):
        try:
            if isinstance(v, (list, tuple)):
                arr = list(v)
            elif isinstance(v, str):
                s = v.strip()
                if s.startswith('[') and s.endswith(']'):
                    # JSON list
                    arr = json.loads(s)
                elif ',' in s:
                    arr = [x.strip() for x in s.split(',')]
                elif s == '' or s.upper() == 'N.A.':
                    arr = []
                else:
                    arr = [s]
            else:
                arr = []

            def _num(x):
                try:
                    if x in (None, '', 'N.A.'): return ''
                    return float(x)
                except Exception:
                    return ''

            f1 = _num(arr[0]) if len(arr) > 0 else ''
            f2 = _num(arr[1]) if len(arr) > 1 else ''
            return f1, f2
        except Exception:
            return '', ''

    fan1, fan2 = _fans_to_two(fans)
    tao=statusdict['tao']['value']
    dhw=statusdict['dhw']['value']
    intemp=statusdict['intemp']['value']
    outtemp=statusdict['outtemp']['value']
    tempzone = get_temp_zone(outtemp)
    humid=statusdict['humid']['value']
    hcurve=statusdict['hcurve']['value']
    flimiton_gpio = str(GPIO.input(freqlimitpin))
    ischanged("flimiton", flimiton_gpio)
    flimiton=statusdict['flimiton']['value']
    # Wykres częstotliwości: ON ma być 10, OFF 0
    try:
        flimiton_num = 10 if int(str(flimiton).strip() or '0') > 0 else 0
    except Exception:
        flimiton_num = 0
    threeway=statusdict['threeway']['value']
    if mode == "quiet":
        mode_q=1
        mode_e=0
        mode_t=0
    elif mode == "eco":
        mode_q=0
        mode_e=2
        mode_t=0
    elif mode == "turbo":
        mode_q=0
        mode_e=0
        mode_t=3
    else:
        mode_q=0
        mode_e=0
        mode_t=0
    if _do_chart: tankchart.append(tank)
    if _do_chart: twichart.append(twitwo[0])
    if _do_chart: twochart.append(twitwo[1])
    if _do_chart: thichart.append(thitho[0])
    if _do_chart: thochart.append(thitho[1])
    if _do_chart: modechart_quiet.append(mode_q)
    if _do_chart: modechart_eco.append(mode_e)
    if _do_chart: modechart_turbo.append(mode_t)
    if _do_chart: tdchart.append(tdts[0])
    if _do_chart: tschart.append(tdts[1])
    if _do_chart: factchart.append(compinfo[0])
    if _do_chart: fsetchart.append(compinfo[1])
    if _do_chart: pdsetchart.append(pdps[0])
    if _do_chart: pdactchart.append(pdps[1])
    if _do_chart: pssetchart.append(pdps[2])
    if _do_chart: psactchart.append(pdps[3])
    if _do_chart: eevlevelchart.append(eevlevel)
    if _do_chart: fan1chart.append(fan1)
    if _do_chart: fan2chart.append(fan2)
    if _do_chart: tsatpdsetchart.append(tsatpd[0])
    if _do_chart: tsatpdactchart.append(tsatpd[1])
    if _do_chart: tsatpssetchart.append(tsatps[0])
    if _do_chart: tsatpsactchart.append(tsatps[1])
    
    # Superheat/Subcooling do wykresów: bierzemy już policzone wartości z statusdict
    def _chart_num(v):
        try:
            if v in (None, '', 'N.A.'): 
                return ''
            return float(v)
        except Exception:
            return ''
    _sh = _chart_num(statusdict.get('superheat', {}).get('value', 'N.A.'))
    _sc = _chart_num(statusdict.get('subcooling', {}).get('value', 'N.A.'))
    if _do_chart: superheatchart.append(_sh)
    if _do_chart: subcoolingchart.append(_sc)
    
    # NOWE tdef (defrost temperature) and defrost flag (0/1) for charts
    try:
        _tdef_v = statusdict.get('tdef', {}).get('value', '')
        if _tdef_v in (None, '', 'N.A.'):
            _tdef_chart = ''
        else:
            _tdef_chart = float(_tdef_v)
    except Exception:
        _tdef_chart = ''
    _defrost_flag = 1 if str(statusdict.get('defrost', {}).get('value', 'off')).strip().lower() == 'on' else 0
    _antifreeze_flag = 1 if str(statusdict.get('antifreeze', {}).get('value', 'off')).strip().lower() == 'on' else 0
    heater = statusdict.get('heater', {}).get('value', '')

    _heater_flag = 1 if str(heater).lower() == 'on' else 0
    _heater_level = 176 if str(statusdict.get('heater', {}).get('value', 'off')).strip().lower() == 'on' else 160
    
    if _do_chart: tdefchart.append(_tdef_chart)
    if _do_chart: defrostchart.append(_defrost_flag)
    if _do_chart: antifreezechart.append(_antifreeze_flag)
    if _do_chart: heaterchart.append(_heater_level)
    
    if _do_chart: taochart.append(tao)
    if _do_chart: intempchart.append(intemp)
    if _do_chart: outtempchart.append(outtemp)
    if _do_chart: humidchart.append(humid)
    if _do_chart: hcurvechart.append(hcurve)
    if _do_chart: flimitonchart.append(flimiton_num)
    if _do_chart: threewaychart.append(threeway)
    
    socketlocal.emit("chart_update", {
        'datechart': str(now),
        'tankchart': tank,
        'twichart': twitwo[0],
        'twochart': twitwo[1],
        'thichart': thitho[0],
        'thochart': thitho[1],
        'taochart': tao,
        'tdchart': tdts[0],
        'tschart': tdts[1],
        'pdsetchart': pdps[0],
        'pdactchart': pdps[1],
        'pssetchart': pdps[2],
        'psactchart': pdps[3],
        'eevlevelchart': eevlevel,
        'fan1chart': fan1,
        'fan2chart': fan2,
        'intempchart': statusdict['intemp']['value'],
        'outtempchart': statusdict['outtemp']['value'],
        'humidchart': statusdict['humid']['value'],
        'hcurvechart': statusdict['hcurve']['value'],
        'factchart': compinfo[0],
        'fsetchart': compinfo[1],
        'flimitonchart': flimiton_num,
        'modechart_quiet': mode_q,
        'modechart_eco': mode_e,
        'modechart_turbo': mode_t,
        'threewaychart': threeway,
        'tdefchart': _tdef_chart,
        'defrostchart': _defrost_flag,
        'antifreezechart': _antifreeze_flag,
        'heaterchart': _heater_level,
        'superheatchart': _sh,
        'subcoolingchart': _sc
    })
    deltacheck(twitwo)
    flimitreset()
    # DHW on-demand: detect end of one-shot DHW cycle before running scheduler
    try:
        dhw_ondemand_tick(threeway)
    except Exception:
        logging.exception('DHW on-demand: tick failed')
    scheduler()
    # DHWWL: during DHW heating force Turbo + disable frequency limit,
    # and restore previous state after returning to CH (fixes "stuck in turbo" after DHW).
    global _dhwwl_active, _dhwwl_prev_mode, _dhwwl_prev_flimiton, _dhwwl_exit_since
    if isinstance(compinfo, list) and len(compinfo) > 0 and dhwwl == "1":
        _threeway = str(threeway).strip().upper()
        _mode_now = str(statusdict.get('mode', {}).get('value', '')).strip().lower()
        _fl_on_now = str(statusdict.get('flimiton', {}).get('value', '0')).strip()
        dhw_now = (compinfo[0] > 0 and _threeway == "DHW")

        if dhw_now:
            _dhwwl_exit_since = None  # cancel pending DHW-exit restore timer
            # Save state once on entry
            if not _dhwwl_active:
                _dhwwl_prev_mode = _mode_now
                _dhwwl_prev_flimiton = _fl_on_now
                _dhwwl_active = True
                logging.info(f"DHWWL: enter DHW, saved mode={_dhwwl_prev_mode}, flimiton={_dhwwl_prev_flimiton}")

            # Enforce DHWWL
            if _fl_on_now == "1":
                logging.info("DHWWL: disabling frequency limit for DHW")
                flimitchange("0")
            # Nowe change mode
            try:
                dhwwl_mode = str(dhwnolimit_mode).strip().lower()
                if dhwwl_mode not in ('turbo','eco','quiet'):
                    dhwwl_mode = 'turbo'
                current_dhw_mode = str(statusdict.get('mode', {}).get('value', '')).strip().lower()
                if current_dhw_mode != dhwwl_mode:
                    logging.info(f"DHW mode: forcing mode {dhwwl_mode}")
                    new_presetchange(dhwwl_mode)
            except Exception as e:
                logging.warning(f"DHW mode: cannot set mode: {e}")
            
        elif _dhwwl_active:
            # Restore on exit (debounced)
            now_ts = time.time()
            if _dhwwl_exit_since is None:
                _dhwwl_exit_since = now_ts
                logging.info(f"DHWWL: DHW exit detected, waiting {DHWWL_RESTORE_DELAY_S}s before restore")
            elif (now_ts - _dhwwl_exit_since) >= DHWWL_RESTORE_DELAY_S:
                logging.info(f"DHWWL: exit DHW confirmed, restoring mode={_dhwwl_prev_mode}, flimiton={_dhwwl_prev_flimiton}")

                try:
                    if _dhwwl_prev_flimiton in ("0", "1") and str(flimit).strip().lower() != "off":
                        # Restore previous relay state (manual/auto)
                        if str(statusdict.get('flimiton', {}).get('value', '0')).strip() != _dhwwl_prev_flimiton:
                            flimitchange(_dhwwl_prev_flimiton)
                except Exception:
                    logging.exception("DHWWL: restore flimit failed")

                try:
                    if _dhwwl_prev_mode in ("quiet", "eco", "turbo"):
                        if str(statusdict.get('mode', {}).get('value', '')).strip().lower() != _dhwwl_prev_mode:
                            new_presetchange(_dhwwl_prev_mode)
                except Exception:
                    logging.exception("DHWWL: restore preset failed")

                _dhwwl_active = False
                _dhwwl_prev_mode = None
                _dhwwl_prev_flimiton = None
                _dhwwl_exit_since = None


    # Keep config-only / GPIO-derived values in statusdict even when UI doesn't poll /getdata
    # (WebSocket-only dashboards need these to avoid long-lived 'N.A.' values)
    try:
        # GPIO states (reflect current outputs)
        _heatdemand = GPIO.input(heatdemandpin)
        _cooldemand = GPIO.input(cooldemandpin)
        _flimiton = GPIO.input(freqlimitpin)
        _flrelay = _flimiton
        ischanged("heatdemand", _heatdemand)
        ischanged("cooldemand", _cooldemand)
        ischanged("flrelay", _flrelay)
        ischanged("flimiton", _flimiton)
    
        # Settings (rarely change, but must not stay as 'N.A.')
        ischanged("flimit", str(config["SETTINGS"].get("flimit", "auto")).strip().lower())
        ischanged("antionoff", str(config["SETTINGS"].get("antionoff", "1")).strip())
        ischanged("antionoffdeltatime", str(config["SETTINGS"].get("antionoffdeltatime", "5")).strip())
    
        # Delta thresholds are config values; publish them even if deltacheck() hasn't fired yet
        ischanged("deltatempturbo", str(config["SETTINGS"].get("deltatempturbo", deltatempturbo)).strip())
        ischanged("deltatempquiet", str(config["SETTINGS"].get("deltatempquiet", deltatempquiet)).strip())
        ischanged("deltatempflimit", str(config["SETTINGS"].get("deltatempflimit", deltatempflimit)).strip())
    except Exception:
        logging.exception("GetParameters: sync GPIO/settings to statusdict failed")

    # Snapshot pełnego statusu co 30s (do logu), niezależnie od ischanged()
    log_status_snapshot(30)

# NOWE Snapshot statusdict co 30s (pełny stan w jednej linii).
_last_snapshot_ts = 0

def log_status_snapshot(interval_s=30):
    """
    Loguje pełny snapshot statusdict w formacie JSON w jednej linii.
    (Wybrane klucze są pomijane, aby snapshot był bardziej czytelny.)
    """
    global _last_snapshot_ts
    now = time.time()
    if now - _last_snapshot_ts < interval_s:
        return
    _last_snapshot_ts = now

    try:
        exclude_snapshot_keys = {"chkwhpd", "dhwkwhpd", "theme", "tempcompensation_set", "dhwcompensation_set",
                               "antifreeze_custom_enable", "antifreeze_custom_outtemp", "antifreeze_custom_twi", "antifreeze_custom_two", "antifreeze_custom_runtime_min"}
        snap = {k: v.get('value', 'N.A.') for k, v in statusdict.items() if k not in exclude_snapshot_keys}
        # Drop empty-string values from snapshot log (mostly config placeholders)
        snap = {k: v for k, v in snap.items() if v not in ('', None)}
        payload = json.dumps(snap, ensure_ascii=False, separators=(",", ":"), default=str)
        logging.info("status_snapshot: %s", payload)
    except Exception as e:
        logging.error(f"Error in log_status_snapshot: {e}")

def gen_charts(hours=12):
    fromwhen=8640-(hours*60)
    chartdate=list(islice(datechart, fromwhen, None))
    charttank=list(islice(tankchart, fromwhen, None))
    charttwi=list(islice(twichart, fromwhen, None))
    charttwo=list(islice(twochart, fromwhen, None))
    chartthi=list(islice(thichart, fromwhen, None))
    charttho=list(islice(thochart, fromwhen, None))
    charttao=list(islice(taochart, fromwhen, None))
    charttd=list(islice(tdchart, fromwhen, None))
    chartts=list(islice(tschart, fromwhen, None))
    chartpdset=list(islice(pdsetchart, fromwhen, None))
    chartpdact=list(islice(pdactchart, fromwhen, None))
    chartpsset=list(islice(pssetchart, fromwhen, None))
    chartpsact=list(islice(psactchart, fromwhen, None))
    chartintemp=list(islice(intempchart, fromwhen, None))
    chartouttemp=list(islice(outtempchart, fromwhen, None))
    charthumid=list(islice(humidchart, fromwhen, None))
    charthcurve=list(islice(hcurvechart, fromwhen, None))
    chartfact=list(islice(factchart, fromwhen, None))
    chartfset=list(islice(fsetchart, fromwhen, None))
    chartflimiton=list(islice(flimitonchart, fromwhen, None))
    chartmode_quiet = list(islice(modechart_quiet, fromwhen, None))
    chartmode_eco = list(islice(modechart_eco, fromwhen, None))
    chartmode_turbo = list(islice(modechart_turbo, fromwhen, None))
    chartthreeway = list(islice(threewaychart, fromwhen, None))
    
    # NOWE Wykres Tdef, Defrost, Heater, Antifreeze
    charttdef = list(islice(tdefchart, fromwhen, None))
    chartdefrost = list(islice(defrostchart, fromwhen, None))
    chartheater = list(islice(heaterchart, fromwhen, None))
    chartantifreeze = list(islice(antifreezechart, fromwhen, None))

    # NOWE Przegrzanie / dochłodzenie jako gotowe serie (liczone przy dopisywaniu próbek do wykresów)
    chartsuperheat = list(islice(superheatchart, fromwhen, None))
    chartsubcooling = list(islice(subcoolingchart, fromwhen, None))
    
    #NOWE Wykres wentylatory i eev
    charteevlevel=list(islice(eevlevelchart, fromwhen, None))
    chartfan1=list(islice(fan1chart, fromwhen, None))
    chartfan2=list(islice(fan2chart, fromwhen, None))
    
    return chartdate, charttank, charttwi, charttwo, chartthi, charttho, charttao, charttd, chartts, chartpdset, chartpdact, chartpsset, chartpsact, charteevlevel, chartfan1, chartfan2, chartintemp, chartouttemp, charthumid, charthcurve, chartfact, chartfset, chartflimiton, chartmode_quiet, chartmode_eco, chartmode_turbo, chartthreeway, chartsuperheat, chartsubcooling, charttdef, chartdefrost, chartheater, chartantifreeze

def create_user(**data):
    """Creates user with encrypted password"""
    if "username" not in data or "password" not in data:
        raise ValueError(gettext("username and password are required."))

    # Hash the user password
    data["password"] = generate_password_hash(
        data.pop("password"), method="pbkdf2:sha256"
    )

    # Here you insert the `data` in your users database
    # for this simple example we are recording in a json file
    db_users = json.load(open("users.json"))
    # add the new created user to json
    db_users[data["username"]] = data
    # commit changes to database
    json.dump(db_users, open("users.json", "w"))
    #return data
    msg=gettext("Password changed")
    return msg

def background_function():
    print("Background function running!")

# Flask route
@app.route('/')
@login_required
def home():
    if firstrun == "1":
        return redirect("/settings", code=302)
    else:
        theme=statusdict['theme']['value']
        global outsidetemp
        return render_template('index.html', theme=theme, version=version, needrestart=needrestart, flimit=flimit, outsidetemp=outsidetemp, antionoff=antionoff, presetquiet=presetquiet, presetturbo=presetturbo, presetautochange=presetautochange, flimittemp=flimittemp, dhwuse=dhwuse, dhwscheduler=dhwscheduler)

@app.route('/curvecalc')
@login_required
def curvecalc_route():
    curve=curvecalc()
    return jsonify(msg=curve)

@app.route('/theme', methods=['POST'])
def theme_route():
    theme = request.form['theme']
    settheme(theme)
    return theme

@app.route('/get_json_data')
def get_json_route():
    return get_json_data()

@app.route('/backup')
def backup_route():
    try:
        subprocess.check_output("7zr a backup.7z config.ini schedule_*", shell=True).decode().rstrip('\n')
        return send_file('/opt/haier/backup.7z', download_name='backup.hpi')
    except Exception as e:
        return str(e)

@app.route('/restore', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            flash('File uploaded, please restart HaierPi service', 'success')
            subprocess.check_output("7zr e -aoa /opt/haier/"+filename+" /opt/haier config.ini schedule_ch.json schedule_dhw.json", shell=True).decode().rstrip('\n')
            return redirect('/', code=302)
    return render_template('upload.html')

@app.route('/charts', methods=['GET','POST'])
@login_required
def charts_route():
    return render_template('charts.html', version=version)

@app.route('/settings', methods=['GET','POST'])
@login_required
def settings():
    return render_template('settings.html', version=version)

@app.route('/parameters', methods=['GET','POST'])
@login_required
def parameters():
    theme=statusdict['theme']['value']
    return  render_template('parameters.html', version=version, theme=theme)

@app.route('/scheduler', methods=['GET','POST'])
@login_required
def scheduler_route():
    if request.method == 'POST':
        if "schedulech" in request.form:
            msg, state = schedule_write('ch', request.form['schedulech'])
            return jsonify(msg=msg, state=state)
        if "scheduledhw" in request.form:
            msg, state = schedule_write('dhw', request.form['scheduledhw'])
            return jsonify(msg=msg, state=state)

    schedule1 = open("schedule_ch.json", "r")
    schedule2 = open("schedule_dhw.json", "r")
    theme=statusdict['theme']['value']
    return  render_template('scheduler.html', ch=Markup(schedule1.read()), dhw=Markup(schedule2.read()), version=version, theme=theme)

@app.route('/statechange', methods=['POST'])
@login_required
def change_state_route():
    mode = request.form['mode']
    value = request.form['value']
    logging.info(f'{mode} - {value}')
    information = statechange(mode, value, "0")
    return information

@app.route('/dhw_ondemand', methods=['POST'])
@login_required
def dhw_ondemand_route():
    # One-shot DHW heating request: only when DHW scheduler is enabled (dhwscheduler==1)
    res = dhw_ondemand_start()
    return jsonify(msg=res.get('msg','dhwondemand.error'), state=res.get('state','danger'))

@app.route('/modechange', methods=['POST'])
@login_required
def change_mode_route():
    newvalue = request.form['newmode']
    msg, response = new_presetchange(newvalue)
    code=b2s(response)
    return jsonify(msg=msg, state=code)

@app.route('/flrchange', methods=['POST'])
@login_required
def change_flimitrelay_route():
    newvalue = request.form['newmode']
    msg,state = flimitchange(newvalue)
    return jsonify(msg=msg, state=state)

@app.route('/tempchange', methods=['POST'])
@login_required
def change_temp_route():
    which = request.form['which']
    value = request.form['value']
    directly = request.form['directly']
    msg, response = new_tempchange(which,value,directly)
    # Direct: natychmiastowa aktualizacja po zmianie settemp (bez czekania na cykl curvecalc)
    if which == 'heat' and str(directly) == "0" and str(heatingcurve).strip().lower() == 'directly':
        try:
            curvecalc()
        except Exception:
            logging.exception("Direct: immediate curvecalc after tempchange failed")
    code=b2s(response)
    socketlocal.emit("data_update", {'setpoint': value})
    return jsonify(msg=msg, state=code)

@app.route('/tempcompchange', methods=['POST'])
@login_required
def change_tempcomp_route():
    value = request.form['value']
    msg, response = new_tempcompchange(value)
    code = b2s(response)
    if response:
        msg = 'ok'
    socketlocal.emit("data_update", {'tempcompensation_set': value})
    return jsonify(msg=msg, state=code)


@app.route('/dhwcompchange', methods=['POST'])
@login_required
def change_dhwcomp_route():
    value = request.form['value']
    msg, response = new_dhwcompchange(value)
    code = b2s(response)
    if response:
        msg = 'ok'
    socketlocal.emit("data_update", {'dhwcompensation_set': value})
    return jsonify(msg=msg, state=code)


@app.route('/updatecheck')
def updatecheck_route():
    response = updatecheck()
    return response

@app.route('/restart', methods=['GET'])
@login_required
def restart_route():
    output = restart()
    return output

@app.route('/changepass', methods=['POST'])
@login_required
def change_pass_route():
    user = request.form['user']
    password = request.form['password']
    response = create_user(username=user, password=password)
    return jsonify(response)

@app.route('/getdata', methods=['GET'])
@login_required(basic=True)
def getdata_route():
    output = getdata()
    return output


@app.route('/api/system_time', methods=['GET'])
@login_required(basic=True)
def system_time_route():
    """Return current server (DietPi) date & time."""
    now = datetime.now()
    try:
        iso = now.isoformat(timespec='seconds')
    except TypeError:
        iso = now.isoformat()
    return jsonify(
        iso=iso,
        display=now.strftime('%Y-%m-%d %H:%M:%S')
    )



@app.route('/service_test_duration', methods=['POST'])
@login_required(basic=True)
def service_test_duration_route():
    """Set service test duration in minutes (stored in config as seconds)."""
    try:
        raw = (request.form.get('value', '') or '').strip()
        # allow comma decimal separator
        raw = raw.replace(',', '.')
        minutes = float(raw)
        # allow fractional minutes (e.g. 0.5, 2.5)
        minutes = max(0.5, min(240.0, minutes))
        # store as seconds; snap to 30s steps (matches 0.5 min UI)
        seconds = int(round(minutes * 60.0))
        seconds = int(round(seconds / 30.0) * 30)
        seconds = max(30, min(240 * 60, seconds))
        minutes = round(seconds / 60.0, 2)
        ok = bool(saveconfig('SETTINGS', 'service_test_duration_s', str(seconds)))
        if not ok:
            return jsonify(state='error', msg='save_failed'), 500
        try:
            socketlocal.emit("data_update", {
                'service_test_duration_s': seconds,
                'service_test_duration_min': minutes,
            })
        except Exception:
            pass
        try:
            statusdict.setdefault('service_test_runtime_min', {})['value'] = minutes
            queue_pub('service_test_runtime_min', minutes)
        except Exception:
            pass
        return jsonify(state='success', msg='ok', value=minutes)
    except Exception:
        logging.exception("service_test_duration_route failed")
        return jsonify(state='error', msg='bad_request'), 400

@app.route('/api/hpi_status', methods=['GET'])
@login_required(basic=True)
def hpi_status_route():
    """Lightweight health/status endpoint for the UI (navbar LED)."""
    now = time.time()
    server_now = datetime.now()
    # Thread liveness (shared with threads_check)
    th = threads_state()
    bg_alive = th['bg']
    serial_alive = th['serial']
    mqtt_alive = th['mqtt']

    # Pump RX age (serial frames)
    ts = globals().get('last_pump_rx_ts', 0.0) or 0.0
    age = (now - ts) if ts > 0 else None

    payload = {
        "ok": (globals().get('dead', 0) == 0) and bg_alive and serial_alive and (mqtt_alive is not False),
        "dead": int(globals().get('dead', 0) or 0),
        "threads": {
            "bg": bg_alive,
            "serial": serial_alive,
            "mqtt": mqtt_alive,
            "mqtt_enabled": bool(th.get('mqtt_enabled')),
        },
        "pump_rx": {
            "last_ts": ts if ts > 0 else None,
            "age_s": age,
            "block": globals().get('last_pump_rx_block', '') or None,
            "len": int(globals().get('last_pump_rx_len', 0) or 0) or None,
            "last_error": globals().get('last_pump_error', '') or None,
        },
        "server_time": {
            "iso": server_now.isoformat(timespec='seconds') if hasattr(server_now, 'isoformat') else str(server_now),
            "display": server_now.strftime('%Y-%m-%d %H:%M:%S'),
        },
    }
    return jsonify(payload)


@app.route('/getparams', methods=['GET'])
@login_required(basic=True)
def getparams_route():
    twitwo, thitho, tdts, archerror, compinfo, fans, pdps, eevlevel, tsatpd, tsatps, tao, tdef, pump, threeway, error, lasterror, superheat, subcooling, firmware = getparams()
    payload = {

        "twitwo": twitwo,
        "thitho": thitho,
        "tdts": tdts,
        "archerror": archerror,
        "compinfo": compinfo,
        "fans": fans,
        "pdps": pdps,
        "eevlevel": eevlevel,
        "tsatpd": tsatpd,
        "tsatps": tsatps,
        "tao": tao,
        "tdef": tdef,
        "pump": pump,
        "threeway": threeway,
        "error": error,
        "lasterror": lasterror,
        "superheat": superheat,
        "subcooling": subcooling,
        "firmware": firmware,
        "chkwhpd": statusdict.get('chkwhpd', {}).get('value', 'N.A.'),
        "dhwkwhpd": statusdict.get('dhwkwhpd', {}).get('value', 'N.A.')
    }
    return _json_response(payload)


@socketlocal.on('client')
def handle_client_message(data):
    global grestarted, heatingcurve
    logging.debug(data)
    if 'hpiapp' in data:
        hpiapp(data['hpiapp'])
    elif 'mode' in data:
        information = statechange(data['mode'], data['value'], "1")
        logging.debug(information)
#        emit('return', {'info': 'ok', 'status': 'success'})
        emit("return", {'statechange': data['mode'], 'status': information })
    elif 'charts' in data:
        variables=['chartdate', 'charttank', 'charttwi', 'charttwo', 'chartthi', 'charttho', 'charttao', 'charttd', 'chartts', 'chartpdset', 'chartpdact', 'chartpsset', 'chartpsact', 'charteevlevel', 'chartfan1', 'chartfan2', 'chartintemp', 'chartouttemp', 'charthumid', 'charthcurve', 'chartfact', 'chartfset', 'chartflimiton', 'chartmode_quiet', 'chartmode_eco', 'chartmode_turbo','chartthreeway', 'chartsuperheat', 'chartsubcooling', 'charttdef', 'chartdefrost', 'chartheater', 'chartantifreeze']
        values=gen_charts(int(data['charts']))
        valname=dict(zip(variables, values))
        emit('charts', valname)

    elif 'set_pump' in data:
        try:
            on = str(data.get('set_pump', 'off')).strip().lower() == 'on'
            ok, msg = service_set_pump(on)
            emit('return', {'info': msg, 'status': 'success' if ok else 'danger'})
        except Exception:
            logging.exception('set_pump failed')
            emit('return', {'info': 'set_pump failed', 'status': 'danger'})

    elif 'set_heater' in data:
        try:
            on = str(data.get('set_heater', 'off')).strip().lower() == 'on'
            ok, msg = service_set_heater(on)
            emit('return', {'info': msg, 'status': 'success' if ok else 'danger'})
        except Exception:
            logging.exception('set_heater failed')
            emit('return', {'info': 'set_heater failed', 'status': 'danger'})

    elif 'anti_legionella_run' in data:
        # Instant start/abort of Anti-legionella cycle (does not require settings Save)
        try:
            want_on = str(data.get('anti_legionella_run', 'off')).strip().lower() == 'on'
            enabled = str(globals().get('anti_legionella_enable', '0')).strip() == '1'

            global anti_legionella_run
            if want_on and (not enabled):
                # Feature disabled -> reject and ensure switch is OFF
                anti_legionella_run = '0'
                globals()['anti_legionella_run'] = '0'
                try:
                    ischanged('anti_legionella_run', '0')
                except Exception:
                    pass
                emit('return', {'info': 'toast.anti_legionella_enable_required', 'status': 'danger'})
                return

            anti_legionella_run = '1' if want_on else '0'
            globals()['anti_legionella_run'] = anti_legionella_run
            try:
                ischanged('anti_legionella_run', anti_legionella_run)
            except Exception:
                try:
                    queue_pub('anti_legionella_run', anti_legionella_run)
                except Exception:
                    pass

            # Kick controller immediately
            try:
                anti_legionella_tick()
            except Exception:
                pass

            if want_on:
                emit('return', {'info': 'toast.anti_legionella_started', 'status': 'success'})

        except Exception:
            logging.exception('anti_legionella_run failed')
            emit('return', {'info': 'toast.request_failed', 'status': 'danger'})

    elif 'get_service' in data:
        try:
            # Instant Service snapshot on demand (no waiting for next ischanged cycle)
            snap = {
                'tempcompensation': statusdict.get('tempcompensation', {}).get('value', 'N.A.'),
                'tempcompensation_set': statusdict.get('tempcompensation_set', {}).get('value', 'N.A.'),
                'dhwcompensation': statusdict.get('dhwcompensation', {}).get('value', 'N.A.'),
                'dhwcompensation_set': statusdict.get('dhwcompensation_set', {}).get('value', 'N.A.'),
                'error': statusdict.get('error', {}).get('value', 'N.A.'),
                'lasterror': statusdict.get('lasterror', {}).get('value', 'N.A.'),
                'archerror': statusdict.get('archerror', {}).get('value', 'N.A.'),
                'firmware': statusdict.get('firmware', {}).get('value', 'N.A.'),
                'pump': statusdict.get('pump', {}).get('value', 'N.A.'),
                'heater': statusdict.get('heater', {}).get('value', 'off'),
                'threeway': statusdict.get('threeway', {}).get('value', 'N.A.'),
                'tdef': statusdict.get('tdef', {}).get('value', 'N.A.'),
                'compinfo': statusdict.get('compinfo', {}).get('value', 'N.A.'),
                'set_pump': statusdict.get('service_set_pump', {}).get('value', 'off'),
                'set_heater': statusdict.get('service_set_heater', {}).get('value', 'off'),
                'service_test_duration_min': round(service_test_duration_s() / 60.0, 2),
            }
            # GPIO states (fast)
            try:
                snap['heatdemand'] = GPIO.input(heatdemandpin)
            except Exception:
                pass
            try:
                snap['cooldemand'] = GPIO.input(cooldemandpin)
            except Exception:
                pass


            # DHW on-demand debug/status for Service snapshot
            try:
                with dhw_ondemand_lock:
                    od_active = bool(dhw_ondemand_active)
                    od_seen = bool(dhw_ondemand_seen_dhw)
                    od_started = float(dhw_ondemand_started_ts or 0.0)
                snap['dhw_ondemand'] = 'on' if od_active else 'off'
                snap['dhw_ondemand_seen_dhw'] = od_seen
                snap['dhw_ondemand_age_s'] = round(time.time() - od_started, 1) if (od_active and od_started) else 0.0
            except Exception:
                pass

            emit('data_update', snap)
        except Exception:
            logging.exception('get_service failed')
            emit('return', {'info': 'Błąd pobierania danych serwisowych', 'status': 'danger'})

    elif 'get_settings' in data:
        try:
            heatingcurve = config['SETTINGS']['heatingcurve']
            antionoff = config['SETTINGS']['antionoff']
            hpiconn = statusdict['hpiconn']['value']
            settings={"SETTINGS$insidetemp": insidetemp,"SETTINGS$emergency_intemp": emergency_intemp,"SETTINGS$outsidetemp": outsidetemp,"SETTINGS$humidity": humidity,"SETTINGS$thermostat_on": thermostat_on,"SETTINGS$lohysteresis": lohysteresis,"SETTINGS$hihysteresis": hihysteresis,"SETTINGS$direct_inside_settemp": direct_inside_settemp,"SETTINGS$antionoff": antionoff,"SETTINGS$antionoffdeltatime": antionoffdeltatime,"SETTINGS$deltatempturbo": deltatempturbo,"SETTINGS$deltatempquiet": deltatempquiet,"SETTINGS$deltatempflimit": deltatempflimit,"SETTINGS$zone_frost_enable": zone_frost_enable,"SETTINGS$zone_frost_temp": zone_frost_temp,"SETTINGS$zone_frost_mode": zone_frost_mode,"SETTINGS$zone_warm_enable": zone_warm_enable,"SETTINGS$zone_warm_temp": zone_warm_temp,"SETTINGS$zone_warm_mode": zone_warm_mode,"SETTINGS$dhwwl": dhwwl,"SETTINGS$dhwnolimit_mode": dhwnolimit_mode,"SETTINGS$dhwuse": dhwuse,"SETTINGS$chscheduler": chscheduler, "SETTINGS$dhwscheduler": dhwscheduler,"SETTINGS$flimit": flimit,"SETTINGS$flimittemp": flimittemp,"SETTINGS$presetautochange": presetautochange,"SETTINGS$presetquiet": presetquiet,"SETTINGS$presetturbo": presetturbo,"SETTINGS$heatingcurve": heatingcurve,"MAIN$heizfreq": timeout,"MAIN$log_level": loglevel,"MAIN$ui_font": globals().get('ui_font', 'inter'),"SETTINGS$hcslope": slope,"SETTINGS$hcpshift": pshift,"SETTINGS$hcamp": hcamp,"SETTINGS$hcman": hcman,"HOMEASSISTANT$HAADDR": haaddr,"HOMEASSISTANT$HAPORT": haport,"HOMEASSISTANT$KEY": hakey,"HOMEASSISTANT$ha_mqtt_discovery": ha_mqtt_discovery,"HOMEASSISTANT$insidesensor": insidesensor,"HOMEASSISTANT$outsidesensor": outsidesensor,"HOMEASSISTANT$humiditysensor": humiditysensor,"MQTT$mqtt": use_mqtt,"HOMEASSISTANT$dhwsensor": config['HOMEASSISTANT'].get('dhwsensor', '').strip(),"MQTT$address": mqtt_broker_addr,"MQTT$port": mqtt_broker_port,"MQTT$mqtt_ssl": mqtt_ssl,"MQTT$main_topic": mqtt_topic,"MQTT$username": mqtt_username,"MQTT$password": mqtt_password,"MQTT$snapshot_interval_s": str(config['MQTT'].get('snapshot_interval_s', '0')).strip(),"MAIN$bindaddress": bindaddr,"MAIN$bindport": bindport,"MAIN$modbusdev": modbusdev,"GPIO$modbus": modbuspin,"GPIO$freqlimit": freqlimitpin,"GPIO$heatdemand": heatdemandpin,"GPIO$cooldemand": cooldemandpin, "HPIAPP$hpikey":hpikey,"HPIAPP$hpiatstart":hpiatstart ,"hpiconn":hpiconn,
                     "SETTINGS$dhw_heater_assist_enable": globals().get('dhw_heater_assist_enable', '0'),
                     "SETTINGS$dhw_heater_assist_below_temp": globals().get('dhw_heater_assist_below_temp', ''),
                     "SETTINGS$anti_legionella_enable": globals().get('anti_legionella_enable', '0'),
                     "SETTINGS$anti_legionella_temp": globals().get('anti_legionella_temp', '60.0')
                     }
            # Anti-legionella run state (instant switch, not part of settings form)
            try:
                settings.update({
                    'anti_legionella_run': globals().get('anti_legionella_run', '0'),
                    'anti_legionella_active': statusdict.get('anti_legionella_active', {}).get('value', 'off'),
                })
            except Exception:
                pass
            settings.update({
                "SETTINGS$antifreeze_custom_enable": globals().get('antifreeze_custom_enable', '0'),
                "SETTINGS$antifreeze_custom_outtemp": globals().get('antifreeze_custom_outtemp', '0.0'),
                "SETTINGS$antifreeze_custom_twi": globals().get('antifreeze_custom_twi', '0.0'),
                "SETTINGS$antifreeze_custom_two": globals().get('antifreeze_custom_two', '0.0'),
                "SETTINGS$antifreeze_custom_runtime_min": globals().get('antifreeze_custom_runtime_min', '1.0'),
            })
            emit('settings', settings)
        except Exception:
            logging.exception('get_settings failed')
            emit('return', {'info': 'Błąd pobierania ustawień', 'status': 'danger'})

    if 'curvecalc' in data:
        logging.debug(data)
        curve=curvecalc()
        emit('return', {'curvecalc': curve })
    if 'restarted' in data:
        grestarted = 0
    if 'tempchange' in data:
        msg, response = new_tempchange(data['tempchange'],data['value'],data['directly'])
        # Direct: natychmiastowa aktualizacja po zmianie settemp (zdalnie) – bez czekania na cykl curvecalc
        if data.get('tempchange') == 'heat' and str(data.get('directly')) == "0" and str(heatingcurve).strip().lower() == 'directly':
            try:
                curvecalc()
            except Exception:
                logging.exception("Direct: immediate curvecalc after remote tempchange failed")
        code=b2s(response)
        if data['tempchange'] == 'heat': 
            emit("data_update", {'setpoint': data['value']})
        emit("return", {'tempchange': msg, 'type': code})
        # Ostrzeżenie tylko dla harmonogramu danego obszaru
        if data.get('tempchange') == 'heat' and chscheduler == "1":
            emit("return", {'tempchange': 'Masz wlaczony harmonogram CO, temperatura zostanie nadpisana wg harmonogramu', 'type': 'warning' })
        elif data.get('tempchange') == 'dhw' and dhwscheduler == "1":
            emit("return", {'tempchange': 'Masz wlaczony harmonogram CWU, temperatura zostanie nadpisana wg harmonogramu', 'type': 'warning' })
    if 'settings' in data:
        try:
            _old_heatingcurve = str(globals().get('heatingcurve', '')).strip().lower()
            _prev_mqtt_cfg = mqtt_current_config()
            for key,value in data['settings'].items():
                KEY1=f'{key.split("$")[0]}'
                KEY2=f'{key.split("$")[1]}'
                VAL=f'{value}'
                if KEY1 == 'MAIN' and KEY2 == 'ui_font':
                    _v = str(VAL).strip().lower()
                    if _v not in ('inter','roboto','system'):
                        _v = 'inter'
                    VAL = _v
                config[KEY1][KEY2] = str(VAL)

                if KEY1 == 'SETTINGS' and KEY2 == 'heatingcurve':
                    _val_hc = str(VAL).strip().lower()
                    if _val_hc in ('auto', 'static', 'manual'):
                        config['SETTINGS']['heatingcurve_last'] = _val_hc
                    elif _val_hc == 'directly':
                        if _old_heatingcurve in ('auto', 'static', 'manual'):
                            config['SETTINGS']['heatingcurve_last'] = _old_heatingcurve
                with open('/opt/config.ini', 'w') as configfile:
                    config.write(configfile)
            emit('return', {'info': "Zapisano", 'status': 'success'})
            loadconfig()

            # Apply MQTT changes immediately (no service restart needed)
            try:
                mqtt_sync(_prev_mqtt_cfg, reason='settings')
            except Exception:
                logging.exception('MQTT sync after settings save failed')

            try:
                _sync_heatcontrol_status()
            except Exception:
                pass


            try:
                _new_heatingcurve = str(globals().get('heatingcurve','')).strip().lower()
                if _new_heatingcurve != _old_heatingcurve:
                    logging.info(f"heatingcurve changed: {_old_heatingcurve} -> {_new_heatingcurve} (immediate curvecalc)")
                    curvecalc()
            except Exception:
                logging.exception('Immediate curvecalc after heatingcurve change failed')
        except:
            emit('return', {'info': 'Błąd zapisu', 'status': 'danger'})

@sio_remote.event
def error(data):
    logging.error(data)
    if 'message' in data:
        if data['message'] == "Unauthorized":
            socketlocal.emit('return', {'info': data['message'], 'status': 'danger'})
            hpiapp('disconnect')
@sio_remote.event
def command(data):
    logging.info(f"Received command: {data}")
    if 'get_scheduler' in data:
        logging.info("get_scheduler-----------------------------------------------------")
        schedule1 = open("schedule_ch.json", "r")
        schedule2 = open("schedule_dhw.json", "r")
        data={}
        sched={}
        sched['chsch'] = json.loads(schedule1.read())
        sched['dhwsch'] = json.loads(schedule2.read())
        data['scheduler']=sched
        sio_remote.emit('data_from_device', data)

    if 'settings' in data:
        try:
            _old_heatingcurve = str(globals().get('heatingcurve', '')).strip().lower()
            _prev_mqtt_cfg = mqtt_current_config()
            for key,value in data['settings'].items():
                KEY1=f'{key.split("$")[0]}'
                KEY2=f'{key.split("$")[1]}'
                VAL=f'{value}'
                if KEY1 == 'MAIN' and KEY2 == 'ui_font':
                    _v = str(VAL).strip().lower()
                    if _v not in ('inter','roboto','system'):
                        _v = 'inter'
                    VAL = _v
                config[KEY1][KEY2] = str(VAL)

                if KEY1 == 'SETTINGS' and KEY2 == 'heatingcurve':
                    _val_hc = str(VAL).strip().lower()
                    if _val_hc in ('auto', 'static', 'manual'):
                        config['SETTINGS']['heatingcurve_last'] = _val_hc
                    elif _val_hc == 'directly':
                        if _old_heatingcurve in ('auto', 'static', 'manual'):
                            config['SETTINGS']['heatingcurve_last'] = _old_heatingcurve
                with open('/opt/config.ini', 'w') as configfile:
                    config.write(configfile)
            sio_remote.emit('return_from_device', {'info': "Zapisano", 'status': 'success'})
            loadconfig()

            # Apply MQTT changes immediately (no service restart needed)
            try:
                mqtt_sync(_prev_mqtt_cfg, reason='settings_remote')
            except Exception:
                logging.exception('MQTT sync after remote settings save failed')

            try:
                _sync_heatcontrol_status()
            except Exception:
                pass

            try:
                _new_heatingcurve = str(globals().get('heatingcurve','')).strip().lower()
                if _new_heatingcurve != _old_heatingcurve:
                    logging.info(f"heatingcurve changed: {_old_heatingcurve} -> {_new_heatingcurve} (immediate curvecalc)")
                    curvecalc()
            except Exception:
                logging.exception('Immediate curvecalc after heatingcurve change failed')
        except:
            sio_remote.emit('return_from_device', {'info': 'Błąd zapisu', 'status': 'danger'})

    if 'get_charts' in data:
        variables=['chartdate', 'charttank', 'charttwi', 'charttwo', 'chartthi', 'charttho', 'charttao', 'charttd', 'chartts', 'chartpdset', 'chartpdact', 'chartpsset', 'chartpsact', 'charteevlevel', 'chartfan1', 'chartfan2', 'chartintemp', 'chartouttemp', 'charthumid', 'charthcurve', 'chartfact', 'chartfset', 'chartflimiton', 'chartmode_quiet', 'chartmode_eco', 'chartmode_turbo','chartthreeway', 'chartsuperheat', 'chartsubcooling', 'charttdef', 'chartdefrost', 'chartheater', 'chartantifreeze']
        values=gen_charts(int(data['get_charts']))
        valname=dict(zip(variables, values))
        charts={"charts": valname}
        logging.info(f"------wielkosc pakietu: {len(json.dumps(valname))}")
        sio_remote.emit("data_from_device", charts)

    elif 'get_settings' in data:
        heatingcurve = config['SETTINGS']['heatingcurve']
        antionoff = config['SETTINGS']['antionoff']
        hpiconn = statusdict['hpiconn']['value']
        settings={"settings": {"SETTINGS$insidetemp": insidetemp,"SETTINGS$emergency_intemp": emergency_intemp,"SETTINGS$outsidetemp": outsidetemp,"SETTINGS$humidity": humidity,"SETTINGS$thermostat_on": thermostat_on,"SETTINGS$lohysteresis": lohysteresis,"SETTINGS$hihysteresis": hihysteresis,"SETTINGS$direct_inside_settemp": direct_inside_settemp,"SETTINGS$antionoff": antionoff,"SETTINGS$antionoffdeltatime": antionoffdeltatime,"SETTINGS$deltatempturbo": deltatempturbo,"SETTINGS$deltatempquiet": deltatempquiet,"SETTINGS$deltatempflimit": deltatempflimit,"SETTINGS$zone_frost_enable": zone_frost_enable,"SETTINGS$zone_frost_temp": zone_frost_temp,"SETTINGS$zone_frost_mode": zone_frost_mode,"SETTINGS$zone_warm_enable": zone_warm_enable,"SETTINGS$zone_warm_temp": zone_warm_temp,"SETTINGS$zone_warm_mode": zone_warm_mode,"SETTINGS$dhwwl": dhwwl,"SETTINGS$dhwnolimit_mode": dhwnolimit_mode,"SETTINGS$dhwuse": dhwuse,"SETTINGS$chscheduler": chscheduler, "SETTINGS$dhwscheduler": dhwscheduler,"SETTINGS$flimit": flimit,"SETTINGS$flimittemp": flimittemp,"SETTINGS$presetautochange": presetautochange,"SETTINGS$presetquiet": presetquiet,"SETTINGS$presetturbo": presetturbo,"SETTINGS$heatingcurve": heatingcurve,"MAIN$heizfreq": timeout,"MAIN$log_level": loglevel,"MAIN$ui_font": globals().get('ui_font', 'inter'),"SETTINGS$hcslope": slope,"SETTINGS$hcpshift": pshift,"SETTINGS$hcamp": hcamp,"SETTINGS$hcman": hcman,"HOMEASSISTANT$HAADDR": haaddr,"HOMEASSISTANT$HAPORT": haport,"HOMEASSISTANT$KEY": hakey,"HOMEASSISTANT$ha_mqtt_discovery": ha_mqtt_discovery,"HOMEASSISTANT$insidesensor": insidesensor,"HOMEASSISTANT$outsidesensor": outsidesensor,"HOMEASSISTANT$humiditysensor": humiditysensor,"MQTT$mqtt": use_mqtt,"MQTT$address": mqtt_broker_addr,"MQTT$port": mqtt_broker_port,"MQTT$mqtt_ssl": mqtt_ssl,"MQTT$main_topic": mqtt_topic,"MQTT$username": mqtt_username,"MQTT$password": mqtt_password,"MQTT$snapshot_interval_s": str(config['MQTT'].get('snapshot_interval_s', '0')).strip(),"MAIN$bindaddress": bindaddr,"MAIN$bindport": bindport,"MAIN$modbusdev": modbusdev,"GPIO$modbus": modbuspin,"GPIO$freqlimit": freqlimitpin,"GPIO$heatdemand": heatdemandpin,"GPIO$cooldemand": cooldemandpin, "HPIAPP$hpikey":hpikey,"HPIAPP$hpiatstart":hpiatstart ,"hpiconn":hpiconn}}
        try:
            settings["settings"].update({
                "SETTINGS$antifreeze_custom_enable": globals().get('antifreeze_custom_enable', '0'),
                "SETTINGS$antifreeze_custom_outtemp": globals().get('antifreeze_custom_outtemp', '0.0'),
                "SETTINGS$antifreeze_custom_twi": globals().get('antifreeze_custom_twi', '0.0'),
                "SETTINGS$antifreeze_custom_two": globals().get('antifreeze_custom_two', '0.0'),
                "SETTINGS$antifreeze_custom_runtime_min": globals().get('antifreeze_custom_runtime_min', '1.0'),
            })
        except Exception:
            pass
        sio_remote.emit("data_from_device", settings)
    #if 'restarted' in data:
    #    grestarted = 0
    if 'mode' in data:
        response = statechange(data['mode'], data['value'], "1")
        sio_remote.emit("return_from_device", {'statechange': data['mode'], 'status': response })
    if 'tempchange' in data:
        msg, response = new_tempchange(data['tempchange'],data['value'],data['directly'])
        code=b2s(response)
        if data['tempchange'] == 'heat':
            sio_remote.emit("data_from_device", {'setpoint': data['value']})
        sio_remote.emit("return_from_device", {'tempchange': msg, 'type': code})
        # Ostrzeżenie tylko dla harmonogramu danego obszaru
        if data.get('tempchange') == 'heat' and chscheduler == "1":
            sio_remote.emit("return_from_device", {'tempchange': 'Masz wlaczony harmonogram CO, temperatura zostanie nadpisana wg harmonogramu', 'type': 'warning' })
        elif data.get('tempchange') == 'dhw' and dhwscheduler == "1":
            sio_remote.emit("return_from_device", {'tempchange': 'Masz wlaczony harmonogram CWU, temperatura zostanie nadpisana wg harmonogramu', 'type': 'warning' })
    if 'curvecalc' in data:
        logging.debug(data)
        curve=curvecalc()
        sio_remote.emit('return_from_device', {'curvecalc': curve })

    if 'get_data' in data:
        heatdemand = GPIO.input(heatdemandpin)
        cooldemand = GPIO.input(cooldemandpin)
        flimiton_gpio = GPIO.input(freqlimitpin)
        flimiton = str(flimiton_gpio)
        flrelay = str(flimiton_gpio)
        restarted = grestarted
        intemp=statusdict['intemp']['value']
        outtemp=statusdict['outtemp']['value']
        tempzone = get_temp_zone(outtemp)
        setpoint=statusdict['settemp']['value']
        hcurve=statusdict['hcurve']['value']
        dhw=statusdict['dhw']['value']
        tank=statusdict['tank']['value']
        mode=statusdict['mode']['value']
        humid=statusdict['humid']['value']
        pch=statusdict['pch']['value']
        pdhw=statusdict['pdhw']['value']
        pcool=statusdict['pcool']['value']
        presetch = presetautochange
        
        ltemp = flimittemp
        fflimit = flimit
        heatingcurve = config['SETTINGS']['heatingcurve']
        antionoff = config['SETTINGS']['antionoff']
        isr241=1
        isr141=1
        while (isr241):
            if (len(R241) == 22):
                tdts=PyHaier.GetTdTs(R241)
                archerror=PyHaier.GetArchError(R241)
                compinfo=PyHaier.GetCompInfo(R241)
                fans=PyHaier.GetFanRpm(R241)
                pdps=PyHaier.GetPdPs(R241)
                eevlevel=PyHaier.GetEEVLevel(R241)
                tsatpd=PyHaier.GetTSatPd(R241)
                tsatps=PyHaier.GetTSatPs(R241)
                tao=PyHaier.GetTao(R241)
                isr241=0
        while (isr141):
            if (len(R141) == 16):
                twitwo = PyHaier.GetTwiTwo(R141)
                thitho = PyHaier.GetThiTho(R141)
                pump=PyHaier.GetPump(R141)
                threeway=PyHaier.Get3way(R141)
                heater=PyHaier.GetHeater(R141)
                heater='on' if str(heater).strip().upper()=='ON' else 'off'
                defrost=PyHaier.GetDefrost(R141)
                antifreeze=PyHaier.GetAntifreeze(R141)
                defrost='on' if str(defrost).strip().upper()=='DEFROST' else 'off'
                antifreeze='on' if str(antifreeze).strip().upper()=='ANTIFREEZE' else 'off'
                isr141=0
        chkwhpd=statusdict['chkwhpd']['value']
        dhwkwhpd=statusdict['dhwkwhpd']['value']
        dtquiet=deltatempquiet
        dtflimit=deltatempflimit
        dtturbo=deltatempturbo
        aoodt=antionoffdeltatime
        
        # --- statusdict ---
        ischanged("heatdemand", heatdemand)
        ischanged("cooldemand", cooldemand)
        ischanged("flimiton", flimiton)
        ischanged("flrelay", flrelay)
        ischanged("pch", pch)
        ischanged("pcool", pcool)
        ischanged("pdhw", pdhw)

        # delta temps
        ischanged("deltatempturbo", dtturbo)
        ischanged("deltatempquiet", dtquiet)
        ischanged("deltatempflimit", dtflimit)

        # R241
        ischanged("tdts", tdts)
        ischanged("archerror", archerror)
        ischanged("compinfo", compinfo)
        ischanged("fans", fans)
        ischanged("pdps", pdps)
        ischanged("eevlevel", eevlevel)
        ischanged("tsatpd", tsatpd)
        ischanged("tsatps", tsatps)
        ischanged("tao", tao)

        # R141
        ischanged("twitwo", twitwo)
        ischanged("thitho", thitho)
        ischanged("pump", pump)
        ischanged("threeway", threeway)
        ischanged("heater", heater)
        
        # NOWE - Tdef / Defrost / Antifreeze / Heater (żeby weszły do locals() i poszły przez sio_remote.emit)
        tdef = statusdict.get("tdef", {}).get("value", "N.A.")
        defrost = statusdict.get("defrost", {}).get("value", "off")
        antifreeze = statusdict.get("antifreeze", {}).get("value", "off")
        error = statusdict.get("error", {}).get("value", "N.A.")
        lasterror = statusdict.get("lasterror", {}).get("value", "N.A.")
        heater = statusdict.get("heater", {}).get("value", "off")
        
        # liczniki
        ischanged("chkwhpd", chkwhpd)
        ischanged("dhwkwhpd", dhwkwhpd)

        
        for name in list(locals().keys()):
            sio_emit={'data_update': {name: locals()[name]}}
            sio_remote.emit('data_from_device', sio_emit)
            #sio_remote.emit("data_from_device", data)

@socketlocal.on('connect')
def handle_connect():
    global grestarted
    # Some reverse proxies / browsers may omit the Referer header on WebSocket upgrade.
    # Keep it as an empty string to avoid crashing the connect handler.
    referer = request.headers.get("Referer") or ""
    if 'charts' in referer:
        variables=['chartdate', 'charttank', 'charttwi', 'charttwo', 'chartthi', 'charttho', 'charttao', 'charttd', 'chartts', 'chartpdset', 'chartpdact', 'chartpsset', 'chartpsact', 'charteevlevel', 'chartfan1', 'chartfan2', 'chartintemp', 'chartouttemp', 'charthumid', 'charthcurve', 'chartfact', 'chartfset', 'chartflimiton', 'chartmode_quiet', 'chartmode_eco', 'chartmode_turbo','chartthreeway', 'chartsuperheat', 'chartsubcooling', 'charttdef', 'chartdefrost', 'chartheater', 'chartantifreeze']
        values=gen_charts()
        valname=dict(zip(variables, values))
        emit('charts', valname)

    elif 'scheduler' in referer:
        schedule1 = open("schedule_ch.json", "r")
        schedule2 = open("schedule_dhw.json", "r")
        data={}
        data['chsch'] = json.loads(schedule1.read())
        data['dhwsch'] = json.loads(schedule2.read())
        emit('scheduler', data)
    elif 'settings' in referer:
        heatingcurve = config['SETTINGS']['heatingcurve']
        antionoff = config['SETTINGS']['antionoff']
        hpiconn = statusdict['hpiconn']['value']
        settings={"SETTINGS$insidetemp": insidetemp,"SETTINGS$emergency_intemp": emergency_intemp,"SETTINGS$outsidetemp": outsidetemp,"SETTINGS$humidity": humidity,"SETTINGS$dhwtemp": dhwtemp,"SETTINGS$thermostat_on": thermostat_on,"SETTINGS$lohysteresis": lohysteresis,"SETTINGS$hihysteresis": hihysteresis,"SETTINGS$direct_inside_settemp": direct_inside_settemp,"SETTINGS$antionoff": antionoff,"SETTINGS$antionoffdeltatime": antionoffdeltatime,"SETTINGS$deltatempturbo": deltatempturbo,"SETTINGS$deltatempquiet": deltatempquiet,"SETTINGS$deltatempflimit": deltatempflimit,"SETTINGS$zone_frost_enable": zone_frost_enable,"SETTINGS$zone_frost_temp": zone_frost_temp,"SETTINGS$zone_frost_mode": zone_frost_mode,"SETTINGS$zone_warm_enable": zone_warm_enable,"SETTINGS$zone_warm_temp": zone_warm_temp,"SETTINGS$zone_warm_mode": zone_warm_mode,"SETTINGS$dhwwl": dhwwl,"SETTINGS$dhwnolimit_mode": dhwnolimit_mode,"SETTINGS$dhwuse": dhwuse,"SETTINGS$chscheduler": chscheduler, "SETTINGS$dhwscheduler": dhwscheduler,"SETTINGS$flimit": flimit,"SETTINGS$flimittemp": flimittemp,"SETTINGS$presetautochange": presetautochange,"SETTINGS$presetquiet": presetquiet,"SETTINGS$presetturbo": presetturbo,"SETTINGS$heatingcurve": heatingcurve,"MAIN$heizfreq": timeout,"MAIN$log_level": loglevel,"MAIN$ui_font": globals().get('ui_font', 'inter'),"SETTINGS$hcslope": slope,"SETTINGS$hcpshift": pshift,"SETTINGS$hcamp": hcamp,"SETTINGS$hcman": hcman,"HOMEASSISTANT$HAADDR": haaddr,"HOMEASSISTANT$HAPORT": haport,"HOMEASSISTANT$KEY": hakey,"HOMEASSISTANT$ha_mqtt_discovery": ha_mqtt_discovery,"HOMEASSISTANT$insidesensor": insidesensor,"HOMEASSISTANT$outsidesensor": outsidesensor,"HOMEASSISTANT$humiditysensor": humiditysensor,
                 "SETTINGS$dhw_heater_assist_enable": globals().get('dhw_heater_assist_enable', '0'),
                 "SETTINGS$dhw_heater_assist_below_temp": globals().get('dhw_heater_assist_below_temp', ''),
                 "SETTINGS$anti_legionella_enable": globals().get('anti_legionella_enable', '0'),
                 "SETTINGS$anti_legionella_temp": globals().get('anti_legionella_temp', '60.0'),
                 "SETTINGS$antifreeze_custom_enable": globals().get('antifreeze_custom_enable', '0'),
                 "SETTINGS$antifreeze_custom_outtemp": globals().get('antifreeze_custom_outtemp', '0.0'),
                 "SETTINGS$antifreeze_custom_twi": globals().get('antifreeze_custom_twi', '0.0'),
                 "SETTINGS$antifreeze_custom_two": globals().get('antifreeze_custom_two', '0.0'),
                 "SETTINGS$antifreeze_custom_runtime_min": globals().get('antifreeze_custom_runtime_min', '1.0'),
                 "MQTT$mqtt": use_mqtt,"HOMEASSISTANT$dhwsensor": config['HOMEASSISTANT'].get('dhwsensor', '').strip(),"MQTT$address": mqtt_broker_addr,"MQTT$port": mqtt_broker_port,"MQTT$mqtt_ssl": mqtt_ssl,"MQTT$main_topic": mqtt_topic,"MQTT$username": mqtt_username,"MQTT$password": mqtt_password,"MQTT$snapshot_interval_s": str(config['MQTT'].get('snapshot_interval_s', '0')).strip(),"MAIN$bindaddress": bindaddr,"MAIN$bindport": bindport,"MAIN$modbusdev": modbusdev,"GPIO$modbus": modbuspin,"GPIO$freqlimit": freqlimitpin,"GPIO$heatdemand": heatdemandpin,"GPIO$cooldemand": cooldemandpin, "HPIAPP$hpikey":hpikey,"HPIAPP$hpiatstart":hpiatstart ,"hpiconn":hpiconn}
        try:
            settings.update({
                'anti_legionella_run': globals().get('anti_legionella_run', '0'),
                'anti_legionella_active': statusdict.get('anti_legionella_active', {}).get('value', 'off'),
            })
        except Exception:
            pass
        emit('settings', settings)
    else:
        restarted = grestarted
        hpiconn=statusdict['hpiconn']['value']
        flimiton=statusdict['flimiton']['value']
        intemp=statusdict['intemp']['value']
        outtemp=statusdict['outtemp']['value']
        # Temperature meta (status / source / age) for tooltips on dashboard
        intemp_status = statusdict.get('intemp_status', {}).get('value', 'ok')
        outtemp_status = statusdict.get('outtemp_status', {}).get('value', 'ok')

        # If src is still N.A. right after reboot, fall back to configured source mode
        _isrc = statusdict.get('intempsrc', {}).get('value', 'N.A.')
        _osrc = statusdict.get('outtempsrc', {}).get('value', 'N.A.')
        if _isrc in ('N.A.', 'N.A', '', None):
            _isrc = insidetemp
        if _osrc in ('N.A.', 'N.A', '', None):
            _osrc = outsidetemp
        intempsrc = _isrc
        outtempsrc = _osrc

        # Minutes since last update (used in tooltip)
        intemptime = statusdict.get('intemptime', {}).get('value', '0')
        outtemptime = statusdict.get('outtemptime', {}).get('value', '0')
        tempzone = get_temp_zone(outtemp)
        setpoint=statusdict['settemp']['value']
        hcurve=statusdict['hcurve']['value']
        dhw=statusdict['dhw']['value']
        tank=statusdict['tank']['value']
        mode=statusdict['mode']['value']
        humid=statusdict['humid']['value']
        pch=statusdict['pch']['value']
        pdhw=statusdict['pdhw']['value']
        with dhw_ondemand_lock:
            dhw_ondemand = 'on' if dhw_ondemand_active else 'off'
        pcool=statusdict['pcool']['value']
        presetch = presetautochange
        heatdemand=GPIO.input(heatdemandpin)
        cooldemand=GPIO.input(cooldemandpin)
        flimiton=GPIO.input(freqlimitpin)
        ltemp = flimittemp
        fflimit = flimit
        heatingcurve = config['SETTINGS']['heatingcurve']
        antionoff = config['SETTINGS']['antionoff']

        # Custom antifreeze runtime state (UI: dashboard Antifreeze indicator should pulse
        # when custom antifreeze is active, even if the page is opened mid-run).
        antifreeze_custom = statusdict.get('antifreeze_custom', {}).get('value', 'off')
        # Fast non-blocking read of service frames (R241/R141).
        # On fresh boot these frames may not be ready yet; never block the dashboard connect.
        tdef = tdts = archerror = compinfo = fans = pdps = eevlevel = tsatpd = tsatps = tao = 'N.A.'
        twitwo = thitho = pump = threeway = heater = defrost = antifreeze = 'N.A.'

        if len(R241) == 22:
            try:
                # R241 block (22 regs): include tdef so it shows immediately in /parameters
                tdef = PyHaier.GetTdef(R241)
                tdts = PyHaier.GetTdTs(R241)
                archerror = PyHaier.GetArchError(R241)
                compinfo = PyHaier.GetCompInfo(R241)
                fans = PyHaier.GetFanRpm(R241)
                pdps = PyHaier.GetPdPs(R241)
                eevlevel = PyHaier.GetEEVLevel(R241)
                tsatpd = PyHaier.GetTSatPd(R241)
                tsatps = PyHaier.GetTSatPs(R241)
                tao = PyHaier.GetTao(R241)
            except Exception:
                logging.exception("Dashboard connect: failed to parse R241 frame")

        if len(R141) == 16:
            try:
                twitwo = PyHaier.GetTwiTwo(R141)
                thitho = PyHaier.GetThiTho(R141)
                pump = PyHaier.GetPump(R141)
                threeway = PyHaier.Get3way(R141)
                heater = PyHaier.GetHeater(R141)
                heater = 'on' if str(heater).strip().upper() == 'ON' else 'off'
                defrost = PyHaier.GetDefrost(R141)
                antifreeze = PyHaier.GetAntifreeze(R141)
                defrost = 'on' if str(defrost).strip().upper() == 'DEFROST' else 'off'
                antifreeze = 'on' if str(antifreeze).strip().upper() == 'ANTIFREEZE' else 'off'
            except Exception:
                logging.exception("Dashboard connect: failed to parse R141 frame")
        chkwhpd=statusdict['chkwhpd']['value']
        dhwkwhpd=statusdict['dhwkwhpd']['value']
        dtquiet=deltatempquiet
        dtflimit=deltatempflimit
        dtturbo=deltatempturbo
        aoodt=antionoffdeltatime

        # Δt (delta) - send the currently cached value on connect so the dashboard
        # doesn't "lose" the value until the next scheduled delta calculation.
        delta = statusdict.get('delta', {}).get('value', 'N.A.')

        for name in list(locals().keys()):
            emit('data_update', {name: locals()[name]})

        # Nie pokazuj komunikatu "Usługa HaierPi startuje" przy każdym powrocie do pulpitu.
        # Flaga grestarted ma być "1" tylko zaraz po realnym restarcie procesu.
        if grestarted == 1:
            grestarted = 0


# Function to run the background function using a scheduler
def run_background_function():
    def _safe_job(fn, name):
        def _wrapped():
            try:
                return fn()
            except Exception:
                logging.exception(f"Scheduled job failed: {name}")
                return None
        return _wrapped

    # Run once at startup so UI gets values immediately after reboot
    _safe_job(GetParameters, "GetParameters_startup")()

    # Custom antifreeze: run once right after first parameter read
    _safe_job(antifreeze_custom_tick, "antifreeze_custom_tick_startup")()

    # DHW heater-only + Anti-legionella: run once after first parameter read
    _safe_job(anti_legionella_tick, "anti_legionella_tick_startup")()
    _safe_job(dhw_heater_assist_tick, "dhw_heater_assist_tick_startup")()

    # Delay initial curve calculation until temperature sensors deliver numeric values
    def _wait_for_temps(max_wait_s=8.0, step_s=0.5):
        start_ts = time.time()
        while time.time() - start_ts < max_wait_s:
            try:
                _i = statusdict.get('intemp', {}).get('value', None)
                _o = statusdict.get('outtemp', {}).get('value', None)
                float(_i)
                float(_o)
                return True
            except Exception:
                time.sleep(step_s)
        return False

    if _wait_for_temps():
        _safe_job(curvecalc, 'curvecalc_startup_delayed')()
    else:
        logging.warning('Startup: temp inputs not ready; running initial curvecalc in 10s anyway')
        threading.Timer(10.0, _safe_job(curvecalc, 'curvecalc_startup_timer')).start()
    every(30).seconds.do(_safe_job(GetParameters, "GetParameters"))
    every(30).seconds.do(_safe_job(antifreeze_custom_tick, "antifreeze_custom_tick"))
    every(30).seconds.do(_safe_job(anti_legionella_tick, "anti_legionella_tick"))
    every(30).seconds.do(_safe_job(dhw_heater_assist_tick, "dhw_heater_assist_tick"))
    every(int(timeout)).minutes.do(_safe_job(curvecalc, "curvecalc"))
    every(1).seconds.do(_safe_job(service_test_tick, "service_test_tick"))
    # Optional: periodic MQTT snapshot (republish all state topics every N seconds)
    every(1).seconds.do(_safe_job(mqtt_snapshot_tick, "mqtt_snapshot_tick"))

    while True:
        try:
            run_pending()
        except Exception:
            logging.exception("Scheduler loop error (run_pending) - continuing")
        time.sleep(1)
        if event.is_set():
            break

def connect_mqtt():
    """MQTT worker thread.

    Runs until mqtt_stop_event is set. Reconnects automatically with a small backoff.
    """
    cl = globals().get('client', None)
    if cl is None:
        return

    backoff = 1.0
    max_backoff = 30.0
    connected_once = False

    while not mqtt_stop_event.is_set():
        # (Re)connect if needed
        try:
            try:
                is_conn = bool(getattr(cl, 'is_connected', lambda: False)())
            except Exception:
                is_conn = False

            sock_open = getattr(cl, '_sock', None) is not None
            if (not is_conn) and (not sock_open):
                try:
                    cl.connect(str(mqtt_broker_addr), int(mqtt_broker_port))
                    connected_once = True
                    backoff = 1.0
                except Exception:
                    if not connected_once:
                        logging.error(colored("MQTT connection error.", "red", attrs=['bold']))
                        connected_once = True
                    time.sleep(backoff)
                    backoff = min(max_backoff, backoff * 1.8)
                    continue

            rc = cl.loop(timeout=1.0)
            if rc != mqtt.MQTT_ERR_SUCCESS:
                # Connection lost or other socket error
                time.sleep(0.5)
        except Exception:
            logging.exception("MQTT worker exception")
            time.sleep(1.0)

    # Stop requested
    try:
        topic = str(getattr(cl, '_client_id', b'').decode())
        if topic:
            cl.publish(topic + "/haierpi/connected", "offline", qos=1, retain=True)
    except Exception:
        pass
    try:
        cl.disconnect()
    except Exception:
        pass

def configure_ha_mqtt_discovery():
    """Publish Home Assistant MQTT Discovery entities.

    This keeps HA configuration fully automatic (no YAML) and publishes
    retained discovery configs so entities survive HA restarts.
    """

    logging.info("Configuring HA discovery")

    # Normalize discovery prefix (HA default is "homeassistant")
    global ha_mqtt_discovery_prefix
    try:
        ha_mqtt_discovery_prefix = (str(ha_mqtt_discovery_prefix or "homeassistant").strip() or "homeassistant")
    except Exception:
        ha_mqtt_discovery_prefix = "homeassistant"
    ha_mqtt_discovery_prefix = ha_mqtt_discovery_prefix.strip('/')

    def _device():
        return {
            "name": "HaierPi",
            "ids": "HaierPi",
            "cu": f"http://{ip_address}:{bindport}",
            "mf": "ktostam",
            "mdl": "HaierPi",
            "sw": version,
        }

    _avty = {
        "avty_t": mqtt_topic + "/haierpi/connected",
        "pl_avail": "online",
        "pl_not_avail": "offline",
    }

    def _pub(domain: str, unique_id: str, payload: dict) -> None:
        """Publish retained discovery config."""
        try:
            cfg = dict(payload)
            cfg.setdefault("dev", _device())
            for k, v in _avty.items():
                cfg.setdefault(k, v)
            topic = f"{ha_mqtt_discovery_prefix}/{domain}/HaierPi/{unique_id}/config"
            client.publish(topic, json.dumps(cfg), qos=1, retain=True)
        except Exception:
            logging.exception("HA discovery publish failed: %s/%s", domain, unique_id)

    def _clear(domain: str, unique_id: str) -> None:
        """Remove old/legacy entities (empty retained config)."""
        try:
            client.publish(
                f"{ha_mqtt_discovery_prefix}/{domain}/HaierPi/{unique_id}/config",
                "",
                qos=1,
                retain=True,
            )
        except Exception:
            pass

    def st(key: str) -> str:
        """Resolve state topic from statusdict (after topic layout mapping)."""
        try:
            return mqtt_topic + str(statusdict[key]['mqtt'])
        except Exception:
            return mqtt_topic + f"/status/{key}/state"

    # --- Cleanup of removed legacy entities ---
    # Old duplicated sensors (we keep only selects)
    _clear('sensor', 'HaierPi_Mode')
    _clear('sensor', 'HaierPi_DHWMode')
    # DHW set temperature used to be a sensor; it's now a controllable number
    _clear('sensor', 'HaierPi_DHWSet')

    # Removed DHW heater-only entities (replaced by heater assist)
    _clear('number', 'HaierPi_DHWHeaterOnlyOutTempThr')
    _clear('number', 'HaierPi_DHWHeaterOnlyHystOn')
    _clear('number', 'HaierPi_DHWHeaterOnlyHystOff')
    _clear('switch', 'HaierPi_DHWHeaterOnlyEnable')
    _clear('binary_sensor', 'HaierPi_DHWHeaterOnlyActive')

    # --- Entity builders ---
    def configure_sensor(name, status_topic, unique_id, unit=None, device_class=None, state_class=None, template=None):
        cfg = {
            "name": name,
            "stat_t": status_topic,
            "uniq_id": unique_id,
            "exp_aft": 0,
        }
        if unit is not None:
            cfg["unit_of_meas"] = unit
        if device_class is not None:
            cfg["dev_cla"] = device_class
        if state_class is not None:
            cfg["stat_cla"] = state_class
        if template is not None:
            cfg["val_tpl"] = template
        _pub("sensor", unique_id, cfg)

    def configure_number(name, command_topic, status_topic, unique_id, unit, min_v, max_v, device_class=None, step="0.1"):
        cfg = {
            "name": name,
            "cmd_t": command_topic,
            "stat_t": status_topic,
            "uniq_id": unique_id,
            "unit_of_meas": unit,
            "min": min_v,
            "max": max_v,
            "mode": "slider",
            "step": step,
        }
        if device_class is not None:
            cfg["dev_cla"] = device_class
        _pub("number", unique_id, cfg)

    def configure_select(name, command_topic, status_topic, unique_id, options):
        cfg = {
            "name": name,
            "cmd_t": command_topic,
            "stat_t": status_topic,
            "uniq_id": unique_id,
            "ops": options,
        }
        _pub("select", unique_id, cfg)

    def configure_binary_sensor(name, status_topic, unique_id, device_class=None, template=None, payload_on="on", payload_off="off"):
        cfg = {
            "name": name,
            "stat_t": status_topic,
            "uniq_id": unique_id,
            "pl_on": payload_on,
            "pl_off": payload_off,
            "exp_aft": 0,
        }
        if device_class is not None:
            cfg["dev_cla"] = device_class
        if template is not None:
            cfg["val_tpl"] = template
        _pub("binary_sensor", unique_id, cfg)

    def configure_switch(name, command_topic, status_topic, unique_id, payload_on="1", payload_off="0", icon=None):
        cfg = {
            "name": name,
            "cmd_t": command_topic,
            "stat_t": status_topic,
            "uniq_id": unique_id,
            "pl_on": payload_on,
            "pl_off": payload_off,
            "stat_on": payload_on,
            "stat_off": payload_off,
            "opt": False,
            "exp_aft": 0,
        }
        if icon is not None:
            cfg["ic"] = icon
        _pub("switch", unique_id, cfg)

    def configure_climate(name, unique_id, cfg: dict):
        payload = {"name": name, "uniq_id": unique_id}
        payload.update(cfg)
        _pub("climate", unique_id, payload)

    def configure_water_heater(name, unique_id, cfg: dict):
        payload = {"name": name, "uniq_id": unique_id}
        payload.update(cfg)
        _pub("water_heater", unique_id, payload)

    # --- NUMBER ---
    configure_number("CH Target temperature", mqtt_topic + "/ch/target_temp/set", st('settemp'), "HaierPi_SetTemp", "°C", 0.0, 50.0, "temperature", step="0.5")
    configure_number("DHW Target temperature", mqtt_topic + "/dhw/target_temp/set", st('dhw'), "HaierPi_DHWTargetTemp", "°C", 10.0, 65.0, "temperature", step="0.5")
    configure_number("DHW heater assist: outside temp threshold", mqtt_topic + "/dhw/heater_assist/outtemp_thr/set", st('dhw_heater_assist_below_temp'), "HaierPi_DHWHeaterAssistOutTempThr", "°C", -50.0, 30.0, "temperature", step="0.5")
    configure_number("Anti-legionella target temperature", mqtt_topic + "/dhw/anti_legionella/temp/set", st('anti_legionella_temp'), "HaierPi_AntiLegionellaTemp", "°C", 40.0, 75.0, "temperature", step="0.5")

    configure_sensor("CH compensation (A03)", st('tempcompensation'), "HaierPi_TempComp", "°C", "temperature", "measurement", None)
    configure_number("CH compensation set (A03)", mqtt_topic + "/service/temp_compenstations/ch/set", st('tempcompensation_set'), "HaierPi_TempCompSet", "°C", -15.0, 15.0, "temperature", step="0.5")

    configure_sensor("DHW compensation (A0d)", st('dhwcompensation'), "HaierPi_DHWComp", "°C", "temperature", "measurement", None)
    configure_number("DHW compensation set (A0d)", mqtt_topic + "/service/temp_compenstations/dhw/set", st('dhwcompensation_set'), "HaierPi_DHWCompSet", "°C", -15.0, 15.0, "temperature", step="0.5")

    configure_number("FLimit threshold temp", mqtt_topic + "/ch/flimit/temp/set", st('flimittemp'), "HaierPi_FLimitTemp", "°C", -30.0, 30.0, "temperature", step="0.5")
    configure_number("Quiet threshold temp", mqtt_topic + "/ch/preset/quiet_temp/set", st('presetquiet'), "HaierPi_PresetQuietTemp", "°C", -30.0, 30.0, "temperature", step="0.5")
    configure_number("Turbo threshold temp", mqtt_topic + "/ch/preset/turbo_temp/set", st('presetturbo'), "HaierPi_PresetTurboTemp", "°C", -30.0, 30.0, "temperature", step="0.5")

    configure_number("Direct Thermostat target", mqtt_topic + "/ch/thermostat/target_temp/set", st('direct_inside_settemp'), "HaierPi_DirectInsideSetTemp", "°C", 5.0, 30.0, "temperature", step="0.5")

    configure_number("Frost zone temp", mqtt_topic + "/ch/zones/frost/temp/set", st('zone_frost_temp'), "HaierPi_ZoneFrostTemp", "°C", -50.0, 50.0, "temperature", step="0.5")
    configure_number("Warm zone temp", mqtt_topic + "/ch/zones/warm/temp/set", st('zone_warm_temp'), "HaierPi_ZoneWarmTemp", "°C", -50.0, 50.0, "temperature", step="0.5")

    configure_number("Custom antifreeze: outside temp", mqtt_topic + "/ch/custom-antifreeze/outtemp_thr/set", st('antifreeze_custom_outtemp'), "HaierPi_AntifreezeCustomOutTemp", "°C", -50.0, 50.0, "temperature", step="0.1")
    configure_number("Custom antifreeze: Twi", mqtt_topic + "/ch/custom-antifreeze/twi_thr/set", st('antifreeze_custom_twi'), "HaierPi_AntifreezeCustomTwi", "°C", -50.0, 50.0, "temperature", step="0.1")
    configure_number("Custom antifreeze: Two", mqtt_topic + "/ch/custom-antifreeze/two_thr/set", st('antifreeze_custom_two'), "HaierPi_AntifreezeCustomTwo", "°C", -50.0, 50.0, "temperature", step="0.1")
    configure_number("Custom antifreeze: runtime", mqtt_topic + "/ch/custom-antifreeze/runtime_min/set", st('antifreeze_custom_runtime_min'), "HaierPi_AntifreezeCustomRuntime", "min", 0.5, 240.0, "duration", step="0.5")

    configure_number("Service test: runtime", mqtt_topic + "/service/tests/runtime_min/set", st('service_test_runtime_min'), "HaierPi_ServiceTestRuntime", "min", 0.5, 240.0, "duration", step="0.5")

    # --- SENSOR ---
    configure_sensor("Heating curve value", st('hcurve'), "HaierPi_Heatcurve", "°C", "temperature", "measurement", None)
    configure_sensor("DHW actual temperature", st('tank'), "HaierPi_DHWCurrent", "°C", "temperature", "measurement", None)
    configure_sensor("Outside temperature", st('outtemp'), "HaierPi_OutsideTemp", "°C", "temperature", "measurement", None)
    configure_sensor("Inside temperature", st('intemp'), "HaierPi_InsideTemp", "°C", "temperature", "measurement", None)
    configure_sensor("Humidity inside", st('humid'), "HaierPi_HumidityInside", "%", "humidity", "measurement", None)

    configure_sensor("3-way valve", st('threeway'), "HaierPi_3wayvalve", None, None, None, None)
    configure_sensor("Pump", st('pump'), "HaierPi_Pump", None, None, None, None)

    configure_sensor("Arch Error", st('archerror'), "HaierPi_Archerror", None, None, None, "{{ value | int(0) }}")
    configure_sensor("Active Error", st('error'), "HaierPi_Error", None, None, None, "{{ value | int(0) }}")
    configure_sensor("Last Error", st('lasterror'), "HaierPi_LastError", None, None, None, "{{ value | int(0) }}")

    configure_sensor("Tao", st('tao'), "HaierPi_Tao", "°C", "temperature", "measurement", None)
    configure_sensor("Tdef", st('tdef'), "HaierPi_Tdef", "°C", "temperature", "measurement", None)

    configure_sensor("Twi", st('twitwo'), "HaierPi_Twi", "°C", "temperature", "measurement", "{{ value_json[0] | float }}")
    configure_sensor("Two", st('twitwo'), "HaierPi_Two", "°C", "temperature", "measurement", "{{ value_json[1] | float }}")
    configure_sensor("Thi", st('thitho'), "HaierPi_Thi", "°C", "temperature", "measurement", "{{ value_json[0] | float }}")
    configure_sensor("Tho", st('thitho'), "HaierPi_Tho", "°C", "temperature", "measurement", "{{ value_json[1] | float }}")

    configure_sensor("Fan 1", st('fans'), "HaierPi_Fan1", "rpm", None, "measurement", "{{ value_json[0] | float }}")
    configure_sensor("Fan 2", st('fans'), "HaierPi_Fan2", "rpm", None, "measurement", "{{ value_json[1] | float }}")

    configure_sensor("Pdset", st('pdps'), "HaierPi_Pd_set", "bar", "pressure", "measurement", "{{ value_json[0] | float }}")
    configure_sensor("Pdact", st('pdps'), "HaierPi_Pd_act", "bar", "pressure", "measurement", "{{ value_json[1] | float }}")
    configure_sensor("Psset", st('pdps'), "HaierPi_Ps_set", "bar", "pressure", "measurement", "{{ value_json[2] | float }}")
    configure_sensor("Psact", st('pdps'), "HaierPi_Ps_act", "bar", "pressure", "measurement", "{{ value_json[3] | float }}")

    configure_sensor("TSatPdset", st('tsatpd'), "HaierPi_TSatPd_set", "°C", "temperature", "measurement", "{{ value_json[0] | float }}")
    configure_sensor("TSatPdact", st('tsatpd'), "HaierPi_TSatPd_act", "°C", "temperature", "measurement", "{{ value_json[1] | float }}")
    configure_sensor("TSatPsset", st('tsatps'), "HaierPi_TSatPs_set", "°C", "temperature", "measurement", "{{ value_json[0] | float }}")
    configure_sensor("TSatPsact", st('tsatps'), "HaierPi_TSatPs_act", "°C", "temperature", "measurement", "{{ value_json[1] | float }}")

    configure_sensor("Heatdemand", st('heatdemand'), "HaierPi_HeatDemand", None, None, "measurement", "{{ value_json | float }}")
    configure_sensor("Cooldemand", st('cooldemand'), "HaierPi_CoolDemand", None, None, None, "{{ value | float }}")

    configure_sensor("Superheat", st('superheat'), "HaierPi_Superheat", "°C", "temperature", "measurement", None)
    configure_sensor("Subcooling", st('subcooling'), "HaierPi_Subcooling", "°C", "temperature", "measurement", None)

    configure_sensor("Delta", st('delta'), "HaierPi_Delta", "°C", "temperature", "measurement", "{{ value_json | float }}")
    configure_sensor("Delta Temp FLimit", st('deltatempflimit'), "HaierPi_DeltaTempFLimit", "°C", "temperature", "measurement", "{{ value_json | float }}")
    configure_sensor("Delta Temp Quiet", st('deltatempquiet'), "HaierPi_DeltaTempQuiet", "°C", "temperature", "measurement", "{{ value_json | float }}")
    configure_sensor("Delta Temp Turbo", st('deltatempturbo'), "HaierPi_DeltaTempTurbo", "°C", "temperature", "measurement", "{{ value_json | float }}")
    configure_sensor("Anti On-Off Delta Time", st('antionoffdeltatime'), "HaierPi_AntiOnOffDeltaTime", "min", "duration", "measurement", "{{ value_json | float }}")

    configure_sensor("Compressor fact", st('compinfo'), "HaierPi_Compfact", "Hz", "frequency", "measurement", "{{ value_json[0] | float }}")
    configure_sensor("Compressor fset", st('compinfo'), "HaierPi_Compfset", "Hz", "frequency", "measurement", "{{ value_json[1] | float }}")
    configure_sensor("Compressor current", st('compinfo'), "HaierPi_Compcurrent", "A", "current", "measurement", "{{ value_json[2] | float }}")
    configure_sensor("Compressor voltage", st('compinfo'), "HaierPi_Compvoltage", "V", "voltage", "measurement", "{{ value_json[3] | float }}")
    configure_sensor("Compressor temperature", st('compinfo'), "HaierPi_Comptemperature", "°C", "temperature", "measurement", "{{ value_json[4] | float }}")

    configure_sensor("Td", st('tdts'), "HaierPi_Td", "°C", "temperature", "measurement", "{{ value_json[0] | float }}")
    configure_sensor("Ts", st('tdts'), "HaierPi_Ts", "°C", "temperature", "measurement", "{{ value_json[1] | float }}")

    configure_sensor("EEV level", st('eevlevel'), "HaierPi_EEVLevel", None, None, "measurement", "{{ value | float }}")

    # --- SELECT ---
    configure_select("FLimit mode", mqtt_topic + "/ch/flimit/mode/set", st('flimit'), "HaierPi_FLimitMode", ["auto", "manual"])
    configure_select("Preset mode", mqtt_topic + "/ch/preset/mode/set", st('presetautochange'), "HaierPi_PresetAutoChange", ["auto", "manual"])
    configure_select("Preset", mqtt_topic + "/ch/preset/set", st('mode'), "Haier_Preset", ["eco", "quiet", "turbo"])
    configure_select("Heating Control", mqtt_topic + "/ch/heatcontrol/set", st('heatcontrol'), "HaierPi_HeatControl", ["curve", "direct"])
    configure_select("Heating Curve Mode", mqtt_topic + "/ch/heatingcurve_mode/set", st('heatingcurve_mode'), "HaierPi_HeatCurveMode", ["auto", "static", "manual"])
    configure_select("Frost zone mode", mqtt_topic + "/ch/zones/frost/mode/set", st('zone_frost_mode'), "HaierPi_ZoneFrostMode", ["turbo", "eco", "quiet", "quiet_flimit"])
    configure_select("Warm zone mode", mqtt_topic + "/ch/zones/warm/mode/set", st('zone_warm_mode'), "HaierPi_ZoneWarmMode", ["turbo", "eco", "quiet", "quiet_flimit"])
    configure_select("CH Mode", mqtt_topic + "/ch/mode/set", mqtt_topic + "/ch/mode/state", "HaierPi_Mode", ["off", "heat", "cool"])
    configure_select("DHW Mode", mqtt_topic + "/dhw/mode/set", mqtt_topic + "/dhw/mode/state", "HaierPi_DHWMode", ["off", "heat"])

    # --- SWITCH ---
    configure_switch("FLimit relay", mqtt_topic + "/ch/flimit/relay/set", st('flrelay'), "HaierPi_FLRelay", payload_on="1", payload_off="0")
    configure_switch("Thermostat enable", mqtt_topic + "/ch/thermostat/enabled/set", st('thermostat_on'), "HaierPi_ThermostatOn", payload_on="1", payload_off="0")
    configure_switch("Frost zone enable", mqtt_topic + "/ch/zones/frost/enabled/set", st('zone_frost_enable'), "HaierPi_ZoneFrostEnable", payload_on="1", payload_off="0")
    configure_switch("Warm zone enable", mqtt_topic + "/ch/zones/warm/enabled/set", st('zone_warm_enable'), "HaierPi_ZoneWarmEnable", payload_on="1", payload_off="0")
    configure_switch("Custom antifreeze enable", mqtt_topic + "/ch/custom-antifreeze/enabled/set", st('antifreeze_custom_enable'), "HaierPi_AntifreezeCustomEnable", payload_on="1", payload_off="0")

    configure_switch("Service test: Pump (A05)", mqtt_topic + "/service/tests/pump/set", st('service_set_pump'), "HaierPi_ServiceSetPump", payload_on="on", payload_off="off")
    configure_switch("Service test: Heater (A04)", mqtt_topic + "/service/tests/heater/set", st('service_set_heater'), "HaierPi_ServiceSetHeater", payload_on="on", payload_off="off")

    configure_switch("PCH_Control", mqtt_topic + "/ch/pch/set", st('pch'), "HaierPi_PCH_Control", payload_on="on", payload_off="off")
    configure_switch("PCool_Control", mqtt_topic + "/ch/pcool/set", st('pcool'), "HaierPi_PCool_Control", payload_on="on", payload_off="off")
    configure_switch("PDHW_Control", mqtt_topic + "/dhw/pdhw/set", st('pdhw'), "HaierPi_PDHW_Control", payload_on="on", payload_off="off")

    configure_switch("DHW on-demand", mqtt_topic + "/dhw/ondemand/set", st('dhw_ondemand'), "HaierPi_DHWOndemand", payload_on="on", payload_off="off")

    configure_switch("DHW heater assist enable", mqtt_topic + "/dhw/heater_assist/enabled/set", st('dhw_heater_assist_enable'), "HaierPi_DHWHeaterAssistEnable", payload_on="1", payload_off="0")
    configure_switch("Anti-legionella enable", mqtt_topic + "/dhw/anti_legionella/enabled/set", st('anti_legionella_enable'), "HaierPi_AntiLegionellaEnable", payload_on="1", payload_off="0")
    configure_switch("Anti-legionella run cycle", mqtt_topic + "/dhw/anti_legionella/run/set", st('anti_legionella_run'), "HaierPi_AntiLegionellaRun", payload_on="1", payload_off="0")

    # --- BINARY SENSOR (Read only) ---
    configure_binary_sensor("PCH_State", st('pch'), "HaierPi_PCH")
    configure_binary_sensor("PCool_State", st('pcool'), "HaierPi_PCool")
    configure_binary_sensor("PDHW_State", st('pdhw'), "HaierPi_PDHW")

    configure_binary_sensor("CH heating active", st('ch_heating'), "HaierPi_CHHeating", device_class="heat")
    configure_binary_sensor("DHW heating active", st('dhw_heating'), "HaierPi_DHWHeating", device_class="heat")

    configure_binary_sensor("CH cooling active", st('ch_cooling'), "HaierPi_CHCooling", device_class="cold")

    configure_binary_sensor("Heat demand", st('heatdemand'), "HaierPi_HeatDemandOn", payload_on="1", payload_off="0")
    configure_binary_sensor("Cool demand", st('cooldemand'), "HaierPi_CoolDemandOn", payload_on="1", payload_off="0")

    configure_binary_sensor("FLimit Active", st('flimiton'), "HaierPi_FLimitOn", payload_on="1", payload_off="0")
    configure_binary_sensor("Defrost", st('defrost'), "HaierPi_Defrost")
    configure_binary_sensor("Antifreeze", st('antifreeze'), "HaierPi_Antifreeze")
    configure_binary_sensor("Custom antifreeze active", st('antifreeze_custom'), "HaierPi_AntifreezeCustom")
    configure_binary_sensor("Heater", st('heater'), "HaierPi_Heater")
    configure_binary_sensor("DHW heater assist active", st('dhw_heater_assist_active'), "HaierPi_DHWHeaterAssistActive")
    configure_binary_sensor("Anti-legionella active", st('anti_legionella_active'), "HaierPi_AntiLegionellaActive")
    configure_binary_sensor("Connected", mqtt_topic + "/haierpi/connected", "HaierPi_Connected", device_class="connectivity", payload_on="online", payload_off="offline")

    # --- New: native HA entities (no YAML) ---
    # CH as climate.*
    configure_climate(
        "HaierPi CH",
        "HaierPi_Climate_CH",
        {
            "modes": ["off", "heat", "cool"],
            "mode_cmd_t": mqtt_topic + "/ch/mode/set",
            "mode_stat_t": mqtt_topic + "/ch/mode/state",
            "temp_cmd_t": mqtt_topic + "/ch/target_temp/set",
            "temp_stat_t": st('settemp'),
            "curr_temp_t": st('intemp'),
            "temp_unit": "C",
            "min_temp": 6.0,
            "max_temp": 55.0,
            "temp_step": 0.1,
            "precision": 0.1,
            "pr_modes": ["eco", "quiet", "turbo"],
            "pr_mode_cmd_t": mqtt_topic + "/ch/preset/set",
            "pr_mode_stat_t": st('mode'),
        },
    )

    # DHW as climate.*
    configure_climate(
        "HaierPi DHW",
        "HaierPi_Climate_DHW",
        {
            "modes": ["off", "heat"],
            "mode_cmd_t": mqtt_topic + "/dhw/mode/set",
            "mode_stat_t": mqtt_topic + "/dhw/mode/state",
            "temp_cmd_t": mqtt_topic + "/dhw/target_temp/set",
            "temp_stat_t": st('dhw'),
            "curr_temp_t": st('tank'),
            "temp_unit": "C",
            "min_temp": 30.0,
            "max_temp": 65.0,
            "temp_step": 1.0,
            "precision": 0.1,
        },
    )

def threads_check():
    global dead
    while True:
        th = threads_state()
        if not th['bg']:
            if dead == 0:
                logging.error("Background thread DEAD")

                dead = 1
        elif not th['serial']:
            if dead == 0:
                logging.error("Serial Thread DEAD")
                dead = 1
        elif th.get('mqtt_enabled'):
            if th['mqtt'] is False:
                if dead == 0:
                    logging.error("MQTT thread DEAD")
                    dead = 1
        if dead == 1:
            now = datetime.now()
            crash_date=now.strftime("%Y-%m-%d_%H-%M-%S")
            proc = subprocess.Popen(['journalctl', '-t', 'HaierPi', '-p','debug'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
            f=open("/opt/haier/crashlog-"+crash_date+".log", "w")
            for line in iter(proc.stdout.readline, ''):
                f.write(line)
            f.close()
            with open("/opt/haier/crashlog-"+crash_date+".log", "r") as f:
                files = {"file": f}
                headers = {'Authorization': f"Bearer {hpikey}"}
                r=requests.post("https://app.haierpi.pl/upload", files=files, headers=headers)
            dead = 2

        time.sleep(1)
        if event.is_set():
            break
        #restart()


def threads_state():
    """Return liveness state of core threads.

    Used both by threads_check() (watchdog) and /api/hpi_status (UI LED).
    """
    def _alive(t):
        try:
            return bool(t and t.is_alive())
        except Exception:
            return False

    bg = _alive(globals().get('bg_thread'))
    serial = _alive(globals().get('serial_thread'))
    mqtt_enabled = (str(globals().get('use_mqtt', '0')) == '1')
    mqtt = None
    if mqtt_enabled:
        mqtt = _alive(globals().get('mqtt_bg'))
    return {
        'bg': bg,
        'serial': serial,
        'mqtt': mqtt,
        'mqtt_enabled': mqtt_enabled,
    }

# Start the Flask app in a separate thread
babel.init_app(app, locale_selector=get_locale)
#babel.init_app(app)

if __name__ == '__main__':
    loadconfig()
    app.jinja_env.globals['get_locale'] = 'pl'
    logging.warning(colored(welcome,"yellow", attrs=['bold']))
    logging.warning(colored(f"Service running: http://{ip_address}:{bindport} ", "green"))
    logging.warning(f"MQTT: {'enabled' if use_mqtt == '1' else 'disabled'}")
    logging.warning(f"Home Assistant MQTT Discovery: {'enabled' if ha_mqtt_discovery == '1' and use_mqtt == '1' else 'disabled'}")
    signal.signal(signal.SIGINT, handler)
    signal.signal(signal.SIGTERM, handler)
    bg_thread = threading.Thread(target=run_background_function, daemon=True)
    bg_thread.start()
    # Start/stop MQTT according to current config (can be toggled in Settings without restart)
    try:
        mqtt_sync(None, reason='startup')
    except Exception:
        logging.exception('MQTT sync at startup failed')

    serial_thread = threading.Thread(target=ReadPump, daemon=True)
    serial_thread.start()
    threadcheck = threading.Thread(target=threads_check)
    threadcheck.start()
    #serve(socketio, host=bindaddr, port=bindport)
        #app.run(debug=False, host=bindaddr, port=bindport)#, ssl_context='adhoc')
    socketlocal.run(app, host=bindaddr, port=bindport, allow_unsafe_werkzeug=True, debug=False)
