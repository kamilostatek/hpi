"""HaierPi GPIO sysfs adapter for NanoPi and Raspberry Pi (BCM mapping).

The legacy HaierPi app uses the Linux sysfs GPIO API. Newer kernels may
allocate the Broadcom gpiochip at a non-zero global base, so BCM 17 may be
/sys/class/gpio/gpio529 rather than gpio17. Resolve the mapping explicitly.

No GPIO is exported and no outputs are changed on module import.
"""

import errno
import logging
import time
from functools import lru_cache
from pathlib import Path

HIGH, LOW = 1, 0
OUT, IN = 'out', 'in'
BASE = Path('/sys/class/gpio')
_OWNED = set()


@lru_cache(maxsize=1)
def _primary_gpiochip():
    """Locate the on-SoC Broadcom controller; never select an expander."""
    matches = []
    for chip in BASE.glob('gpiochip*'):
        if not chip.is_dir():
            continue
        try:
            label = (chip / 'label').read_text(encoding='ascii').strip().lower()
            base = int((chip / 'base').read_text(encoding='ascii').strip())
            count = int((chip / 'ngpio').read_text(encoding='ascii').strip())
        except (OSError, ValueError):
            continue
        if base < 0 or count < 28:
            continue
        if ('pinctrl-bcm' in label or 'bcm2835-gpio' in label or
                'bcm2711-gpio' in label):
            matches.append((base, count, label))

    if len(matches) != 1:
        raise RuntimeError(
            'Nie mozna jednoznacznie wykryc glownego kontrolera GPIO BCM '
            'Raspberry Pi w /sys/class/gpio/gpiochip*. '
            'Nie zmieniono GPIO, sprawdz jadro i interfejs sysfs.'
        )
    return matches[0]


def _sysfs_pin(pin):
    bcm = int(pin)
    model = Path('/proc/device-tree/model')
    if not model.exists() or b'Raspberry Pi' not in model.read_bytes():
        return bcm
    base, count, _ = _primary_gpiochip()
    if bcm < 0 or bcm >= count:
        raise ValueError('GPIO BCM poza zakresem glownego kontrolera: ' + str(bcm))
    return base + bcm


def _gpio_dir(pin):
    return BASE / ('gpio' + str(_sysfs_pin(pin)))


def setup(pin, action, initial=None):
    if action not in (OUT, IN):
        raise ValueError('GPIO direction must be in or out')
    if initial is not None:
        if action != OUT or initial not in (LOW, HIGH):
            raise ValueError('initial requires an output and LOW or HIGH')
        action = 'low' if initial == LOW else 'high'
    resolved = _sysfs_pin(pin)
    path = BASE / ('gpio' + str(resolved))
    if not path.is_dir():
        try:
            (BASE / 'export').write_text(str(resolved), encoding='ascii')
            _OWNED.add(resolved)
        except OSError as exc:
            if exc.errno != errno.EBUSY:
                raise
    deadline = time.monotonic() + 1.0
    while not (path / 'direction').exists():
        if time.monotonic() >= deadline:
            raise RuntimeError('GPIO direction unavailable: ' + str(resolved))
        time.sleep(0.01)
    (path / 'direction').write_text(action, encoding='ascii')


def output(pin, value):
    try:
        (_gpio_dir(pin) / 'value').write_text(str(int(value)), encoding='ascii')
    except OSError as exc:
        logging.getLogger(__name__).error('GPIO %s output failed: %s', pin, exc)
        return False


def input(pin):
    try:
        return (_gpio_dir(pin) / 'value').read_text(encoding='ascii').strip()
    except OSError as exc:
        logging.getLogger(__name__).error('GPIO %s input failed: %s', pin, exc)
        return False


def cleanup(pin):
    # Never unexport a line managed by another process.
    resolved = _sysfs_pin(pin)
    if resolved in _OWNED:
        if (BASE / ('gpio' + str(resolved))).is_dir():
            (BASE / 'unexport').write_text(str(resolved), encoding='ascii')
        _OWNED.discard(resolved)
