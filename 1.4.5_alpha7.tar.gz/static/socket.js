document.addEventListener("DOMContentLoaded", function() {
	var socket = io();
	window.socket = socket;
	try { window.dispatchEvent(new Event("haier_socket_ready")); } catch (e) {}
window.__tempZone = window.__tempZone || 'normal';

	const url = new URL (document.URL)
	var path = url.pathname
	var adds = false
	if (path == '/parameters') {
		adds = true
		//console.log(adds)
	}

// ---- UI helper: DHW card can be disabled via config (SETTINGS$dhwuse) ----
function dhwUiDisabled() {
  const card = document.getElementById('dhw-card');
  return !!(card && card.classList.contains('dhw-disabled'));
}

// ---- Formatting helper for Parameters: always show 1 decimal place (e.g., 20.0) ----
function fmt1(val) {
  // Returns a string with 1 decimal place, or "N.A" if value is not a valid number.
  if (val === null || val === undefined) return "N.A";
  const s = String(val).trim();
  if (s === "" || s.toUpperCase() === "N.A" || s.toLowerCase() === "nan") return "N.A";
  const num = Number(s);
  if (!Number.isFinite(num)) return s;   // keep original for non-numeric states like "ERR"
  return num.toFixed(1);
}

// ---- UI helper: CH setpoint icon (dashboard)
// In DIRECT mode (heatcontrol=direct): show 🔥 for pch and ❄️ for pcool (fallback: power).
// In CURVE mode (heatcontrol=curve): show 🏠 (user adjusts indoor target via curve).
function setChSettempModeIcon(iconClass) {
  const el = document.getElementById('ch-settemp-mode-icon');
  if (!el) return;
  // Ensure only one Bootstrap Icon class is active (besides the base "bi")
  ['bi-power', 'bi-fire', 'bi-snow', 'bi-house'].forEach(c => el.classList.remove(c));
  if (iconClass) el.classList.add(iconClass);
}

function updateChSettempModeIcon() {
  const ctrl = String(window.__heatcontrol ?? '').toLowerCase().trim();
  const curveMode = String(window.__heatingCurve ?? '').toLowerCase().trim();
  // Treat as CURVE when explicitly set, or when legacy heatingcurve is not "directly".
  if (ctrl === 'curve' || (ctrl !== 'direct' && curveMode && curveMode !== 'directly')) {
    setChSettempModeIcon('bi-house');
    return;
  }
  // default (direct / unknown)
  const sel = document.getElementById('powerheat');
  const mode = sel ? String(sel.value || '').toLowerCase().trim() : '';
  if (mode === 'pcool') setChSettempModeIcon('bi-snow');
  else if (mode === 'pch') setChSettempModeIcon('bi-fire');
  else setChSettempModeIcon('bi-power');
}

// ---- DHW on-demand: button gating (avoid starting when tank is already hot; also block while cycle is active) ----
const DHW_ONDEMAND_MIN_DELTA = 5.0;
let lastTankTemp = null;
let lastDhwSetTemp = null;
let lastDhwOnDemandActive = false;
let lastDhwHeaterAssistActive = false;
let lastAntiLegionellaActive = false;
let lastAntiLegionellaRunReq = false;

const dhwOnDemandBtn = document.getElementById('dhwset-btn');
const dhwOnDemandAvailable = !!(dhwOnDemandBtn && dhwOnDemandBtn.getAttribute('data-bs-toggle') === 'tooltip');

function parseMaybeNumber(v) {
  if (v === null || v === undefined) return null;
  const s = String(v).trim().replace(',', '.');
  if (!s || s.toUpperCase() === 'N.A' || s.toLowerCase() === 'nan') return null;
  let buf = '';
  let gotDigit = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    const isDigit = ch >= '0' && ch <= '9';
    if (isDigit || ch === '.' || ch === '-' || ch === '+') {
      buf += ch;
      if (isDigit) gotDigit = true;
    } else if (gotDigit) {
      break;
    }
  }
  if (!buf) return null;
  const n = Number(buf);
  return Number.isFinite(n) ? n : null;
}

function setDhwOnDemandButtonEnabled(enabled) {
  if (!dhwOnDemandBtn) return;
  // Do not override server-side read-only mode (when feature is unavailable)
  if (!dhwOnDemandAvailable) return;

  function initTooltip() {
    try {
      // keep tooltip attributes (Bootstrap reads title at init)
      dhwOnDemandBtn.setAttribute('data-bs-toggle', 'tooltip');
      dhwOnDemandBtn.setAttribute('data-bs-placement', 'top');
      const key = 'dhwondemand.tooltip';
      if (window.i18next && i18next.exists(key)) {
        dhwOnDemandBtn.setAttribute('data-bs-title', i18next.t(key));
      }
      const inst = bootstrap.Tooltip.getInstance(dhwOnDemandBtn);
      if (inst) inst.dispose();
      new bootstrap.Tooltip(dhwOnDemandBtn);
    } catch (e) {}
  }

  function disposeTooltip() {
    try {
      const inst = bootstrap.Tooltip.getInstance(dhwOnDemandBtn);
      if (inst) inst.dispose();
    } catch (e) {}
  }

  if (enabled) {
    dhwOnDemandBtn.disabled = false;
    dhwOnDemandBtn.classList.remove('disabled');
    dhwOnDemandBtn.classList.remove('topbar-setpoint--readonly');
    dhwOnDemandBtn.setAttribute('aria-disabled', 'false');
    initTooltip();
  } else {
    dhwOnDemandBtn.disabled = true;
    dhwOnDemandBtn.classList.add('disabled');
    dhwOnDemandBtn.classList.add('topbar-setpoint--readonly');
    dhwOnDemandBtn.setAttribute('aria-disabled', 'true');
    disposeTooltip();
  }
}

function updateDhwOnDemandButtonState() {
  if (!dhwOnDemandAvailable) return;
  const deltaOk = (lastTankTemp !== null && lastDhwSetTemp !== null)
    ? ((lastDhwSetTemp - lastTankTemp) >= DHW_ONDEMAND_MIN_DELTA)
    : true;
  const enabled = (!lastDhwOnDemandActive) && (!(lastAntiLegionellaActive || lastAntiLegionellaRunReq)) && deltaOk;
  setDhwOnDemandButtonEnabled(enabled);
}

// ---- DHW card notes (dashboard): show the most important active cycle ----
function updateDhwCwuNotes() {
  const elAnti = document.getElementById('dhw-antilegionella-note');
  const elHeaterAssist = document.getElementById('dhw-heaterassist-note');
  const elOnDemand = document.getElementById('dhw-ondemand-note');

  if (!elAnti && !elHeaterAssist && !elOnDemand) return;

  // Priority: Anti-legionella (red) > Heater-only DHW > DHW on-demand
  // Show anti-legionella note when cycle is active OR requested (so it appears right after navigation).
  if (lastAntiLegionellaActive || lastAntiLegionellaRunReq) {
    if (elAnti) elAnti.classList.remove('d-none');
    if (elHeaterAssist) elHeaterAssist.classList.add('d-none');
    if (elOnDemand) elOnDemand.classList.add('d-none');
    return;
  }
  if (lastDhwHeaterAssistActive) {
    if (elAnti) elAnti.classList.add('d-none');
    if (elHeaterAssist) elHeaterAssist.classList.remove('d-none');
    if (elOnDemand) elOnDemand.classList.add('d-none');
    return;
  }
  if (elAnti) elAnti.classList.add('d-none');
  if (elHeaterAssist) elHeaterAssist.classList.add('d-none');
  if (elOnDemand) {
    if (lastDhwOnDemandActive) elOnDemand.classList.remove('d-none');
    else elOnDemand.classList.add('d-none');
  }
}

// ---- Bootstrap notes state after navigation (e.g. cycle started on Settings, then user opens Dashboard) ----
function bootstrapDhwCycleNotes() {
  // Run only on pages that actually render DHW notes
  const elAnti = document.getElementById('dhw-antilegionella-note');
  const elHeaterAssist = document.getElementById('dhw-heaterassist-note');
  const elOnDemand = document.getElementById('dhw-ondemand-note');
  if (!elAnti && !elHeaterAssist && !elOnDemand) return;

  const boolish = (v) => {
    const low = String(v === undefined || v === null ? '' : v).trim().toLowerCase();
    return (low === 'on' || low === '1' || low === 'true' || low === 'yes');
  };

  try {
    fetch('/getdata', { cache: 'no-store' })
      .then(r => (r && r.ok) ? r.json() : null)
      .then(data => {
        if (!data) return;
        if (Object.prototype.hasOwnProperty.call(data, 'dhw_ondemand')) {
          lastDhwOnDemandActive = boolish(data.dhw_ondemand);
        }
        if (Object.prototype.hasOwnProperty.call(data, 'dhw_heater_assist_active')) {
          lastDhwHeaterAssistActive = boolish(data.dhw_heater_assist_active);
        }
        if (Object.prototype.hasOwnProperty.call(data, 'anti_legionella_run')) {
          lastAntiLegionellaRunReq = boolish(data.anti_legionella_run);
        }
        if (Object.prototype.hasOwnProperty.call(data, 'anti_legionella_active')) {
          lastAntiLegionellaActive = boolish(data.anti_legionella_active);
        }
        try { updateDhwCwuNotes(); } catch (e) {}
        try { updateDhwOnDemandButtonState(); } catch (e) {}
      })
      .catch(() => {});
  } catch (e) {}
}

try { updateDhwOnDemandButtonState(); } catch (e) {}
try { bootstrapDhwCycleNotes(); } catch (e) {}

// ---- Color helpers: Superheat/Subcooling health bands (HVAC-friendly defaults) ----
// NOTE: thresholds are practical for inverter monoblock + R32; you can tweak later.
/**
 * Thresholds (K) tuned for inverter monoblock R32 (practical/service ranges)
 * CO (CH):  SH <5 blue | 5-12 green | >12 red
 *           SC <3 blue | 3-10 green | >10 red
 * CWU (DHW): SH <6 blue | 6-15 green | >15 red
 *            SC <4 blue | 4-12 green | >12 red
 */
function hvacModeFromThreeway() {
  const tw = (lastThreeway !== null && lastThreeway !== undefined) ? String(lastThreeway).toUpperCase() : "";
  if (!tw) return null;
  // During defrost PyHaier reports ERR for the 3-way valve; do NOT treat that as CH.
  if (tw.includes("ERR")) return null;
  if (tw.includes("DHW") || tw.includes("CWU")) return "DHW";
  if (tw.includes("CH") || tw.includes("CO") || tw.includes("HEAT")) return "CH";
  return null;
}

function hvacRunning() {
  // Consider the refrigeration circuit "running" when compressor frequency (fact) > 0
  const hz = (typeof compinfo !== "undefined" && compinfo && compinfo.length) ? Number(compinfo[0]) : 0;
  return (Number.isFinite(hz) && hz > 0);
}

function shColorK_CH(v) {
  if (!Number.isFinite(v)) return "#999";
  if (v < 5) return "#1e90ff";      // blue
  if (v <= 12) return "#2e8b57";    // green
  return "#d32f2f";                 // red
}
function scColorK_CH(v) {
  if (!Number.isFinite(v)) return "#999";
  if (v < 3) return "#1e90ff";
  if (v <= 10) return "#2e8b57";
  return "#d32f2f";
}

function shColorK_DHW(v) {
  if (!Number.isFinite(v)) return "#999";
  if (v < 6) return "#1e90ff";
  if (v <= 15) return "#2e8b57";
  return "#d32f2f";
}
function scColorK_DHW(v) {
  if (!Number.isFinite(v)) return "#999";
  if (v < 4) return "#1e90ff";
  if (v <= 12) return "#2e8b57";
  return "#d32f2f";
}

function shColorK(v) {
  return (hvacModeFromThreeway() === "DHW") ? shColorK_DHW(v) : shColorK_CH(v);
}
function scColorK(v) {
  return (hvacModeFromThreeway() === "DHW") ? scColorK_DHW(v) : scColorK_CH(v);
}

function paintValue($el, color) {
  if (!$el || !$el.length) return;
  if (!color) {
    $el.css("color", "");
    $el.css("font-weight", "");
    return;
  }
  $el.css("color", color);
  $el.css("font-weight", "500");
}


function fmtAgeSimple(timeMin) {
  if (timeMin === null || timeMin === undefined) return "?";
  const m = Number(timeMin);
  if (!isFinite(m)) return "?";
  if (m < 60) return String(Math.round(m)) + " min";
  if (m < 24 * 60) return String(Math.max(1, Math.round(m / 60))) + " h";
  return String(Math.max(1, Math.round(m / (24 * 60)))) + " d";
}


// ---- i18n helper (i18next, safe fallback) ----
function t(key, fallback, opts) {
  try {
    if (window.i18next && typeof window.i18next.t === 'function') {
      const o = Object.assign({ defaultValue: fallback }, opts || {});
      return window.i18next.t(key, o);
    }
  } catch (e) {}
  return fallback;
}

// ---- UI helper: temperature status (fallback / stale) ----
let lastIntempStatus = "ok";
let lastIntempValue = null;

let lastOuttempStatus = "ok";
let lastIntempSrc = null;
let lastOuttempSrc = null;
let lastIntempTimeMin = null;
let lastOuttempTimeMin = null;

function applyTempStatusUI() {
  const iEl = $("#intemp");
  const oEl = $("#outtemp");

  function applyTo($el, status, src, timeMin, keyName) {
    if (!$el || !$el.length) return;

    // clear previous state
    $el.removeClass("temp-forced temp-outdated");

    const st = String(status || "ok").toLowerCase();
    const s = String(src || "").toLowerCase();

    if (st === "forced") $el.addClass("temp-forced");
    if (st === "outdated") $el.addClass("temp-outdated");

    // Special case: emergency inside temp shows "Awaria" and blinks (handled by CSS on temp-outdated)
    if (keyName === "intemp" && s === "emergency") {
      $el.addClass("temp-outdated");
    }

    // Tooltip: status + source + time (multiline)
    const showSrc = (() => {
      // Collapse local sensors into a single UI label
      if (s === "ds18b" || s === "dht22") return "builtin";
      if (s === "ha") return "ha";
      if (s === "tao") return "tao";
      if (s === "cache") return "cache";
      if (s === "missing") return "missing";
      if (s === "emergency") return "emergency";
      return src || "N.A";
    })();

    const readingLabel = t('temp.tooltip.reading', 'reading');
    const sourceLabel = t('temp.tooltip.source', 'source');
    const timeLabel = t('temp.tooltip.time', 'time');

    const statusLabel = t('temp.status.' + st, st);
    const sourceVal = t(String(showSrc), String(showSrc));
    const tlabel = fmtAgeSimple(timeMin);

    const tooltip = readingLabel + ': ' + statusLabel + "\n" +
                    sourceLabel + ': ' + sourceVal + "\n" +
                    timeLabel + ': ' + tlabel;
    $el.attr("title", tooltip);
  }

  applyTo(iEl, lastIntempStatus, lastIntempSrc, lastIntempTimeMin, "intemp");
  applyTo(oEl, lastOuttempStatus, lastOuttempSrc, lastOuttempTimeMin, "outtemp");
}

function renderIntemp(adds) {
  const el = $("#intemp");
  if (!el.length) return;

  const src = String(lastIntempSrc || "").toLowerCase();
  if (src === "emergency") {
    el.text(t('temp.emergency_value', 'Emergency'));
    const unit = $("#intemp_unit");
    if (unit.length) unit.hide();
    return;
  }

  const unit = $("#intemp_unit");
  if (unit.length) unit.show();

  // IMPORTANT: don't turn missing values (null/""/nan) into 0.0
  const raw = lastIntempValue;
  if (raw === null || raw === undefined) return;

  const s = String(raw).trim();
  if (s === "" || s.toLowerCase() === "nan" || s.toUpperCase() === "N.A") return;

  const v = Number(s);
  if (Number.isFinite(v)) {
    el.text(v.toFixed(1) + (adds ? " °C" : ""));
  } else {
    el.text(s);
  }
}


// Refresh translated labels on language change (tooltips / emergency label)
try {
  if (window.i18next && typeof window.i18next.on === 'function') {
    window.i18next.on('languageChanged', function () {
      applyTempStatusUI();
      renderIntemp(adds);
    });
  }
} catch (e) {}


// ---- UI helpers: active mode highlight (Quiet/Eco/Turbo) + frequency limit label ----
  function setActiveMode(mode) {
    const ids = ["quiet", "eco", "turbo"];
    const names = { quiet: "Quiet", eco: "Eco", turbo: "Turbo" };

    // Remove highlight classes
    ids.forEach(id => { const el = $("#"+id); if (el.length) el.removeClass("mode-active"); });
    ids.forEach(id => { const el = $("#"+id+"-label"); if (el.length) el.removeClass("mode-active"); });

    // Reset any old HTML (<b><u>...) back to plain text
    for (const [id, label] of Object.entries(names)) {
      const el = $("#"+id); if (el.length) el.text(label);
      const lab = $("#"+id+"-label"); if (lab.length) lab.text(label);
    }

    // Highlight active one
    if (ids.includes(String(mode))) {
      const el = $("#"+mode); if (el.length) el.addClass("mode-active");
      const lab = $("#"+mode+"-label"); if (lab.length) lab.addClass("mode-active");
    }
  }

  function setFreqLimitActive(on) {
    const lab = $("#flimiton-label");
    if (!lab.length) return;
    if (String(on) === "1") lab.addClass("mode-active");
    else lab.removeClass("mode-active");
  }

// ---- UI helper (dashboard): Δt visibility ----
// Backend already returns delta="N.A." when it shouldn't be shown (compressor off / DHW valve / defrost).
// Frontend rule: show Δt only when it's a finite number.
let lastThreeway = null;
let lastHeatDemand = "0";
let lastPch = "off";
let lastPdhw = "off";
let lastDefrost = "off";
let lastAntiOnOff = null;

// Hold last valid delta value so it doesn't "blink" between calculations / reconnects.
// NOTE: we still hide Δt when it is not meaningful (DHW/defrost/compressor off/AntiON-OFF off/TempZone).
let lastDeltaNumeric = null;
const _DELTA_LS_KEY = "haierpi_last_delta_v1";
const _DELTA_LS_MAX_AGE_MS = 24 * 60 * 60 * 1000; // 24h

function _storeCachedDelta(n) {
  try {
    localStorage.setItem(_DELTA_LS_KEY, JSON.stringify({ v: n, ts: Date.now() }));
  } catch (e) {}
}

function _loadCachedDelta() {
  try {
    const raw = localStorage.getItem(_DELTA_LS_KEY);
    if (!raw) return;
    const obj = JSON.parse(raw);
    if (!obj) return;
    const v = Number(obj.v);
    const ts = Number(obj.ts);
    if (!Number.isFinite(v)) return;
    if (Number.isFinite(ts) && (Date.now() - ts) > _DELTA_LS_MAX_AGE_MS) return;
    lastDeltaNumeric = v;
  } catch (e) {}
}

function _parseFiniteNumber(v) {
  if (v === null || v === undefined) return null;
  const s0 = String(v).trim();
  const s = s0.replace(',', '.');
  if (!s || s.toUpperCase() === "N.A" || s.toUpperCase() === "N.A." || s.toLowerCase() === "nan") return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

function _compHzMax() {
  try {
    if (typeof compinfo !== "undefined" && Array.isArray(compinfo)) {
      if (compinfo.length >= 2) {
        const a = _parseFiniteNumber(compinfo[0]) || 0;
        const b = _parseFiniteNumber(compinfo[1]) || 0;
        return Math.max(a, b);
      }
      if (compinfo.length === 1) {
        return _parseFiniteNumber(compinfo[0]) || 0;
      }
    }
  } catch (e) {}
  return 0;
}

function _deltaShouldBeVisible() {
  // When a temperature zone (Frost/Warm) is active, the Δt value is not shown.
  try {
    const z = String(window.__tempZone || 'normal').toLowerCase().trim();
    if (z === 'frost' || z === 'warm') return false;
  } catch (e) {}

  // Defrost hides delta
  try {
    if (String(lastDefrost || '').toLowerCase() === 'on') return false;
  } catch (e) {}

  // AntiON-OFF disabled => hide delta
  try {
    if (lastAntiOnOff !== null && String(lastAntiOnOff).trim() !== '1') return false;
  } catch (e) {}

  // DHW mode => hide delta (only if we actually know the 3-way position)
  try {
    if (lastThreeway !== null && lastThreeway !== undefined) {
      const tw = String(lastThreeway || '').toUpperCase();
      if (tw.includes('DHW') || tw.includes('CWU')) return false;
    }
  } catch (e) {}

  // Compressor off => hide delta (only if compinfo is known)
  try {
    if (typeof compinfo !== "undefined" && Array.isArray(compinfo) && compinfo.length > 0) {
      if (_compHzMax() <= 0) return false;
    }
  } catch (e) {}

  return true;
}

function updateDeltaVisibility() {
  const $delta = $("#delta");
  if (!$delta.length) return; // element exists only on main dashboard (Anti ON-OFF card)

  const $wrap = $("#aood-delta-wrap");
  if (!$wrap.length) return;

  // Hide when delta is not meaningful.
  if (!_deltaShouldBeVisible()) {
    $wrap.hide();
    return;
  }

  // Prime cache from current DOM value if we don't have one yet.
  const cur = _parseFiniteNumber($delta.text());
  if (cur !== null) lastDeltaNumeric = cur;

  // Show last valid delta until next valid calculation arrives.
  if (lastDeltaNumeric !== null) {
    $delta.text(Number(lastDeltaNumeric).toFixed(1));
    $wrap.show();
  } else {
    $wrap.hide();
  }
}

// Load cached delta early so a page refresh doesn't "lose" the value.
_loadCachedDelta();


// ---- UI helper: update fire icons (CH/DHW) dynamically based on lastThreeway + compressor Hz ----
function refreshFireIcons() {
  // If we don't know the three-way position yet, keep both idle
  const twRaw = (lastThreeway !== null && lastThreeway !== undefined) ? String(lastThreeway).toUpperCase() : "";
  if (!twRaw) {
    updateFireStatus("ch", "firestatus.idle");
    updateFireStatus("dhw", "firestatus.idle");
    return;
  }

  const running = hvacRunning();
  const mode = hvacModeFromThreeway(); // "CH" or "DHW" (or null on ERR/unknown)

  if (mode === "CH") {
    // Avoid "false blinking" during switchover / pump-down: require actual heat demand
    const demand = String(lastHeatDemand) === "1";
    const enabled = String(lastPch).toLowerCase() === "on";
    const heating = running && enabled && demand;

    updateFireStatus("ch",  heating ? "firestatus.heating" : "firestatus.idle");
    updateFireStatus("dhw", "firestatus.idle");
  } else if (mode === "DHW") {
    // For DHW we don't have a separate demand flag, so gate by DHW enable + compressor running
    const enabled = String(lastPdhw).toLowerCase() === "on";
    const heating = running && enabled;

    updateFireStatus("dhw", heating ? "firestatus.heating" : "firestatus.idle");
    updateFireStatus("ch",  "firestatus.idle");
  } else {
    updateFireStatus("ch",  "firestatus.idle");
    updateFireStatus("dhw", "firestatus.idle");
  }
}

// -------------------------------------------------------------------------------
socket.on('return', function(msg) {
                        console.log("RETURN")
                        console.log(msg)

		switch(Object.keys(msg)[0]) {
			case "curvecalc":
				appendAlert(msg.curvecalc, 'success');
				$("#hcurve").text(msg.curvecalc);
				$("#button-spinner").addClass("d-none");
				break;
			case "tempchange":
				appendAlert(msg.tempchange, msg.type);
				break;
			case "statechange":
                                if( msg.statechange == 'pch' || msg.statechange == 'pcool' || msg.statechange == 'off' ) {
                                $("#heat-loading-overlay")[0].classList.add("d-none")
                                } else if ( msg.statechange == 'pdhw' ) {
                $("#pdhw-loading-overlay")[0].classList.add("d-none")
                                }
		}
	});
if (path != '/settings') {
    socket.on('data_update', function(msg) {
		switch(Object.keys(msg)[0]) {
		case "restarted":
				if (msg.restarted == 1) {
					restartModal.hide()
					errorRestart.cancel()
					appendAlert("servicestart", "success")
					socket.emit("client", { 'restarted' : 0 })
				}
				break;
	    	case "twitwo":
    if (msg.twitwo && msg.twitwo.length >= 2) {
        const v1 = Number(msg.twitwo[0]);
        const v2 = Number(msg.twitwo[1]);

        $("#twi").text(
            Number.isFinite(v1) ? v1.toFixed(1) + (adds ? " °C" : "") : "N.A"
        );
        $("#two").text(
            Number.isFinite(v2) ? v2.toFixed(1) + (adds ? " °C" : "") : "N.A"
        );

        if (Number.isFinite(v1) && Number.isFinite(v2)) {
            $("#deltat").text((v2 - v1).toFixed(1) + (adds ? " °C" : ""));
        }
    }
    break;
			case "thitho":
				$("#thi").text((adds ? fmt1(msg.thitho[0]) : msg.thitho[0]) + (adds ? " °C" : ""))
        		$("#tho").text((adds ? fmt1(msg.thitho[1]) : msg.thitho[1]) + (adds ? " °C" : ""))
				break;
			case "pdps":
				$("#pdset").text((adds ? fmt1(msg.pdps[0]) : msg.pdps[0]) + (adds ? " bar" : ""))
				$("#pdact").text((adds ? fmt1(msg.pdps[1]) : msg.pdps[1]) + (adds ? " bar" : ""))
				$("#psset").text((adds ? fmt1(msg.pdps[2]) : msg.pdps[2]) + (adds ? " bar" : ""))
				$("#psact").text((adds ? fmt1(msg.pdps[3]) : msg.pdps[3]) + (adds ? " bar" : ""))
				break;
			case "tsatpd":
				$("#tsatpdset").text((adds ? fmt1(msg.tsatpd[0]) : msg.tsatpd[0]) + (adds ? " °C" : ""))
				$("#tsatpdact").text((adds ? fmt1(msg.tsatpd[1]) : msg.tsatpd[1]) + (adds ? " °C" : ""))
				break;
			case "tsatps":
				$("#tsatpsset").text((adds ? fmt1(msg.tsatps[0]) : msg.tsatps[0]) + (adds ? " °C" : ""))
				$("#tsatpsact").text((adds ? fmt1(msg.tsatps[1]) : msg.tsatps[1]) + (adds ? " °C" : ""))
				break;
			case "superheat":
				$("#superheat").text((adds ? fmt1(msg.superheat) : msg.superheat) + (adds ? " °C" : ""))
				if (hvacRunning()) { paintValue($("#superheat"), shColorK(Number(msg.superheat))); } else { paintValue($("#superheat"), null); }
				break;
			case "subcooling":
				$("#subcooling").text((adds ? fmt1(msg.subcooling) : msg.subcooling) + (adds ? " °C" : ""))
				if (hvacRunning()) { paintValue($("#subcooling"), scColorK(Number(msg.subcooling))); } else { paintValue($("#subcooling"), null); }
				break;
			case "firmware":
				{
				  const fw = msg.firmware;
				  if (fw === null || fw === undefined) $("#firmware").text("N.A");
				  else if (typeof fw === "number" && Number.isFinite(fw)) $("#firmware").text(fw.toFixed(1));
				  else $("#firmware").text(String(fw));
				}
				break;
			case "eevlevel":
				$("#eevlevel").text(msg.eevlevel+" °")
				break;
	    	case "compinfo":
				$("#fact").text(msg.compinfo[0] + (adds ? " Hz" : ""))
				$("#fset").text(msg.compinfo[1] + (adds ? " Hz" : ""))
				$("#ccurr").text(msg.compinfo[2] + (adds ? " A" : ""))
				$("#cvolt").text(msg.compinfo[3] + (adds ? " V" : ""))
				$("#ctemp").text((adds ? fmt1(msg.compinfo[4]) : msg.compinfo[4]) + (adds ? " °C" : ""))
				compinfo = msg.compinfo
				updateDeltaVisibility()
				refreshFireIcons();
				break;
			case "fans":
				$("#fan1").text(msg.fans[0] + (adds ? " rpm" : ""))
				$("#fan2").text(msg.fans[1] + (adds ? " rpm" : ""))
				break;
			case "tao":
				$("#tao").text((adds ? fmt1(msg.tao) : msg.tao) + (adds ? " °C" : ""))
				break;
			case "tdts":
				$("#td").text((adds ? fmt1(msg.tdts[0]) : msg.tdts[0]) + (adds ? " °C" : ""))
				$("#ts").text((adds ? fmt1(msg.tdts[1]) : msg.tdts[1]) + (adds ? " °C" : ""))
				break;
	    	case "pump":
				{
					const pRaw = (msg.pump !== undefined && msg.pump !== null) ? String(msg.pump) : "";
					const pLow = pRaw.toLowerCase();
					const pOn  = (pLow === "on"  || pRaw === "1" || pLow === "true");
					const pOff = (pLow === "off" || pRaw === "0" || pLow === "false");
					const pTxt = pOn ? "on" : (pOff ? "off" : pLow);
					const $p = $("#pump");
					if (adds) {
						// Parameters page: show raw value (no i18n)
						$p.text(pTxt);
						$p.removeAttr("data-i18n");
					} else {
						// Dashboard: always render translated text immediately; keep key for language switching
						$p.attr("data-i18n", pTxt);
						$p.text(t(pTxt, pTxt));
					}
				}
				break;
            case "threeway":
                // 3-way valve status (CH/DHW only)
                {
                    const twRaw = (msg.threeway !== undefined && msg.threeway !== null) ? String(msg.threeway) : "";
                    const twUp = twRaw.trim().toUpperCase();

                    // Only two meaningful states exist here: CH / DHW. When the unit is idle
                    // (pch/pcool OFF, compressor stopped) the value can be empty/ERR/N.A.*.
                    // In that case show a neutral "N.A" on UI (no lowercase "n.a" and no sticky last state).
                    let twKey = null; // 'ch' | 'dhw' | null
                    if (twUp.includes("DHW") || twUp.includes("CWU")) twKey = "dhw";
                    else if (twUp.includes("CH") || twUp.includes("CO") || twUp.includes("HEAT")) twKey = "ch";

                    const $tw = $("#threeway");
                    if (adds) {
                        // Parameters page: show raw-ish value without i18n
                        $tw.text(twKey ? twKey : "N.A");
                        $tw.removeAttr("data-i18n");
                    } else {
                        if (twKey) {
                            // Dashboard: translated label (CO/CWU)
                            $tw.attr("data-i18n", twKey);
                            $tw.text(t(twKey, twKey));
                        } else {
                            // Dashboard: do not translate N.A
                            $tw.removeAttr("data-i18n");
                            $tw.text("N.A");
                        }
                    }

                    // No DEFROST/ANTIFREEZE pulsing here anymore (they are separate statuses)
                    $tw.removeClass("defrost-pulse antifreeze-pulse");

                    // Keep lastThreeway for Δt + fire icons logic; clear it when unknown
                    lastThreeway = (twKey === "ch") ? "CH" : (twKey === "dhw" ? "DHW" : null);
                    updateDeltaVisibility();
                    refreshFireIcons();
                }
                break;
	    	case "heater":
				// Heater:
				// - Dashboard: label "Heater" pulses in burgundy when ON (span has class 'heater-indicator')
				// - Parameters: value cell shows On/Off (td does NOT have 'heater-indicator')
				const hRaw = (msg.heater !== undefined && msg.heater !== null) ? String(msg.heater) : "";
				const hOn = (hRaw.toLowerCase() === "on" || hRaw === "1" || hRaw.toLowerCase() === "true");
				const $h = $("#heater");
				if ($h && $h.length) {
					if ($h.hasClass("heater-indicator")) {
						// keep label text; only pulse when ON
						if (hOn) $h.addClass("heater-pulse");
						else $h.removeClass("heater-pulse");
					} else {
						// parameters table: force english lowercase in Parameters
							if (adds) {
								$h.text(hOn ? "on" : "off");
								$h.removeAttr("data-i18n");
							} else {
								const hTxt = (window.i18next && i18next.exists(hOn ? "on" : "off")) ? i18next.t(hOn ? "on" : "off") : (hOn ? "On" : "Off");
								$h.text(hTxt);
							}
					}
				}
				break;
			case "defrost":
                            lastDefrost = msg.defrost;
				// Defrost:
				// - Dashboard: label pulses in blue when ON (span has class 'defrost-indicator')
				// - Parameters: value cell shows On/Off
				const dRaw = (msg.defrost !== undefined && msg.defrost !== null) ? String(msg.defrost) : "";
				const dOn = (dRaw.toLowerCase() === "on" || dRaw === "1" || dRaw.toLowerCase() === "true");
				const $d = $("#defrost");
				if ($d && $d.length) {
					if ($d.hasClass("defrost-indicator")) {
						if (dOn) $d.addClass("defrost-pulse");
						else $d.removeClass("defrost-pulse");
					} else {
						if (adds) {
							$d.text(dOn ? "on" : "off");
							$d.removeAttr("data-i18n");
						} else {
							const dTxt = (window.i18next && i18next.exists(dOn ? "on" : "off")) ? i18next.t(dOn ? "on" : "off") : (dOn ? "On" : "Off");
							$d.text(dTxt);
						}
					}
				}
				updateDeltaVisibility();
                            break;

	    	
			case "antifreeze":
				// Antifreeze (builtin from pump):
				// - Dashboard: label pulses in pink when ON (span has class 'antifreeze-indicator')
				// - Parameters: value cell shows On/Off
				const afRaw = (msg.antifreeze !== undefined && msg.antifreeze !== null) ? String(msg.antifreeze) : "";
				const afOn = (afRaw.toLowerCase() === "on" || afRaw === "1" || afRaw.toLowerCase() === "true");
				window.__af_on = afOn;
				const $af = $("#antifreeze");
				if ($af && $af.length) {
					if ($af.hasClass("antifreeze-indicator")) {
						const combined = afOn || (window.__af_custom_on === true);
						if (combined) $af.addClass("antifreeze-pulse");
						else $af.removeClass("antifreeze-pulse");
					} else {
						if (adds) {
							$af.text(afOn ? "on" : "off");
							$af.removeAttr("data-i18n");
						} else {
							const afTxt = (window.i18next && i18next.exists(afOn ? "on" : "off")) ? i18next.t(afOn ? "on" : "off") : (afOn ? "On" : "Off");
							$af.text(afTxt);
						}
					}
				}
				break;

			case "antifreeze_custom":
				// Custom antifreeze (HaierPi logic): affects dashboard indicator (combined with builtin antifreeze)
				const afcRaw = (msg.antifreeze_custom !== undefined && msg.antifreeze_custom !== null) ? String(msg.antifreeze_custom) : "";
				const afcOn = (afcRaw.toLowerCase() === "on" || afcRaw === "1" || afcRaw.toLowerCase() === "true");
				window.__af_custom_on = afcOn;
				const $afc = $("#antifreeze");
				if ($afc && $afc.length && $afc.hasClass("antifreeze-indicator")) {
					const combined = (window.__af_on === true) || afcOn;
					if (combined) $afc.addClass("antifreeze-pulse");
					else $afc.removeClass("antifreeze-pulse");
				}
				break;
case "archerror":
							$("#archerror").text(msg.archerror)
							break;
			case "tdef":
				// Defrost temperature (tdef)
				$("#tdef").text((adds ? fmt1(msg.tdef) : msg.tdef) + (adds ? " °C" : ""));
				break;
			case "error":
				$("#error").text(msg.error);
				break;
			case "lasterror":
				$("#lasterror").text(msg.lasterror);
				break;
	    	case "dtquiet":
				$("#deltatempquiet").text(fmt1(msg.dtquiet));
				break;
		    case "dtturbo":
				$("#deltatempturbo").text(fmt1(msg.dtturbo));
			break;
		    case "dtflimit":
				$("#deltatempflimit").text(fmt1(msg.dtflimit));
				break;
	    	case "aoodt":
        		$("#antionoffdeltatime").text(fmt1(msg.aoodt));
				break;
	    	case "delta":
	                            {
	                              const n = _parseFiniteNumber(msg.delta);
	                              if (n !== null) {
	                                lastDeltaNumeric = n;
	                                _storeCachedDelta(n);
	                                $("#delta").text(n.toFixed(1));
	                              } else {
	                                // Don't overwrite a valid value with "N.A." between calculations.
	                                if (lastDeltaNumeric !== null) {
	                                  $("#delta").text(Number(lastDeltaNumeric).toFixed(1));
	                                } else {
	                                  $("#delta").text(msg.delta);
	                                }
	                              }
	                              updateDeltaVisibility();
	                            }
	                            break;
		    case "flimiton":
				$("#flimiton").text(msg.flimiton)
				$("#flimitchange").val(msg.flimiton)
				switch (msg.flimiton) {
					case "0":
						if (adds) {
							$("#flrelay").text("off");
							$("#flrelay").removeAttr("data-i18n");
						} else {
							$("#flrelay").attr("data-i18n", "off");
							$("#flrelay").text(t("off", "off"));
						}
				break;
					case "1":
						if (adds) {
							$("#flrelay").text("on");
							$("#flrelay").removeAttr("data-i18n");
						} else {
							$("#flrelay").attr("data-i18n", "on");
							$("#flrelay").text(t("on", "on"));
						}
					break;
				}
				setFreqLimitActive(msg.flimiton);
				break;
			case "flrelay": {
				// Actual relay state (CN23). During DHW Turbo override the backend may change
				// the relay without sending a separate flimiton update. Handle both.
				const v = String(msg.flrelay ?? '').trim();
				if (v === "0" || v === "1") {
					$("#flimitchange").val(v);
					setFreqLimitActive(v);
				}
				if (adds) {
					if (v === "0") $("#flrelay").text("off");
					else if (v === "1") $("#flrelay").text("on");
					else $("#flrelay").text(v || "N.A");
					$("#flrelay").removeAttr("data-i18n");
				} else {
					if (v === "0") {
						$("#flrelay").attr("data-i18n", "off");
						$("#flrelay").text(t("off", "off"));
					} else if (v === "1") {
						$("#flrelay").attr("data-i18n", "on");
						$("#flrelay").text(t("on", "on"));
					} else {
						$("#flrelay").removeAttr("data-i18n");
						$("#flrelay").text(v || "N.A");
					}
				}
				break;
			}
		    case "tank":
				if (dhwUiDisabled()) break;
				lastTankTemp = parseMaybeNumber(msg.tank);
				$("#ttemp").text(fmt1(msg.tank) + (adds ? " °C" : ""));
				try { updateDhwOnDemandButtonState(); } catch (e) {}
				break;
		    case "hcurve": {
  const raw = msg.hcurve;
  const num = Number(raw);
  if (Number.isFinite(num)) {
    $("#hcurve").text(num.toFixed(1) + (adds ? " °C" : "°C"));
  } else {
    // keep backend state like "N.A", "ERR", etc.
    $("#hcurve").text((raw === undefined || raw === null || raw === "" || String(raw).toLowerCase() === "nan") ? "N.A" : String(raw));
  }
  break;
}

		    case "dhw":
				if (dhwUiDisabled()) break;
				const unit = adds ? " °C" : "°C";
				const rawDhw = (msg.dhw === undefined || msg.dhw === null) ? "N.A" : String(msg.dhw);
				const dhwVal = Number(rawDhw);
				const hasUnit = /\u00B0\s*C/i.test(rawDhw);
				if (Number.isFinite(dhwVal)) {
					$("#dhwsetpoint").text(dhwVal.toFixed(1) + unit);
					if (!adds) {
						dhwsetpoint = dhwVal;
						$("#dhwtempval").val(dhwVal.toFixed(1));
					}
				} else {
					// Keep backend state like "N.A", "ERR" etc.; only append unit if not already present
					$("#dhwsetpoint").text(hasUnit ? rawDhw : (rawDhw + unit));
					if (!adds) {
						dhwsetpoint = rawDhw;
						$("#dhwtempval").val(rawDhw);
					}
				}
				lastDhwSetTemp = Number.isFinite(dhwVal) ? dhwVal : parseMaybeNumber(rawDhw);
				try { updateDhwOnDemandButtonState(); } catch (e) {}
				break;
		    
		    case "dhw_ondemand":
				// DHW on-demand cycle indicator (dashboard) + block trigger while active
				{
					const raw = (msg.dhw_ondemand !== undefined && msg.dhw_ondemand !== null) ? String(msg.dhw_ondemand) : '';
					const low = raw.trim().toLowerCase();
					const on = (low === 'on' || low === '1' || low === 'true' || low === 'yes');
					lastDhwOnDemandActive = on;
					try { updateDhwCwuNotes(); } catch (e) {}
					try { updateDhwOnDemandButtonState(); } catch (e) {}
				}
				break;
			case "dhw_heater_assist_active":
				{
					const raw = (msg.dhw_heater_assist_active !== undefined && msg.dhw_heater_assist_active !== null) ? String(msg.dhw_heater_assist_active) : '';
					const low = raw.trim().toLowerCase();
					const on = (low === 'on' || low === '1' || low === 'true' || low === 'yes');
					lastDhwHeaterAssistActive = on;
					try { updateDhwCwuNotes(); } catch (e) {}
					try { updateDhwOnDemandButtonState(); } catch (e) {}
				}
				break;
			case "anti_legionella_run":
				// Anti-legionella run request (show note even if active flag hasn't arrived yet)
				{
					const raw = (msg.anti_legionella_run !== undefined && msg.anti_legionella_run !== null) ? String(msg.anti_legionella_run) : '';
					const low = raw.trim().toLowerCase();
					const on = (low === 'on' || low === '1' || low === 'true' || low === 'yes');
					lastAntiLegionellaRunReq = on;
					try { updateDhwCwuNotes(); } catch (e) {}
					try { updateDhwOnDemandButtonState(); } catch (e) {}
				}
				break;
			case "anti_legionella_active":
				{
					const raw = (msg.anti_legionella_active !== undefined && msg.anti_legionella_active !== null) ? String(msg.anti_legionella_active) : '';
					const low = raw.trim().toLowerCase();
					const on = (low === 'on' || low === '1' || low === 'true' || low === 'yes');
					lastAntiLegionellaActive = on;
					try { updateDhwCwuNotes(); } catch (e) {}
					try { updateDhwOnDemandButtonState(); } catch (e) {}
				}
				break;
case "setpoint":
				$("#setpoint").text(fmt1(msg.setpoint) + (adds ? " °C" : ""));
				if (!adds) {
					$("#intempval").val(fmt1(msg.setpoint))
					temp = msg.setpoint
				}
				break;
			// Alias for the same value: backend frequently emits "settemp" (config setpoint)
			// while the dashboard UI listens on "setpoint".
			// Handling both fixes missing live updates for CO setpoint.
			case "settemp":
				$("#setpoint").text(fmt1(msg.settemp) + (adds ? " °C" : ""));
				if (!adds) {
					$("#intempval").val(fmt1(msg.settemp))
					temp = msg.settemp
				}
				break;
	    	case "intemp":
				lastIntempValue = msg.intemp;
				renderIntemp(adds);
				break;
	    	case "intemp_status":
	    			lastIntempStatus = msg.intemp_status;
	    			renderIntemp(adds);
					applyTempStatusUI();
	    			break;
case "intempsrc":
	    			lastIntempSrc = msg.intempsrc;
	    			applyTempStatusUI();
	    			break;
			case "intemptime":
				lastIntempTimeMin = msg.intemptime;
				applyTempStatusUI();
				break;
case "outtemp":
				$("#outtemp").text(fmt1(msg.outtemp));
				break;
			case "tempzone":
				window.__tempZone = String(msg.tempzone || msg.temp_zone || msg.zone || 'normal').toLowerCase();
				updateDeltaVisibility();
				break;
	    	case "outtemp_status":
	    			lastOuttempStatus = msg.outtemp_status;
	    			applyTempStatusUI();
	    			break;
case "outtempsrc":
	    			lastOuttempSrc = msg.outtempsrc;
	    			applyTempStatusUI();
	    			break;
			case "outtemptime":
				lastOuttempTimeMin = msg.outtemptime;
				applyTempStatusUI();
				break;
case "humid":
				{
					const h = Number(msg.humid);
					const ok = Number.isFinite(h);
					// /parameters: <td id="humid">...</td> (bez % w HTML)
					// index: <span id="humid">...</span> %  oraz <span id="humid_ch">...</span> %
					const txt = ok ? h.toFixed(1) : "N.A";
					if (adds) {
						$("#humid").text(ok ? (txt + " %") : "N.A");
					} else {
						$("#humid").text(txt);
						// Heating card humidity
						$("#humid_ch").text(txt);
					}
				}
				break;
		    case "ltemp":
				$("#ltemp").text(msg.ltemp)
				break;
	    	case "antionoff":
                            lastAntiOnOff = msg.antionoff;
				if(msg.antionoff == "1") {
				    $("#presetdiv").hide();
				    $("#antionoffdiv").show();
				}
				updateDeltaVisibility();
                            break;
	    	case "mode":
				$("#presetchange").val(msg.mode)
				$("#mode").text(msg.mode)
								setActiveMode(msg.mode);

				break;
		    case "presetquiet":
				$("#presetquiet").text(msg.presetquiet);
				break;
	    	case "presetturbo":
				$("#presetturbo").text(msg.presetturbo);
				break;
	    	case "presetch":
				if(msg.presetch == "manual") {
				    $("#presetchange").show()
				    $("#preset").text(" Auto")
				} else if ( msg.presetch == "auto") {
				    $("#presetauto").show();
				    $("#preset").text("Manual")
				}
				break;
			case "flimit":
			case "fflimit":
				{
					// Frequency limit mode (manual/auto). Backend sends "flimit"; keep "fflimit" for backward compatibility.
					const v = String((msg.flimit !== undefined) ? msg.flimit : msg.fflimit || '').toLowerCase();
					if (v === "manual") {
						$("#flimit").text("Manual");
						$("#flimitchange").show();
						$("#flimitauto").hide();
					} else if (v === "auto") {
						$("#flimitauto").show();
						$("#flimitchange").hide();
						$("#flimit").text("Auto");
					} else if (v) {
						// Unknown value – show as-is
						$("#flimit").text(String((msg.flimit !== undefined) ? msg.flimit : msg.fflimit));
					}
					break;
				}
		    case "heatcontrol":
		    	{
		    		const v = String(msg.heatcontrol ?? '').toLowerCase().trim();
		    		window.__heatcontrol = v;
		    		try { updateChSettempModeIcon(); } catch (e) {}
		    		// Keep compatibility with legacy "heatingcurve" flag used by UI logic.
		    		if (v === "direct") {
		    			window.__heatingCurve = "directly";
		    			minch = 25;
		    			maxch = 55;
		    			window.__heatStep = 0.5;
		    			window.__heatMin  = 25;
		    			window.__heatMax  = 55;
		    		} else if (v === "curve") {
		    			window.__heatingCurve = String(window.__heatingCurveMode ?? window.__heatingCurve ?? "auto").toLowerCase().trim();
		    			minch = 12;
		    			maxch = 30;
		    			window.__heatStep = 0.1;
		    			window.__heatMin  = 12;
		    			window.__heatMax  = 30;
		    		}
		    	}
		    	break;
		    case "heatingcurve_mode":
		    	{
		    		const m = String(msg.heatingcurve_mode ?? '').toLowerCase().trim();
		    		window.__heatingCurveMode = m;
		    		// If we're in curve mode, let __heatingCurve track the actual curve mode (auto/manual/static)
		    		const ctrl = String(window.__heatcontrol ?? '').toLowerCase().trim();
		    		if (ctrl === "curve" && (m === "auto" || m === "manual" || m === "static")) {
		    			window.__heatingCurve = m;
		    		}
		    	}
		    	break;
		    case "heatingcurve":
				window.__heatingCurve = String(msg.heatingcurve ?? '').toLowerCase().trim();
				try { updateChSettempModeIcon(); } catch (e) {}
				if(msg.heatingcurve == "directly" ) {
		    		minch=25
				    maxch=55
				    window.__heatStep = 0.5;
				    window.__heatMin  = 25;
				    window.__heatMax  = 55;
				} else {
				    minch=12
				    maxch=30
				    window.__heatStep = 0.1;
				    window.__heatMin  = 12;
				    window.__heatMax  = 30;
				}
				break;
	  	}
	

if (msg.threeway !== undefined && msg.threeway !== null) {
	const _tw = String(msg.threeway).trim().toUpperCase();
	if (_tw === "CH" || _tw === "DHW") lastThreeway = _tw;
}
if (msg.heatdemand !== undefined && msg.heatdemand !== null) { lastHeatDemand = String(msg.heatdemand); }
if (msg.pch !== undefined && msg.pch !== null) { lastPch = String(msg.pch).toLowerCase(); }
if (msg.pdhw !== undefined && msg.pdhw !== null) { lastPdhw = String(msg.pdhw).toLowerCase(); }
updateDeltaVisibility();

refreshFireIcons();
switch(msg.pch) {
        	case "on":
				if (!adds) {
					if ($("#firestatus")[0].classList.contains("bi-snow") == true ) {
						toggleCSSclasses($("#firestatus")[0], "bi-fire", "bi-snow")
						$("#powerheat").val("pch");
							if ($("#ch-settemp-mode-icon").length) {
								if ($("#ch-settemp-mode-icon")[0].classList.contains("bi-snow") == true ) {
									toggleCSSclasses($("#ch-settemp-mode-icon")[0], "bi-fire", "bi-snow")
								} else if ($("#ch-settemp-mode-icon")[0].classList.contains("bi-fire") == false) {
									$("#ch-settemp-mode-icon")[0].classList.add("bi-fire");
								}
							}

						$("#water-decrement-button").removeAttr('disabled');
						$("#water-increment-button").removeAttr('disabled');
					} else if ($("#firestatus")[0].classList.contains("bi-fire") == false) {
						$("#firestatus")[0].classList.add("bi-fire");
						$("#powerheat").val("pch");
							if ($("#ch-settemp-mode-icon").length) {
								if ($("#ch-settemp-mode-icon")[0].classList.contains("bi-snow") == true ) {
									toggleCSSclasses($("#ch-settemp-mode-icon")[0], "bi-fire", "bi-snow")
								} else if ($("#ch-settemp-mode-icon")[0].classList.contains("bi-fire") == false) {
									$("#ch-settemp-mode-icon")[0].classList.add("bi-fire");
								}
							}

						$("#water-decrement-button").removeAttr('disabled');
						$("#water-increment-button").removeAttr('disabled');
					}
				}
                break;
            case "off":
				//console.log(adds)
				if (!adds) {
					//console.log("no adds")
					if ($("#firestatus")[0].classList.contains("bi-fire") == true ) {
						$("#firestatus")[0].classList.remove("bi-fire");
					}
					if ($("#ch-settemp-mode-icon").length) {
								$("#ch-settemp-mode-icon")[0].classList.remove("bi-fire");
								$("#ch-settemp-mode-icon")[0].classList.remove("bi-snow");
							}
							$("#powerheat").val("off");
					$("#water-decrement-button").attr('disabled','disabled');
					$("#water-increment-button").attr('disabled','disabled');
				}
                break;
            default:
        }
        switch(msg.pcool) {
        	case "on":
				if (!adds) {
					if ($("#firestatus")[0].classList.contains("bi-fire") == true ) {
						toggleCSSclasses($("#firestatus")[0], "bi-fire", "bi-snow")
						$("#powerheat").val("pcool");
							if ($("#ch-settemp-mode-icon").length) {
								if ($("#ch-settemp-mode-icon")[0].classList.contains("bi-fire") == true ) {
									toggleCSSclasses($("#ch-settemp-mode-icon")[0], "bi-fire", "bi-snow")
								} else if ($("#ch-settemp-mode-icon")[0].classList.contains("bi-snow") == false) {
									$("#ch-settemp-mode-icon")[0].classList.add("bi-snow");
								}
							}

						$("#water-decrement-button").removeAttr('disabled');
						$("#water-increment-button").removeAttr('disabled');
					} else if ($("#firestatus")[0].classList.contains("bi-fire") == false) {
						$("#firestatus")[0].classList.add("bi-snow");
						$("#powerheat").val("pcool");
							if ($("#ch-settemp-mode-icon").length) {
								if ($("#ch-settemp-mode-icon")[0].classList.contains("bi-fire") == true ) {
									toggleCSSclasses($("#ch-settemp-mode-icon")[0], "bi-fire", "bi-snow")
								} else if ($("#ch-settemp-mode-icon")[0].classList.contains("bi-snow") == false) {
									$("#ch-settemp-mode-icon")[0].classList.add("bi-snow");
								}
							}

						$("#water-decrement-button").removeAttr('disabled');
						$("#water-increment-button").removeAttr('disabled');
					}
				}
            	break;
            case "off":
				if (!adds) {
					if ($("#firestatus")[0].classList.contains("bi-snow") == true ) {
						$("#firestatus")[0].classList.remove("bi-snow");
						if ($("#ch-settemp-mode-icon").length) {
							$("#ch-settemp-mode-icon")[0].classList.remove("bi-fire");
							$("#ch-settemp-mode-icon")[0].classList.remove("bi-snow");
						}
						$("#powerheat").val("off");
						$("#water-decrement-button").attr('disabled','disabled');
						$("#water-increment-button").attr('disabled','disabled');
					}
				}
                break;
            default:
        }
		// Ensure CH setpoint icon matches the active control mode (DIRECT vs CURVE)
		try { updateChSettempModeIcon(); } catch (e) {}
        switch(msg.pdhw) {
        	case "on":
						if (dhwUiDisabled()) break;
				if (!adds) {
					if ($("#dhwstatus")[0].classList.contains("bi-droplet-fill") == false ) {
						toggleCSSclasses($("#dhwstatus")[0], "bi-droplet-fill", "bi-power")
						$("#powerdhw").val("on");
						$("#dhw-decrement-button").removeAttr('disabled');
						$("#dhw-increment-button").removeAttr('disabled');
					}
				}
                break;
            case "off":
						if (dhwUiDisabled()) break;
				if (!adds) {
					if ($("#dhwstatus")[0].classList.contains("bi-droplet-fill") == true ) {
						toggleCSSclasses($("#dhwstatus")[0], "bi-droplet-fill", "bi-power")
						$("#powerdhw").val("off");
						$("#dhw-decrement-button").attr('disabled','disabled');
						$("#dhw-increment-button").attr('disabled','disabled');
					} else {
						$("#powerdhw").val("off");
						$("#dhw-decrement-button").attr('disabled','disabled');
						$("#dhw-increment-button").attr('disabled','disabled');
					}
				}
                break;
            default:
        }
	  //console.log(msg)
    });
} else {
	//console.log("settings");
	//console.log(socket);
setTimeout(() => {
  console.log(socket);
}, 3000);
}
});